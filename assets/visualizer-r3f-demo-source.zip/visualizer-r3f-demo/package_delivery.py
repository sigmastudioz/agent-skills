"""Allowlisted editable delivery; excludes caches, private records, raw tests and old attempts."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
files={}
def add(path,archive):
 path=Path(path)
 if path.is_symlink() or not path.is_file():raise ValueError(f'Not a regular source file: {path}')
 files[str(archive)]=path
for name in ['README.md','LICENSE','THIRD_PARTY_NOTICES.md','brief.md','gap-trace.md','skill-learnings.md','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','verify_delivery.py','package_delivery.py','audio-report.json','server-checks.json','validation.json']:
 add(ROOT/name,name)
for p in (ROOT/'src').rglob('*'):
 if p.is_file() and p.suffix in ('.ts','.tsx','.py','.css','.json') and '__pycache__' not in p.parts:add(p,p.relative_to(ROOT))
for p in (ROOT/'licenses').rglob('*'):
 if p.is_file():add(p,p.relative_to(ROOT))
for name in ['watch.html','poster.png','captions.srt','captions.vtt','audio/visualizer.wav','audio/envelope.json','exports/visualizer-r3f.mp4','exports/visualizer-r3f-render.json']:
 add(ROOT/'public'/name,Path('public')/name)
# First-party reusable dependencies remain one authoritative source in the task workspace.
canonical=ROOT.parent/'visual-demos/source'
if not canonical.exists():canonical=ROOT/'engine'
for name in ['server.py','shared/media_server.py','shared/audio_synthesis.py']:add(canonical/name,Path('engine')/name)
# The standalone compiled preview has only the final film and required local runtime assets.
for p in (ROOT/'dist').rglob('*'):
 if p.is_file() and p.suffix!='.zip' and 'history' not in p.parts and p.name not in ('raw.wav','music-stem.wav','effects-stem.wav','smoke.mp4','smoke-render.json','smoke-encoder.log') and not p.name.endswith('.log'):
  add(p,p.relative_to(ROOT))
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in sorted(files.items())}
(ROOT/'delivery-manifest.json').write_text(json.dumps({'author':'Lex from SigmaStudioz','files':manifest},indent=2)+'\n')
add(ROOT/'delivery-manifest.json','delivery-manifest.json')
target=ROOT/'public/visualizer-r3f-source.zip';staging=target.with_suffix('.part.zip')
with zipfile.ZipFile(staging,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for name,path in sorted(files.items()):z.write(path,Path('visualizer-r3f-demo')/name)
with zipfile.ZipFile(staging) as z:
 assert z.testzip() is None
 for name,digest in manifest.items():assert hashlib.sha256(z.read('visualizer-r3f-demo/'+name)).hexdigest()==digest
staging.replace(target)
print('Verified',len(files),'self-contained delivery files;',target.stat().st_size,'bytes')
