# Third-party notices

Original film, geometry, GLSL, layout, score and first-party code: Lex from SigmaStudioz, MIT.
The shared capture server, HTTP range handler and synthesis functions are unchanged snapshots
of the task's previously authored first-party helpers, distributed once in the portable bundle.

Direct runtime: React 19.3.1 / React DOM 19.3.1 (MIT); React Three Fiber 9.8.2 (MIT);
Drei 10.7.9 (MIT); Three.js 0.186.1 (MIT). The complete transitive inventory is package-lock.json.
Build/validation tools and their licenses remain in npm package metadata and retained license texts.
Manrope Variable 5.3.0 is SIL Open Font License 1.1. The font is locally bundled; no paid service.
NumPy is BSD-3-Clause. Pillow uses HPND; FFmpeg and the installed codec build have their own terms.
No FFmpeg executable or Python package binary is redistributed. npm dependencies install only when
an end user deliberately runs the documented setup command.

pmndrs examples supplied visual inspiration only. Their models, art, audio and source code are not
redistributed. No ownership of the pmndrs examples is implied.
