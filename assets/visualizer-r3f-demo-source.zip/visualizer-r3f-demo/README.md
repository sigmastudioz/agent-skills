# SigmaStudioz Visualizer — data city and explainer controls

By **Lex from SigmaStudioz**. Original 36-second 1080p60 React Three Fiber film and interactive
scene, re-cut on 2026-11-13 to show the two recipes added in Visualizer 1.4.5. The first cut
(a material study with an illustrative queue, 2026-10-19) is in the repository history of
`assets/visualizer-r3f-demo.mp4`; it is not in this bundle.

## Watch and explore

- Open `public/watch.html` beside the delivered `public/exports/` folder for the ordinary film.
- Run the source preview below for live shader/scene controls and the local render workflow.
- `public/exports/visualizer-r3f.mp4`: H.264,60fps, stereo AAC.
- `public/captions.srt` / `captions.vtt`: timed scene summaries, not speech transcripts (`python3 src/captions.py`).
- `src/timeline.json`: one scene and sound-event clock.
- `validation.json`, `audio-report.json`, `gap-trace.md`: actual evidence and remaining limits.

Two scenes carry the film. **Data city** (5.4–15 s): 37 towers from a seeded synthetic sample of
repositories in five teams; height is commits, linear from zero, and shade is open issues. Two
records are rejected (a duplicate id and a negative value), a zero and a no-data record stay
distinct, the tallest tower is selected to read its exact values, and a plan view removes height.
The camera dollies back and narrows its lens together so equal heights read equal. **Explainer
controls** (15–29.4 s): a vane pump with a cutaway (C), three named camera shots (1, 2, 3), notes
pinned to parts, and a rewind to the current beat (B) that takes the pump's own clock from 10 s back
to 8 s. Every moving part is a function of scene time. The key presses in the film are authored
events on the timeline, not a recorded session; the same keys work in the live preview. The data
is synthetic, not production telemetry. Baked cues in the MP4 are linear; the preview's control
sounds are interactive.

## Reproduce

Requires Node 20.19+ or 22.12+, Python 3.11+, NumPy, FFmpeg with libx264/AAC, and a WebGL2-capable browser.
The export verifier additionally uses Pillow. Use isolated environments; no global installs or account setup.
Versions are recorded in the package lock and delivery manifest.

```sh
npm ci
python3 -m venv .venv
.venv/bin/pip install numpy Pillow
.venv/bin/python src/soundtrack.py
npm run typecheck
node --import tsx src/model-check.ts
```

In two terminals, from this project folder:

```sh
.venv/bin/python src/serve.py
```

```sh
npm run dev
```

Open `http://127.0.0.1:8776/`. Sound starts only after user input. Use the chapter buttons,
the time range, Cutaway (C), the shot buttons (1, 2, 3), Notes (A), rewind to the scene start (B),
Reset (R), selection, mute/volume, reduced motion and effects controls. Hotkeys do not fire
while a field has focus. The preview
uses an explicit manual frame loop; animation pauses when hidden. Rendering intentionally samples
the authored scenario, then restores interactive overrides. All text is composited into captured pixels.

Under Render controls, render a short study first, then the 1080p60 film. The adapter sends bounded
2-frame RGBA batches to the existing owned loopback encoder on 8777. It accepts only Origin 8776,
validates frame order/size/count and promotes a staged file only after complete decode. It rejects
existing output, preserving completed films. Move a deliberate earlier attempt into a history folder
before rendering a revised candidate. Do not delete the source or pretend a partial capture succeeded.

The portable ZIP includes the unchanged shared encoder/synthesis dependencies under `engine/`.
In the task workspace these are reused from the existing `visual-demos/source` owner; there is no
second authoritative encoder implementation. Audio envelope output is measured RMS, not FFT.

After export:

```sh
.venv/bin/python verify_delivery.py
npm run build
```

Serve `dist/` over HTTP for the compiled interactive preview. Its dependencies and font assets
are local. The simple `public/watch.html` also works beside the media without the React tooling.
Do not build before the export if you expect the compiled film player to contain that export.

## Art, sound and rights

Inspiration for the opening and closing material study: [pmndrs examples](https://pmndrs.github.io/examples/), particularly Aquarium,
Room With Soft Shadows, Shader Materials and Bezier Curves And Nodes. The inspiration is
containment, material separation, purposeful lighting and readable flow; no example artwork,
models, textures, audio or code were copied. Original geometry, layout, GLSL, timing, music and
effects are by Lex from SigmaStudioz. No reference voice or footage is used.

React, React DOM, R3F, Drei, Three.js and build tools retain their own licenses. Manrope is
self-hosted under SIL Open Font License 1.1. See `THIRD_PARTY_NOTICES.md` and retained license texts.
Original first-party sources use the included MIT license.

## Verification limits

This is an authored film and focused renderer integration, not a fresh-agent efficacy run.
Deterministic offline 60fps output is distinct from realtime performance on a particular device.
Encoded loudness, peaks, frame counts, decode and stereo behavior are measured separately from
subjective listening; the agent did not perform a listening review. Native marketplaces remain
separate from this local creative artifact. Publishing this candidate requires the normal existing
repository workflow; no social posting or new marketplace submission is part of the render.
