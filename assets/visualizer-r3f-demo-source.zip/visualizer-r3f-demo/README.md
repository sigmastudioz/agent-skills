# SigmaStudioz Visualizer — a material study

By **Lex from SigmaStudioz**. Original 36-second 1080p60 React Three Fiber film and interactive
scene. The earlier public Visualizer demo remains intact; this is its new review candidate.

## Watch and explore

- Open `public/watch.html` beside the delivered `public/exports/` folder for the ordinary film.
- Run the source preview below for live shader/scene controls and the local render workflow.
- `public/exports/visualizer-r3f.mp4`: H.264,60fps, stereo AAC.
- `public/captions.srt` / `captions.vtt`: timed scene summaries, not speech transcripts.
- `src/timeline.json`: one scene and sound-event clock.
- `validation.json`, `audio-report.json`, `gap-trace.md`: actual evidence and remaining limits.

The geometric system uses a deterministic illustrative fluid queue. Arrivals are 2 items/s, then
5 from 13 to 16 seconds, against service 3/s. Six items accumulate, then clear by 19 seconds as arrivals
fall to 1/s. Live manual controls show a separate labeled 3-second scenario. These are illustrative
values, not production telemetry. Two film views sample the same state; differing lighting does
not imply pixel identity. Baked cues in the MP4 are linear; the preview's control sounds are interactive.

## Reproduce

Requires Node 20.19+ or 22.12+, Python 3.11+, NumPy, FFmpeg with libx264/AAC, and a WebGL2-capable browser.
The export verifier additionally uses Pillow. Use isolated environments; no global installs or account setup.
Versions are recorded in the package lock and delivery manifest.

```sh
npm ci
python3 -m venv .venv
.venv/bin/pip install numpy Pillow
.venv/bin/python src/soundtrack.py
npm run typecheck
node --import tsx src/model-check.ts
```

In two terminals, from this project folder:

```sh
.venv/bin/python src/serve.py
```

```sh
npm run dev
```

Open `http://127.0.0.1:8776/`. Sound starts only after user input. Use the chapter buttons,
keyboard range controls, selection, mute/volume, reduced motion and effects controls. The preview
uses an explicit manual frame loop; animation pauses when hidden. Rendering intentionally samples
the authored scenario, then restores interactive overrides. All text is composited into captured pixels.

Under Render controls, render a short study first, then the 1080p60 film. The adapter sends bounded
2-frame RGBA batches to the existing owned loopback encoder on 8777. It accepts only Origin 8776,
validates frame order/size/count and promotes a staged file only after complete decode. It rejects
existing output, preserving completed films. Move a deliberate earlier attempt into a history folder
before rendering a revised candidate. Do not delete the source or pretend a partial capture succeeded.

The portable ZIP includes the unchanged shared encoder/synthesis dependencies under `engine/`.
In the task workspace these are reused from the existing `visual-demos/source` owner; there is no
second authoritative encoder implementation. Audio envelope output is measured RMS, not FFT.

After export:

```sh
.venv/bin/python verify_delivery.py
npm run build
```

Serve `dist/` over HTTP for the compiled interactive preview. Its dependencies and font assets
are local. The simple `public/watch.html` also works beside the media without the React tooling.
Do not build before the export if you expect the compiled film player to contain that export.

## Art, sound and rights

Inspiration: [pmndrs examples](https://pmndrs.github.io/examples/), particularly Aquarium,
Room With Soft Shadows, Shader Materials and Bezier Curves And Nodes. The inspiration is
containment, material separation, purposeful lighting and readable flow; no example artwork,
models, textures, audio or code were copied. Original geometry, layout, GLSL, timing, music and
effects are by Lex from SigmaStudioz. No reference voice or footage is used.

React, React DOM, R3F, Drei, Three.js and build tools retain their own licenses. Manrope is
self-hosted under SIL Open Font License 1.1. See `THIRD_PARTY_NOTICES.md` and retained license texts.
Original first-party sources use the included MIT license.

## Verification limits

This is an authored film and focused renderer integration, not a fresh-agent efficacy run.
Deterministic offline 60fps output is distinct from realtime performance on a particular device.
Encoded loudness, peaks, frame counts, decode and stereo behavior are measured separately from
subjective listening; the agent did not perform a listening review. Native marketplaces remain
separate from this local creative artifact. Publishing this candidate requires the normal existing
repository workflow; no social posting or new marketplace submission is part of the render.
