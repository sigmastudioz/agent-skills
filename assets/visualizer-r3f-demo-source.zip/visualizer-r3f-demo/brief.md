# Visualizer / material study

Author: Lex from SigmaStudioz. Deliver a36-second1920×1080/60fps film, an interactive
React Three Fiber preview, captions, poster and reproducible sources. Preserve the old demo.
No marketing claim of agent efficacy, measured production throughput or universal realtime FPS.

Direction: a dark editorial studio, thick glass, brushed alloy, teal ceramic, warm copper,
soft area reflections and original procedural surfaces. A single sculptural system opens into
nodes, shows a truthful fluid queue, becomes a material study and resolves into synchronized views.
Objects retain identity; quintic transitions and absolute-time sampling permit arbitrary seeks.

Inspiration: pmndrs Aquarium (containment/refraction), Room With Soft Shadows (grounding and
light separation), Shader Materials (surface character), Bezier Curves And Nodes (meaningful flow).
Those examples were visually inspected during this chat. New geometry, layout, shader functions,
score and effects are original; no gallery textures, models, audio, fonts or art are copied.
Official Drei transmission/environment/Lightformer APIs checked for this implementation.

Audio: original composed harmony, evolving arpeggios, shaped bass, brushed percussion,
glass resonances, restrained stereo movement and event-specific transitions. A measured normalized
WAV RMS envelope drives bounded shader motion. No voiceover or cloned voice. Captions are scene summaries.

Acceptance: actual R3F scene; GLSL/physical transmission visible; view/model consequences inspectable;
seeded out-of-order time and queue invariants; actual60fps source motion; full export decode;
readable type/brand at720p; correct audio/caption duration and encoded loudness; working pause,
seek/reset, mute/volume, reduced motion and graceful WebGL fallback. Listening and device limits
must be stated honestly. No public replacement before the new film is concrete and reviewable.
