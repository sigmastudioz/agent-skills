# Reusable lessons from the R3F production

- A manual R3F loop needs one explicit render owner. Update the model/geometry first,
  run transmission buffers after those updates, then render scene and typography in order.
  Prime Drei environment/React effects before shader warm-up and frame zero.
- DOM overlays do not appear in WebGL capture. This film uses a dedicated orthographic
  HUD, with labels projected from the same scene transform and layout contract as the geometry.
- Domain direction matters in decorative animation too: queued input items belong on the inlet
  path, not beside the output just because that corner has space. Label meaningful endpoints.
- Smoothstep/quintic expressions can exceed bounds by floating-point epsilon. Clamp output when
  animation states have a strict0–1contract; independently test physical queue/model invariants.
- Cached media errors persist when an export appears at a previously missing URL. Explicitly load
  the native video element after capture succeeds, then check actual metadata and time advancement.
- Interactive control sounds are a separate adapter from a film's cue track. Start only after
  user input, honor mute/volume, cap voices and disconnect each voice. Use one shared event clock
  for baked score/effects/captions and identify measured RMS separately from spectral analysis.
- Treat a short encode as pipeline proof, not art approval. Inspect hero, mechanism, macro and
  payoff frames and transitions. This review prompted actual flow labels and a stronger macro view.
- Retain old attempts and source fingerprints. A new film does not retroactively establish a
  native-agent efficacy result or a new marketplace approval. Keep subjective listening distinct
  from loudness/peak/stereo measurements and offline60fps distinct from realtime device speed.
