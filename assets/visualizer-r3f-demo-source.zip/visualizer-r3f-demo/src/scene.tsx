import { useEffect, useMemo, useRef, type RefObject } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Environment, Lightformer, MeshTransmissionMaterial } from '@react-three/drei'
import * as THREE from 'three'
import { sample, transition, clamp, energyAt, type Controls, type Envelope } from './model'
import { surfaceVertex, surfaceFragment, shadowVertex, shadowFragment } from './shaders'
import { Hud } from './typography'
import {nodes as layoutNodes,createPaths,worldAt,networkStrength} from './layout'

type Props={controls:RefObject<Controls>;envelope:Envelope;onSelect:()=>void}
const TAU=Math.PI*2

function Core({controls,envelope,small=false}:Props&{small?:boolean}){
 const ref=useRef<THREE.Mesh>(null)
 const material=useRef<THREE.ShaderMaterial>(null)
 const uniforms=useMemo(()=>({uTime:{value:0},uEnergy:{value:0},uSelected:{value:0}}),[])
 useFrame(()=>{
  const c=controls.current,t=c.seconds,s=sample(t,c.arrival)
  if(ref.current){
   ref.current.rotation.set(.2+Math.sin(t*.19)*.08,t*.14,Math.sin(t*.15)*.08)
   ref.current.scale.setScalar((small?.58:.88)*(1+.05*s.material*Math.sin(t*.5)))
  }
  if(material.current){uniforms.uTime.value=t;uniforms.uEnergy.value=c.effects?energyAt(envelope,t):0;uniforms.uSelected.value=c.selected?1:0}
 },-3)
 return <mesh ref={ref} castShadow><icosahedronGeometry args={[1,5]}/><shaderMaterial ref={material} vertexShader={surfaceVertex} fragmentShader={surfaceFragment} uniforms={uniforms}/></mesh>
}

function Sculpture({controls,envelope,onSelect,small=false}:Props&{small?:boolean}){
 const shell=useRef<THREE.Mesh>(null),alloy=useRef<THREE.Mesh>(null),hoop=useRef<THREE.Mesh>(null)
 useFrame(()=>{
  const t=controls.current.seconds,s=sample(t,controls.current.arrival)
  if(shell.current){shell.current.rotation.set(.28+Math.sin(t*.13)*.09,.45+Math.sin(t*.2)*.22,.2+t*.045);shell.current.scale.setScalar(small?.58:1)}
  if(alloy.current){alloy.current.rotation.set(1.1+Math.sin(t*.12)*.14,t*.09+.3,-.6);alloy.current.scale.setScalar(small?.58:1)}
  if(hoop.current){hoop.current.rotation.set(.4,t*.08,.35);hoop.current.scale.setScalar((small?.58:1)*(1+s.material*.06))}
 },-3)
 return <group onClick={e=>{e.stopPropagation();onSelect()}}>
  <Core controls={controls} envelope={envelope} onSelect={onSelect} small={small}/>
  <mesh ref={shell} castShadow><torusGeometry args={[1.42,.27,28,160]}/>
   {small?<meshPhysicalMaterial color="#b9e2d5" metalness={.45} roughness={.18} clearcoat={1}/>:<MeshTransmissionMaterial resolution={512} samples={5} thickness={.75} roughness={.10} chromaticAberration={.045} anisotropicBlur={.08} distortion={.06} distortionScale={.25} temporalDistortion={.08} ior={1.32} color="#d9f3eb"/>}
  </mesh>
  <mesh ref={alloy} castShadow><torusGeometry args={[1.49,.055,16,160]}/><meshPhysicalMaterial color="#c3c9bd" metalness={.95} roughness={.22} clearcoat={1}/></mesh>
  <mesh ref={hoop}><torusGeometry args={[1.82,.009,8,180]}/><meshBasicMaterial color="#7ba69b" transparent opacity={.45}/></mesh>
 </group>
}

function Network({controls,curves}:Pick<Props,'controls'>&{curves:THREE.CatmullRomCurve3[]}){
 const nodes=useRef<THREE.Mesh[]>([]),dots=useRef<THREE.InstancedMesh>(null),paths=useRef<THREE.Group>(null)
 const positions=useMemo(()=>layoutNodes.map(n=>new THREE.Vector3(...n.position)),[])
 const tubes=useMemo(()=>curves.map(c=>new THREE.TubeGeometry(c,70,.012,8,false)),[curves])
 const dummy=useMemo(()=>new THREE.Object3D(),[]),point=useMemo(()=>new THREE.Vector3(),[])
 useEffect(()=>()=>tubes.forEach(g=>g.dispose()),[tubes])
 useFrame(()=>{
  const c=controls.current,t=c.seconds,s=sample(t,c.arrival),strength=networkStrength(s)
  nodes.current.forEach((node,i)=>{if(!node)return;node.position.copy(positions[i]);node.scale.setScalar(strength);node.rotation.set(t*.12+i,t*.22,0)})
  if(paths.current){paths.current.visible=strength>.001;paths.current.scale.setScalar(Math.max(.001,strength))}
  if(dots.current){
   dots.current.visible=strength>.001
   for(let i=0;i<30;i++){
    const route=Math.floor(i/10),q=(t*(route===0?s.model.arrival*.036:.11)+(i%10)/10)%1
    curves[route].getPoint(route===2?1-q:q,point)
    dummy.position.copy(point);dummy.scale.setScalar((c.effects?.037:.028)*strength);dummy.updateMatrix();dots.current.setMatrixAt(i,dummy.matrix)
   }
   dots.current.instanceMatrix.needsUpdate=true
  }
 },-2)
 return <>
  <group ref={paths}>{tubes.map((g,i)=><mesh key={i} geometry={g} dispose={null}><meshBasicMaterial color={i===0?'#568f83':'#a57b58'} transparent opacity={.55}/></mesh>)}</group>
  {positions.map((_,i)=><mesh key={i} ref={el=>{if(el)nodes.current[i]=el}} castShadow>
   {i===1?<octahedronGeometry args={[.28,2]}/>:<sphereGeometry args={[.24,28,20]}/>}
   <meshPhysicalMaterial color={['#94c8b3','#bca17b','#71a9a0'][i]} metalness={.65} roughness={.2} clearcoat={1}/>
  </mesh>)}
  <instancedMesh ref={dots} args={[undefined,undefined,30]}><sphereGeometry args={[1,10,8]}/><meshBasicMaterial color="#c4e6c3"/></instancedMesh>
 </>
}

function Queue({controls,curve}:Pick<Props,'controls'>&{curve:THREE.CatmullRomCurve3}){
 const items=useRef<THREE.Mesh[]>([])
 useFrame(()=>{
  const c=controls.current,t=c.seconds,s=sample(t,c.arrival)
  items.current.forEach((m,i)=>{if(!m)return;const v=clamp(s.model.queue-i)*s.control;m.visible=v>.001;curve.getPoint(.86-i*.045,m.position);m.position.y+=Math.sin(t*1.3+i*.4)*.02;m.scale.setScalar(v);m.rotation.set(t*.2,i*.4+t*.3,0)})
 },-2)
 return <>{Array.from({length:12},(_,i)=><mesh key={i} ref={el=>{if(el)items.current[i]=el}}><sphereGeometry args={[.09,20,16]}/><meshPhysicalMaterial color="#df9c65" metalness={.6} roughness={.2} clearcoat={1}/></mesh>)}</>
}

function Dust({controls}:Pick<Props,'controls'>){
 const mesh=useRef<THREE.InstancedMesh>(null),dummy=useMemo(()=>new THREE.Object3D(),[])
 useFrame(()=>{
  const c=controls.current,t=c.seconds
  if(!mesh.current)return
  mesh.current.visible=c.effects
  for(let i=0;i<90;i++){
   const r=2.5+(i%11)*.13,a=i*2.399963+t*(.018+(i%3)*.002)
   dummy.position.set(Math.cos(a)*r,Math.sin(a)*r*.7,Math.sin(i*3.1+t*.08)*1.4-1)
   dummy.scale.setScalar(.008+(i%4)*.002);dummy.updateMatrix();mesh.current.setMatrixAt(i,dummy.matrix)
  }
  mesh.current.instanceMatrix.needsUpdate=true
 },-2)
 return <instancedMesh ref={mesh} args={[undefined,undefined,90]}><sphereGeometry args={[1,6,5]}/><meshBasicMaterial color="#90bbae" transparent opacity={.35}/></instancedMesh>
}

function World(props:Props){
 const curves=useMemo(createPaths,[])
 const root=useRef<THREE.Group>(null),hero=useRef<THREE.Group>(null),pair=useRef<THREE.Group>(null)
 const outline=useMemo(()=>{const box=new THREE.BoxGeometry(2.48,2.86,.04);const edges=new THREE.EdgesGeometry(box);box.dispose();return edges},[])
 useEffect(()=>()=>outline.dispose(),[outline])
 useFrame(()=>{
  const c=props.controls.current,t=c.seconds,s=sample(t,c.arrival)
  if(root.current){const view=worldAt(t);root.current.position.set(...view.position);root.current.rotation.set(...view.rotation)}
  if(hero.current){hero.current.scale.setScalar(1.07-s.split*.89+s.material*.53);hero.current.visible=s.split<.995}
  if(pair.current){pair.current.visible=s.split>.001;pair.current.scale.setScalar(s.split)}
 },-3)
 return <group ref={root}>
  <group ref={hero}><Sculpture {...props}/></group>
  <Network controls={props.controls} curves={curves}/><Queue controls={props.controls} curve={curves[0]}/><Dust controls={props.controls}/>
  <group ref={pair}>
   {[-1.35,1.35].map((x,i)=><group key={i} position={[x,.15,0]}><Sculpture {...props} small/>
    <mesh position={[0,0,-.55]}><boxGeometry args={[2.48,2.86,.04]}/><meshStandardMaterial color="#142c2c" roughness={.7} metalness={.25}/></mesh>
    <lineSegments position={[0,0,-.52]} geometry={outline} dispose={null}><lineBasicMaterial color="#5a8278" transparent opacity={.65}/></lineSegments>
   </group>)}
  </group>
  <mesh rotation={[-Math.PI/2,0,0]} position={[0,-2.17,0]}><planeGeometry args={[8,5]}/><shaderMaterial transparent depthWrite={false} vertexShader={shadowVertex} fragmentShader={shadowFragment}/></mesh>
 </group>
}

export function FilmScene(props:Props){
 const {gl,scene,camera}=useThree()
 const hud=useMemo(()=>new Hud(),[])
 useEffect(()=>()=>hud.dispose(),[hud])
 useFrame(()=>{
  const t=props.controls.current.seconds
  camera.position.set(Math.sin(t*.12)*.09,.48+Math.sin(t*.1)*.07,12.6)
  camera.lookAt(0,0,0)
  hud.draw(props.controls.current,props.envelope,camera)
  gl.autoClear=true;gl.setRenderTarget(null);gl.render(scene,camera)
  gl.autoClear=false;gl.clearDepth();gl.render(hud.scene,hud.camera);gl.autoClear=true
 },1)
 return <>
  <color attach="background" args={['#091b1e']}/>
  <fog attach="fog" args={['#091b1e',17,32]}/>
  <ambientLight intensity={.45}/>
  <directionalLight position={[-3,6,7]} intensity={3.0} color="#e9f3d9"/>
  <directionalLight position={[6,2,-3]} intensity={2.3} color="#75c1b5"/>
  <pointLight position={[0,-1,4]} intensity={12} color="#e9a16a"/>
  <Environment frames={1} resolution={256} environmentIntensity={1.1}>
   <Lightformer form="rect" intensity={5} color="#e9f3d9" position={[-4,5,3]} scale={[6,4]} target={[0,0,0]}/>
   <Lightformer form="rect" intensity={3} color="#71d3ca" position={[5,1,2]} scale={[2,6]} target={[0,0,0]}/>
   <Lightformer form="ring" intensity={4} color="#ffd09e" position={[1,-2,-4]} scale={3} target={[0,0,0]}/>
   <Lightformer form="rect" intensity={1} color="#cdd6ca" position={[0,7,-2]} scale={[10,2]} target={[0,0,0]}/>
  </Environment>
  <World {...props}/>
 </>
}
