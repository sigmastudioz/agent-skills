import { useEffect, useMemo, useRef, type RefObject } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Environment, Lightformer, MeshTransmissionMaterial } from '@react-three/drei'
import * as THREE from 'three'
import { sample, energyAt, lerp, type Controls, type Envelope } from './model'
import { surfaceVertex, surfaceFragment, shadowVertex, shadowFragment } from './shaders'
import { Hud } from './typography'
import { worldAt, cityAt, towerRise, plateRise, pumpState, cameraAt, CENTER } from './layout'
import { city, tallest } from './city'
import { poseAt } from './pump'

type Props={controls:RefObject<Controls>;envelope:Envelope;onSelect:()=>void}

function Core({controls,envelope}:Props){
 const ref=useRef<THREE.Mesh>(null)
 const material=useRef<THREE.ShaderMaterial>(null)
 const uniforms=useMemo(()=>({uTime:{value:0},uEnergy:{value:0},uSelected:{value:0}}),[])
 useFrame(()=>{
  const c=controls.current,t=c.seconds
  if(ref.current){ref.current.rotation.set(.2+Math.sin(t*.19)*.08,t*.14,Math.sin(t*.15)*.08);ref.current.scale.setScalar(.88)}
  if(material.current){uniforms.uTime.value=t;uniforms.uEnergy.value=c.effects?energyAt(envelope,t):0;uniforms.uSelected.value=c.selected?1:0}
 },-3)
 return <mesh ref={ref} castShadow><icosahedronGeometry args={[1,5]}/><shaderMaterial ref={material} vertexShader={surfaceVertex} fragmentShader={surfaceFragment} uniforms={uniforms}/></mesh>
}

function Sculpture(props:Props){
 const shell=useRef<THREE.Mesh>(null),alloy=useRef<THREE.Mesh>(null),hoop=useRef<THREE.Mesh>(null)
 useFrame(()=>{
  const t=props.controls.current.seconds
  if(shell.current)shell.current.rotation.set(.28+Math.sin(t*.13)*.09,.45+Math.sin(t*.2)*.22,.2+t*.045)
  if(alloy.current)alloy.current.rotation.set(1.1+Math.sin(t*.12)*.14,t*.09+.3,-.6)
  if(hoop.current)hoop.current.rotation.set(.4,t*.08,.35)
 },-3)
 return <group onClick={e=>{e.stopPropagation();props.onSelect()}}>
  <Core {...props}/>
  <mesh ref={shell} castShadow><torusGeometry args={[1.42,.27,28,160]}/>
   <MeshTransmissionMaterial resolution={512} samples={5} thickness={.75} roughness={.10} chromaticAberration={.045} anisotropicBlur={.08} distortion={.06} distortionScale={.25} temporalDistortion={.08} ior={1.32} color="#d9f3eb"/>
  </mesh>
  <mesh ref={alloy} castShadow><torusGeometry args={[1.49,.055,16,160]}/><meshPhysicalMaterial color="#c3c9bd" metalness={.95} roughness={.22} clearcoat={1}/></mesh>
  <mesh ref={hoop}><torusGeometry args={[1.82,.009,8,180]}/><meshBasicMaterial color="#7ba69b" transparent opacity={.45}/></mesh>
 </group>
}

const LIGHT=new THREE.Color('#e3efe2'),DEEP=new THREE.Color('#2a7f7a'),NODATA=new THREE.Color('#6f7773'),PICK=new THREE.Color('#f0a561')
/** Data city: one instanced mesh; every tower is a unit box scaled and lifted by half its height. */
function CityView({controls}:Pick<Props,'controls'>){
 const group=useRef<THREE.Group>(null),mesh=useRef<THREE.InstancedMesh>(null),plates=useRef<THREE.Mesh[]>([])
 const dummy=useMemo(()=>new THREE.Object3D(),[]),color=useMemo(()=>new THREE.Color(),[])
 useFrame(()=>{
  const t=controls.current.seconds,s=sample(t),pose=cityAt(t)
  if(!group.current||!mesh.current)return
  group.current.visible=s.city>.001
  if(!group.current.visible)return
  group.current.position.set(...pose.position);group.current.rotation.set(...pose.rotation);group.current.scale.setScalar(pose.scale)
  city.towers.forEach((tower,i)=>{
   const district=city.districts.find(d=>d.id===tower.group)!
   const h=Math.max(.001,tower.height*towerRise(t,district.index,tower.order))
   dummy.position.set(tower.x,h/2,tower.z);dummy.scale.set(tower.size,h,tower.size);dummy.updateMatrix();mesh.current!.setMatrixAt(i,dummy.matrix)
   const picked=tower.id===tallest.id&&(pose.selected||controls.current.selected)
   mesh.current!.setColorAt(i,picked?PICK:tower.tone===null?NODATA:color.copy(LIGHT).lerp(DEEP,tower.tone))
  })
  mesh.current.instanceMatrix.needsUpdate=true
  if(mesh.current.instanceColor)mesh.current.instanceColor.needsUpdate=true
  plates.current.forEach((plate,i)=>{if(plate)plate.scale.set(plateRise(t,i)||.001,1,plateRise(t,i)||.001)})
 },-2)
 return <group ref={group} visible={false}>
  {city.districts.map((d,i)=><mesh key={d.id} ref={el=>{if(el)plates.current[i]=el}} position={[d.x,-.06,d.z]}>
   <boxGeometry args={[d.width+.5,.1,d.depth+.5]}/><meshStandardMaterial color="#1c3b3a" roughness={.85} metalness={.2}/>
  </mesh>)}
  <instancedMesh ref={mesh} args={[undefined,undefined,city.towers.length]} frustumCulled={false}>
   <boxGeometry args={[1,1,1]}/><meshStandardMaterial roughness={.5} metalness={.12}/>
  </instancedMesh>
 </group>
}

/** Vane pump for the explainer controls. Only the casing is clipped; the parts inside stay whole. */
function PumpView({controls}:Pick<Props,'controls'>){
 const group=useRef<THREE.Group>(null),rotor=useRef<THREE.Group>(null),fluid=useRef<THREE.Mesh>(null)
 const gl=useThree(s=>s.gl)
 const plane=useMemo(()=>new THREE.Plane(new THREE.Vector3(0,0,-1),1.7),[]),planes=useMemo(()=>[plane],[plane])
 useEffect(()=>{gl.localClippingEnabled=true},[gl])
 useFrame(()=>{
  const c=controls.current,t=c.seconds,s=sample(t),state=pumpState(t,c),pose=poseAt(state.tau)
  if(!group.current)return
  group.current.visible=s.pump>.001
  group.current.scale.setScalar(Math.max(.001,s.pump))
  plane.constant=lerp(1.7,CENTER[2],state.cut)          // world z <= constant is kept: the near half is removed
  if(rotor.current)rotor.current.rotation.y=pose.rotor
  if(fluid.current){fluid.current.position.set(...pose.fluid);fluid.current.visible=pose.fluidVisible}
 },-2)
 return <group ref={group} position={CENTER} visible={false}>
  <mesh><cylinderGeometry args={[1.5,1.5,1.4,64,1,true]}/><meshPhysicalMaterial color="#9fb9ae" metalness={.82} roughness={.3} clearcoat={.6} side={THREE.DoubleSide} clippingPlanes={planes}/></mesh>
  {[.7,-.7].map(y=><mesh key={y} position={[0,y,0]} rotation={[-Math.PI/2,0,0]}><circleGeometry args={[1.5,64]}/><meshPhysicalMaterial color="#86a399" metalness={.82} roughness={.34} side={THREE.DoubleSide} clippingPlanes={planes}/></mesh>)}
  <group ref={rotor}>
   <mesh><cylinderGeometry args={[.22,.22,1.2,32]}/><meshPhysicalMaterial color="#c98a55" metalness={.85} roughness={.25} clearcoat={1}/></mesh>
   {[0,1,2,3].map(i=><mesh key={i} rotation={[0,i*Math.PI/2,0]} position={[Math.cos(i*Math.PI/2)*.62,0,-Math.sin(i*Math.PI/2)*.62]}>
    <boxGeometry args={[.86,1.0,.07]}/><meshStandardMaterial color="#e0aa74" metalness={.25} roughness={.45}/>
   </mesh>)}
  </group>
  <mesh ref={fluid}><sphereGeometry args={[.2,28,20]}/><meshStandardMaterial color="#7ff0e8" emissive="#2bb8b2" emissiveIntensity={2.2} roughness={.3}/></mesh>
 </group>
}

function Dust({controls}:Pick<Props,'controls'>){
 const mesh=useRef<THREE.InstancedMesh>(null),dummy=useMemo(()=>new THREE.Object3D(),[])
 useFrame(()=>{
  const c=controls.current,t=c.seconds,s=sample(t)
  if(!mesh.current)return
  mesh.current.visible=c.effects&&s.hero>.02
  for(let i=0;i<90;i++){
   const r=2.5+(i%11)*.13,a=i*2.399963+t*(.018+(i%3)*.002)
   dummy.position.set(Math.cos(a)*r,Math.sin(a)*r*.7,Math.sin(i*3.1+t*.08)*1.4-1)
   dummy.scale.setScalar((.008+(i%4)*.002)*s.hero);dummy.updateMatrix();mesh.current.setMatrixAt(i,dummy.matrix)
  }
  mesh.current.instanceMatrix.needsUpdate=true
 },-2)
 return <instancedMesh ref={mesh} args={[undefined,undefined,90]}><sphereGeometry args={[1,6,5]}/><meshBasicMaterial color="#90bbae" transparent opacity={.35}/></instancedMesh>
}

function World(props:Props){
 const root=useRef<THREE.Group>(null),hero=useRef<THREE.Group>(null),shadow=useRef<THREE.Mesh>(null)
 useFrame(()=>{
  const t=props.controls.current.seconds,s=sample(t)
  if(root.current){const view=worldAt(t);root.current.position.set(...view.position);root.current.rotation.set(...view.rotation)}
  if(hero.current){hero.current.scale.setScalar(Math.max(.001,1.07*s.hero));hero.current.visible=s.hero>.004}
  if(shadow.current)shadow.current.visible=s.hero>.5
 },-3)
 return <>
  <group ref={root}>
   <group ref={hero}><Sculpture {...props}/></group><Dust controls={props.controls}/>
   <mesh ref={shadow} rotation={[-Math.PI/2,0,0]} position={[0,-2.17,0]}><planeGeometry args={[8,5]}/><shaderMaterial transparent depthWrite={false} vertexShader={shadowVertex} fragmentShader={shadowFragment}/></mesh>
  </group>
  <CityView controls={props.controls}/><PumpView controls={props.controls}/>
 </>
}

export function FilmScene(props:Props){
 const {gl,scene,camera,size}=useThree()
 const hud=useMemo(()=>new Hud(),[])
 useEffect(()=>()=>hud.dispose(),[hud])
 useFrame(()=>{
  const c=props.controls.current,t=c.seconds,s=sample(t),view=cameraAt(t,s,c),cam=camera as THREE.PerspectiveCamera
  cam.position.set(...view.position);cam.lookAt(...view.target)
  cam.fov=view.fov;cam.near=.1*view.distanceScale;cam.far=60*view.distanceScale
  if(view.shift>1e-4)cam.setViewOffset(size.width,size.height,-view.shift*size.width,view.raise*size.height,size.width,size.height);else cam.clearViewOffset()
  cam.updateProjectionMatrix();cam.updateMatrixWorld(true)
  if(scene.fog instanceof THREE.Fog){const d=12.6*(view.distanceScale-1);scene.fog.near=17+d;scene.fog.far=32+d}
  hud.draw(c,props.envelope,cam)
  gl.autoClear=true;gl.setRenderTarget(null);gl.render(scene,camera)
  gl.autoClear=false;gl.clearDepth();gl.render(hud.scene,hud.camera);gl.autoClear=true
 },1)
 return <>
  <color attach="background" args={['#091b1e']}/>
  <fog attach="fog" args={['#091b1e',17,32]}/>
  <ambientLight intensity={.45}/>
  <directionalLight position={[-3,6,7]} intensity={3.0} color="#e9f3d9"/>
  <directionalLight position={[6,2,-3]} intensity={2.3} color="#75c1b5"/>
  <pointLight position={[0,-1,4]} intensity={12} color="#e9a16a"/>
  <Environment frames={1} resolution={256} environmentIntensity={1.1}>
   <Lightformer form="rect" intensity={5} color="#e9f3d9" position={[-4,5,3]} scale={[6,4]} target={[0,0,0]}/>
   <Lightformer form="rect" intensity={3} color="#71d3ca" position={[5,1,2]} scale={[2,6]} target={[0,0,0]}/>
   <Lightformer form="ring" intensity={4} color="#ffd09e" position={[1,-2,-4]} scale={3} target={[0,0,0]}/>
   <Lightformer form="rect" intensity={1} color="#cdd6ca" position={[0,7,-2]} scale={[10,2]} target={[0,0,0]}/>
  </Environment>
  <World {...props}/>
 </>
}
