import * as THREE from 'three'
import {transition,type sample} from './model'
/** One layout contract drives geometry, queue placement and the exported HUD labels. */
export const nodes=[2.58,.55,-1.25].map((a,i)=>({id:['input','state','output'][i],label:['INPUT','STATE','OUTPUT'][i],position:[Math.cos(a)*2.45,Math.sin(a)*1.86,Math.sin(a*1.3)*.6] as [number,number,number]}))
export function createPaths(){return nodes.map(n=>{const p=new THREE.Vector3(...n.position);return new THREE.CatmullRomCurve3([p,p.clone().multiplyScalar(.6).add(new THREE.Vector3(0,0,1)),new THREE.Vector3(0,0,.1)])})}
export function worldAt(t:number){return {position:[2.45+Math.sin(t*.12)*.045,-.02+Math.sin(t*.43)*.045,0] as [number,number,number],rotation:[.03,Math.sin(t*.12)*.07,Math.sin(t*.1)*.025] as [number,number,number]}}
export function networkStrength(s:ReturnType<typeof sample>){return s.open*(1-transition(s.t,18.6,.8))}

export function hudWeights(s:ReturnType<typeof sample>){return {
 control:s.control*(1-transition(s.t,18.6,.4)),
 material:s.material*transition(s.t,19.15,.65)*(1-transition(s.t,24.7,.45)),
 clock:s.split*transition(s.t,25.65,.55)*(1-transition(s.t,30.7,.3))
}}
