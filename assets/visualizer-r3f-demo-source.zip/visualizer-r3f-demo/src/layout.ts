import {transition,clamp,lerp,backOut,timeline,type sample,type Controls} from './model'
import {city} from './city'
import {SHOTS,rewindTarget,PUMP_DURATION} from './pump'
/** One layout contract drives geometry, camera and the exported HUD labels. */
export const CENTER:[number,number,number]=[2.45,-.05,0]
const E=timeline.events,KEYS=E.keys
export const keyTime=(key:string)=>KEYS.find(k=>k.key===key)!.time
export function worldAt(t:number){return {position:[2.45+Math.sin(t*.12)*.045,-.02+Math.sin(t*.43)*.045,0] as [number,number,number],rotation:[.03,Math.sin(t*.12)*.07,Math.sin(t*.1)*.025] as [number,number,number]}}

// ---- data city
export const CITY_SCALE=6.5/city.span
export function cityAt(t:number){
 const plan=transition(t,E.plan,.9)*(1-transition(t,E.plan_end,.7))
 return {plan,selected:t>=E.select,scale:CITY_SCALE,
  position:[CENTER[0]+.5,lerp(-.25,.6,plan),0] as [number,number,number],
  rotation:[lerp(.5,Math.PI/2,plan),lerp(-.48,0,plan),0] as [number,number,number]}
}
/** Staggered pop-in per tower (0.55 s, back ease), district by district on the beat grid. */
export function towerRise(t:number,district:number,order:number){
 const start=E.district_rise[district]+order*.07
 return backOut((t-start)/.55)*(1-transition(t,14.3,.6))
}
export const plateRise=(t:number,district:number)=>transition(t,E.district_rise[district]-.35,.5)*(1-transition(t,14.4,.6))

// ---- explainer
/** Explained-scene seconds for a film time: runs from the cutaway on, and rewinds one beat at the B key. */
export function pumpClock(t:number){
 const start=16,rewind=keyTime('B')
 if(t<start)return 2
 const before=2+(Math.min(t,rewind)-start)
 return t<rewind?before:Math.min(PUMP_DURATION,rewindTarget(before)+(t-rewind))
}
export function pumpState(t:number,c?:Controls){
 const authoredCut=transition(t,keyTime('C'),.5)*(1-transition(t,28.5,.4))
 return {tau:pumpClock(t),cut:c&&c.cutaway!==null?(c.cutaway?1:0):authoredCut,notes:c&&c.notes!==null?c.notes:true}
}
const add=(a:readonly number[],b:readonly number[])=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]] as [number,number,number]
const mix3=(a:readonly number[],b:readonly number[],k:number)=>[lerp(a[0],b[0],k),lerp(a[1],b[1],k),lerp(a[2],b[2],k)] as [number,number,number]
/** Index of the shot the authored film is on, and the eased offset on the way to it. */
export function shotAt(t:number){
 const order:[number,number][]=[[-Infinity,0],[keyTime('2'),1],[keyTime('3'),2],[keyTime('1'),0]]
 let i=0;order.forEach((o,n)=>{if(t>=o[0])i=n})
 const from=SHOTS[order[Math.max(0,i-1)][1]].offset,to=SHOTS[order[i][1]].offset
 // Frame-rate independent ease toward the shot: 1 - exp(-6·seconds since the key).
 const k=i===0?1:1-Math.exp(-6*(t-order[i][0]))
 return {index:order[i][1],offset:mix3(from,to,k)}
}
export const SHIFT=.165   // the pump sits right of centre, where the hero and the city sit
export const RAISE=.085   // and above the key-cap panel
export function cameraAt(t:number,s:ReturnType<typeof sample>,c?:Controls){
 const base:[number,number,number]=[Math.sin(t*.12)*.09,.48+Math.sin(t*.1)*.07,12.6]
 // Data city: dolly back and narrow the lens together, so equal heights read equal anywhere.
 const flat=1+16*s.city,fov=2*Math.atan(Math.tan(18.5*Math.PI/180)/flat)*180/Math.PI
 const far:[number,number,number]=[base[0]*flat,base[1]*flat,base[2]*flat]
 const offset=c&&c.shot!==null?SHOTS[clamp(c.shot,0,SHOTS.length-1)].offset:shotAt(t).offset
 const p=s.pump
 return {position:mix3(far,add(CENTER,offset),p),target:mix3([0,0,0],CENTER,p),fov,shift:SHIFT*p,raise:RAISE*p,distanceScale:flat}
}
