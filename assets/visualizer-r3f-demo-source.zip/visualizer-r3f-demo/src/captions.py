"""Write public/captions.srt and captions.vtt from the caption cues in src/timeline.json."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
cues = json.loads((ROOT/'src/timeline.json').read_text())['captions']


def stamp(seconds, comma):
    ms = round(seconds*1000); h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f'{h:02d}:{m:02d}:{s:02d}{"," if comma else "."}{ms:03d}'


srt = '\n\n'.join(f'{i}\n{stamp(a, True)} --> {stamp(b, True)}\n{text}' for i, (a, b, text) in enumerate(cues, 1))+'\n'
vtt = 'WEBVTT\n\n'+'\n\n'.join(f'{stamp(a, False)} --> {stamp(b, False)}\n{text}' for a, b, text in cues)+'\n'
(ROOT/'public/captions.srt').write_text(srt); (ROOT/'public/captions.vtt').write_text(vtt)
print(len(cues), 'caption cues written; last ends at', cues[-1][1], 's')
