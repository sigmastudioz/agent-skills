/** User-gesture sonification for preview controls; the film uses its composed cue track. */
export class InteractionSound {
 private context:AudioContext|null=null
 private voices=new Set<OscillatorNode>()
 private master:GainNode|null=null
 private level=0
 setVolume(volume:number,enabled:boolean){
  this.level=enabled&&Number.isFinite(volume)?Math.max(0,Math.min(1,volume)):0
  if(this.context&&this.master){const now=this.context.currentTime;this.master.gain.cancelScheduledValues(now);this.master.gain.setValueAtTime(this.master.gain.value,now);this.master.gain.linearRampToValueAtTime(this.level,now+.008)}
 }
 play(value:number,volume:number,enabled:boolean){
  this.setVolume(volume,enabled)
  if(!enabled||volume<=0||!Number.isFinite(value)||typeof AudioContext==='undefined')return
  const ctx=this.context??(this.context=new AudioContext())
  if(!this.master){this.master=ctx.createGain();this.master.gain.value=this.level;this.master.connect(ctx.destination)}
  void ctx.resume().catch(()=>{})
  if(this.voices.size>=4)return
  const osc=ctx.createOscillator(),harmonic=ctx.createOscillator(),gain=ctx.createGain(),overtone=ctx.createGain(),pan=ctx.createStereoPanner()
  const t=ctx.currentTime,hz=260+Math.max(0,Math.min(6,value))*42
  osc.type='sine';osc.frequency.setValueAtTime(hz,t);osc.frequency.exponentialRampToValueAtTime(hz*.985,t+.34)
  harmonic.frequency.setValueAtTime(hz*2.756,t);overtone.gain.value=.13
  gain.gain.setValueAtTime(.00001,t);gain.gain.exponentialRampToValueAtTime(.055,t+.008);gain.gain.exponentialRampToValueAtTime(.00001,t+.4)
  pan.pan.value=(Math.max(0,Math.min(6,value))/6-.5)*.5
  osc.connect(gain);harmonic.connect(overtone);overtone.connect(gain);gain.connect(pan);pan.connect(this.master)
  this.voices.add(osc)
  osc.onended=()=>{this.voices.delete(osc);osc.disconnect();harmonic.disconnect();overtone.disconnect();gain.disconnect();pan.disconnect()}
  osc.start(t);harmonic.start(t);osc.stop(t+.42);harmonic.stop(t+.42)
 }
 close(){for(const voice of this.voices){try{voice.stop()}catch{}}this.voices.clear();this.master?.disconnect();void this.context?.close().catch(()=>{});this.context=null;this.master=null}
}
