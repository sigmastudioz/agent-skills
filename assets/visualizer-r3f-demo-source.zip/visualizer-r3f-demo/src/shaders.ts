export const surfaceVertex=`
uniform float uTime; uniform float uEnergy;
varying vec3 vN; varying vec3 vEye; varying vec3 vP;
void main(){
 vec3 p=position;
 float w=sin(p.y*3.1+uTime*.65)*cos(p.z*2.7+p.x*1.8-uTime*.32);
 p+=normal*(.055*w+.028*uEnergy*sin(p.x*4.+uTime));
 vec4 mv=modelViewMatrix*vec4(p,1.);
 vN=normalize(normalMatrix*normal);vEye=normalize(-mv.xyz);vP=p;
 gl_Position=projectionMatrix*mv;
}`
export const surfaceFragment=`
uniform float uTime; uniform float uEnergy; uniform float uSelected;
varying vec3 vN; varying vec3 vEye; varying vec3 vP;
void main(){
 vec3 n=normalize(vN), eye=normalize(vEye);
 float f=pow(1.-max(dot(n,eye),0.),2.1);
 float key=pow(max(dot(n,normalize(vec3(-.6,.9,1.))),0.),1.7);
 float soft=pow(max(dot(n,normalize(vec3(.8,-.2,.4))),0.),3.);
 float band=.5+.5*sin(vP.y*8.+vP.x*2.+uTime*.38);
 vec3 teal=vec3(.006,.075,.068),pearl=vec3(.19,.57,.39),copper=vec3(.52,.21,.075);
 float flow=vP.y*6.+sin(vP.x*3.4+uTime*.16)+sin(vP.z*4.1-uTime*.12)*.65;
 float pigment=.5+.5*sin(flow*2.4);
 float vein=pow(1.-abs(sin(flow*1.2)),18.);
 vec3 ink=mix(teal,pearl,smoothstep(.12,.91,pigment)*.68)*(.42+key*.6);
 ink=mix(ink,copper,vein*.58);
 ink=mix(ink,copper,soft*.46);
 vec3 spectral=.5+.5*cos(vec3(.1,2.1,4.3)+vP.z*2.+uTime*.08);
 ink+=f*mix(vec3(.17,.42,.40),spectral*.48,.38);
 float thread=pow(band,46.);
 ink+=thread*(.08+.07*uEnergy)*vec3(.6,.9,.75);
 ink+=pow(max(dot(reflect(-normalize(vec3(-.4,.8,.8)),n),eye),0.),60.)*.42;
 ink+=uSelected*.08*vec3(.2,.8,.65);
 gl_FragColor=vec4(ink,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`
export const shadowVertex=`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`
export const shadowFragment=`varying vec2 vUv;void main(){float a=exp(-dot((vUv-.5)*vec2(3.,5.),(vUv-.5)*vec2(3.,5.))*2.)*.35;gl_FragColor=vec4(.0,.0,.0,a);}`
