import timeline from './timeline.json'
export { timeline }
export const clamp = (x:number,a=0,b=1)=>Math.max(a,Math.min(b,x))
export const ease = (x:number)=>{x=clamp(x);return clamp(x*x*x*(x*(x*6-15)+10))}
export const transition=(t:number,start:number,duration=1.3)=>ease((t-start)/duration)
export function queueAt(t:number,manual:number|null=null){
  if(!Number.isFinite(t)||t<0||t>timeline.duration)throw Error('Scene time outside0–36seconds')
  if(manual!==null&&(!Number.isFinite(manual)||manual<0||manual>6))throw Error('Invalid arrival rate')
  const arrival=manual??(t<13?2:t<16?5:1),service=3
  const queue=manual!==null?Math.max(0,(manual-service)*3):t<13?0:t<16?2*(t-13):Math.max(0,6-2*(t-16))
  return {arrival,service,queue}
}
export function shotAt(t:number){return timeline.scenes.find(s=>t>=s.start&&t<s.end)??timeline.scenes.at(-1)!}
export function sample(t:number,manual:number|null=null){
  const model=queueAt(t,manual)
  return {t,model,shot:shotAt(t),open:transition(t,5.4),control:transition(t,11.4)*(1-transition(t,18.8)),material:transition(t,18.8)*(1-transition(t,24.9)),split:transition(t,24.9)*(1-transition(t,30.8)),end:transition(t,30.8),fade:Math.min(1,transition(t,0,.9),1-transition(t,35.3,.7))}
}
export type Controls={seconds:number;arrival:number|null;effects:boolean;selected:boolean;pointer:[number,number]}
export type Envelope={fps:number;levels:number[];source_sha256:string;method:string}
export const energyAt=(env:Envelope,t:number)=>{const f=clamp(t*env.fps,0,env.levels.length-1),i=Math.floor(f);return env.levels[i]+(env.levels[Math.min(i+1,env.levels.length-1)]-env.levels[i])*(f-i)}
