import timeline from './timeline.json'
export { timeline }
export const clamp = (x:number,a=0,b=1)=>Math.max(a,Math.min(b,x))
export const ease = (x:number)=>{x=clamp(x);return clamp(x*x*x*(x*(x*6-15)+10))}
export const transition=(t:number,start:number,duration=1.3)=>ease((t-start)/duration)
export const lerp=(a:number,b:number,k:number)=>a+(b-a)*k
/** Back ease-out: overshoots to about 110 % before settling at 100 % (the "pop-in" entry). */
export const backOut=(x:number)=>{x=clamp(x);const c=1.70158;return 1+(c+1)*Math.pow(x-1,3)+c*Math.pow(x-1,2)}
export function assertTime(t:number){if(!Number.isFinite(t)||t<0||t>timeline.duration)throw Error('Scene time outside 0–36 seconds')}
export function shotAt(t:number){return timeline.scenes.find(s=>t>=s.start&&t<s.end)??timeline.scenes.at(-1)!}
/** Scene weights. Every value is a pure function of film seconds, so any seek draws the same frame. */
export function sample(t:number){
  assertTime(t)
  return {t,shot:shotAt(t),
    hero:Math.max(1-transition(t,5.1,1.0),transition(t,29.3,1.2)),
    city:transition(t,5.5,1.1)*(1-transition(t,14.3,.7)),
    pump:transition(t,15.0,1.1)*(1-transition(t,28.7,.7)),
    end:transition(t,29.6),
    fade:Math.min(1,transition(t,0,.9),1-transition(t,35.3,.7))}
}
/** Interactive overrides are null while the authored film scenario is in charge. */
export type Controls={seconds:number;effects:boolean;selected:boolean;pointer:[number,number];cutaway:boolean|null;shot:number|null;notes:boolean|null}
export type Envelope={fps:number;levels:number[];source_sha256:string;method:string}
export const energyAt=(env:Envelope,t:number)=>{const f=clamp(t*env.fps,0,env.levels.length-1),i=Math.floor(f);return env.levels[i]+(env.levels[Math.min(i+1,env.levels.length-1)]-env.levels[i])*(f-i)}
