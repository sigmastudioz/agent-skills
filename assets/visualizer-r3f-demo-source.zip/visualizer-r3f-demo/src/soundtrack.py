"""Original composed score and material sonification. Lex from SigmaStudioz; no samples/voices."""
from pathlib import Path
import sys,json,math,hashlib,subprocess,wave
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
# Reuse the existing owned synthesis primitives; the delivery bundle includes this dependency.
ENGINE=ROOT/'engine'
if not ENGINE.exists():ENGINE=ROOT.parent/'visual-demos/source'
sys.path.insert(0,str(ENGINE))
from shared.audio_synthesis import RATE,pad,note,pan,mix,room,write_wave
SPEC=json.loads((ROOT/'src/timeline.json').read_text());DURATION=SPEC['duration']
N=DURATION*RATE;TIME=np.arange(N)/RATE;RNG=np.random.default_rng(SPEC['seed'])

def glass(hz,duration=1.8,level=.15):
 t=np.arange(round(duration*RATE))/RATE;v=np.zeros(len(t))
 for i,(partial,decay,weight) in enumerate([(1,2.2,1),(2.756,4.4,.29),(5.404,7.5,.10),(8.933,12,.035)]):
  v+=weight*np.sin(2*np.pi*hz*partial*t+.18*np.sin(2*np.pi*hz*.5*t)*np.exp(-t*9))*np.exp(-t*decay)
 return v*level*(1-np.exp(-t*800))*np.minimum(1,(duration-t)*20)

def air(duration=1.6,level=.1):
 t=np.arange(round(duration*RATE))/RATE;n=RNG.normal(0,1,len(t))
 low=np.convolve(n,np.ones(90)/90,'same');body=np.convolve(n,np.ones(15)/15,'same')-low
 envelope=np.sin(np.pi*t/duration)**2
 return (body*.65+low*.8)*envelope*level

def cue(kind,index):
 if kind=='glass':return glass([587.33,659.25,880,440][index%4],1.8,.14)
 if kind in ('air','open'):return air(1.6,.27)
 if kind in ('click','contact'):
  t=np.arange(round(.36*RATE))/RATE
  body=np.sin(2*np.pi*(290*t-90*t*t))*np.exp(-t*28)*.12
  grain=np.convolve(RNG.normal(0,1,len(t)),np.ones(11)/11,'same')*.07*np.exp(-t*55)
  return (body+grain)*(1-np.exp(-t*1500))
 if kind=='tension':
  t=np.arange(round(2.1*RATE))/RATE
  return (.08*np.sin(2*np.pi*(58*t-5*t*t))+.04*np.sin(2*np.pi*61*t))*np.sin(np.pi*t/2.1)**2
 if kind in ('resolve','bloom'):
  result=np.zeros(round(3*RATE))
  for i,hz in enumerate([293.66,440,587.33,659.25]):
   sound=glass(hz,2.4-i*.13,.11 if kind=='resolve' else .07);start=round(i*.13*RATE);result[start:start+len(sound)]+=sound
  return result
 raise ValueError(kind)

music=np.zeros((N,2),dtype=np.float64);effects=np.zeros_like(music)
# One chord per scene; starts follow the scene starts in timeline.json.
chords=[([146.83,174.61,220,261.63,329.63],0,6.6),([116.54,146.83,174.61,220],5.4,10.4),([130.81,174.61,220,261.63,329.63],15,7.4),([98,146.83,174.61,220,293.66],21.6,8.6),([146.83,220,293.66,329.63],29.4,6.6)]
for tones,start,length in chords:
 mix(music,pad(tones,length)*1.15,start)
# An evolving pentatonic phrase leaves gaps for physical events and the ending.
beat=60/100;scale=[293.66,329.63,440,523.25,587.33,659.25];pattern=[0,None,2,1,None,4,2,None,3,2,None,5,4,None,2,None]
for i in range(math.ceil(DURATION/beat)):
 t=i*beat
 if t>33:break
 degree=pattern[i%len(pattern)]
 if degree is not None:
  instrument=glass(scale[degree],1.7,.038 if t<6 else .052) if i%3==0 else note(scale[degree],1.3,.055)
  mix(music,pan(instrument,math.sin(i*.73)*.48),t+.08)
 if i%4==0:
  chord=next(c for c in reversed(chords) if t>=c[1]);hz=chord[0][0]/2
  tt=np.arange(round(1.3*RATE))/RATE
  sub=(np.sin(2*np.pi*hz*tt)+.18*np.sin(2*np.pi*2*hz*tt))*np.exp(-tt*3.1)*(1-np.exp(-tt*90))*.085
  mix(music,pan(sub,0),t)
 if 6<t<29:
  if i%4 in (0,3):
   tt=np.arange(round(.23*RATE))/RATE
   kick=np.sin(2*np.pi*(46*tt+1.9*(1-np.exp(-tt*35))))*np.exp(-tt*23)*(1-np.exp(-tt*600))*.052
   mix(music,pan(kick,0),t)
  if i%2==1:
   tt=np.arange(round(.12*RATE))/RATE;n=RNG.normal(0,1,len(tt));brush=(n-np.convolve(n,np.ones(12)/12,'same'))*np.exp(-tt*42)*.009
   mix(music,pan(brush,(-1 if i%4==1 else 1)*.4),t+.015)
for i,c in enumerate(SPEC['cues']):
 sound=cue(c['kind'],i)*c['level']
 position=np.linspace(-.55,.55,len(sound)) if c['kind'] in ('air','open') else c['pan']
 mix(effects,pan(sound,position),c['time'])
# Vane ticks come from the mechanism, not the edit grid: 4 vanes at 1.6 rad/s pass a fixed port
# 4 x 1.6 / (2 pi) = 1.02 times a second. Explained-scene seconds map to film seconds exactly as
# pumpClock does in src/layout.ts (runs from 16 s, rewinds from 10 s to 8 s at the B key).
ROTOR_RAD_PER_S=1.6;VANES=4;VANE_PASS_HZ=ROTOR_RAD_PER_S*VANES/(2*math.pi)
REWIND=next(k['time'] for k in SPEC['events']['keys'] if k['key']=='B')
vane_times=[]
for k in range(1,40):
 tau=4+k/VANE_PASS_HZ
 if tau<2+(REWIND-16):vane_times.append(16+(tau-2))
 if 8<=tau<=12 and REWIND+(tau-8)<28.4:vane_times.append(REWIND+(tau-8))
vane_times.sort()
for i,t in enumerate(vane_times):mix(effects,pan(cue('contact',i)*.2,math.sin(i*1.7)*.3),t)
# Material movement beds are quiet, wide and avoid permanent percussive busyness.
for t in (5.0,14.6,21.2,29.0):mix(effects,pan(air(1.25,.08),np.linspace(.4,-.4,round(1.25*RATE))),t)
# The music ducks at the rewind key so the jump back reads as a deliberate edit, then returns.
shape=np.interp(TIME,[0,1,5,6,23.7,24.0,24.5,25.3,29,30,34,36],[0,.8,.9,1,1,.42,.5,.95,.8,.95,.7,0])
music*=shape[:,None]
music+=room(music)*1.2;effects+=room(effects)*.5
result=music+effects
result*=np.minimum(1,TIME/.06)[:,None]*np.minimum(1,(DURATION-TIME)/.8)[:,None]
result*=min(1,.78/(np.max(np.abs(result))+1e-8))
out=ROOT/'public/audio';out.mkdir(parents=True,exist_ok=True)
stems=ROOT/'audio-stems';stems.mkdir(exist_ok=True)
write_wave(stems/'music-stem.wav',music*.8);write_wave(stems/'effects-stem.wav',effects*.8);write_wave(stems/'raw.wav',result)
raw=stems/'raw.wav';target=out/'visualizer.wav';norm='I=-15.2:TP=-1.7:LRA=9'
filterbase='highpass=f=30,lowpass=f=17500,'
def parse(stderr):return json.JSONDecoder().raw_decode(stderr[stderr.rfind('{'):])[0]
first=subprocess.run(['ffmpeg','-hide_banner','-i',str(raw),'-af',filterbase+f'loudnorm={norm}:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
a=parse(first.stderr)
params=f'loudnorm={norm}:measured_I={a["input_i"]}:measured_TP={a["input_tp"]}:measured_LRA={a["input_lra"]}:measured_thresh={a["input_thresh"]}:offset={a["target_offset"]}:linear=true:print_format=json'
second=subprocess.run(['ffmpeg','-hide_banner','-y','-i',str(raw),'-af',filterbase+params,'-ar',str(RATE),str(target)],capture_output=True,text=True,check=True)
with wave.open(str(target)) as f:data=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').reshape(-1,2)/32768
rms=np.sqrt(np.mean(data.reshape(-1,RATE//60,2)**2,axis=(1,2)));level=np.clip(rms/(np.percentile(rms,97)+1e-8),0,1)
for i in range(1,len(level)):level[i]=level[i-1]+(.18 if level[i]>level[i-1] else .075)*(level[i]-level[i-1])
(out/'envelope.json').write_text(json.dumps({'fps':60,'method':'smoothed RMS of final normalized WAV, not FFT','source_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'levels':np.round(level,5).tolist()}))
(ROOT/'audio-report.json').write_text(json.dumps({'author':SPEC['author'],'source':'Original deterministic synthesis; no samples or voice cloning','layers':['evolving harmonic bed','felt-key and inharmonic glass phrases','rounded sub bass','soft rhythmic accents','brushed air','causal material contacts','stereo early reflections'],'normalization':parse(second.stderr),'stereo_correlation':float(np.corrcoef(data.T)[0,1]),'sample_peak':float(np.max(np.abs(data))),'cues':SPEC['cues'],'listening_review':'Not performed by agent; measured and structural checks only'},indent=2)+'\n')
report=json.loads((ROOT/'audio-report.json').read_text())
report['mechanism_pulse']={'source':'vane pump: 4 vanes x 1.6 rad/s / (2 pi)','vane_pass_hz':round(VANE_PASS_HZ,4),'tick_times_s':[round(t,3) for t in vane_times]}
report['cue_sheet']=[{'id':c['id'],'time_s':c['time'],'kind':c['kind'],'level':c['level'],'pan':c['pan']} for c in SPEC['cues']]
report['beat_grid']={'bpm':SPEC['bpm'],'beat_s':60/SPEC['bpm'],'note':'authored grid of this synthesized score; picture events are placed on it in timeline.json'}
(ROOT/'audio-report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Original36-second stereo score generated;',parse(second.stderr)['output_i'],'LUFS')
