// Pure explainer model: beats, the rewind rule, and the pose of every moving part at a scene time.
export interface Beat { id: string; start: number; title: string }
export const PUMP_DURATION = 12
export const BEATS: readonly Beat[] = [
  { id: 'casing', start: 0, title: 'The casing holds pressure' },
  { id: 'rotor', start: 4, title: 'The rotor turns' },
  { id: 'flow', start: 8, title: 'Fluid is carried round' },
]
export const ROTOR_RAD_PER_S = 1.6, VANES = 4
/** Vane passes per second at a fixed port: derived from the mechanism, not from the edit grid. */
export const VANE_PASS_HZ = (ROTOR_RAD_PER_S * VANES) / (2 * Math.PI)
export function beatIndexAt(t: number, beats: readonly Beat[] = BEATS) { let i = 0; beats.forEach((b, n) => { if (t >= b.start) i = n }); return i }
/** Start of the current beat; within `grace` seconds of that start, the beat before. */
export function rewindTarget(t: number, beats: readonly Beat[] = BEATS, grace = 0.6) {
  const i = beatIndexAt(t, beats)
  return t - beats[i].start <= grace && i > 0 ? beats[i - 1].start : beats[i].start
}
export function poseAt(tau: number) {
  const rotor = Math.max(0, tau - 4) * ROTOR_RAD_PER_S
  // The fluid marker rides in the pocket between two vanes (45 degrees after a vane), so it turns with the rotor.
  const pocket = rotor + Math.PI / 4
  return { rotor, fluid: [Math.cos(pocket) * 1.02, 0, -Math.sin(pocket) * 1.02] as [number, number, number], fluidVisible: tau >= 8 }
}
export interface Shot { key: string; name: string; offset: [number, number, number] }
/** Camera positions relative to the pump centre; every shot looks at the centre. */
export const SHOTS: readonly Shot[] = [
  { key: '1', name: 'Overview', offset: [5.8, 4.0, 7.4] },
  { key: '2', name: 'Rotor close-up', offset: [2.9, 2.6, 4.8] },
  { key: '3', name: 'Section, side on', offset: [0, 1.9, 7.9] },
]
/** `drop` puts the label below the part instead of above it, so two notes never stack. */
export interface Note { id: string; anchor: [number, number, number] | ((tau: number) => [number, number, number]); text: string; from: number; inside?: boolean; side: -1 | 1; drop?: boolean; moving?: boolean }
export const NOTES: readonly Note[] = [
  { id: 'casing', anchor: [-1.5, 0.7, 0], text: 'Casing', from: 0, side: -1 },
  { id: 'rotor', anchor: [0, 0.62, 0], text: 'Rotor · 1.6 rad/s', from: 4, inside: true, side: 1 },
  { id: 'fluid', anchor: tau => poseAt(tau).fluid, text: 'Fluid, carried between vanes', from: 8, inside: true, side: 1, drop: true, moving: true },
]
