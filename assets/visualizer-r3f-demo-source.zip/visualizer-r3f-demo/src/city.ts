// Pure data-city model: records in, validated towers and districts out. No React, no Three.js.
export interface RepoRecord { id: string; group: string; commits: number | null; openIssues: number | null }
export interface Tower { id: string; group: string; x: number; z: number; size: number; height: number; value: number | null; shade: number | null; tone: number | null; order: number }
export interface District { id: string; index: number; x: number; z: number; width: number; depth: number; count: number }
export interface City { towers: Tower[]; districts: District[]; maxValue: number; maxShade: number; unitsPerValue: number; rejected: { id: string; reason: string }[]; span: number }
export const MAX_HEIGHT = 8
const LOT = 1.4, TOWER = 1.0, STREET = 1.6, FLAT = 0.06

export function buildCity(records: readonly RepoRecord[]): City {
  const rejected: City['rejected'] = [], seen = new Set<string>(), valid: RepoRecord[] = []
  for (const r of records) {
    const bad = (v: number | null) => v !== null && (!Number.isFinite(v) || v < 0)
    if (!r.id || seen.has(r.id)) rejected.push({ id: r.id || '(missing id)', reason: 'duplicate or missing id' })
    else if (bad(r.commits) || bad(r.openIssues)) rejected.push({ id: r.id, reason: 'negative or non-finite value' })
    else { seen.add(r.id); valid.push(r) }
  }
  const maxValue = Math.max(0, ...valid.map(r => r.commits ?? 0)), maxShade = Math.max(0, ...valid.map(r => r.openIssues ?? 0))
  const unitsPerValue = maxValue > 0 ? MAX_HEIGHT / maxValue : 0     // linear from zero
  const groups = [...new Set(valid.map(r => r.group))].sort()
  const towers: Tower[] = [], districts: District[] = []
  let cursor = 0
  groups.forEach((group, index) => {
    // Tallest at the back of each district so short towers are not hidden from the default view.
    const members = valid.filter(r => r.group === group).sort((a, b) => (a.commits ?? -1) - (b.commits ?? -1) || a.id.localeCompare(b.id))
    const columns = Math.ceil(Math.sqrt(members.length)), rows = Math.ceil(members.length / columns)
    const width = columns * LOT, depth = rows * LOT
    members.forEach((r, i) => {
      const column = i % columns, row = Math.floor(i / columns)
      towers.push({ id: r.id, group, value: r.commits, shade: r.openIssues, size: TOWER, order: i,
        x: cursor + column * LOT + LOT / 2, z: (rows - 1 - row) * LOT + LOT / 2 - depth / 2,
        height: r.commits === null ? FLAT : Math.max(FLAT, r.commits * unitsPerValue),
        tone: r.commits === null ? null : maxShade > 0 && r.openIssues !== null ? r.openIssues / maxShade : 0 })
    })
    districts.push({ id: group, index, x: cursor + width / 2, z: 0, width, depth, count: members.length })
    cursor += width + STREET
  })
  const span = cursor - STREET, shift = span / 2
  towers.forEach(t => { t.x -= shift }); districts.forEach(d => { d.x -= shift })
  return { towers, districts, maxValue, maxShade, unitsPerValue, rejected, span }
}

/** Synthetic sample, seeded so every run draws the same city. */
export function sampleRecords(seed = 7): RepoRecord[] {
  let s = seed; const rnd = () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296
  const out: RepoRecord[] = []
  ;['docs', 'infra', 'mobile', 'platform', 'web'].forEach((group, g) => {
    const n = 5 + Math.floor(rnd() * 5)
    for (let i = 0; i < n; i++) out.push({ id: `${group}-${String(i + 1).padStart(2, '0')}`, group, commits: Math.round(20 + rnd() * rnd() * 900 * (1 + g / 3)), openIssues: Math.round(rnd() * 60) })
  })
  out[3].commits = 0                  // a real zero: a flat lot that still has a value
  out[10].commits = null              // unavailable: grey flat lot, left out of the scale
  out.push({ id: 'web-01', group: 'web', commits: 5, openIssues: 1 })          // duplicate id -> rejected
  out.push({ id: 'infra-99', group: 'infra', commits: -4, openIssues: 0 })     // negative -> rejected
  return out
}
export const city = buildCity(sampleRecords())
export const tallest = city.towers.reduce((a, b) => (b.height > a.height ? b : a))
