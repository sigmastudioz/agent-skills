"""Adapter for the existing owned loopback frame encoder; no second encoder implementation."""
from pathlib import Path
from functools import partial
import importlib.util,json,sys
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parent.parent
ENGINE=ROOT/'engine'
if not ENGINE.exists():ENGINE=ROOT.parent/'visual-demos/source'
sys.path.insert(0,str(ENGINE))
spec=importlib.util.spec_from_file_location('sigma_capture_backend',ENGINE/'server.py')
backend=importlib.util.module_from_spec(spec);spec.loader.exec_module(backend)
backend.ROOT=ROOT/'public';backend.PORT=8776
backend.SPECS={'visualizer-r3f':(1920,1080,60,36),'smoke':(1280,720,60,2)}
(backend.ROOT/'exports').mkdir(parents=True,exist_ok=True)
class Handler(backend.Handler):
 def do_POST(self):
  job=backend.JOB
  super().do_POST()
  if self.path=='/finish' and job and backend.JOB is None and job['target'].exists():
   receipt=backend.ROOT/'exports'/f'{job["name"]}-render.json'
   data=json.loads(receipt.read_text());data['engine']='React Three Fiber9.8.2 / Drei10.7.9 / Three.js0.186.1';data['capture']='RootState.advance at explicit frame seconds; GPU readPixels;2-frame bounded batches';receipt.write_text(json.dumps(data,indent=2)+'\n')
if __name__=='__main__':
 server=ThreadingHTTPServer(('127.0.0.1',8777),partial(Handler,directory=str(backend.ROOT)))
 print('Encoder127.0.0.1:8777; accepts only Origin http://127.0.0.1:8776',flush=True)
 try:server.serve_forever()
 finally:
  server.server_close()
  if backend.JOB:
   backend.JOB['process'].kill();backend.JOB['process'].wait();backend.JOB['log'].close()
