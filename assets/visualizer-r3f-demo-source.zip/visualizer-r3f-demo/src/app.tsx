import React,{useCallback,useEffect,useRef,useState,Component,type ErrorInfo,type ReactNode} from 'react'
import {createRoot} from 'react-dom/client'
import {Canvas,type RootState} from '@react-three/fiber'
import * as THREE from 'three'
import '@fontsource-variable/manrope'
import './style.css'
import {FilmScene} from './scene'
import {InteractionSound} from './feedback'
import {timeline,type Controls,type Envelope} from './model'
import {SHOTS} from './pump'
import {pumpState,shotAt as authoredShot} from './layout'

class SceneBoundary extends Component<{children:ReactNode;onError:(s:string)=>void},{bad:boolean}>{
 state={bad:false};static getDerivedStateFromError(){return {bad:true}}
 componentDidCatch(e:Error,_:ErrorInfo){this.props.onError(e.message)}
 render(){return this.state.bad?<p>3D preview unavailable. The ordinary video player remains available below.</p>:this.props.children}
}
async function post(path:string,body:BodyInit){const r=await fetch('/capture'+path,{method:'POST',body});const data=await r.json();if(!r.ok)throw Error(data.error??'Capture failed');return data}
function App(){
 const feedback=useRef(new InteractionSound()),video=useRef<HTMLVideoElement>(null),mounted=useRef(true)
 const controls=useRef<Controls>({seconds:1.2,effects:true,selected:false,pointer:[0,0],cutaway:null,shot:null,notes:null})
 const root=useRef<RootState|null>(null),audio=useRef<HTMLAudioElement>(null),raf=useRef(0),last=useRef(0),cancel=useRef(false)
 const playing=useRef(false),busy=useRef(false)
 const [env,setEnv]=useState<Envelope|null>(null),[ready,setReady]=useState(false),[seconds,setSeconds]=useState(1.2),[selected,setSelected]=useState(false),[overrides,setOverrides]=useState<{cutaway:boolean|null;shot:number|null;notes:boolean|null}>({cutaway:null,shot:null,notes:null})
 const [gpuLost,setGpuLost]=useState(false)
 const [status,setStatus]=useState('Loading the local score and typeface…'),[fault,setFault]=useState(''),[muted,setMuted]=useState(true),[volume,setVolume]=useState(.8),[motion,setMotion]=useState(!matchMedia('(prefers-reduced-motion: reduce)').matches),[isPlaying,setIsPlaying]=useState(false),[exporting,setExporting]=useState(false),[effects,setEffects]=useState(true)
 const draw=useCallback((t:number)=>{controls.current.seconds=t;if(root.current?.gl.getContext().isContextLost())return;try{root.current?.advance(t)}catch(e){setFault(String(e));playing.current=false;if(busy.current)throw e}},[])
 const stop=useCallback(()=>{playing.current=false;cancelAnimationFrame(raf.current);audio.current?.pause();setIsPlaying(false)},[])
 const seek=useCallback((t:number)=>{if(busy.current)return;stop();draw(t);setSeconds(t);if(audio.current&&audio.current.readyState>=1)audio.current.currentTime=t},[draw,stop])
 const toggleSelection=useCallback(()=>{controls.current.selected=!controls.current.selected;setSelected(controls.current.selected);feedback.current.play(controls.current.selected?4:1,volume,!muted&&!busy.current);draw(controls.current.seconds)},[draw,volume,muted])
 useEffect(()=>{
  const abort=new AbortController()
  Promise.all([fetch('/audio/envelope.json',{signal:abort.signal}).then(r=>{if(!r.ok)throw Error('Score envelope missing');return r.json()}),document.fonts.load('650 96px "Manrope Variable"')]).then(([e])=>{if(abort.signal.aborted)return;if(!e.levels?.length)throw Error('Invalid score envelope');setEnv(e);setStatus('Preparing the React Three Fiber scene…')}).catch(e=>{if(e.name!=='AbortError')setFault(String(e))})
  return()=>abort.abort()
 },[])
 const created=useCallback((s:RootState)=>{
  root.current=s;s.gl.toneMappingExposure=1.12
  s.gl.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();stop();cancel.current=true;setReady(false);setGpuLost(true);setFault('WebGL context lost. Reload the preview, or use the ordinary film player below.')})
  // Wait for React/Drei effects to commit, then prime the environment and offscreen buffers.
  requestAnimationFrame(()=>requestAnimationFrame(async()=>{
   if(!mounted.current)return
   try{for(let i=0;i<3;i++)s.advance(1.2);await s.gl.compileAsync(s.scene,s.camera);s.advance(1.2);setReady(true);setStatus('Ready · React Three Fiber9.8.2 / Drei10.7.9 · sound starts only after a click.')}catch(e){setFault(String(e))}
  }))
 },[stop])
 useEffect(()=>{
  mounted.current=true
  const preference=matchMedia('(prefers-reduced-motion: reduce)')
  const change=()=>{if(preference.matches){setMotion(false);stop()}}
  const leave=()=>{cancel.current=true;stop();if(busy.current)navigator.sendBeacon('/capture/cancel','')}
  preference.addEventListener('change',change);window.addEventListener('pagehide',leave)
  return()=>{mounted.current=false;preference.removeEventListener('change',change);window.removeEventListener('pagehide',leave);feedback.current.close()}
 },[stop])
 useEffect(()=>{const hidden=()=>{if(document.hidden&&!busy.current)stop()};document.addEventListener('visibilitychange',hidden);return()=>{document.removeEventListener('visibilitychange',hidden);stop()}},[stop])
 async function play(){
  if(busy.current||!ready)return
  if(!motion){setStatus('Motion is paused by preference. Seek or choose a chapter.');return}
  if(playing.current){stop();return}
  if(controls.current.seconds>=36)draw(0)
  playing.current=true;setIsPlaying(true);last.current=performance.now()
  const a=audio.current;if(a&&a.readyState>=1){a.currentTime=controls.current.seconds;await a.play().catch(()=>setStatus('Playback started; enable sound with its button if desired.'))}
  function tick(now:number){if(!playing.current)return;const t=Math.min(36,a&&!a.paused?a.currentTime:controls.current.seconds+Math.min(.1,(now-last.current)/1000));last.current=now;draw(t);setSeconds(t);if(t>=36)stop();else raf.current=requestAnimationFrame(tick)}
  raf.current=requestAnimationFrame(tick)
 }
 async function render(kind:'visualizer-r3f'|'smoke'){
  if(busy.current||!root.current||!ready)return
  busy.current=true;setExporting(true);cancel.current=false;stop();setFault('')
  const s=root.current,old={...controls.current},size={...s.size}
  try{
   const config=await post('/start',JSON.stringify({name:kind}));Object.assign(controls.current,{cutaway:null,shot:null,notes:null,effects:true,selected:false})
   s.setDpr(1);s.setSize(config.width,config.height);await s.gl.compileAsync(s.scene,s.camera)
   const gl=s.gl.getContext(),bytes=config.width*config.height*4,chunk=new Uint8Array(bytes*2),start=performance.now()
   for(let i=0;i<config.frames;i+=2){
    if(cancel.current)throw Error('Render cancelled; partial output retained')
    for(let j=0;j<2&&i+j<config.frames;j++){
     // A layout change can make the canvas observer resize the drawing buffer mid-export; hold the export size.
     if(s.gl.domElement.width!==config.width||s.gl.domElement.height!==config.height){s.setSize(config.width,config.height);await new Promise(r=>requestAnimationFrame(()=>r(null)))}
     draw((i+j)/config.fps+0);gl.readPixels(0,0,config.width,config.height,gl.RGBA,gl.UNSIGNED_BYTE,chunk.subarray(j*bytes,(j+1)*bytes))
     if(gl.getError()!==gl.NO_ERROR)throw Error('GPU readback failed')
    }
    await post('/frames?seq='+i,chunk)
    if(i%30===0)setStatus(`Rendering ${Math.round((i+2)/config.frames*100)}% · ${i+2}/${config.frames} actual R3F frames`)
   }
   const result=await post('/finish','');video.current?.load();setStatus(`Export verified · ${result.file} · ${result.frames} frames · ${((performance.now()-start)/1000).toFixed(1)}s render time`)
  }catch(e){setFault(String(e));await post('/cancel','').catch(()=>{});setStatus('Export stopped. Existing completed films are preserved.')}
  finally{Object.assign(controls.current,old);s.setSize(size.width,size.height);draw(old.seconds);busy.current=false;setExporting(false)}
 }
 const override=useCallback((patch:Partial<{cutaway:boolean|null;shot:number|null;notes:boolean|null}>)=>{if(busy.current)return;Object.assign(controls.current,patch);setOverrides(o=>({...o,...patch}));draw(controls.current.seconds)},[draw])
 const authored=overrides.cutaway===null&&overrides.shot===null&&overrides.notes===null
 const live=pumpState(seconds,controls.current),liveShot=overrides.shot??authoredShot(seconds).index
 useEffect(()=>{
  // Hotkeys never fire while the viewer is typing or holding a modifier.
  const onKey=(e:KeyboardEvent)=>{
   const el=e.target as HTMLElement
   if(e.metaKey||e.ctrlKey||e.altKey||el.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName))return
   const index=SHOTS.findIndex(s=>s.key===e.key)
   if(index>=0)override({shot:index})
   else if(e.key==='c'||e.key==='C')override({cutaway:!(pumpState(controls.current.seconds,controls.current).cut>.5)})
   else if(e.key==='a'||e.key==='A')override({notes:!(controls.current.notes??true)})
   else if(e.key==='b'||e.key==='B'){const now=controls.current.seconds,scene=timeline.scenes.find(s=>now>=s.start&&now<s.end)??timeline.scenes[0],i=timeline.scenes.indexOf(scene);seek(now-scene.start<=.6&&i>0?timeline.scenes[i-1].start:scene.start)}
   else if(e.key==='r'||e.key==='R'){override({cutaway:null,shot:null,notes:null});seek(0)}
  }
  window.addEventListener('keydown',onKey);return()=>window.removeEventListener('keydown',onKey)
 },[override,seek])
 return <main>
  <header><div><span className="eyebrow">LEX FROM SIGMASTUDIOZ</span><h1>Visualizer / data city and explainer controls</h1></div><a href="#film">Watch the export ↗</a></header>
  <section className="stage" aria-label="Interactive React Three Fiber scene">
   {env&&<SceneBoundary onError={setFault}><Canvas style={{visibility:gpuLost?'hidden':'visible'}} frameloop="never" dpr={1} camera={{position:[0,.5,12.6],fov:37,near:.1,far:60}} gl={{antialias:true,preserveDrawingBuffer:true,alpha:false}} onCreated={created} fallback={<p>WebGL unavailable. Use the film player below.</p>}><FilmScene controls={controls} envelope={env} onSelect={toggleSelection}/></Canvas></SceneBoundary>}
   {gpuLost&&<div className="fallback"><h2>The film is still available.</h2><p>The GPU preview stopped. Watch the exported film below, or reload the scene.</p><button onClick={()=>location.reload()}>Reload scene</button><a href="#film">Watch the film</a></div>}
  </section>
  <section className="transport"><button onClick={play} disabled={!ready||exporting}>{isPlaying?'Pause':'Play'}</button><button disabled={exporting} aria-keyshortcuts="R" onClick={()=>{override({cutaway:null,shot:null,notes:null});controls.current.selected=false;setSelected(false);seek(0)}}>Reset (R)</button><label className="seek">Time <input aria-label="Scene time" type="range" min="0" max="36" step=".01" value={seconds} disabled={exporting} onChange={e=>seek(Number(e.target.value))}/><output>{seconds.toFixed(2)} /36s</output></label></section>
  <nav aria-label="Chapters">{timeline.scenes.map(s=><button key={s.id} disabled={exporting} onClick={()=>seek(s.start+.95)}>{s.eyebrow.split('/').at(-1)?.trim()}</button>)}</nav>
  <section className="options">
   <button disabled={exporting} aria-pressed={live.cut>.5} aria-keyshortcuts="C" onClick={()=>override({cutaway:!(live.cut>.5)})}>Cutaway (C)</button>
   {SHOTS.map((shot,i)=><button key={shot.key} disabled={exporting} aria-pressed={liveShot===i} aria-keyshortcuts={shot.key} onClick={()=>override({shot:i})}>{shot.key} · {shot.name}</button>)}
   <button disabled={exporting} aria-pressed={live.notes} aria-keyshortcuts="A" onClick={()=>override({notes:!live.notes})}>Notes (A)</button>
   <button disabled={exporting||authored} onClick={()=>override({cutaway:null,shot:null,notes:null})}>Authored scenario</button>
   <button disabled={exporting} aria-pressed={selected} onClick={toggleSelection}>{selected?'Tallest tower selected':'Select tallest tower'}</button>
   <button disabled={exporting} aria-pressed={!muted} onClick={()=>{const next=!muted;setMuted(next);if(audio.current)audio.current.muted=next;feedback.current.setVolume(volume,!next);feedback.current.play(2,volume,!next)}}>{muted?'Sound off':'Sound on'}</button>
   <label>Volume<input aria-label="Volume" type="range" min="0" max="1" step=".05" value={volume} onChange={e=>{const v=Number(e.target.value);setVolume(v);if(audio.current)audio.current.volume=v;feedback.current.setVolume(v,!muted)}}/></label>
   <button aria-pressed={!motion} onClick={()=>{setMotion(!motion);if(motion)stop()}}>{motion?'Motion on':'Motion off'}</button>
   <button disabled={exporting} aria-pressed={!effects} onClick={()=>{controls.current.effects=!effects;setEffects(!effects);draw(seconds)}}>{effects?'Effects on':'Effects reduced'}</button>
  </section>
  <p className="summary" aria-live="polite">{authored?'Authored scenario':'Manual overrides'} · cutaway {live.cut>.5?'on':'off'} · shot {liveShot+1} ({SHOTS[liveShot].name}) · notes {live.notes?'on':'off'} · pump clock {live.tau.toFixed(1)} s · {selected?'tallest tower selected':'no selection'}</p>
  <p className="status" role="status">{status}</p>{fault&&<p className="error" role="alert">{fault}</p>}
  <details><summary>Render controls / local encoder required</summary><p>Captures the fixed authored scenario and full materials at exact frame times. Interactive overrides are restored afterwards. Existing completed exports are never overwritten.</p><button disabled={exporting||!ready} onClick={()=>render('smoke')}>Render 2-second study</button><button disabled={exporting||!ready} onClick={()=>render('visualizer-r3f')}>Render 1080p60 film</button><button disabled={!exporting} onClick={()=>{cancel.current=true}}>Cancel render</button><button disabled={exporting||!ready} onClick={()=>{const extension=root.current?.gl.getContext().getExtension('WEBGL_lose_context');if(extension)extension.loseContext();else setStatus('The context-loss test extension is unavailable here.')}}>Test GPU fallback</button></details>
  <section id="film"><h2>The finished film</h2><video ref={video} controls preload="metadata" poster="/poster.png"><source src="/exports/visualizer-r3f.mp4" type="video/mp4"/><track kind="captions" src="/captions.vtt" srcLang="en" label="English scene summaries"/></video><p><a href="/exports/visualizer-r3f.mp4" download>Download MP4</a> · <a href="/captions.srt" download>Captions</a></p></section>
  <audio ref={audio} src="/audio/visualizer.wav" preload="metadata" muted={muted} onLoadedMetadata={()=>{if(audio.current)audio.current.volume=volume}}/>
  <footer>By Lex from SigmaStudioz · Original geometry and score · Synthetic data · An authored demo, not a recorded agent session</footer>
 </main>
}
createRoot(document.getElementById('root')!).render(<App/> )
