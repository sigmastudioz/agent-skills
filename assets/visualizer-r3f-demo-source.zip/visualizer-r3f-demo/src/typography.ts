import * as THREE from 'three'
import { sample, ease, clamp, timeline, type Controls, type Envelope } from './model'
import {nodes,worldAt,networkStrength,hudWeights} from './layout'
const FG='#e8ede1', MUTED='#90ada5', ACCENT='#b5d6ba', COPPER='#dcaa7a'
export class Hud {
 canvas=document.createElement('canvas');ctx:CanvasRenderingContext2D;texture:THREE.CanvasTexture
 anchor=new THREE.Object3D();labelPoint=new THREE.Vector3()
 scene=new THREE.Scene();camera=new THREE.OrthographicCamera(-1,1,1,-1,0,1)
 plane:THREE.Mesh<THREE.PlaneGeometry,THREE.MeshBasicMaterial>
 constructor(){
  this.canvas.width=1920;this.canvas.height=1080;this.ctx=this.canvas.getContext('2d')!
  this.texture=new THREE.CanvasTexture(this.canvas);this.texture.colorSpace=THREE.SRGBColorSpace
  this.plane=new THREE.Mesh(new THREE.PlaneGeometry(2,2),new THREE.MeshBasicMaterial({map:this.texture,transparent:true,depthTest:false,depthWrite:false,toneMapped:false}))
  this.scene.add(this.plane)
 }
 text(text:string,x:number,y:number,size:number,color=FG,weight=500,spacing=0){
  const c=this.ctx;c.font=`${weight} ${size}px "Manrope Variable", sans-serif`;c.fillStyle=color;c.textBaseline='alphabetic'
  if(!spacing){c.fillText(text,x,y);return}
  for(const letter of text){c.fillText(letter,x,y);x+=c.measureText(letter).width+spacing}
 }
 wrap(text:string,x:number,y:number,size:number,width:number,color=FG,weight=500,max=2){
  const c=this.ctx;c.font=`${weight} ${size}px "Manrope Variable", sans-serif`;let line='',n=0
  for(const word of text.split(' ')){
   const next=(line+' '+word).trim()
   if(c.measureText(next).width>width&&line){this.text(line,x,y+n*size*1.45,size,color,weight);line=word;n++}else line=next
  }
  this.text(line,x,y+n*size*1.45,size,color,weight)
  if(n+1>max)throw Error(`Text overflow: ${text}`)
 }
 line(x:number,y:number,w:number,color=MUTED,alpha=.3){const c=this.ctx;c.save();c.globalAlpha*=alpha;c.strokeStyle=color;c.lineWidth=1;c.beginPath();c.moveTo(x,y);c.lineTo(x+w,y);c.stroke();c.restore()}
 draw(control:Controls,envelope:Envelope,camera:THREE.Camera){
  const c=this.ctx,t=control.seconds,s=sample(t,control.arrival),shot=s.shot,hud=hudWeights(s)
  c.clearRect(0,0,1920,1080)
  // Subtle vignette keeps original geometry and typography in separate visual planes.
  const gradient=c.createLinearGradient(0,0,1060,0);gradient.addColorStop(0,'rgba(7,23,25,.80)');gradient.addColorStop(.65,'rgba(7,23,25,.18)');gradient.addColorStop(1,'rgba(7,23,25,0)');c.fillStyle=gradient;c.fillRect(0,0,1140,1080)
  this.text('SIGMASTUDIOZ',100,88,23,MUTED,650,3)
  this.text('VISUALIZER  /  A MATERIAL STUDY',1290,88,17,MUTED,600,1.5)
  this.line(100,121,1720,MUTED,.24)
  const entering=ease((t-shot.start)/.75),leaving=shot.id==='signature'?1:1-ease((t-shot.end+.45)/.45)
  c.save();c.globalAlpha=entering*leaving
  const lift=(1-entering)*20
  this.text(shot.eyebrow,102,322+lift,18,ACCENT,650,1.5)
  shot.title.forEach((line,i)=>this.text(line,94,445+i*108+lift,shot.id==='signature'?119:94,FG,650,-3))
  this.wrap(shot.body,102,shot.title.length===1?566:628,27,685,MUTED,500,2)
  if(shot.id==='signature'){
   this.line(104,680,130,ACCENT,.7)
   this.text('npx skills add sigmastudioz/agent-skills',103,744,23,FG,550)
   this.text('--skill visualizer',103,782,23,ACCENT,550)
   this.text('github.com/sigmastudioz/agent-skills',103,839,20,MUTED,500)
  }
  c.restore()
  const network=networkStrength(s)
  if(network>.01){
   const view=worldAt(t);this.anchor.position.set(...view.position);this.anchor.rotation.set(...view.rotation);this.anchor.updateMatrixWorld(true)
   c.save();c.globalAlpha=network
   for(const node of nodes){
    this.labelPoint.set(...node.position).applyMatrix4(this.anchor.matrixWorld).project(camera)
    const x=(this.labelPoint.x+1)*960,y=(1-this.labelPoint.y)*540+(node.id==='output'?-34:49)
    c.font='600 17px "Manrope Variable"';const width=c.measureText(node.label).width
    this.text(node.label,x-width/2,y,17,MUTED,600,1)
   }
   c.restore()
  }
  if(hud.control>.01){
   c.save();c.globalAlpha=hud.control
   this.text('ILLUSTRATIVE FLUID QUEUE',1090,760,18,MUTED,650,1)
   this.text(`${s.model.arrival.toFixed(0)} arrivals/s`,1090,807,27,FG,650)
   this.text('3 served/s',1420,807,27,MUTED,500)
   c.fillStyle='#24413e';c.fillRect(1090,835,600,4);c.fillStyle=COPPER;c.fillRect(1090,835,600*clamp(s.model.queue/9),4)
   this.text(`${s.model.queue.toFixed(1)} items waiting`,1090,880,27,s.model.queue>0?COPPER:ACCENT,650)
   c.restore()
  }
  if(hud.material>.01){
   c.save();c.globalAlpha=hud.material
   for(const [i,label] of ['REFRACTION','BRUSHED ALLOY','PROCEDURAL INK'].entries()){
    const x=1060+i*245;c.fillStyle=[ACCENT,COPPER,'#8ac1b5'][i];c.beginPath();c.arc(x,829,4,0,Math.PI*2);c.fill();this.text(label,x+16,835,15,MUTED,650,.5)
   }
   // These marks are actual measured WAV envelope samples, not fabricated spectrum bins.
   const frame=Math.floor(t*envelope.fps)
   c.fillStyle='#78a598';for(let i=0;i<66;i++){const q=envelope.levels[clamp(frame-65+i,0,envelope.levels.length-1)]??0;c.fillRect(1060+i*10,883-q*23,3,2+q*23)}
   this.text('SOUND ENVELOPE / MEASURED RMS',1060,919,14,MUTED,600,1)
   c.restore()
  }
  if(hud.clock>.01){
   c.save();c.globalAlpha=hud.clock
   this.text('INTERACTIVE',1141,774,17,ACCENT,650,1)
   this.text('FILM',1530,774,17,ACCENT,650,1)
   const time=`${t.toFixed(2)} s / seed ${timeline.seed}`
   this.text(time,1112,818,19,MUTED,500);this.text(time,1470,818,19,MUTED,500)
   this.line(1090,855,625,MUTED,.45);const f=clamp((t-25)/6)
   for(let i=0;i<31;i++){c.fillStyle=i/30<f?ACCENT:'#36534d';c.fillRect(1090+i*20,849,i%5===0?2:1,i%5===0?16:9)}
   this.text(`FRAME ${String(Math.floor(t*60)).padStart(4,'0')} / 2160`,1090,907,16,MUTED,600,1)
   c.restore()
  }
  this.line(100,962,1720,MUTED,.25)
  this.text('By Lex from SigmaStudioz',100,1021,23,FG,600)
  this.text('REACT THREE FIBER  ·  ORIGINAL GEOMETRY + SCORE',1110,1021,15,MUTED,600,1)
  c.save();c.globalAlpha=.45
  this.text('Authored demonstration · Illustrative data',100,1053,14,MUTED,500)
  this.text(`${String(Math.floor(t/60)).padStart(2,'0')}:${(t%60).toFixed(2).padStart(5,'0')}  /  00:36`,1610,1053,15,MUTED,500)
  c.restore()
  // Picture and type share the same fade; black is intentional only at the endpoints.
  if(s.fade<1){c.fillStyle=`rgba(7,23,25,${1-s.fade})`;c.fillRect(0,0,1920,1080)}
  this.texture.needsUpdate=true
 }
 dispose(){this.plane.geometry.dispose();this.plane.material.dispose();this.texture.dispose()}
}
