import * as THREE from 'three'
import { sample, ease, clamp, timeline, type Controls, type Envelope } from './model'
import {cityAt,pumpState,shotAt,keyTime,CENTER} from './layout'
import {city,tallest} from './city'
import {BEATS,NOTES,SHOTS,PUMP_DURATION,beatIndexAt} from './pump'
const fmt=(v:number|null)=>v===null?'no data':v.toLocaleString('en-US')
const FG='#e8ede1', MUTED='#90ada5', ACCENT='#b5d6ba', COPPER='#dcaa7a'
export class Hud {
 canvas=document.createElement('canvas');ctx:CanvasRenderingContext2D;texture:THREE.CanvasTexture
 anchor=new THREE.Object3D();labelPoint=new THREE.Vector3();toCamera=new THREE.Vector3();centre=new THREE.Vector3(...CENTER)
 scene=new THREE.Scene();camera=new THREE.OrthographicCamera(-1,1,1,-1,0,1)
 plane:THREE.Mesh<THREE.PlaneGeometry,THREE.MeshBasicMaterial>
 constructor(){
  this.canvas.width=1920;this.canvas.height=1080;this.ctx=this.canvas.getContext('2d')!
  this.texture=new THREE.CanvasTexture(this.canvas);this.texture.colorSpace=THREE.SRGBColorSpace
  this.plane=new THREE.Mesh(new THREE.PlaneGeometry(2,2),new THREE.MeshBasicMaterial({map:this.texture,transparent:true,depthTest:false,depthWrite:false,toneMapped:false}))
  this.scene.add(this.plane)
 }
 text(text:string,x:number,y:number,size:number,color=FG,weight=500,spacing=0){
  const c=this.ctx;c.font=`${weight} ${size}px "Manrope Variable", sans-serif`;c.fillStyle=color;c.textBaseline='alphabetic'
  if(!spacing){c.fillText(text,x,y);return}
  for(const letter of text){c.fillText(letter,x,y);x+=c.measureText(letter).width+spacing}
 }
 wrap(text:string,x:number,y:number,size:number,width:number,color=FG,weight=500,max=2){
  const c=this.ctx;c.font=`${weight} ${size}px "Manrope Variable", sans-serif`;let line='',n=0
  // When the text needs two lines, break where the lines are closest in length (no orphaned last word).
  const words=text.split(' ')
  if(c.measureText(text).width>width){
   let best=1,gap=Infinity
   for(let i=1;i<words.length;i++){const a=c.measureText(words.slice(0,i).join(' ')).width,b=c.measureText(words.slice(i).join(' ')).width;if(a<=width&&b<=width&&Math.abs(a-b)<gap){gap=Math.abs(a-b);best=i}}
   if(gap<Infinity){this.text(words.slice(0,best).join(' '),x,y,size,color,weight);this.text(words.slice(best).join(' '),x,y+size*1.45,size,color,weight);return}
  }
  for(const word of words){
   const next=(line+' '+word).trim()
   if(c.measureText(next).width>width&&line){this.text(line,x,y+n*size*1.45,size,color,weight);line=word;n++}else line=next
  }
  this.text(line,x,y+n*size*1.45,size,color,weight)
  if(n+1>max)throw Error(`Text overflow: ${text}`)
 }
 line(x:number,y:number,w:number,color=MUTED,alpha=.3){const c=this.ctx;c.save();c.globalAlpha*=alpha;c.strokeStyle=color;c.lineWidth=1;c.beginPath();c.moveTo(x,y);c.lineTo(x+w,y);c.stroke();c.restore()}
 /** Project a point in a posed group's local space to HUD pixels (1920×1080). */
 project(local:readonly number[],camera:THREE.Camera):[number,number,boolean]{
  this.labelPoint.set(local[0],local[1],local[2]).applyMatrix4(this.anchor.matrixWorld).project(camera)
  return [(this.labelPoint.x+1)*960,(1-this.labelPoint.y)*540,this.labelPoint.z<1&&Math.abs(this.labelPoint.x)<=1&&Math.abs(this.labelPoint.y)<=1]
 }
 pose(position:readonly number[],rotation:readonly number[],scale:number){this.anchor.position.set(position[0],position[1],position[2]);this.anchor.rotation.set(rotation[0],rotation[1],rotation[2]);this.anchor.scale.setScalar(scale);this.anchor.updateMatrixWorld(true)}
 label(text:string,x:number,y:number,size=17,color=FG){
  const c=this.ctx;c.font=`600 ${size}px "Manrope Variable", sans-serif`;const w=c.measureText(text).width
  c.fillStyle='rgba(7,23,25,.86)';c.strokeStyle='rgba(144,173,165,.7)';c.lineWidth=1
  c.beginPath();c.roundRect(x-9,y-size-7,w+18,size+15,5);c.fill();c.stroke()
  this.text(text,x,y,size,color,600)
 }
 keycap(key:string,x:number,y:number,state:'idle'|'on'|'hit'){
  const c=this.ctx;c.lineWidth=state==='idle'?1:2
  c.fillStyle=state==='hit'?ACCENT:'rgba(20,44,44,.9)';c.strokeStyle=state==='idle'?'rgba(144,173,165,.55)':ACCENT
  c.beginPath();c.roundRect(x,y,46,46,7);c.fill();c.stroke()
  c.font='650 22px "Manrope Variable", sans-serif';const w=c.measureText(key).width
  this.text(key,x+23-w/2,y+31,22,state==='hit'?'#0b2224':state==='on'?ACCENT:MUTED,650)
 }
 draw(control:Controls,envelope:Envelope,camera:THREE.Camera){
  const c=this.ctx,t=control.seconds,s=sample(t),shot=s.shot
  c.clearRect(0,0,1920,1080)
  // Subtle vignette keeps original geometry and typography in separate visual planes.
  const gradient=c.createLinearGradient(0,0,1060,0);gradient.addColorStop(0,'rgba(7,23,25,.80)');gradient.addColorStop(.65,'rgba(7,23,25,.18)');gradient.addColorStop(1,'rgba(7,23,25,0)');c.fillStyle=gradient;c.fillRect(0,0,1140,1080)
  this.text('SIGMASTUDIOZ',100,88,23,MUTED,650,3)
  this.text('VISUALIZER  /  DATA CITY + EXPLAINER CONTROLS',1166,88,17,MUTED,600,1.5)
  this.line(100,121,1720,MUTED,.24)
  const entering=ease((t-shot.start)/.75),leaving=shot.id==='signature'?1:1-ease((t-shot.end+.45)/.45)
  c.save();c.globalAlpha=entering*leaving
  const lift=(1-entering)*20
  this.text(shot.eyebrow,102,322+lift,18,ACCENT,650,1.5)
  shot.title.forEach((line,i)=>this.text(line,94,445+i*108+lift,shot.id==='signature'?119:94,FG,650,-3))
  this.wrap(shot.body,102,shot.title.length===1?566:628,27,685,MUTED,500,2)
  if(shot.id==='signature'){
   this.line(104,680,130,ACCENT,.7)
   this.text('npx skills add sigmastudioz/agent-skills',103,744,23,FG,550)
   this.text('--skill visualizer',103,782,23,ACCENT,550,.6)
   this.text('github.com/sigmastudioz/agent-skills',103,839,20,MUTED,500)
  }
  c.restore()
  if(s.city>.01){
   const pose=cityAt(t);this.pose(pose.position,pose.rotation,pose.scale)
   c.save();c.globalAlpha=s.city
   // District names sit on the ground in front of each district and follow the camera.
   for(const d of city.districts){
    const shown=ease((t-timeline.events.district_rise[d.index])/.5);if(shown<.02)continue
    const [x,y]=this.project([d.x,0,Math.max(...city.districts.map(k=>k.depth))/2+1.5],camera)
    c.save();c.globalAlpha*=shown;c.font='600 17px "Manrope Variable", sans-serif';const text=`${d.id.toUpperCase()} · ${d.count}`
    this.text(text,x-c.measureText(text).width/2,y+10,17,MUTED,600,.5);c.restore()
   }
   if(pose.selected||control.selected){
    const [x,y]=this.project([tallest.x,tallest.height,tallest.z],camera),k=control.selected?1:ease((t-timeline.events.select)/.35)
    c.save();c.globalAlpha*=k
    c.font='600 17px "Manrope Variable", sans-serif';const w=c.measureText(tallest.id).width,left=x+52+w+9>1800
    c.strokeStyle=COPPER;c.lineWidth=1.5;c.beginPath();c.moveTo(x,y);c.lineTo(left?x-46:x+46,y-46);c.stroke()
    c.fillStyle=COPPER;c.beginPath();c.arc(x,y,4,0,Math.PI*2);c.fill()
    this.label(tallest.id,left?x-52-w:x+52,y-44,17,COPPER);c.restore()
   }
   const px=1090,py=742
   this.text('DATA CITY  ·  SYNTHETIC, SEEDED SAMPLE',px,py,16,MUTED,650,1)
   this.text(`${city.towers.length} repositories  ·  ${city.districts.length} teams`,px,py+38,24,FG,600)
   this.text(`Left out: ${city.rejected.map(r=>`${r.id} (${r.reason.replace(' or missing id','').replace(' or non-finite','')})`).join(', ')}`,px,py+68,17,MUTED,550)
   this.text(`HEIGHT  0 – ${fmt(city.maxValue)} commits, linear from zero`,px,py+100,18,MUTED,600,.5)
   this.text('OPEN ISSUES  0',px,py+130,18,MUTED,600,.5)
   const ramp=c.createLinearGradient(px+170,0,px+310,0);ramp.addColorStop(0,'#e3efe2');ramp.addColorStop(1,'#2a7f7a');c.fillStyle=ramp;c.fillRect(px+170,py+117,140,13)
   this.text(String(city.maxShade),px+320,py+130,18,MUTED,600)
   c.fillStyle='#6f7773';c.fillRect(px+376,py+117,13,13);this.text('no data',px+397,py+130,18,MUTED,600)
   if(pose.selected||control.selected){
    c.save();c.globalAlpha*=control.selected?1:ease((t-timeline.events.select)/.35)
    this.text(`${tallest.id}  ·  ${fmt(tallest.value)} commits  ·  ${fmt(tallest.shade)} open issues`,px,py+170,24,COPPER,650);c.restore()
   }
   const view=pose.plan>.5?'PLAN VIEW  ·  HEIGHT REMOVED':'CITY VIEW'
   this.text(view,px,py+204,16,pose.plan>.5?COPPER:ACCENT,650,1)
   c.restore()
  }
  if(s.pump>.01){
   const state=pumpState(t,control),beat=beatIndexAt(state.tau),authored=control.shot===null&&control.cutaway===null
   this.pose(CENTER,[0,0,0],s.pump)
   c.save();c.globalAlpha=s.pump
   // Notes: a dot on the part, a leader and a label. A note for a part inside the casing waits for the cutaway.
   if(state.notes)for(const note of NOTES){
    if(state.tau<note.from||(note.inside&&state.cut<.6))continue
    const anchor=typeof note.anchor==='function'?note.anchor(state.tau):note.anchor
    const [x,y,visible]=this.project(anchor,camera);if(!visible)continue
    // A part that has turned behind the rotor is out of sight: its note fades with it.
    this.toCamera.copy(camera.position).sub(this.centre);const facing=note.moving?(anchor[0]*this.toCamera.x+anchor[2]*this.toCamera.z)/Math.hypot(this.toCamera.x,this.toCamera.z):1
    const k=ease((state.tau-note.from)/.4)*(note.inside?ease((state.cut-.6)/.4):1)*ease((s.pump-.55)/.4)*ease((facing+.8)/.25)
    if(k<.01)continue
    c.save();c.globalAlpha*=k;c.font='600 17px "Manrope Variable", sans-serif'
    const w=c.measureText(note.text).width,lx=note.side>0?x+58:x-58-w,ly=note.drop?y+74:y-52
    c.strokeStyle='rgba(232,237,225,.8)';c.lineWidth=1.25;c.beginPath();c.moveTo(x,y);c.lineTo(note.side>0?lx-9:lx+w+9,ly-6);c.stroke()
    c.fillStyle=FG;c.beginPath();c.arc(x,y,4,0,Math.PI*2);c.fill()
    this.label(note.text,lx,ly);c.restore()
   }
   const px=1090,py=760,keys=timeline.events.keys
   const current=control.shot!==null?control.shot:shotAt(t).index
   ;[['C',state.cut>.5],['1',current===0],['2',current===1],['3',current===2],['B',false]].forEach(([key,on],i)=>{
    const pressed=keys.find(k=>k.key===key)!.time,hit=authored&&t>=pressed&&t<pressed+.5
    this.keycap(key as string,px+i*58,py,hit?'hit':on?'on':'idle')
   })
   const last=[...keys].reverse().find(k=>t>=k.time)
   // One status line: the last key's effect in the film, the current shot in the live preview.
   this.text(authored&&last?last.label:`SHOT ${current+1} · ${SHOTS[current].name.toUpperCase()}`,px+312,py+31,18,ACCENT,650,1)
   // Beat bar: three beats of the explained scene and a playhead that jumps back on rewind.
   const bx=px,by=py+88,bw=600
   BEATS.forEach((b,i)=>{
    const x0=bx+bw*b.start/PUMP_DURATION,x1=bx+bw*(BEATS[i+1]?.start??PUMP_DURATION)/PUMP_DURATION
    c.fillStyle=i===beat?'#3f6b62':'#24413e';c.fillRect(x0+2,by,x1-x0-4,6)
   })
   const head=bx+bw*state.tau/PUMP_DURATION;c.fillStyle=COPPER;c.fillRect(head-2,by-8,4,22)
   const rewound=authored?t-keyTime('B'):-1
   if(rewound>=0&&rewound<1.4){
    c.save();c.globalAlpha*=1-ease((rewound-.9)/.5)
    const from=bx+bw*10/PUMP_DURATION,to=bx+bw*8/PUMP_DURATION
    c.strokeStyle=COPPER;c.lineWidth=2;c.beginPath();c.moveTo(from,by-14);c.quadraticCurveTo((from+to)/2,by-44,to,by-14);c.stroke()
    c.beginPath();c.moveTo(to,by-14);c.lineTo(to+11,by-17);c.moveTo(to,by-14);c.lineTo(to+4,by-25);c.stroke()
    this.text('10.0 s  to  8.0 s',from+14,by-26,16,COPPER,650);c.restore()
   }
   this.text(`BEAT ${beat+1} OF ${BEATS.length}`,bx,by+44,16,ACCENT,650,1)
   this.text(BEATS[beat].title,bx+128,by+45,20,FG,600)
   const clock=`${state.tau.toFixed(1)} s`;c.font='600 20px "Manrope Variable", sans-serif'
   this.text(clock,bx+bw-c.measureText(clock).width,by+45,20,MUTED,600)
   c.restore()
  }
  this.line(100,962,1720,MUTED,.25)
  this.text('By Lex from SigmaStudioz',100,1021,23,FG,600)
  this.text('REACT THREE FIBER  ·  ORIGINAL GEOMETRY + SCORE',1110,1021,15,MUTED,600,1)
  c.save();c.globalAlpha=.7
  this.text('Authored demonstration · Synthetic data',100,1053,16,MUTED,500)
  this.text(`${String(Math.floor(t/60)).padStart(2,'0')}:${(t%60).toFixed(2).padStart(5,'0')}  /  00:36`,1668,1053,16,MUTED,500)
  c.restore()
  // Picture and type share the same fade; black is intentional only at the endpoints.
  if(s.fade<1){c.fillStyle=`rgba(7,23,25,${1-s.fade})`;c.fillRect(0,0,1920,1080)}
  this.texture.needsUpdate=true
  void envelope
 }
 dispose(){this.plane.geometry.dispose();this.plane.material.dispose();this.texture.dispose()}
}
