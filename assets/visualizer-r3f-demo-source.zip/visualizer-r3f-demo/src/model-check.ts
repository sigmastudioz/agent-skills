import assert from 'node:assert/strict'
import {queueAt,sample,energyAt,timeline} from './model'
import {networkStrength,hudWeights} from './layout'
for(const [t,q] of [[0,0],[13,0],[14,2],[15,4],[16,6],[17,4],[19,0],[36,0]])assert.ok(Math.abs(queueAt(t).queue-q)<1e-9)
for(const t of [24.3,1.2,15.5,31.2,15.5])assert.deepEqual(sample(t),sample(t))
for(const rate of [0,3,6])assert.equal(queueAt(15,rate).queue,Math.max(0,(rate-3)*3))
for(const x of [NaN,Infinity,-1,37])assert.throws(()=>queueAt(x))
for(const x of [NaN,Infinity,-1,7])assert.throws(()=>queueAt(15,x))
for(let i=0;i<=2160;i++){const s=sample(i/60);assert.ok(s.model.queue>=0);for(const k of ['open','control','material','split','end','fade'] as const)assert.ok(s[k]>=0&&s[k]<=1)}
assert.equal(energyAt({fps:60,levels:[0,1],source_sha256:'test',method:'test'},1/120),.5)
assert.equal(timeline.scenes.at(-1)?.end,timeline.duration)
for(let i=1;i<timeline.scenes.length;i++)assert.equal(timeline.scenes[i-1].end,timeline.scenes[i].start)
console.log('PASS: queue analytic points, recovery, manual controls, invalid inputs,2161bounded samples, contiguous shots and envelope interpolation')

for(let i=0;i<=2160;i++){
 const t=i/60,s=sample(t),h=hudWeights(s)
 assert.ok([h.control,h.material,h.clock].filter(v=>v>.01).length<=1,'Overlapping explanatory callouts')
 if(t>=19.4)assert.equal(networkStrength(s),0,'Retired graph must not reappear')
}
console.log('PASS: phase visibility never resurrects retired graph; explanatory callouts never overlap')
