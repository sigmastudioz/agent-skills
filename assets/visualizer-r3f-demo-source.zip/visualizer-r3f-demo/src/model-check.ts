import assert from 'node:assert/strict'
import {sample,energyAt,timeline,backOut} from './model'
import {cityAt,towerRise,pumpClock,pumpState,shotAt,cameraAt,keyTime} from './layout'
import {city,tallest,buildCity,MAX_HEIGHT} from './city'
import {BEATS,rewindTarget,poseAt,VANE_PASS_HZ,ROTOR_RAD_PER_S,SHOTS} from './pump'

// Data city: contract, scale and the two non-values.
assert.equal(city.towers.length,37);assert.deepEqual(city.rejected.map(r=>r.id).sort(),['infra-99','web-01'])
for(const t of city.towers)if(t.value)assert.ok(Math.abs(t.height/t.value-city.unitsPerValue)<1e-9,'height is proportional to value')
assert.equal(tallest.value,city.maxValue);assert.ok(Math.abs(tallest.height-MAX_HEIGHT)<1e-9)
assert.equal(city.towers.filter(t=>t.value===null).length,1);assert.ok(city.towers.find(t=>t.value===0)!.height<.1)
assert.equal(buildCity([]).towers.length,0)
assert.ok(Math.abs(backOut(1)-1)<1e-12&&Math.abs(backOut(0))<1e-12&&Math.max(...Array.from({length:101},(_,i)=>backOut(i/100)))>1.09)
assert.ok(Math.abs(towerRise(13,0,0)-1)<1e-12&&Math.abs(towerRise(5.9,0,0))<1e-12)
console.log('PASS: 37 towers, 2 rejected, proportional heights, zero and no-data kept apart, pop-in overshoots then settles at 1')

// Explainer: beats, the rewind rule and one clock.
assert.equal(rewindTarget(5.5),4);assert.equal(rewindTarget(4.3),0);assert.equal(rewindTarget(10),8);assert.equal(rewindTarget(0.2),0)
const B=keyTime('B');assert.ok(Math.abs(pumpClock(B-1e-9)-10)<1e-6);assert.equal(pumpClock(B),8);assert.equal(pumpClock(B+1.5),9.5);assert.equal(pumpClock(36),12)
assert.deepEqual(poseAt(9.25),poseAt(9.25));assert.ok(Math.abs(poseAt(9.25).rotor-(9.25-4)*ROTOR_RAD_PER_S)<1e-12)
assert.ok(Math.abs(VANE_PASS_HZ-1.0186)<1e-3)
assert.equal(shotAt(keyTime('2')-.01).index,0);assert.equal(shotAt(keyTime('2')+2).index,1);assert.equal(shotAt(keyTime('3')+2).index,2);assert.equal(shotAt(keyTime('1')+2).index,0)
assert.equal(pumpState(16).cut,0);assert.equal(pumpState(18).cut,1);assert.equal(pumpState(18,{seconds:18,effects:true,selected:false,pointer:[0,0],cutaway:false,shot:null,notes:null}).cut,0)
assert.equal(BEATS.length,3);assert.equal(SHOTS.length,3)
console.log('PASS: rewind grace rule, clock jumps 10 s to 8 s at the B key, pose is a function of time, vane-pass rate 1.02 Hz, shot order')

// Film: deterministic, bounded, and never two explanatory panels at once.
for(const t of [24.3,1.2,15.5,31.2,15.5])assert.deepEqual(sample(t),sample(t))
for(const x of [NaN,Infinity,-1,37])assert.throws(()=>sample(x))
for(let i=0;i<=2160;i++){
 const t=i/60,s=sample(t),cam=cameraAt(t,s)
 for(const k of ['hero','city','pump','end','fade'] as const)assert.ok(s[k]>=0&&s[k]<=1)
 assert.ok(!(s.city>.01&&s.pump>.01),`city and explainer panels overlap at ${t}`)
 assert.ok(cam.fov>1.5&&cam.fov<=37.01&&cam.position.every(Number.isFinite))
 const plan=cityAt(t).plan;assert.ok(plan>=0&&plan<=1)
}
assert.equal(energyAt({fps:60,levels:[0,1],source_sha256:'test',method:'test'},1/120),.5)
assert.equal(timeline.scenes.at(-1)?.end,timeline.duration)
for(let i=1;i<timeline.scenes.length;i++)assert.equal(timeline.scenes[i-1].end,timeline.scenes[i].start)
for(let i=1;i<timeline.captions.length;i++)assert.equal(timeline.captions[i-1][1],timeline.captions[i][0])
assert.equal(timeline.captions.at(-1)?.[1],timeline.duration)
const beat=60/timeline.bpm
for(const t of [...timeline.events.district_rise,timeline.events.select,timeline.events.plan,...timeline.events.keys.map(k=>k.time),...timeline.scenes.map(s=>s.start)])assert.ok(Math.abs(t/beat-Math.round(t/beat))<1e-9,`event ${t} is off the beat grid`)
console.log('PASS: 2161 bounded deterministic samples, panels never overlap, contiguous scenes and captions, every event on the 100 BPM grid')
