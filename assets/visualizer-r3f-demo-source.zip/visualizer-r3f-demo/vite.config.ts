import { defineConfig } from 'vite'
export default defineConfig({server:{host:'127.0.0.1',port:8776,strictPort:true,proxy:{'/capture':{target:'http://127.0.0.1:8777',rewrite:path=>path.replace(/^\/capture/,'')}}},build:{chunkSizeWarningLimit:1600}})
