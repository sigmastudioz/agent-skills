# Connected-path trace — Visualizer R3F demo

Goal: richer original Visualizer film/preview, by Lex from SigmaStudioz. Owner: this chat;
no subagents delegated. Sources are isolated under outputs/visualizer-r3f-demo. The old public film,
Video Analysis film and published skill remain unchanged. Acceptance contract: brief.md.

| ID | Path / consumer | Evidence / state |
| --- | --- | --- |
| R3F-01 | timeline → pure model → geometry / text / score / captions | Analytic queue points, manual rate bounds,2161frame samples, contiguous scenes and RMS interpolation pass |
| R3F-02 | layout → paths / waiting items / exported node labels | One shared layout owner; review found missing labels and downstream waiting position, both repaired |
| R3F-03 | model time → useFrame → physical glass / procedural surface → HUD compositor | Actual browser and short encoded study inspected; stable uniforms and manually advanced frame clock |
| R3F-04 | shared frame encoder → ordered readback → staged encode → full decode → film | Existing engine reused through local adapter; final2160-frame export passed full decode,2160frames,36s,1080p60; hash in validation.json |
| R3F-05 | score events → original stems → normalized WAV → RMS → shader and AAC | Original synthesis; cue IDs/time shared; measured source mix and final encoded mix (-15.35LUFS/-1.67dBTP), subjective listening unperformed |
| R3F-06 | input → validated manual scenario → visible queue / selection / feedback | Keyboard rate6→queue9, selection, reset and user-started feedback controls observed |
| R3F-07 | mute / volume / reduced motion → preview playback | Mute toggle, volume0and.8, reset and Motion off blocking Play observed |
| R3F-08 | render completion → ordinary player source → playable file | Found player retained initial404; added explicit media reload after successful capture; actual final video playback advanced past20s, paused at32.494s, duration36/errornull/readyState4 |
| R3F-09 | GPU / page lifecycle → fallback / cancellation / disposal | Declarative GPU resources plus explicit HUD/tube/outline disposal; context loss message and ordinary film remain; Reload scene restored Ready R3F; real loss/recovery verified |
| R3F-10 | artifact → self-contained sources / licenses / edit / reproduce | Package lock, original-source rights and canonical helper snapshots; compiled dist rendered Ready on8778; portable ZIP hashes and extracted adapter import are recorded in delivery-check.json |

Fixes: bounded quintic easing clamps a floating-point overshoot; explicit upstream queue placement;
projected labels share the actual scene transform; material macro shot gives a distinct framing;
completed media reloads; live feedback starts only from a user action and honors mute/volume;
OS reduced-motion changes and page-exit cancellation are handled. No unrelated repo restructure.

Full coverage does not mean every browser/device failure was simulated. Keep runtime, static-only,
measured audio and subjective review boundaries distinct in the final validation receipt.

Final review also repaired retired graph reappearance and overlapping explanatory callouts.
Regression samples cover every timeline frame boundary; final encoded transition stills were inspected.
Live feedback uses a shared gain stage so mute/volume also affect active voice tails.
Portable delivery excludes prior renders, caches, private records and raw stems.
