"""Inspect actual encoded media and preserve measurable delivery evidence."""
from pathlib import Path
import subprocess,json,hashlib,re
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent;film=ROOT/'public/exports/visualizer-r3f.mp4'
def run(args):return subprocess.run(args,capture_output=True,text=True,check=True)
probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(film)]).stdout)
v=next(x for x in probe['streams'] if x['codec_type']=='video');a=next(x for x in probe['streams'] if x['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1920,1080,'60/1',2160)
assert abs(float(probe['format']['duration'])-36)<.05 and a['channels']==2
run(['ffmpeg','-v','error','-i',str(film),'-f','null','-'])
meter=run(['ffmpeg','-hide_banner','-i',str(film),'-af','loudnorm=I=-15.2:TP=-1.7:LRA=9:print_format=json','-f','null','-'])
loud=json.JSONDecoder().raw_decode(meter.stderr[meter.stderr.rfind('{'):])[0]
unique={}
for t in [3,8,14.5,21,27.5,33]:
 crc=run(['ffmpeg','-v','error','-ss',str(t),'-i',str(film),'-frames:v','8','-an','-f','framemd5','-']).stdout
 hashes=[line.split(',')[-1].strip() for line in crc.splitlines() if line and not line.startswith('#')]
 assert len(hashes)==8 and len(set(hashes))==8,(t,hashes)
 unique[str(t)]=len(set(hashes))
frames=[1.2,7.5,14.5,20.8,27.5,33]
for t in frames+[5.2,5.5,5.9,11.3,11.7,18.9,19.5,24.9,25.5,30.9,31.5,35.9]:
 run(['ffmpeg','-v','error','-ss',str(t),'-i',str(film),'-frames:v','1','-update','1','-y',str(ROOT/'stills'/f'{t:g}.png')])
font=ImageFont.load_default(size=18)
sheet=Image.new('RGB',(1920,788),'#071719');draw=ImageDraw.Draw(sheet)
for i,t in enumerate(frames):
 im=Image.open(ROOT/'stills'/f'{t:g}.png').convert('RGB');im.thumbnail((640,360));x=(i%3)*640;y=(i//3)*394;sheet.paste(im,(x,y));draw.text((x+15,y+365),f'{t:.2f}s',font=font,fill='#c9dccd')
sheet.save(ROOT/'stills/contact-sheet.png')
Image.open(ROOT/'stills/1.2.png').save(ROOT/'public/poster.png')
report={'author':'Lex from SigmaStudioz','source':'Actual React Three Fiber manual-frame export','file':str(film.relative_to(ROOT)),'sha256':hashlib.sha256(film.read_bytes()).hexdigest(),'bytes':film.stat().st_size,'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':int(v['nb_frames']),'duration':float(probe['format']['duration']),'video_codec':v['codec_name'],'audio_codec':a['codec_name'],'audio_channels':a['channels'],'full_decode':'passed','encoded_integrated_lufs':float(loud['input_i']),'encoded_true_peak_dbtp':float(loud['input_tp']),'eight_consecutive_distinct_frames':unique,'captions':'6scene summaries from the shared timeline; no voiceover','listening_review':'not performed by agent; measured/structural audio checks','visual_review':'pending contact-sheet/transition review','limits':['Offline60fps export does not imply realtime60fps on all devices','Authored demonstration, not an agent efficacy run']}
(ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
