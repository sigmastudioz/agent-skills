# Two films, one motion language

Audience: people choosing/installing agent skills. Duration:32seconds each,16:9,1080p60.
Identity: Lex from SigmaStudioz. Original sculptural glass/metal, cream/cobalt and slate/mint.
No voiceover. Six scene-summary captions per film; original stereo score and synchronized effects.
Scene timing and sound cues are canonical in `source/timelines.json`.

## Visualizer

| Time | Picture and dominant action | Sound / purpose |
| --- | --- | --- |
|0–4|A continuous iridescent knot turns slowly; close framing establishes the hero silhouette. “Make ideas move.”|Harmonic bloom, low soft onset; show a finished visual first.|
|4–9|Metallic input/state/output objects and curved paths assemble around the hero; parcels travel through the graph.|Fold/contact accents and a developing felt-key motif; establish ownership and continuity.|
|9–15|Arrival rises from2to5items/s against3items/s service. The input queue grows to6items; arrival falls to1 and the queue drains tozero.|Directional scanning cues, restrained clicks and a softer recovery; explain a real deterministic illustrative model.|
|15–21|The same geometry sits inside independently moving frame outlines while a film timeline fills in.|Air sweep, frame contacts and return of musical density; show one state contract across formats.|
|21–26|Model/controls, picture/sound and exported-file responsibilities appear in causal order.|Resolution harmony and precise chime; checks are workflow instructions, not invented test results.|
|26–32|Hero and frame settle. Large Visualizer title, Lex attribution and actual install command hold.|Original resolving chord with a gentle tail; leave time to read the action.|

## Video Analysis

| Time | Picture and dominant action | Sound / purpose |
| --- | --- | --- |
|0–4|An original sculptural object floats in a dark inspection world. “See what happened.”|Lower, more precise harmonic entry; establish clarity and evidence.|
|4–9|Six actual source images rise into a layered spatial stack, then fan continuously toward a grid.|Contact/fold cues; introduce the original6second clip, metadata and recorded source identity.|
|9–15|Selected source frames sit on real planes, with decoded PTS labels.11frames were sampled;6are shown.|A moving scan cue and sparse detail ticks; make sample provenance inspectable.|
|15–21|One actual frame moves forward while surrounding frames recede. Its PTS stays attached to its plane.|A focused sweep and quiet bed; connect a claim to its evidence instead of fabricating a terminal.|
|21–26|The grid returns with explicit limits: sparse samples, separate audio inspection and unknowns.|Reduced density and a resolving accent; distinguish evidence from interpretation.|
|26–32|Video Analysis, Lex attribution and actual install command hold while the hero settles.|Final original harmony and fade; clear attribution and installation.|

The synthetic source is our own render, not the supplied reference videos. Its source hash and
actual decoded sample times are in `evidence/manifest.json`. This clip was created before the
final marketing-film material balance; its preserved appearance is part of the evidence.
