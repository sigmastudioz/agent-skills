# Two films, one motion language

Audience: people choosing/installing agent skills. Duration:32seconds each,16:9,1080p60.
Identity: Lex from SigmaStudioz. Original sculptural glass/metal, cream/cobalt and slate/mint.
No voiceover. Six scene-summary captions per film; original stereo score and synchronized effects.
Scene timing and sound cues are canonical in `source/timelines.json`.

## Visualizer (re-cut 2026-11-13)

100 BPM; one beat is 0.6 s, which is 36 frames. Scene starts are whole beats. The grid is measured
from the final mix (`audio/visualizer-beatmap.json`) and the film prints the measured values.

| Time | Picture and dominant action | Sound / purpose |
| --- | --- | --- |
|0–4.8|The iridescent knot turns. “Make ideas move.” appears one word per beat (beats 2, 3, 4).|Harmonic bloom, a click per word; kinetic type on the beat.|
|4.8–12|The knot pulses twice per beat (lub-dub) and a ring expands from each downbeat. A beat strip fills as beats pass, with the measured tempo and offsets.|Kick and sub on the grid, a chime on two downbeats; show that the picture follows measured sound.|
|12–16.8|Pop-in: three nodes, one per beat, 0.5 s each, about 110 % overshoot. Anticipation: at 15.0 s a parcel pulls back 12 % for 0.4 s, then travels an arc for 1.4 s and stops on the next scene's first beat.|A pop per node, a fold on the wind-up and a stitch on the release; each move is named with duration, strength and subject.|
|16.8–20.4|Follow-through: the parcel has just stopped and its tail, on a stem, swings on as a damped spring for about 1.5 s. Text scramble: the third node's label decodes over 0.9 s and locks left to right.|A click as the tail settles, a sweep under the decode and a chime on the lock.|
|20.4–27.6|A looping asset, 4 beats (2.4 s, 144 frames), shown three times: the knot floats, its highlight shimmers, its rings pulse; camera, colour and silhouette stay fixed.|A fold at the loop start and a soft click at each repeat; frame 0 equals frame 144.|
|27.6–32|Hero settles. Large Visualizer title, Lex attribution and install command hold.|Original resolving chord with a gentle tail.|

## Video Analysis

| Time | Picture and dominant action | Sound / purpose |
| --- | --- | --- |
|0–4|An original sculptural object floats in a dark inspection world. “See what happened.”|Lower, more precise harmonic entry; establish clarity and evidence.|
|4–9|Six actual source images rise into a layered spatial stack, then fan continuously toward a grid.|Contact/fold cues; introduce the original6second clip, metadata and recorded source identity.|
|9–15|Selected source frames sit on real planes, with decoded PTS labels.11frames were sampled;6are shown.|A moving scan cue and sparse detail ticks; make sample provenance inspectable.|
|15–21|One actual frame moves forward while surrounding frames recede. Its PTS stays attached to its plane.|A focused sweep and quiet bed; connect a claim to its evidence instead of fabricating a terminal.|
|21–26|The grid returns with explicit limits: sparse samples, separate audio inspection and unknowns.|Reduced density and a resolving accent; distinguish evidence from interpretation.|
|26–32|Video Analysis, Lex attribution and actual install command hold while the hero settles.|Final original harmony and fade; clear attribution and installation.|

The synthetic source is our own render, not the supplied reference videos. Its source hash and
actual decoded sample times are in `evidence/manifest.json`. This clip was created before the
final marketing-film material balance; its preserved appearance is part of the evidence.
