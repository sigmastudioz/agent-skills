# SigmaStudioz motion lab

Two original 32-second films by **Lex from SigmaStudioz**: Visualizer and Video Analysis.
The requested delivery format is 1920×1080, 60 actual rendered frames per second, H.264/AAC.
Final export measurements and remaining review limits belong in `validation.json`.

## Watch and inspect

Serve this folder with `python3 source/server.py`, then open
`http://127.0.0.1:8773/preview.html`. The server binds only to the local loopback address.
For the independently playable films, open `watch.html`. Use the live scene film selector,
chapters, timeline, play/pause, replay, sound, volume and motion controls.
Audio starts muted and requires a user gesture. Reduced-motion preferences start playback paused.
Exported MP4s remain independently playable linear films.

Visualizer explains an illustrative fluid queue through one model, changing input, scene time,
film production and checks. It is not a recorded agent coding session or production benchmark.
Video Analysis uses actual frames from our original six-second synthetic source clip. The local
released sampler returned eleven frames within a twelve-frame budget; six are displayed in the
film. Actual decoded PTS, hashes, metadata and coverage limits are retained in `evidence/`.
There is no claim that sparse samples establish exhaustive viewing or audio understanding.

## Reproduce

Requirements: Python3.10+, NumPy, FFmpeg/ffprobe and a modern browser with WebGL2. Use an existing
environment or an isolated environment. No dependency auto-installer or model download is included.
Three.js0.186.1 is pinned locally with its original MIT license and verified provenance.

1. Run `python3 source/soundtrack.py` to create both original layered scores and measured RMS envelopes.
2. Run the loopback server. In **Local production controls**, render the two-second study; inspect it.
3. Render the original source clip. Run the released Video Analysis sampler using:

   ```sh
   python3 source/prepare_evidence.py --sampler /your/agent-skills/plugins/video-analysis/skills/video-analysis/scripts/sample.py
   ```

4. Reload the preview to load the evidence manifest and actual extracted images.
5. Choose Visualizer and **Export selected film · 1080p60**. Repeat for Video Analysis.
6. Run `python3 source/verify.py` for full decode, frame count, caption, provenance and audio checks.

The browser computes every frame at its exact timestamp, renders actual meshes and custom shaders
into the antialiased display framebuffer with its final color transfer, then sends bounded two-frame RGBA batches to the local encoder.
FFmpeg flips the GPU row order once, encodes the image and muxes the mastered original soundtrack.
The server rejects unknown names, foreign origins, duplicate outputs, invalid batch order, truncated
data and incomplete frame clocks. It exposes no arbitrary command or input-file API. Completed
files are published atomically only after a full decode succeeds. Failed `.part.mp4` files are
preserved; move a failed part aside before retrying. Keep the browser tab open while exporting.

The shared model, timeline and materials drive preview and export. Live playback can skip frames
on a slow device; the export always requests each of the1920 distinct frame times. Successful
encoding does not establish realtime60fps on every browser. Audio energy drives a subtle material
accent through the measured soundtrack RMS envelope; this is not live microphone or FFT analysis.

## Assets and rights

Original geometry, shader, animation, captions, music and synthesized effects: Lex from SigmaStudioz,
MIT. No reference footage, third-party soundtrack, cloned voice, customer data or private session
log is included. System fonts are rendered by the host, not redistributed; other systems can vary.
Three.js remains under its included MIT license. The sampler is a separately available original
MIT skill helper; its source hash is recorded rather than silently copying a second implementation.
Shared sound primitives and byte-range media serving reuse our earlier DDD demo engine.

See `source/timelines.json` for the scene and cue sheet, `gap-trace.md` for integration coverage,
and `audio/*-report.json` for actual normalization results. The on-screen captions are scene
summaries; there is no voiceover. Structural sound checks are separate from a listening review.
