"""Original scores for the two films. Shared cue clock; no samples or cloned voices."""
import hashlib
import json
import math
from pathlib import Path
import subprocess
import wave
import numpy as np
from shared.audio_synthesis import RATE, note, pad, pan, mix, effect, room, write_wave

ROOT = Path(__file__).resolve().parent.parent


def master(name, spec, duration=32, fps=60):
    rng = np.random.default_rng(514 if name == 'visualizer' else 719)
    n = round(duration * RATE)
    times = np.arange(n) / RATE
    music = np.zeros((n, 2), dtype=np.float32)
    foley = np.zeros_like(music)
    shift = 1 if name == 'visualizer' else 2 ** (2 / 12)
    chords = np.array([[146.83, 220, 293.66, 349.23], [130.81, 196, 261.63, 329.63],
                       [116.54, 174.61, 233.08, 293.66], [146.83, 220, 293.66, 440]]) * shift
    for i, start in enumerate(range(0, 32, 4)):
        chord = chords[i % 4]
        mix(music, pad(chord, min(6.5, duration-start)), start)
    beat = 60 / (104 if name == 'visualizer' else 98)
    motif = [0, None, 2, 1, None, 3, 2, None]
    for i in range(math.ceil(duration / beat)):
        t = i * beat
        chord = chords[(i // 7) % 4]
        degree = motif[i % 8]
        if degree is not None and t < 29:
            mix(music, pan(note(chord[degree]*2, 1.5, .105), math.sin(i*.62)*.55), t)
        if i % 4 == 0:
            tt = np.arange(round(1.6*RATE))/RATE
            bass = .09*np.sin(2*np.pi*chord[0]/2*tt)*(1-np.exp(-tt*40))*np.exp(-tt*3)
            mix(music, pan(bass, 0), t)
        if 4 < t < 26 and i % 4 in (0, 3):
            tt = np.arange(round(.22*RATE))/RATE
            kick = .07*np.sin(2*np.pi*(49*tt+3.5*(1-np.exp(-tt*25))))*np.exp(-tt*24)
            mix(music, pan(kick, 0), t)
        if 6 < t < 25 and i % 4 == 2:
            tt = np.arange(round(.16*RATE))/RATE
            noise = rng.uniform(-1, 1, len(tt))
            brush = np.convolve(noise, np.ones(24)/24, 'same') * np.exp(-tt*30)*.045
            mix(music, pan(brush, .38 if i % 8 == 2 else -.38), t)
    density = np.interp(times, [0, 1.6, 8, 14.4, 15, 16, 20, 21, 26, 29, 32],
                        [.1, .8, 1, .75, .3, .65, 1, .65, .9, .7, 0])
    music *= density[:, None]
    for cue in spec['cues']:
        mono = effect(cue['kind'], rng) * cue['level'] * 1.3
        position = cue['pan']
        if cue['kind'] in ('scan', 'wipe'):
            position = np.linspace(-.65, .65, len(mono))
        mix(foley, pan(mono, position), cue['time'])
    # Separate layers preserve precise attacks while giving pads a wider, darker room.
    music += room(music)*.8
    foley += room(foley)*.42
    result = music + foley
    result *= np.minimum(1, times/.08)[:, None]*np.minimum(1, (duration-times)/.85)[:, None]
    peak = np.max(np.abs(result))
    if peak > .8:
        result *= .8/peak
    out = ROOT/'audio'; out.mkdir(exist_ok=True)
    raw = out/f'{name}-raw.wav'; target = out/f'{name}.wav'
    write_wave(raw, result)
    norm = 'I=-16:TP=-1.5:LRA=9'
    first = subprocess.run(['ffmpeg', '-hide_banner', '-i', str(raw), '-af', f'loudnorm={norm}:print_format=json', '-f', 'null', '-'], capture_output=True, text=True, check=True)
    measured = json.JSONDecoder().raw_decode(first.stderr[first.stderr.rfind('{'):])[0]
    settings = f'loudnorm={norm}:measured_I={measured["input_i"]}:measured_TP={measured["input_tp"]}:measured_LRA={measured["input_lra"]}:measured_thresh={measured["input_thresh"]}:offset={measured["target_offset"]}:linear=true:print_format=json'
    second = subprocess.run(['ffmpeg', '-hide_banner', '-y', '-i', str(raw), '-af', settings, '-ar', str(RATE), str(target)], capture_output=True, text=True, check=True)
    normalized = json.JSONDecoder().raw_decode(second.stderr[second.stderr.rfind('{'):])[0]
    with wave.open(str(target)) as f:
        samples = np.frombuffer(f.readframes(f.getnframes()), dtype='<i2').reshape(-1, 2)/32768
    rms = np.sqrt(np.mean(samples.reshape(-1, RATE//fps, 2)**2, axis=(1, 2)))
    levels = np.clip(rms/(np.percentile(rms, 95)+1e-8), 0, 1)
    for i in range(1, len(levels)):
        levels[i] = levels[i-1]+(.2 if levels[i]>levels[i-1] else .065)*(levels[i]-levels[i-1])
    (out/f'{name}-envelope.json').write_text(json.dumps({'fps':fps, 'method':'smoothed RMS of normalized WAV; not FFT', 'source_sha256':hashlib.sha256(target.read_bytes()).hexdigest(), 'levels':np.round(levels, 4).tolist()}))
    (out/f'{name}-report.json').write_text(json.dumps({'source':'Original deterministic synthesis by Lex from SigmaStudioz', 'layers':['harmonic pads', 'felt-key motif', 'sub bass', 'soft kick', 'brush percussion', 'material cues', 'stereo reflections'], 'cues':spec['cues'], 'normalization':normalized, 'listening_review':'not yet performed'}, indent=2))
    print(name, normalized['output_i'], 'LUFS,', normalized['output_tp'], 'dBTP', flush=True)


if __name__ == '__main__':
    data = json.loads((ROOT/'source/timelines.json').read_text())
    for name, spec in data['films'].items():
        master(name, spec)
