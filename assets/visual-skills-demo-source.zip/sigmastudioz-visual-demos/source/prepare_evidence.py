"""Use the released Video Analysis sampler; preserve its actual PTS and source hash."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent


def main(sampler):
    source=ROOT/'exports/sample-source.mp4'
    if not (ROOT/'evidence/inventory.json').exists():
        subprocess.run([sys.executable,str(sampler),str(source),'--output',str(ROOT/'evidence'),'--frames','12','--side','960'],check=True)
    data=json.loads((ROOT/'evidence/inventory.json').read_text())
    assert data['sha256']==hashlib.sha256(source.read_bytes()).hexdigest()
    assert 6<=len(data['samples'])<=12
    assert all(0<=f['source_seconds']<6.01 for f in data['samples'])
    manifest={'source':'exports/sample-source.mp4','source_sha256':data['sha256'],
              'sampler_sha256':hashlib.sha256(sampler.read_bytes()).hexdigest(),
              'sampler_origin':'sigmastudioz/agent-skills / plugins/video-analysis / version1.0.0',
              'frames':data['samples'],'coverage':f"{len(data['samples'])} samples, six shown in film. Not exhaustive frame coverage.",
              'audio':'Present in source; sampler metadata does not constitute listening or transcription.'}
    (ROOT/'evidence/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'samples':len(data['samples']),'sha256':data['sha256']}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--sampler',type=Path,required=True);args=p.parse_args()
    main(args.sampler.resolve())
