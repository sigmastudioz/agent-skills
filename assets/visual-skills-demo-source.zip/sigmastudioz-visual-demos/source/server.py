"""Loopback-only deterministic browser-frame encoder. Reads bounded batches, publishes atomically."""
from functools import partial
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import threading
from urllib.parse import urlsplit, parse_qs
from shared.media_server import MediaHandler

ROOT = Path(__file__).resolve().parent.parent
LOCK = threading.Lock()
JOB = None
PORT = 8773
SPECS = {'visualizer':(1920,1080,60,32), 'video-analysis':(1920,1080,60,32), 'sample-source':(960,540,60,6), 'smoke':(1280,720,60,2)}


class Handler(MediaHandler):
    def log_message(self, fmt, *args):
        if self.command == 'POST' and '/frames?' in self.path:
            return
        super().log_message(fmt, *args)

    def reply(self, value, status=200):
        body = json.dumps(value).encode()
        self.send_response(status); self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)

    def do_POST(self):
        global JOB
        if self.headers.get('Origin') != f'http://127.0.0.1:{PORT}':
            self.reply({'error':'Same-origin loopback requests only'},403); return
        path = urlsplit(self.path)
        try:
            with LOCK:
                if path.path == '/start':
                    size = int(self.headers.get('Content-Length','0'))
                    if not 0<size<1024: raise ValueError('Invalid configuration size')
                    name = json.loads(self.rfile.read(size))['name']
                    if name not in SPECS or JOB: raise ValueError('Unknown film or encoder busy')
                    width,height,fps,duration = SPECS[name]
                    target = ROOT/'exports'/f'{name}.mp4'; staging = target.with_suffix('.part.mp4')
                    if target.exists() or staging.exists(): raise ValueError('Output exists; preserve previous export')
                    audio = ROOT/'audio'/('video-analysis.wav' if name=='video-analysis' else 'visualizer.wav')
                    log = (ROOT/'exports'/f'{name}-encoder.log').open('w')
                    cmd = ['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgba','-video_size',f'{width}x{height}','-framerate',str(fps),'-i','pipe:0','-i',str(audio),'-vf','vflip','-map','0:v','-map','1:a','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','256k','-t',str(duration),'-movflags','+faststart',str(staging)]
                    process = subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log)
                    JOB = dict(name=name,width=width,height=height,fps=fps,duration=duration,next=0,process=process,log=log,target=target,staging=staging)
                    self.reply({'width':width,'height':height,'fps':fps,'frames':fps*duration}); return
                if path.path == '/frames' and JOB:
                    q = parse_qs(path.query); seq = int(q.get('seq',['-1'])[0])
                    length = int(self.headers.get('Content-Length','0')); frame = JOB['width']*JOB['height']*4
                    count = length//frame
                    if seq != JOB['next'] or length%frame or not 1<=count<=2 or seq+count>JOB['fps']*JOB['duration']:
                        raise ValueError('Frame size/order/count mismatch')
                    body = self.rfile.read(length)
                    if len(body)!=length: raise ValueError('Truncated batch')
                    JOB['process'].stdin.write(body); JOB['next'] += count
                    self.reply({'next':JOB['next']}); return
                if path.path == '/finish' and JOB:
                    if JOB['next']!=JOB['fps']*JOB['duration']: raise ValueError('Incomplete frame clock')
                    JOB['process'].stdin.close(); code=JOB['process'].wait(timeout=120); JOB['log'].close()
                    if code: raise ValueError('Encoder failed; inspect its log')
                    subprocess.run(['ffmpeg','-v','error','-i',str(JOB['staging']),'-f','null','-'],check=True,timeout=120)
                    JOB['staging'].replace(JOB['target'])
                    result={'file':f"exports/{JOB['name']}.mp4",'frames':JOB['next'],'engine':'Three.js r186; actual mesh/shader frames','fps':JOB['fps']}
                    (ROOT/'exports'/f"{JOB['name']}-render.json").write_text(json.dumps(result,indent=2)+'\n')
                    JOB=None; self.reply(result); return
                if path.path == '/cancel' and JOB:
                    JOB['process'].kill(); JOB['process'].wait(); JOB['log'].close(); JOB=None
                    self.reply({'cancelled':True,'partial_preserved':True}); return
                raise ValueError('No matching render operation')
        except Exception as error:
            self.reply({'error':str(error)},409)


if __name__ == '__main__':
    server=ThreadingHTTPServer(('127.0.0.1',PORT),partial(Handler,directory=str(ROOT)))
    print(f'http://127.0.0.1:{PORT}/preview.html',flush=True)
    try: server.serve_forever()
    finally:
        server.server_close()
        if JOB:
            JOB['process'].kill(); JOB['process'].wait(); JOB['log'].close()
