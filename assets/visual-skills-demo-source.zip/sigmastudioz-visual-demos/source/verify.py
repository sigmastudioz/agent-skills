"""Verify actual exports, captions, audio and source provenance; create review stills."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import numpy as np

ROOT=Path(__file__).resolve().parent.parent


def run(args):
    return subprocess.run(args,capture_output=True,check=True)


def check(name,spec):
    path=ROOT/'exports'/f'{name}.mp4'
    meta=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(path)]).stdout)
    v=next(s for s in meta['streams'] if s['codec_type']=='video')
    a=next(s for s in meta['streams'] if s['codec_type']=='audio')
    assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'60/1',1920)
    assert v['codec_name']=='h264' and a['codec_name']=='aac' and a['channels']==2
    assert abs(float(meta['format']['duration'])-32)<.05
    # Full decode also fails on any encoder corruption reported by FFmpeg.
    run(['ffmpeg','-v','error','-xerror','-i',str(path),'-f','null','-'])
    measured=run(['ffmpeg','-hide_banner','-i',str(path),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']).stderr.decode()
    loud=json.JSONDecoder().raw_decode(measured[measured.rfind('{'):])[0]
    assert -17<float(loud['input_i'])<-15, loud
    assert float(loud['input_tp'])<-1.0, loud
    audio=run(['ffmpeg','-v','error','-i',str(path),'-vn','-f','f32le','-ac','2','-ar','48000','pipe:1']).stdout
    samples=np.frombuffer(audio,dtype='<f4').reshape(-1,2)
    correlation=float(np.corrcoef(samples.T)[0,1]);assert correlation>-.2
    assert np.max(np.abs(samples))<1
    captions=(ROOT/'exports'/f'{name}.srt').read_text()
    blocks=captions.strip().split('\n\n');assert len(blocks)==6
    for block,s in zip(blocks,spec['scenes']):assert s['caption'] in block
    # Six different scene frames make orientation, readability and motion review inspectable.
    hashes=[]
    # One frame per scene; the visualizer's scenes sit on its beat grid.
    for i,t in enumerate([1.5,8.0,14.2,18.6,23.0,29.5] if name=='visualizer' else [1.5,5.5,11.5,17.5,23.5,29.5]):
        image=ROOT/'exports'/f'{name}-shot-{i+1}.png'
        run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(path),'-frames:v','1',str(image)])
        hashes.append(hashlib.sha256(image.read_bytes()).hexdigest())
    assert len(set(hashes))==6
    poster=ROOT/'exports'/f'{name}-poster.png'
    run(['ffmpeg','-v','error','-y','-ss','15.6' if name=='visualizer' else '5.5','-i',str(path),'-frames:v','1',str(poster)])
    run(['ffmpeg','-v','error','-y','-framerate','1','-i',str(ROOT/'exports'/f'{name}-shot-%d.png'),'-vf','scale=640:360,tile=2x3','-frames:v','1',str(ROOT/'exports'/f'{name}-contact.png')])
    # Check neighbouring actual frame times are distinct; not just a 60fps container of repeated poses.
    digest=run(['ffmpeg','-v','error','-ss','10','-i',str(path),'-frames:v','8','-an','-f','framemd5','pipe:1']).stdout.decode()
    frame_hashes=[line.split(',')[-1].strip() for line in digest.splitlines() if not line.startswith('#')]
    assert len(set(frame_hashes))==8
    env=json.loads((ROOT/'audio'/f'{name}-envelope.json').read_text())
    assert len(env['levels'])==1920 and env['fps']==60
    assert env['source_sha256']==hashlib.sha256((ROOT/'audio'/f'{name}.wav').read_bytes()).hexdigest()
    extra={}
    if name=='visualizer':
        # The loop must close: the scene region one loop (4 beats = 144 frames) apart, decoded from the film.
        beat=60/spec['bpm'];start=spec['beats']['loop'][0]*beat;length=spec['beats']['loop_beats']*beat
        def region(t):
            raw=run(['ffmpeg','-v','error','-ss',f'{t:.6f}','-i',str(path),'-frames:v','1','-vf','crop=820:700:1040:130,format=gray','-f','rawvideo','pipe:1']).stdout
            return np.frombuffer(raw,dtype=np.uint8).astype(np.int16)
        first,second,quarter=region(start+length*.5),region(start+length*1.5),region(start+length*.75)
        same=float(np.abs(first-second).mean());different=float(np.abs(first-quarter).mean())
        assert same<1.0 and different>3*same+.5,(same,different)
        beatmap=json.loads((ROOT/'audio'/f'{name}-beatmap.json').read_text())
        assert beatmap['source_sha256']==hashlib.sha256((ROOT/'audio'/f'{name}.wav').read_bytes()).hexdigest()
        assert abs(beatmap['fitted_bpm']-spec['bpm'])<.1 and abs(beatmap['residual_ms']['mean'])<16.7
        extra={'loop_closure':{'loop_seconds':length,'frames':round(length*60),'mean_abs_difference_one_loop_apart':round(same,3),'mean_abs_difference_quarter_loop_apart':round(different,3),'scale':'8-bit luma in the scene region, decoded from the MP4'},
               'beat_grid':{k:beatmap[k] for k in ('declared_bpm','fitted_bpm','beat_onsets','residual_ms','off_grid_onsets_s','method')}}
    return {**extra,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,
            'width':1920,'height':1080,'fps':60,'frames':1920,'seconds':float(meta['format']['duration']),
            'video':'H.264 / yuv420p','audio':'AAC stereo / 256k target','integrated_lufs':float(loud['input_i']),
            'true_peak_dbtp':float(loud['input_tp']),'stereo_correlation':round(correlation,4),
            'peak_sample':float(np.max(np.abs(samples))),'full_decode':'passed','captions':'6 synchronized scene summaries',
            'consecutive_frames':'8/8 distinct at10seconds','listening_review':'Not performed by agent; structural checks only'}


def main():
    # `verify.py visualizer` checks one film and keeps the other film's recorded results.
    wanted=set(sys.argv[1:]);previous=json.loads((ROOT/'validation.json').read_text()) if (ROOT/'validation.json').exists() else {}
    data=json.loads((ROOT/'source/timelines.json').read_text());result=dict(previous.get('films',{})) if wanted else {}
    for name,spec in data['films'].items():
        cursor=0
        for scene in spec['scenes']:
            assert abs(scene['start']-cursor)<1e-6 and scene['duration']>0;cursor+=scene['duration']
        assert abs(cursor-32)<1e-6 and all(0<=c['time']<32 for c in spec['cues'])
        if wanted and name not in wanted:continue
        result[name]=check(name,spec)
        print(name,result[name]['integrated_lufs'],'LUFS',result[name]['true_peak_dbtp'],'dBTP',flush=True)
    evidence=json.loads((ROOT/'evidence/manifest.json').read_text())
    assert evidence['source_sha256']==hashlib.sha256((ROOT/evidence['source']).read_bytes()).hexdigest()
    assert len(evidence['frames'])==11
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'source').rglob('*') if p.is_file() and '__pycache__' not in str(p)}
    report={'author':'Lex from SigmaStudioz','films':result,'source_hashes':hashes,
            'evidence':'Original synthetic source;11actual sparse frames,6shown; unsampled tail remains explicit',
            'visual_review':'Contact sheets and transitions pending inspection','browser_controls':'pending',
            'publication':'local review artifacts; no new marketplace or social publication'}
    if wanted:report={**previous,'films':result,'source_hashes':hashes,'partial_recheck':sorted(wanted)}
    (ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':main()
