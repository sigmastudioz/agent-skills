"""Verify actual exports, captions, audio and source provenance; create review stills."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import numpy as np

ROOT=Path(__file__).resolve().parent.parent


def run(args):
    return subprocess.run(args,capture_output=True,check=True)


def check(name,spec):
    path=ROOT/'exports'/f'{name}.mp4'
    meta=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(path)]).stdout)
    v=next(s for s in meta['streams'] if s['codec_type']=='video')
    a=next(s for s in meta['streams'] if s['codec_type']=='audio')
    assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'60/1',1920)
    assert v['codec_name']=='h264' and a['codec_name']=='aac' and a['channels']==2
    assert abs(float(meta['format']['duration'])-32)<.05
    # Full decode also fails on any encoder corruption reported by FFmpeg.
    run(['ffmpeg','-v','error','-xerror','-i',str(path),'-f','null','-'])
    measured=run(['ffmpeg','-hide_banner','-i',str(path),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']).stderr.decode()
    loud=json.JSONDecoder().raw_decode(measured[measured.rfind('{'):])[0]
    assert -17<float(loud['input_i'])<-15, loud
    assert float(loud['input_tp'])<-1.0, loud
    audio=run(['ffmpeg','-v','error','-i',str(path),'-vn','-f','f32le','-ac','2','-ar','48000','pipe:1']).stdout
    samples=np.frombuffer(audio,dtype='<f4').reshape(-1,2)
    correlation=float(np.corrcoef(samples.T)[0,1]);assert correlation>-.2
    assert np.max(np.abs(samples))<1
    captions=(ROOT/'exports'/f'{name}.srt').read_text()
    blocks=captions.strip().split('\n\n');assert len(blocks)==6
    for block,s in zip(blocks,spec['scenes']):assert s['caption'] in block
    # Six different scene frames make orientation, readability and motion review inspectable.
    hashes=[]
    for i,t in enumerate([1.5,5.5,11.5,17.5,23.5,29.5]):
        image=ROOT/'exports'/f'{name}-shot-{i+1}.png'
        run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(path),'-frames:v','1',str(image)])
        hashes.append(hashlib.sha256(image.read_bytes()).hexdigest())
    assert len(set(hashes))==6
    poster=ROOT/'exports'/f'{name}-poster.png'
    run(['ffmpeg','-v','error','-y','-ss','5.5','-i',str(path),'-frames:v','1',str(poster)])
    run(['ffmpeg','-v','error','-y','-framerate','1','-i',str(ROOT/'exports'/f'{name}-shot-%d.png'),'-vf','scale=640:360,tile=2x3','-frames:v','1',str(ROOT/'exports'/f'{name}-contact.png')])
    # Check neighbouring actual frame times are distinct; not just a 60fps container of repeated poses.
    digest=run(['ffmpeg','-v','error','-ss','10','-i',str(path),'-frames:v','8','-an','-f','framemd5','pipe:1']).stdout.decode()
    frame_hashes=[line.split(',')[-1].strip() for line in digest.splitlines() if not line.startswith('#')]
    assert len(set(frame_hashes))==8
    env=json.loads((ROOT/'audio'/f'{name}-envelope.json').read_text())
    assert len(env['levels'])==1920 and env['fps']==60
    assert env['source_sha256']==hashlib.sha256((ROOT/'audio'/f'{name}.wav').read_bytes()).hexdigest()
    return {'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,
            'width':1920,'height':1080,'fps':60,'frames':1920,'seconds':float(meta['format']['duration']),
            'video':'H.264 / yuv420p','audio':'AAC stereo / 256k target','integrated_lufs':float(loud['input_i']),
            'true_peak_dbtp':float(loud['input_tp']),'stereo_correlation':round(correlation,4),
            'peak_sample':float(np.max(np.abs(samples))),'full_decode':'passed','captions':'6 synchronized scene summaries',
            'consecutive_frames':'8/8 distinct at10seconds','listening_review':'Not performed by agent; structural checks only'}


def main():
    data=json.loads((ROOT/'source/timelines.json').read_text());result={}
    for name,spec in data['films'].items():
        cursor=0
        for scene in spec['scenes']:
            assert scene['start']==cursor and scene['duration']>0;cursor+=scene['duration']
        assert cursor==32 and all(0<=c['time']<32 for c in spec['cues'])
        result[name]=check(name,spec)
        print(name,result[name]['integrated_lufs'],'LUFS',result[name]['true_peak_dbtp'],'dBTP',flush=True)
    evidence=json.loads((ROOT/'evidence/manifest.json').read_text())
    assert evidence['source_sha256']==hashlib.sha256((ROOT/evidence['source']).read_bytes()).hexdigest()
    assert len(evidence['frames'])==11
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'source').rglob('*') if p.is_file() and '__pycache__' not in str(p)}
    report={'author':'Lex from SigmaStudioz','films':result,'source_hashes':hashes,
            'evidence':'Original synthetic source;11actual sparse frames,6shown; unsampled tail remains explicit',
            'visual_review':'Contact sheets and transitions pending inspection','browser_controls':'pending',
            'publication':'local review artifacts; no new marketplace or social publication'}
    (ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':main()
