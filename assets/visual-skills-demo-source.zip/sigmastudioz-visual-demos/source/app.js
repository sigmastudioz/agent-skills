import * as THREE from '../vendor/three/three.module.js';
import {MotionScene} from './scene.js';
const $=s=>document.querySelector(s), status=$('#status'), error=$('#error'), canvas=$('#scene');
let scene,playing=false,time=0,raf=0,last=0,film='visualizer',exporting=false,cancelled=false,muted=true;
const sounds={visualizer:new Audio('audio/visualizer.wav'),'video-analysis':new Audio('audio/video-analysis.wav')};
for(const [name,a] of Object.entries(sounds)){a.preload='metadata';a.volume=.8;a.muted=true;a.hidden=true;a.dataset.film=name;document.body.append(a)}
const reduced=matchMedia('(prefers-reduced-motion: reduce)');let motion=!reduced.matches;
const fetchJSON=async path=>{const r=await fetch(path);if(!r.ok)throw Error(path+' unavailable');return r.json()};
const stop=()=>{playing=false;cancelAnimationFrame(raf);raf=0;Object.values(sounds).forEach(a=>a.pause());$('#play').textContent='Play'};
function display(){if(!scene)return;scene.render(time,film);$('#seek').value=time;$('#clock').textContent=time.toFixed(3)+' / 32';canvas.dataset.time=String(time);canvas.dataset.engine='Three.js r'+THREE.REVISION}
function tick(now){raf=0;if(!playing||document.hidden)return;time=Math.min(32,time+(now-last)/1000);last=now;display();if(time>=32){stop();status.textContent='Finished. Replay or inspect a chapter.'}else raf=requestAnimationFrame(tick)}
async function start(){if(exporting)return;if(!motion){status.textContent='Motion is paused by preference. Enable motion, or inspect a chapter.';return}if(time>=32)time=0;playing=true;last=performance.now();$('#play').textContent='Pause';const a=sounds[film];if(a.readyState>=1){a.currentTime=time;try{await a.play()}catch{status.textContent='Visual playback started. Sound playback may require another click.'}}raf=requestAnimationFrame(tick)}
async function post(path,body){let r=await fetch(path,{method:'POST',body});const data=await r.json();if(!r.ok)throw Error(data.error??'Export request failed');return data}
async function render(name){
  if(exporting)return;stop();cancelled=false;error.textContent='';exporting=true;
  const oldFilm=film;
  try{
    const config=await post('/start',JSON.stringify({name}));
    $('#film').disabled=true;$('#seek').disabled=true;
    film=name==='video-analysis'?name:'visualizer';
    if(name==='video-analysis'&&scene.strips.length!==6)throw Error('Actual evidence frames must be loaded before exporting analysis');
    scene.renderer.setSize(config.width,config.height,false);
    const gl=scene.renderer.getContext();
    const bytes=config.width*config.height*4;
    const chunk=new Uint8Array(bytes*2);
    const start=performance.now();
    for(let i=0;i<config.frames;i+=2){
      if(cancelled)throw Error('Render cancelled; partial output preserved');
      for(let j=0;j<2&&i+j<config.frames;j++){
        scene.render((i+j)/config.fps,name==='sample-source'?name:film,null);
        gl.readPixels(0,0,config.width,config.height,gl.RGBA,gl.UNSIGNED_BYTE,chunk.subarray(j*bytes,(j+1)*bytes));
        if(gl.getError()!==gl.NO_ERROR)throw Error('GPU readback failed');
      }
      await post('/frames?seq='+i,chunk);
      if(i%30===0){status.textContent=`Rendering ${name}: ${Math.round((i+2)/config.frames*100)}% · ${i+2}/${config.frames} actual GPU frames`}
    }
    const output=await post('/finish','');film=oldFilm;
    status.textContent=`Export verified: ${output.file} · ${output.frames} frames · ${((performance.now()-start)/1000).toFixed(1)} seconds to render`;
    canvas.dataset.export=output.file;
  }catch(e){error.textContent=e.message;await post('/cancel','').catch(()=>{});status.textContent='Export stopped; completed films remain intact.'}
  finally{film=oldFilm;scene?.renderer.setRenderTarget(null);scene?.renderer.setSize(1920,1080,false);exporting=false;$('#film').disabled=false;$('#seek').disabled=false;display()}
}
try{
  const [timelines,v,a,evidence]=await Promise.all([fetchJSON('source/timelines.json'),fetchJSON('audio/visualizer-envelope.json'),fetchJSON('audio/video-analysis-envelope.json'),fetchJSON('evidence/manifest.json').catch(()=>null)]);
  scene=new MotionScene(canvas,film,timelines,{visualizer:v,'video-analysis':a},evidence);await scene.loadEvidence();
  await scene.renderer.compileAsync(scene.scene,scene.camera);display();status.textContent='Ready · Three.js r'+THREE.REVISION+' · no autoplay sound.';
  const chapters=()=>{$('.chapters').replaceChildren();for(const s of timelines.films[film].scenes){let b=document.createElement('button');b.textContent=s.title;b.onclick=()=>{stop();time=s.start+Math.min(1,s.duration/2);display()};$('.chapters').append(b)}};chapters();
  $('#play').onclick=()=>playing?stop():start();$('#replay').onclick=()=>{stop();time=0;display();start()};
  $('#seek').oninput=e=>{stop();time=Number(e.target.value);display()};
  $('#sound').onclick=()=>{muted=!muted;for(const a of Object.values(sounds))a.muted=muted;$('#sound').textContent=muted?'Sound off':'Sound on';$('#sound').setAttribute('aria-pressed',String(!muted));if(playing){const a=sounds[film];a.currentTime=time;a.play().catch(()=>{})}};
  $('#volume').oninput=e=>{for(const a of Object.values(sounds))a.volume=Number(e.target.value)};
  $('#film').onchange=e=>{stop();film=e.target.value;scene.film=film;scene.scene.background=new THREE.Color(film==='visualizer'?0xf2eee5:0x101b27);scene.uniforms.tint.value.set(film==='visualizer'?0x6855ec:0x65e0cb);time=0;display();chapters();if(film==='video-analysis'&&!evidence)status.textContent='Render source clip, run the local sampler, then reload to load actual evidence.'};
  const motionUI=()=>{$('#motion').textContent=motion?'Motion on':'Motion off';$('#motion').setAttribute('aria-pressed',String(!motion))};motionUI();
  $('#motion').onclick=()=>{motion=!motion;motionUI();if(!motion)stop()};reduced.addEventListener('change',()=>{if(reduced.matches){motion=false;motionUI();stop()}});
  $('#render').onclick=()=>render(film);$('#source').onclick=()=>render('sample-source');$('#smoke').onclick=()=>render('smoke');$('#cancel').onclick=()=>{cancelled=true};
  $('#test-fallback').onclick=()=>{if(exporting)return;const extension=scene.renderer.getContext().getExtension('WEBGL_lose_context');if(extension)extension.loseContext();else status.textContent='Context-loss test extension unavailable; exported videos remain linked.'};
  canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();cancelled=true;stop();canvas.hidden=true;$('#fallback').style.display='block';$('#fallback').src='exports/'+film+'.mp4';error.textContent='GPU context lost. The exported film is available through the ordinary video player.'});
  canvas.addEventListener('webglcontextrestored',()=>{status.textContent='GPU restored. Reload to resume scene inspection; plain video remains available.'});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&!exporting)stop()});
  window.addEventListener('pagehide',e=>{stop();if(!e.persisted){scene.dispose();for(const a of Object.values(sounds)){a.removeAttribute('src');a.load();a.remove()}}});
}catch(e){error.textContent=e.message;status.textContent='Scene unavailable. Exported MP4 links remain available.';canvas.hidden=true;$('#fallback').style.display='block';$('#fallback').src='exports/visualizer.mp4';scene?.dispose()}
