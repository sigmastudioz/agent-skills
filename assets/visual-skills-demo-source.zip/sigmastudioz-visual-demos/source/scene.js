import * as THREE from '../vendor/three/three.module.js';

const smooth=x=>{x=THREE.MathUtils.clamp(x,0,1);return x*x*x*(x*(x*6-15)+10)};
export function scenario(t){
  // An illustrative fluid queue; units are items/s, not a measured production system.
  let queue=0;
  for(let i=0;i<Math.floor(Math.min(15,t)*60);i++){
    const seconds=i/60,arrival=seconds<9?2:seconds<12?5:1;
    queue=Math.max(0,queue+(arrival-3)/60);
  }
  return {arrival:t<9?2:t<12?5:1,service:3,queue};
}

export class MotionScene {
  constructor(canvas, film, timelines, envelopes, evidence){
    this.canvas=canvas;this.film=film;this.data=timelines;this.envelopes=envelopes;this.evidence=evidence;
    this.resources=[];this.images=[];this.width=1920;this.height=1080;this.overrideRate=null;
    this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,preserveDrawingBuffer:true});
    this.renderer.setPixelRatio(1);this.renderer.setSize(1920,1080,false);
    this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure=1.15;
    this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(37,16/9,.1,100);
    this.camera.position.set(0,1.1,13.4);this.camera.lookAt(0,0,0);
    this.scene.add(new THREE.HemisphereLight(0xddeeff,0x452661,3.4));
    for(const [color,intensity,position] of [[0xffffff,100,[0,6,5]],[0xaaa5ff,70,[6,1,4]],[0x7bffc2,55,[-4,2,2]]]){
      const light=new THREE.PointLight(color,intensity,28,2);light.position.set(...position);this.scene.add(light);
    }
    this.group=new THREE.Group();this.group.position.set(2.6,.15,0);this.scene.add(this.group);
    const dark=film==='video-analysis';
    this.scene.background=new THREE.Color(dark?0x101b27:0xf2eee5);
    this.uniforms={time:{value:0},energy:{value:0},tint:{value:new THREE.Color(dark?0x65e0cb:0x6855ec)}};
    this.material=new THREE.ShaderMaterial({uniforms:this.uniforms,
      vertexShader:`varying vec3 n; varying vec3 p; varying vec3 eye; uniform float time;
      void main(){vec3 q=position;float wave=sin(q.y*4.0+time*.65)*sin(q.x*3.0-time*.35);q+=normal*wave*.028;n=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(q,1.);eye=normalize(-mv.xyz);p=q;gl_Position=projectionMatrix*mv;}`,
      fragmentShader:`varying vec3 n;varying vec3 p;varying vec3 eye;uniform float time;uniform float energy;uniform vec3 tint;
      void main(){float facing=clamp(dot(normalize(n),normalize(eye)),0.,1.);float f=pow(1.-facing,2.4);float key=pow(max(dot(normalize(n),normalize(vec3(-.5,.8,.7))),0.),2.);
      vec3 pearl=.52+.44*cos(vec3(0.,2.1,4.2)+p.y*2.2+p.x*.65+time*.16);
      vec3 c=mix(tint*.32,pearl*.64,.20+f*.65)+key*.20+f*vec3(.06,.08,.13);
      c+=pow(max(0.,sin(p.y*9.+p.x*2.-time*.4)),30.)*.10*(.65+energy*.35);gl_FragColor=vec4(c,1.);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      }`});this.resources.push(this.material);
    this.hero=new THREE.Mesh(new THREE.TorusKnotGeometry(1.05,.29,200,32,2,3),this.material);this.group.add(this.hero);
    this.metal=new THREE.MeshPhysicalMaterial({color:dark?0x516678:0xc7cad2,metalness:.65,roughness:.24,clearcoat:1,clearcoatRoughness:.16});
    this.mint=new THREE.MeshPhysicalMaterial({color:0x7ddcb1,metalness:.25,roughness:.22,clearcoat:1});
    this.amber=new THREE.MeshPhysicalMaterial({color:0xf0b45b,metalness:.35,roughness:.22,clearcoat:1});
    this.resources.push(this.metal,this.mint,this.amber);
    this.nodes=[];this.curves=[];this.travel=[];this.paths=[];
    for(let i=0;i<3;i++){
      const a=i*Math.PI*2/3+.35,position=new THREE.Vector3(Math.cos(a)*2.65,Math.sin(a)*2.3,Math.sin(a)*.6);
      const mesh=new THREE.Mesh(i===1?new THREE.OctahedronGeometry(.45,2):new THREE.SphereGeometry(.4,32,24),i===2?this.amber:this.metal);
      mesh.position.copy(position);this.group.add(mesh);this.nodes.push(mesh);
      const curve=new THREE.CatmullRomCurve3([position.clone(),position.clone().multiplyScalar(.65).add(new THREE.Vector3(0,0,.6)),new THREE.Vector3(.2,.1,0)]);
      this.curves.push(curve);
      const line=new THREE.Mesh(new THREE.TubeGeometry(curve,64,.018,8,false),new THREE.MeshBasicMaterial({color:dark?0x5a8094:0xb2a7cb,transparent:true,opacity:.55}));
      this.group.add(line);this.paths.push(line);this.resources.push(line.material);
      const marbles=[];
      for(let j=0;j<5;j++){let m=new THREE.Mesh(new THREE.SphereGeometry(.075,14,10),this.mint);this.group.add(m);marbles.push(m)}
      this.travel.push(marbles);
    }
    this.queue=[];
    for(let i=0;i<14;i++){let m=new THREE.Mesh(new THREE.SphereGeometry(.075,16,12),this.amber);this.group.add(m);this.queue.push(m)}
    this.rings=[];
    for(let i=0;i<3;i++){
      let mesh=new THREE.Mesh(new THREE.TorusGeometry(2.05+i*.13,.008,8,150),new THREE.MeshBasicMaterial({color:dark?0x4b7d89:0xbbb0ce,transparent:true,opacity:.45}));
      mesh.rotation.set(.4+i*.25,.3+i*.35,.15);this.group.add(mesh);this.rings.push(mesh);this.resources.push(mesh.material);
    }
    // Independent translucent geometry frames: these really move through depth.
    this.panels=[];
    for(let i=0;i<6;i++){
      const g=new THREE.Group(),edge=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(2.8,1.6,.055)),new THREE.LineBasicMaterial({color:dark?0x73d8c9:0x8977bd,transparent:true,opacity:.5}));
      g.add(edge);this.group.add(g);this.panels.push(g);this.resources.push(edge.geometry,edge.material);
    }
    this.overlay=document.createElement('canvas');this.overlay.width=1920;this.overlay.height=1080;
    this.ctx=this.overlay.getContext('2d');this.overlayTexture=new THREE.CanvasTexture(this.overlay);this.overlayTexture.colorSpace=THREE.SRGBColorSpace;
    this.overlayScene=new THREE.Scene();this.overlayCamera=new THREE.OrthographicCamera(-1,1,1,-1,0,1);
    const om=new THREE.MeshBasicMaterial({map:this.overlayTexture,transparent:true,depthTest:false,depthWrite:false,toneMapped:false});
    this.overlayScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2,2),om));this.resources.push(this.overlayTexture,om);
    this.textures=[];this.strips=[];this.disposed=false;
  }
  async loadEvidence(){
    const frames=this.evidence?.frames??[];
    const loader=new THREE.TextureLoader();
    for(let i=0;i<Math.min(frames.length,6);i++){
      const entry=frames[Math.round(i*(frames.length-1)/5)];
      const texture=await loader.loadAsync('../evidence/'+entry.file);texture.colorSpace=THREE.SRGBColorSpace;this.textures.push(texture);
      const m=new THREE.MeshBasicMaterial({map:texture,toneMapped:false,side:THREE.DoubleSide});
      const strip=new THREE.Mesh(new THREE.PlaneGeometry(2.64,1.485),m);strip.userData.evidence=entry;
      this.group.add(strip);this.strips.push(strip);this.resources.push(m);
    }
  }
  update(t, mode=this.film){
    this.time=t;this.mode=mode;const analysis=mode==='video-analysis',source=mode==='sample-source';
    const spec=this.data.films[analysis?'video-analysis':'visualizer'];this.spec=spec;
    const shot=spec.scenes.filter(s=>t>=s.start).at(-1)??spec.scenes[0];this.shot=shot;
    this.uniforms.time.value=t;this.uniforms.energy.value=this.envelopes[analysis?'video-analysis':'visualizer']?.levels[Math.min(1919,Math.floor(t*60))]??0;
    const expansion=smooth((t-3)/2),tofilm=smooth((t-15)/2),outro=smooth((t-26)/1.8);
    this.group.rotation.y=Math.sin(t*.14)*.16;this.group.rotation.z=Math.sin(t*.11)*.028;
    this.hero.rotation.set(t*.12,.25+t*.20,Math.sin(t*.22)*.12);
    const heroScale=(1.12-.20*expansion)*(1-.15*tofilm)*(1+.1*outro);
    this.hero.scale.setScalar(heroScale);this.hero.position.set(0,Math.sin(t*.65)*.06,0);
    this.camera.position.x=Math.sin(t*.12)*.13;this.camera.position.y=1.1+Math.sin(t*.16)*.13;this.camera.lookAt(0,0,0);
    const model=scenario(t);
    this.nodes.forEach((node,i)=>{node.scale.setScalar(expansion*.9);node.rotation.y=t*.3+i;this.paths[i].visible=expansion>.02;
      this.travel[i].forEach((m,j)=>{m.visible=expansion>.2;const q=(t*.18+j/5)%1;m.position.copy(this.curves[i].getPoint(i===2?1-q:q));m.scale.setScalar(expansion)});
    });
    this.queue.forEach((m,i)=>{const visible=smooth((t-9)/.5)*(1-smooth((t-15)/.5));m.visible=visible>.001&&i<Math.ceil(model.queue);m.position.set(2.2-i*.15,.66,.65);m.scale.setScalar(visible)});
    this.rings.forEach((m,i)=>{m.rotation.y=.5+i*.35+t*.035;m.rotation.z=i*.3+Math.sin(t*.25)*.05; m.scale.setScalar(1+Math.sin(t*.45+i)*.015)});
    this.panels.forEach((p,i)=>{
      p.visible=tofilm>.01;p.position.set((i-2.5)*.29,0,-.8-i*.33);p.rotation.set(-.05,(1-tofilm)*.8+.17,0);
      p.scale.setScalar(tofilm*(1-outro*.5));
    });
    if(analysis){
      this.hero.visible=t<9||t>=26;
      const heroStrength=(1-smooth((t-7.7)/1.3))*.78+smooth((t-26)/1.3)*.90;
      this.hero.scale.multiplyScalar(heroStrength);
      this.nodes.forEach(n=>n.visible=false);this.paths.forEach(n=>n.visible=false);this.travel.flat().forEach(n=>n.visible=false);this.queue.forEach(n=>n.visible=false);
      this.panels.forEach(n=>n.visible=false);this.rings.forEach(n=>{n.visible=t<9||t>=26;n.scale.multiplyScalar((1-smooth((t-7.7)/1.3))+smooth((t-26)/1.3))});
      this.strips.forEach((p,i)=>{
        const reveal=smooth((t-4-i*.16)/1.1),focus=Math.floor((t-9)/1.8)%6;
        p.visible=t>=4&&t<26;
        let x=(i%3-1)*2.36,y=.95-Math.floor(i/3)*1.64,z=-.4;
        const fan=smooth((t-7)/2.5); x=THREE.MathUtils.lerp((i-2.5)*.45,x,fan);y=THREE.MathUtils.lerp((i-2.5)*.14,y,fan);z=THREE.MathUtils.lerp(-i*.5,z,fan);
        const focusLift=.28*Math.exp(-Math.pow((t-(9.5+i*.85))/.7,2));
        const trace=smooth((t-15)/1.4)*(1-smooth((t-21)/1.4));
        if(i===3){x=THREE.MathUtils.lerp(x,0,trace);y=THREE.MathUtils.lerp(y,.15,trace);z+=trace*.9}
        else {x+=Math.sign(x||1)*trace*.5;z-=trace*.75}
        p.position.set(x,y,z+focusLift);p.rotation.y=(1-fan)*-.22+Math.sin(t*.1)*.025;
        p.scale.setScalar(reveal*(i===3?.82+trace*.7:.82-trace*.3)*(1-smooth((t-25.2)/.8)));
        p.material.transparent=true;p.material.opacity=i===3?1:1-trace*.72;
        const outline=this.panels[i];outline.visible=p.visible;outline.position.copy(p.position);outline.rotation.copy(p.rotation);outline.scale.copy(p.scale);
        outline.children[0].material.opacity=.25+focusLift+trace*(i===3?.45:0);
      });
    }else{this.hero.visible=true;this.nodes.forEach(n=>n.visible=true);this.strips.forEach(n=>n.visible=false)}
    if(source){this.group.position.set(0,0,0);this.camera.position.set(0,.7,9);this.camera.lookAt(0,0,0);this.nodes.forEach(n=>n.scale.setScalar(.9));this.paths.forEach(n=>n.visible=true);this.travel.flat().forEach(n=>n.visible=true)}else this.group.position.set(2.6,.15,0);
    this.scene.updateMatrixWorld(true);this.camera.updateMatrixWorld(true);this.drawType(t,source);
  }
  text(text,x,y,size=30,color,weight=400){
    const c=this.ctx;c.fillStyle=color??this.ink;c.font=`${weight} ${size}px system-ui, -apple-system, sans-serif`;c.fillText(text,x,y);
  }
  wrap(text,x,y,size,width,color,weight=400,line=1.15){
    const c=this.ctx;c.font=`${weight} ${size}px system-ui, -apple-system, sans-serif`;
    let words=text.split(' '),row='',n=0;
    for(const word of words){if(c.measureText((row?row+' ':'')+word).width>width&&row){this.text(row,x,y+n*size*line,size,color,weight);row=word;n++}else row+=(row?' ':'')+word}
    this.text(row,x,y+n*size*line,size,color,weight);return y+(n+1)*size*line;
  }
  project(object){let v=new THREE.Vector3();object.getWorldPosition(v);v.project(this.camera);return [(v.x+1)*960,(1-v.y)*540]}
  drawType(t,source){
    const c=this.ctx;c.clearRect(0,0,1920,1080);this.ink=this.mode==='video-analysis'?'#eef3f2':'#1b2234';
    const muted=this.mode==='video-analysis'?'#91adb6':'#646b79',accent=this.mode==='video-analysis'?'#7fdfc4':'#6451d0';
    if(source){this.text('ORIGINAL SYNTHETIC SOURCE / 6 SEC',70,76,26);this.text('Lex from SigmaStudioz',70,1024,25);this.text(t.toFixed(3)+' s',1630,1024,27);this.overlayTexture.needsUpdate=true;return}
    const s=this.shot,local=t-s.start,enter=smooth(local/.8),offset=(1-enter)*18;
    c.globalAlpha=enter;
    this.text('SIGMASTUDIOZ   /   MOTION LAB',100,87,24,muted,600);
    this.text(this.mode==='visualizer'?'01 / VISUALIZER':'02 / VIDEO ANALYSIS',1365,87,23,muted,550);
    this.wrap(s.title,100,320+offset,86,750,this.ink,550,1.03);
    const body={hook:'A clear idea. A living system.',model:'Meaning first. Motion with purpose.',control:'A change you can see—and explain.',film:'State → scene → frame → film.',verify:'The result has to work.',source:'Original clip. Recorded provenance.',sample:'Real frames. Actual timestamps.',trace:'Observation → interpretation.',limits:'Partial coverage stays explicit.',end:'By Lex from SigmaStudioz'};
    this.wrap(body[s.id]??'',104,570,33,690,muted,400,1.3);
    if(s.id==='end'){
      this.text('INSTALL THE SKILL',104,690,23,accent,650);
      this.text('npx skills add sigmastudioz/agent-skills',104,744,26,this.ink,500);
      this.text('--skill '+this.mode,104,788,28,accent,600);
      this.text('github.com/sigmastudioz/agent-skills',104,853,25,muted);
    }else if(this.mode==='visualizer'&&s.id==='control'){
      const m=scenario(t);this.text('ILLUSTRATIVE FLUID QUEUE',104,680,22,accent,650);
      this.text(`Arrival  ${m.arrival.toFixed(0)} /s`,104,733,29);this.text('Service  3 /s',104,777,29);
      this.text(`Queue  ${m.queue.toFixed(1)} items`,104,830,34,accent,550);
    }else if(this.mode==='visualizer'&&s.id==='film'){
      for(let i=0;i<8;i++){c.fillStyle=i<=Math.floor((t-15)*1.1)?accent:muted;c.globalAlpha=.22+((i<=Math.floor((t-15)*1.1))?.6:0);c.fillRect(104+i*76,720,60,42)}c.globalAlpha=enter;
      this.text('ONE DETERMINISTIC CLOCK  /  60 FPS',104,806,23,muted,550);
    }else if(s.id==='verify'){
      ['Model + controls','Picture + sound','Playable export'].forEach((v,i)=>{this.text('↳  '+v,104,690+i*51,30,i<(t-21)*.8?accent:muted,500)});
    }else if(this.mode==='video-analysis'&&s.id==='source'){
      this.text('LOCAL ORIGINAL  /  960 × 540',104,700,24,accent,600);
      this.text('6.000 seconds  •  60 fps',104,751,30);
      this.text('Source preserved; SHA-256 recorded',104,806,25,muted);
    }else if(this.mode==='video-analysis'&&['sample','trace','limits'].includes(s.id)){
      const rows=s.id==='sample'?[`${this.evidence?.frames.length??0} sampled · 6 shown`,'Decoded PTS, not filename math','Targeted detail when needed']:s.id==='trace'?['Source → frame','Frame → observed motion','Claim → evidence reference']:['Visual sample ≠ every frame','A transcript ≠ listening','Unknowns remain visible'];
      rows.forEach((v,i)=>this.text(v,104,692+i*56,28,i===0?accent:muted,450));
    }
    c.globalAlpha=1;
    if(this.mode==='video-analysis'&&t>=9&&t<26){
      for(const p of this.strips){if(p.material.opacity<.5)continue;const label=p.localToWorld(new THREE.Vector3(-.85,-.94,.02)).project(this.camera);this.text(`PTS ${Number(p.userData.evidence.pts_seconds).toFixed(3)} s`,(label.x+1)*960,(1-label.y)*540,20,'#a8c9cc',550)}
    }
    if(this.mode==='visualizer'&&t>=4&&t<15){
      this.nodes.forEach((n,i)=>{const [x,y]=this.project(n);this.text(['INPUT','STATE','OUTPUT'][i],x-37,y+57,20,muted,600)});
    }
    c.strokeStyle=this.mode==='video-analysis'?'#314552':'#d1c9d1';c.lineWidth=1;c.beginPath();c.moveTo(100,920);c.lineTo(1820,920);c.stroke();
    this.wrap(s.caption,100,977,29,1700,this.ink,400,1.2);
    this.text('Lex from SigmaStudioz',100,1040,22,muted,550);
    this.text(this.mode==='visualizer'?'Illustrative model · actual Three.js render':'Original source · actual local frame extraction',1010,1040,21,muted);
    c.fillStyle=accent;c.fillRect(100,906,1720*Math.min(1,t/32),3);
    this.overlayTexture.needsUpdate=true;
  }
  render(t,mode=this.film,target=null){
    this.update(t,mode);this.renderer.setRenderTarget(target);this.renderer.autoClear=true;this.renderer.render(this.scene,this.camera);
    this.renderer.autoClear=false;this.renderer.clearDepth();this.renderer.render(this.overlayScene,this.overlayCamera);this.renderer.autoClear=true;
  }
  dispose(){
    if(this.disposed)return;this.disposed=true;
    this.scene.traverse(o=>o.geometry?.dispose());this.overlayScene.traverse(o=>o.geometry?.dispose());
    [...new Set([...this.resources,...this.textures])].forEach(r=>r.dispose());this.renderer.dispose();
  }
}
