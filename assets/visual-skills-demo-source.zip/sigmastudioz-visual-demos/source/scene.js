import * as THREE from '../vendor/three/three.module.js';

const smooth=x=>{x=THREE.MathUtils.clamp(x,0,1);return x*x*x*(x*(x*6-15)+10)};
// Named motion (visualizer film). Every function is pure in time, so any seek draws the same frame.
/** Pop-in: back ease-out, about 110 % before settling at 100 %. */
export const backOut=x=>{x=THREE.MathUtils.clamp(x,0,1);const c=1.70158;return 1+(c+1)*Math.pow(x-1,3)+c*Math.pow(x-1,2)};
/** Anticipation: a counter-move (a third of the time, 12 % of the distance), then an ease-out release. */
export function anticipate(seconds,windUp=.4,move=1.2){
  if(seconds<=0)return 0;
  if(seconds<windUp)return -.12*Math.sin(Math.PI*seconds/windUp);
  const x=THREE.MathUtils.clamp((seconds-windUp)/move,0,1);return 1-Math.pow(1-x,3);
}
/** Follow-through: displacement of an attached part after the body stops, as a damped spring. */
export const followThrough=(sinceStop,amplitude=.24,damping=4,omega=14)=>sinceStop<0?0:amplitude*Math.exp(-damping*sinceStop)*Math.cos(omega*sinceStop);
/** Pulse: two Gaussian peaks per beat (lub-dub); exactly 0 between them. `phase` is the beat fraction. */
export function pulse(phase){const g=(x,w)=>Math.exp(-Math.pow(x/w,2));const d=Math.min(phase,1-phase);return THREE.MathUtils.clamp(g(d,.07)+.55*g(phase-.3,.06)-.004,0,1.2)}
/** Text scramble: seeded characters, new every 2 frames, until each glyph's staggered lock time. */
export function scramble(text,seconds,frame,total=.9){
  const glyphs='ABCDEFGHJKLMNPRSTUVWXYZ0123456789';let out='';
  for(let i=0;i<text.length;i++){
    const lock=total*(i+1)/text.length;
    if(seconds>=lock||text[i]===' ')out+=text[i];
    else{let h=(Math.floor(frame/2)*374761393+i*668265263)>>>0;h=((h^(h>>>13))*1274126177)>>>0;out+=glyphs[h%glyphs.length]}
  }
  return out;
}
/** Loop phase 0..1 for a loop of `beats` beats starting at `startBeat`; the same phase always draws the same frame. */
export const loopPhase=(t,beat,startBeat,beats)=>{const x=(t/beat-startBeat)/beats;return x-Math.floor(x)};
export function scenario(t){
  // An illustrative fluid queue; units are items/s, not a measured production system.
  let queue=0;
  for(let i=0;i<Math.floor(Math.min(15,t)*60);i++){
    const seconds=i/60,arrival=seconds<9?2:seconds<12?5:1;
    queue=Math.max(0,queue+(arrival-3)/60);
  }
  return {arrival:t<9?2:t<12?5:1,service:3,queue};
}

export class MotionScene {
  constructor(canvas, film, timelines, envelopes, evidence){
    this.canvas=canvas;this.film=film;this.data=timelines;this.envelopes=envelopes;this.evidence=evidence;
    this.resources=[];this.images=[];this.width=1920;this.height=1080;this.overrideRate=null;
    this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,preserveDrawingBuffer:true});
    this.renderer.setPixelRatio(1);this.renderer.setSize(1920,1080,false);
    this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure=1.15;
    this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(37,16/9,.1,100);
    this.camera.position.set(0,1.1,13.4);this.camera.lookAt(0,0,0);
    this.scene.add(new THREE.HemisphereLight(0xddeeff,0x452661,3.4));
    for(const [color,intensity,position] of [[0xffffff,100,[0,6,5]],[0xaaa5ff,70,[6,1,4]],[0x7bffc2,55,[-4,2,2]]]){
      const light=new THREE.PointLight(color,intensity,28,2);light.position.set(...position);this.scene.add(light);
    }
    this.group=new THREE.Group();this.group.position.set(2.6,.15,0);this.scene.add(this.group);
    const dark=film==='video-analysis';
    this.scene.background=new THREE.Color(dark?0x101b27:0xf2eee5);
    this.uniforms={time:{value:0},energy:{value:0},tint:{value:new THREE.Color(dark?0x65e0cb:0x6855ec)}};
    this.material=new THREE.ShaderMaterial({uniforms:this.uniforms,
      vertexShader:`varying vec3 n; varying vec3 p; varying vec3 eye; uniform float time;
      void main(){vec3 q=position;float wave=sin(q.y*4.0+time*.65)*sin(q.x*3.0-time*.35);q+=normal*wave*.028;n=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(q,1.);eye=normalize(-mv.xyz);p=q;gl_Position=projectionMatrix*mv;}`,
      fragmentShader:`varying vec3 n;varying vec3 p;varying vec3 eye;uniform float time;uniform float energy;uniform vec3 tint;
      void main(){float facing=clamp(dot(normalize(n),normalize(eye)),0.,1.);float f=pow(1.-facing,2.4);float key=pow(max(dot(normalize(n),normalize(vec3(-.5,.8,.7))),0.),2.);
      vec3 pearl=.52+.44*cos(vec3(0.,2.1,4.2)+p.y*2.2+p.x*.65+time*.16);
      vec3 c=mix(tint*.32,pearl*.64,.20+f*.65)+key*.20+f*vec3(.06,.08,.13);
      c+=pow(max(0.,sin(p.y*9.+p.x*2.-time*.4)),30.)*.10*(.65+energy*.35);gl_FragColor=vec4(c,1.);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      }`});this.resources.push(this.material);
    this.hero=new THREE.Mesh(new THREE.TorusKnotGeometry(1.05,.29,200,32,2,3),this.material);this.group.add(this.hero);
    this.metal=new THREE.MeshPhysicalMaterial({color:dark?0x516678:0xc7cad2,metalness:.65,roughness:.24,clearcoat:1,clearcoatRoughness:.16});
    this.mint=new THREE.MeshPhysicalMaterial({color:0x7ddcb1,metalness:.25,roughness:.22,clearcoat:1});
    this.amber=new THREE.MeshPhysicalMaterial({color:0xf0b45b,metalness:.35,roughness:.22,clearcoat:1});
    this.resources.push(this.metal,this.mint,this.amber);
    this.nodes=[];this.curves=[];this.travel=[];this.paths=[];
    for(let i=0;i<3;i++){
      const a=i*Math.PI*2/3+.35,position=new THREE.Vector3(Math.cos(a)*2.65,Math.sin(a)*2.3,Math.sin(a)*.6);
      const mesh=new THREE.Mesh(i===1?new THREE.OctahedronGeometry(.45,2):new THREE.SphereGeometry(.4,32,24),i===2?this.amber:this.metal);
      mesh.position.copy(position);this.group.add(mesh);this.nodes.push(mesh);
      const curve=new THREE.CatmullRomCurve3([position.clone(),position.clone().multiplyScalar(.65).add(new THREE.Vector3(0,0,.6)),new THREE.Vector3(.2,.1,0)]);
      this.curves.push(curve);
      const line=new THREE.Mesh(new THREE.TubeGeometry(curve,64,.018,8,false),new THREE.MeshBasicMaterial({color:dark?0x5a8094:0xb2a7cb,transparent:true,opacity:.55}));
      this.group.add(line);this.paths.push(line);this.resources.push(line.material);
      const marbles=[];
      for(let j=0;j<5;j++){let m=new THREE.Mesh(new THREE.SphereGeometry(.075,14,10),this.mint);this.group.add(m);marbles.push(m)}
      this.travel.push(marbles);
    }
    this.queue=[];
    for(let i=0;i<14;i++){let m=new THREE.Mesh(new THREE.SphereGeometry(.075,16,12),this.amber);this.group.add(m);this.queue.push(m)}
    this.rings=[];
    for(let i=0;i<3;i++){
      let mesh=new THREE.Mesh(new THREE.TorusGeometry(2.05+i*.13,film==='video-analysis'?.008:.016,8,150),new THREE.MeshBasicMaterial({color:dark?0x4b7d89:0xbbb0ce,transparent:true,opacity:.45}));
      mesh.rotation.set(.4+i*.25,.3+i*.35,.15);this.group.add(mesh);this.rings.push(mesh);this.resources.push(mesh.material);
    }
    // Independent translucent geometry frames: these really move through depth.
    this.panels=[];
    for(let i=0;i<6;i++){
      const g=new THREE.Group(),edge=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(2.8,1.6,.055)),new THREE.LineBasicMaterial({color:dark?0x73d8c9:0x8977bd,transparent:true,opacity:.5}));
      g.add(edge);this.group.add(g);this.panels.push(g);this.resources.push(edge.geometry,edge.material);
    }
    this.overlay=document.createElement('canvas');this.overlay.width=1920;this.overlay.height=1080;
    this.ctx=this.overlay.getContext('2d');this.overlayTexture=new THREE.CanvasTexture(this.overlay);this.overlayTexture.colorSpace=THREE.SRGBColorSpace;
    this.overlayScene=new THREE.Scene();this.overlayCamera=new THREE.OrthographicCamera(-1,1,1,-1,0,1);
    const om=new THREE.MeshBasicMaterial({map:this.overlayTexture,transparent:true,depthTest:false,depthWrite:false,toneMapped:false});
    this.overlayScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2,2),om));this.resources.push(this.overlayTexture,om);
    this.textures=[];this.strips=[];this.disposed=false;
    // Visualizer film only: a parcel with a lagging tail, and one expanding ring for the downbeat.
    this.violet=new THREE.MeshPhysicalMaterial({color:0x6451d0,metalness:.3,roughness:.25,clearcoat:1});this.resources.push(this.violet);
    this.parcel=new THREE.Mesh(new THREE.SphereGeometry(.23,28,20),this.violet);this.tail=new THREE.Mesh(new THREE.SphereGeometry(.13,20,16),this.mint);
    // A stem ties the tail to the parcel, so the swing reads as one object finishing its move.
    this.stem=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3()]),new THREE.LineBasicMaterial({color:0x3f3a66}));this.stem.visible=false;this.stem.frustumCulled=false;this.group.add(this.stem);this.resources.push(this.stem.material);
    // The parcel travels an arc over the hero, from the first node to the second, clear of both.
    this.arc=new THREE.CatmullRomCurve3([this.nodes[0].position.clone().multiplyScalar(1.34),new THREE.Vector3(.1,2.7,.7),this.nodes[1].position.clone().multiplyScalar(1.32)]);
    this.parcel.visible=this.tail.visible=false;this.group.add(this.parcel,this.tail);
    this.beatRing=new THREE.Mesh(new THREE.TorusGeometry(1.9,.022,8,160),new THREE.MeshBasicMaterial({color:0x6451d0,transparent:true,opacity:0}));
    this.beatRing.visible=false;this.group.add(this.beatRing);this.resources.push(this.beatRing.material);
    this.beatmap=null;this.accentColor=new THREE.Color(0x6451d0);
  }
  /** Scene state for the visualizer film: sound on the beat, named motion, a loop that closes. */
  updateVisualizer(t){
    const spec=this.data.films.visualizer,B=60/spec.bpm,beats=spec.beats,b=t/B;this.spec=spec;this.B=B;
    this.shot=spec.scenes.filter(s=>t>=s.start).at(-1)??spec.scenes[0];
    const L0=beats.loop[0]*B,L1=beats.loop[1]*B,looping=t>=L0&&t<L1;
    // While the loop plays, free-running motion is held; the loop's own motion is periodic.
    const te=t<L0?t:t<L1?L0:t-(L1-L0),phase=looping?loopPhase(t,B,beats.loop[0],beats.loop_beats):0;
    this.loop={looping,phase,L0,L1};
    const level=this.envelopes.visualizer?.levels[Math.min(1919,Math.floor(t*60))]??0;
    this.uniforms.time.value=te;this.uniforms.energy.value=looping?.5+.5*Math.sin(2*Math.PI*2*phase):level;   // shimmer: two cycles per loop
    this.group.rotation.y=Math.sin(te*.14)*.16;this.group.rotation.z=Math.sin(te*.11)*.028;
    this.hero.rotation.set(te*.12,.25+te*.20,Math.sin(te*.22)*.12);
    const soundOn=smooth((b-beats.sound[0]-.3)/.8)*(1-smooth((b-beats.sound[1]+.6)/.6)),outro=smooth((t-L1)/1.5);
    const beat=pulse(b-Math.floor(b))*soundOn;                              // lub-dub on every beat of the sound scene
    const motion=smooth((b-20)/1.2)*(1-smooth((b-33.2)/.8));                // the hero steps back for the named moves
    this.hero.scale.setScalar(1.12*(1-.2*motion)*(1+.07*beat)*(1+.1*outro));
    this.hero.position.set(0,looping?.13*Math.sin(2*Math.PI*phase):Math.sin(te*.65)*.06*(1-smooth((t-L0+.5)/.5)+smooth((t-L1)/.5)),0);   // float: one cycle per loop
    this.camera.position.x=Math.sin(te*.12)*.13;this.camera.position.y=1.1+Math.sin(te*.16)*.13;this.camera.lookAt(0,0,0);
    this.rings.forEach((m,i)=>{m.visible=true;m.rotation.y=.5+i*.35+te*.035;m.rotation.z=i*.3+Math.sin(te*.25)*.05;
      m.scale.setScalar(looping?1+.09*Math.sin(2*Math.PI*2*phase):1+Math.sin(te*.45+i)*.015);                   // pulse: two cycles per loop, all rings together
      const lit=smooth((t-L0)/.4)*(1-smooth((t-L1+.4)/.4));m.material.color.set(0xbbb0ce).lerp(this.accentColor,lit);m.material.opacity=.45+.5*lit});
    // One ring expands from each downbeat of the sound scene.
    const bar=(b-beats.sound[0])/4,since=bar-Math.floor(bar);
    this.beatRing.visible=soundOn>.01&&bar>=0;this.beatRing.rotation.set(.35,.2,0);this.beatRing.scale.setScalar(.75+.75*since);this.beatRing.material.opacity=.9*soundOn*Math.pow(1-since,1.5);
    // Pop-in: one node per beat, 0.5 s each.
    this.nodes.forEach((node,i)=>{const k=backOut((t-beats.pop_in[i]*B)/.5)*(1-smooth((b-33.2)/.8));node.visible=k>.001;node.scale.setScalar(Math.max(.001,k*.9));node.rotation.y=te*.3+i;this.paths[i].visible=k>.5;this.paths[i].material.opacity=.85;this.travel[i].forEach(m=>m.visible=false)});
    this.queue.forEach(m=>m.visible=false);this.panels.forEach(p=>p.visible=false);this.strips.forEach(n=>n.visible=false);
    // Anticipation, then follow-through on the tail once the parcel stops.
    // 0.4 s wind-up and a 1.4 s release, so the stop lands on the first beat of the next scene.
    const WIND=.4,MOVE=1.4,start=beats.anticipation*B,seconds=t-start,u=anticipate(seconds,WIND,MOVE),curve=this.arc,stop=start+WIND+MOVE;
    const along=x=>x>=0?curve.getPoint(Math.min(1,x)):curve.getPoint(0).add(curve.getTangent(0).multiplyScalar(x*curve.getLength()));
    const shown=smooth((t-start+.5)/.4)*(1-smooth((b-33.2)/.8));
    this.parcel.visible=this.tail.visible=this.stem.visible=shown>.001;
    if(shown>.001){
      const p=along(u),direction=curve.getTangent(Math.min(1,Math.max(0,u)));
      const squash=seconds>0&&seconds<.4?1-.12*Math.sin(Math.PI*seconds/.4):1;                                  // squash on the wind-up
      this.parcel.position.copy(p);this.parcel.scale.set(shown/squash,shown*squash,shown/squash);
      const lag=along(anticipate(seconds-.09,WIND,MOVE)),swing=followThrough(t-stop,.55,2.2,11);
      this.tail.position.copy(lag).addScaledVector(direction,-.5+swing);this.tail.scale.setScalar(shown);
      this.stem.geometry.setFromPoints([this.parcel.position,this.tail.position]);
      this.motion={u,seconds,sinceStop:t-stop,swing};
    }else this.motion={u:0,seconds,sinceStop:t-stop,swing:0};
    this.group.position.set(2.6,.15,0);
    this.scene.updateMatrixWorld(true);this.camera.updateMatrixWorld(true);this.drawType(t,false);
  }
  async loadEvidence(){
    const frames=this.evidence?.frames??[];
    const loader=new THREE.TextureLoader();
    for(let i=0;i<Math.min(frames.length,6);i++){
      const entry=frames[Math.round(i*(frames.length-1)/5)];
      const texture=await loader.loadAsync('../evidence/'+entry.file);texture.colorSpace=THREE.SRGBColorSpace;this.textures.push(texture);
      const m=new THREE.MeshBasicMaterial({map:texture,toneMapped:false,side:THREE.DoubleSide});
      const strip=new THREE.Mesh(new THREE.PlaneGeometry(2.64,1.485),m);strip.userData.evidence=entry;
      this.group.add(strip);this.strips.push(strip);this.resources.push(m);
    }
  }
  update(t, mode=this.film){
    this.time=t;this.mode=mode;
    if(mode==='visualizer'){this.beatRing.visible=true;return this.updateVisualizer(t)}
    this.parcel.visible=this.tail.visible=this.stem.visible=this.beatRing.visible=false;this.paths.forEach(p=>p.material.opacity=.55);const analysis=mode==='video-analysis',source=mode==='sample-source';
    const spec=this.data.films[analysis?'video-analysis':'visualizer'];this.spec=spec;
    const shot=spec.scenes.filter(s=>t>=s.start).at(-1)??spec.scenes[0];this.shot=shot;
    this.uniforms.time.value=t;this.uniforms.energy.value=this.envelopes[analysis?'video-analysis':'visualizer']?.levels[Math.min(1919,Math.floor(t*60))]??0;
    const expansion=smooth((t-3)/2),tofilm=smooth((t-15)/2),outro=smooth((t-26)/1.8);
    this.group.rotation.y=Math.sin(t*.14)*.16;this.group.rotation.z=Math.sin(t*.11)*.028;
    this.hero.rotation.set(t*.12,.25+t*.20,Math.sin(t*.22)*.12);
    const heroScale=(1.12-.20*expansion)*(1-.15*tofilm)*(1+.1*outro);
    this.hero.scale.setScalar(heroScale);this.hero.position.set(0,Math.sin(t*.65)*.06,0);
    this.camera.position.x=Math.sin(t*.12)*.13;this.camera.position.y=1.1+Math.sin(t*.16)*.13;this.camera.lookAt(0,0,0);
    const model=scenario(t);
    this.nodes.forEach((node,i)=>{node.scale.setScalar(expansion*.9);node.rotation.y=t*.3+i;this.paths[i].visible=expansion>.02;
      this.travel[i].forEach((m,j)=>{m.visible=expansion>.2;const q=(t*.18+j/5)%1;m.position.copy(this.curves[i].getPoint(i===2?1-q:q));m.scale.setScalar(expansion)});
    });
    this.queue.forEach((m,i)=>{const visible=smooth((t-9)/.5)*(1-smooth((t-15)/.5));m.visible=visible>.001&&i<Math.ceil(model.queue);m.position.set(2.2-i*.15,.66,.65);m.scale.setScalar(visible)});
    this.rings.forEach((m,i)=>{m.rotation.y=.5+i*.35+t*.035;m.rotation.z=i*.3+Math.sin(t*.25)*.05; m.scale.setScalar(1+Math.sin(t*.45+i)*.015)});
    this.panels.forEach((p,i)=>{
      p.visible=tofilm>.01;p.position.set((i-2.5)*.29,0,-.8-i*.33);p.rotation.set(-.05,(1-tofilm)*.8+.17,0);
      p.scale.setScalar(tofilm*(1-outro*.5));
    });
    if(analysis){
      this.hero.visible=t<9||t>=26;
      const heroStrength=(1-smooth((t-7.7)/1.3))*.78+smooth((t-26)/1.3)*.90;
      this.hero.scale.multiplyScalar(heroStrength);
      this.nodes.forEach(n=>n.visible=false);this.paths.forEach(n=>n.visible=false);this.travel.flat().forEach(n=>n.visible=false);this.queue.forEach(n=>n.visible=false);
      this.panels.forEach(n=>n.visible=false);this.rings.forEach(n=>{n.visible=t<9||t>=26;n.scale.multiplyScalar((1-smooth((t-7.7)/1.3))+smooth((t-26)/1.3))});
      this.strips.forEach((p,i)=>{
        const reveal=smooth((t-4-i*.16)/1.1),focus=Math.floor((t-9)/1.8)%6;
        p.visible=t>=4&&t<26;
        let x=(i%3-1)*2.36,y=.95-Math.floor(i/3)*1.64,z=-.4;
        const fan=smooth((t-7)/2.5); x=THREE.MathUtils.lerp((i-2.5)*.45,x,fan);y=THREE.MathUtils.lerp((i-2.5)*.14,y,fan);z=THREE.MathUtils.lerp(-i*.5,z,fan);
        const focusLift=.28*Math.exp(-Math.pow((t-(9.5+i*.85))/.7,2));
        const trace=smooth((t-15)/1.4)*(1-smooth((t-21)/1.4));
        if(i===3){x=THREE.MathUtils.lerp(x,0,trace);y=THREE.MathUtils.lerp(y,.15,trace);z+=trace*.9}
        else {x+=Math.sign(x||1)*trace*.5;z-=trace*.75}
        p.position.set(x,y,z+focusLift);p.rotation.y=(1-fan)*-.22+Math.sin(t*.1)*.025;
        p.scale.setScalar(reveal*(i===3?.82+trace*.7:.82-trace*.3)*(1-smooth((t-25.2)/.8)));
        p.material.transparent=true;p.material.opacity=i===3?1:1-trace*.72;
        const outline=this.panels[i];outline.visible=p.visible;outline.position.copy(p.position);outline.rotation.copy(p.rotation);outline.scale.copy(p.scale);
        outline.children[0].material.opacity=.25+focusLift+trace*(i===3?.45:0);
      });
    }else{this.hero.visible=true;this.nodes.forEach(n=>n.visible=true);this.strips.forEach(n=>n.visible=false)}
    if(source){this.group.position.set(0,0,0);this.camera.position.set(0,.7,9);this.camera.lookAt(0,0,0);this.nodes.forEach(n=>n.scale.setScalar(.9));this.paths.forEach(n=>n.visible=true);this.travel.flat().forEach(n=>n.visible=true)}else this.group.position.set(2.6,.15,0);
    this.scene.updateMatrixWorld(true);this.camera.updateMatrixWorld(true);this.drawType(t,source);
  }
  text(text,x,y,size=30,color,weight=400){
    const c=this.ctx;c.fillStyle=color??this.ink;c.font=`${weight} ${size}px system-ui, -apple-system, sans-serif`;c.fillText(text,x,y);
  }
  wrap(text,x,y,size,width,color,weight=400,line=1.15){
    const c=this.ctx;c.font=`${weight} ${size}px system-ui, -apple-system, sans-serif`;
    let words=text.split(' '),row='',n=0;
    for(const word of words){if(c.measureText((row?row+' ':'')+word).width>width&&row){this.text(row,x,y+n*size*line,size,color,weight);row=word;n++}else row+=(row?' ':'')+word}
    this.text(row,x,y+n*size*line,size,color,weight);return y+(n+1)*size*line;
  }
  project(object){let v=new THREE.Vector3();object.getWorldPosition(v);v.project(this.camera);return [(v.x+1)*960,(1-v.y)*540]}
  drawType(t,source){
    const c=this.ctx;c.clearRect(0,0,1920,1080);this.ink=this.mode==='video-analysis'?'#eef3f2':'#1b2234';
    const muted=this.mode==='video-analysis'?'#91adb6':'#646b79',accent=this.mode==='video-analysis'?'#7fdfc4':'#6451d0';
    if(source){this.text('ORIGINAL SYNTHETIC SOURCE / 6 SEC',70,76,26);this.text('Lex from SigmaStudioz',70,1024,25);this.text(t.toFixed(3)+' s',1630,1024,27);this.overlayTexture.needsUpdate=true;return}
    const s=this.shot,local=t-s.start,enter=smooth(local/.8),offset=(1-enter)*18;
    c.globalAlpha=enter;
    this.text('SIGMASTUDIOZ   /   MOTION LAB',100,87,24,muted,600);
    if(this.mode==='visualizer'){c.font='550 23px system-ui, -apple-system, sans-serif';this.text('01 / VISUALIZER',1820-c.measureText('01 / VISUALIZER').width,87,23,muted,550)}
    else this.text('02 / VIDEO ANALYSIS',1365,87,23,muted,550);
    if(this.mode==='visualizer'&&s.id==='hook'){
      // Kinetic type: each word rises in on its beat (beat-synced words).
      c.font='550 86px system-ui, -apple-system, sans-serif';let x=100;const B=this.B,beats=this.spec.beats.hook_words;
      s.title.split(' ').forEach((word,i)=>{const k=smooth((t-beats[i]*B)/.22);c.globalAlpha=k;this.text(word,x,320+(1-k)*26,86,this.ink,550);x+=c.measureText(word+' ').width});
      c.globalAlpha=enter;
    }else this.wrap(s.title,100,320+offset,86,750,this.ink,550,1.03);
    const body=this.mode==='visualizer'?{hook:'A clear idea. A living system.',sound:'Cuts, words and pulses follow the score.',motion:'Name it. Give it a duration, a strength, a subject.',settle:'The part that follows sells the stop.',loop:'One verb per element. The rest stays fixed.',end:'Interactive visuals. Visualization videos.'}:{hook:'A clear idea. A living system.',model:'Meaning first. Motion with purpose.',control:'A change you can see—and explain.',film:'State → scene → frame → film.',verify:'The result has to work.',source:'Original clip. Recorded provenance.',sample:'Real frames. Actual timestamps.',trace:'Observation → interpretation.',limits:'Partial coverage stays explicit.',end:'By Lex from SigmaStudioz'};
    this.wrap(body[s.id]??'',104,570,33,690,muted,400,1.3);
    if(s.id==='end'){
      this.text('INSTALL THE SKILL',104,690,23,accent,650);
      this.text('npx skills add sigmastudioz/agent-skills',104,744,26,this.ink,500);
      this.text('--skill '+this.mode,104,788,28,accent,600);
      this.text('github.com/sigmastudioz/agent-skills',104,853,25,muted);
    }else if(this.mode==='visualizer'&&s.id==='sound'){
      const B=this.B,[b0,b1]=this.spec.beats.sound,b=t/B,map=this.beatmap;
      this.text('BEAT GRID  /  FROM THE FINAL MIX',104,680,22,accent,650);
      for(let i=b0;i<=b1;i++){const played=b>=i,down=(i-b0)%4===0;c.globalAlpha=enter*(played?1:.3);c.fillStyle=played?accent:muted;c.fillRect(104+(i-b0)*52,down?706:716,down?5:3,down?44:24)}
      c.globalAlpha=enter;c.fillStyle=this.ink;c.fillRect(104+THREE.MathUtils.clamp(b-b0,0,b1-b0)*52-1,698,2,60);
      this.text(map?`Measured ${map.fitted_bpm.toFixed(1)} BPM over ${map.beat_onsets} beat onsets`:'Beat map not loaded',104,806,29);
      this.text(map?`Mean offset ${map.residual_ms.mean.toFixed(0)} ms, largest ${map.residual_ms.max_abs.toFixed(0)} ms. One frame is 16.7 ms.`:'Run source/beatmap.py',104,850,24,muted);
    }else if(this.mode==='visualizer'&&(s.id==='motion'||s.id==='settle')){
      const B=this.B,k=this.spec.beats,b=t/B;
      const rows=[['POP-IN','0.5 s · 110 % · on the nodes',k.pop_in[0],k.pop_in[2]+1],['ANTICIPATION','0.4 s back 12 %, then release · on the parcel',k.anticipation,k.anticipation+3],['FOLLOW-THROUGH','damped spring · on the tail',k.anticipation+3,k.scramble],['TEXT SCRAMBLE','0.9 s, locks left to right · on the label',k.scramble,k.scramble+3]];
      rows.forEach(([name,detail,from,to],i)=>{const on=b>=from&&b<to,seen=b>=from;c.globalAlpha=enter*(on?1:seen?.55:.25);
        this.text(name,104,690+i*52,24,on?accent:this.ink,650);this.text(detail,372,690+i*52,24,muted,400)});
      c.globalAlpha=enter;
    }else if(this.mode==='visualizer'&&s.id==='loop'){
      const B=this.B,[b0,b1]=this.spec.beats.loop,n=this.spec.beats.loop_beats,b=t/B,loops=(b1-b0)/n;
      this.text(`LOOP  /  ${n} BEATS  ·  ${(n*B).toFixed(1)} s  ·  ${Math.round(n*B*60)} FRAMES`,104,680,22,accent,650);
      for(let i=0;i<loops;i++){const done=THREE.MathUtils.clamp((b-b0)/n-i,0,1);c.globalAlpha=enter*.3;c.fillStyle=muted;c.fillRect(104+i*212,706,200,12);c.globalAlpha=enter;c.fillStyle=accent;c.fillRect(104+i*212,706,200*done,12)}
      c.globalAlpha=enter;
      this.text('Knot floats  ·  highlight shimmers  ·  rings pulse',104,790,29);
      this.text('Fixed: camera, colour and silhouette. Frame 0 equals frame 144.',104,836,24,muted);
    }else if(this.mode==='visualizer'&&s.id==='control'){
      const m=scenario(t);this.text('ILLUSTRATIVE FLUID QUEUE',104,680,22,accent,650);
      this.text(`Arrival  ${m.arrival.toFixed(0)} /s`,104,733,29);this.text('Service  3 /s',104,777,29);
      this.text(`Queue  ${m.queue.toFixed(1)} items`,104,830,34,accent,550);
    }else if(this.mode==='visualizer'&&s.id==='film'){
      for(let i=0;i<8;i++){c.fillStyle=i<=Math.floor((t-15)*1.1)?accent:muted;c.globalAlpha=.22+((i<=Math.floor((t-15)*1.1))?.6:0);c.fillRect(104+i*76,720,60,42)}c.globalAlpha=enter;
      this.text('ONE DETERMINISTIC CLOCK  /  60 FPS',104,806,23,muted,550);
    }else if(s.id==='verify'){
      ['Model + controls','Picture + sound','Playable export'].forEach((v,i)=>{this.text('↳  '+v,104,690+i*51,30,i<(t-21)*.8?accent:muted,500)});
    }else if(this.mode==='video-analysis'&&s.id==='source'){
      this.text('LOCAL ORIGINAL  /  960 × 540',104,700,24,accent,600);
      this.text('6.000 seconds  •  60 fps',104,751,30);
      this.text('Source preserved; SHA-256 recorded',104,806,25,muted);
    }else if(this.mode==='video-analysis'&&['sample','trace','limits'].includes(s.id)){
      const rows=s.id==='sample'?[`${this.evidence?.frames.length??0} sampled · 6 shown`,'Decoded PTS, not filename math','Targeted detail when needed']:s.id==='trace'?['Source → frame','Frame → observed motion','Claim → evidence reference']:['Visual sample ≠ every frame','A transcript ≠ listening','Unknowns remain visible'];
      rows.forEach((v,i)=>this.text(v,104,692+i*56,28,i===0?accent:muted,450));
    }
    c.globalAlpha=1;
    if(this.mode==='video-analysis'&&t>=9&&t<26){
      for(const p of this.strips){if(p.material.opacity<.5)continue;const label=p.localToWorld(new THREE.Vector3(-.85,-.94,.02)).project(this.camera);this.text(`PTS ${Number(p.userData.evidence.pts_seconds).toFixed(3)} s`,(label.x+1)*960,(1-label.y)*540,20,'#a8c9cc',550)}
    }
    if(this.mode==='visualizer'){
      const B=this.B,k=this.spec.beats,b=t/B,frame=Math.round(t*60);
      this.nodes.forEach((n,i)=>{if(!n.visible||n.scale.x<.5)return;const [x,y]=this.project(n);
        // The last label decodes: seeded scramble, then locks glyph by glyph.
        if(i===2&&b<k.scramble)return;   // the last label waits for its decode
        const label=['INPUT','STATE','OUTPUT'][i],text=i===2?scramble(label,(b-k.scramble)*B,frame):label;
        c.font='600 20px ui-monospace, Menlo, monospace';c.fillStyle=i===2&&b>=k.scramble&&b<k.scramble+1.5?accent:muted;c.fillText(text,x-c.measureText(label).width/2,y+(i===1?80:64))});
    }
    c.strokeStyle=this.mode==='video-analysis'?'#314552':'#d1c9d1';c.lineWidth=1;c.beginPath();c.moveTo(100,920);c.lineTo(1820,920);c.stroke();
    this.wrap(s.caption,100,977,29,1700,this.ink,400,1.2);
    this.text('Lex from SigmaStudioz',100,1040,22,muted,550);
    if(this.mode==='visualizer'){c.font='400 21px system-ui, -apple-system, sans-serif';const note='Authored demonstration · actual Three.js render';this.text(note,1820-c.measureText(note).width,1040,21,muted)}
    else this.text('Original source · actual local frame extraction',1010,1040,21,muted);
    c.fillStyle=accent;c.fillRect(100,906,1720*Math.min(1,t/32),3);
    this.overlayTexture.needsUpdate=true;
  }
  render(t,mode=this.film,target=null){
    this.update(t,mode);this.renderer.setRenderTarget(target);this.renderer.autoClear=true;this.renderer.render(this.scene,this.camera);
    this.renderer.autoClear=false;this.renderer.clearDepth();this.renderer.render(this.overlayScene,this.overlayCamera);this.renderer.autoClear=true;
  }
  dispose(){
    if(this.disposed)return;this.disposed=true;
    this.scene.traverse(o=>o.geometry?.dispose());this.overlayScene.traverse(o=>o.geometry?.dispose());
    [...new Set([...this.resources,...this.textures])].forEach(r=>r.dispose());this.renderer.dispose();
  }
}
