import assert from 'node:assert/strict';
import {scenario} from './scene.js';

assert.equal(scenario(0).queue,0,'empty initial state');
assert.equal(scenario(9).queue,0,'stable input leaves no backlog');
assert.ok(Math.abs(scenario(12).queue-6)<1e-7,'three-second overload creates six waiting items');
assert.ok(scenario(13.5).queue<scenario(12).queue,'recovery drains the waiting queue');
assert.ok(scenario(15).queue<1e-7,'recovery completes before the next scene');
for(let t=0;t<=32;t+=.125){assert.ok(scenario(t).queue>=0);assert.deepEqual(scenario(t),scenario(t))}
console.log('Illustrative queue boundaries, nonnegative state and seek repeatability: passed.');
