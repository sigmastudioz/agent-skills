import assert from 'node:assert/strict';
import {scenario,backOut,anticipate,followThrough,pulse,scramble,loopPhase} from './scene.js';

assert.equal(scenario(0).queue,0,'empty initial state');
assert.equal(scenario(9).queue,0,'stable input leaves no backlog');
assert.ok(Math.abs(scenario(12).queue-6)<1e-7,'three-second overload creates six waiting items');
assert.ok(scenario(13.5).queue<scenario(12).queue,'recovery drains the waiting queue');
assert.ok(scenario(15).queue<1e-7,'recovery completes before the next scene');
for(let t=0;t<=32;t+=.125){assert.ok(scenario(t).queue>=0);assert.deepEqual(scenario(t),scenario(t))}
console.log('Illustrative queue boundaries, nonnegative state and seek repeatability: passed.');

// Named motion in the visualizer film: each function is pure in time.
assert.ok(Math.abs(backOut(0))<1e-12&&Math.abs(backOut(1)-1)<1e-12,'pop-in starts at 0 and settles at exactly 1');
assert.ok(Math.max(...Array.from({length:101},(_,i)=>backOut(i/100)))>1.09,'pop-in overshoots to about 110 %');
assert.ok(Math.min(...Array.from({length:41},(_,i)=>anticipate(i/100)))<-.11,'anticipation moves back about 12 % first');
assert.equal(anticipate(0),0);assert.equal(anticipate(1.6),1);assert.ok(anticipate(.9)>anticipate(.5),'release is monotonic');
assert.equal(followThrough(-.1),0);assert.ok(Math.abs(followThrough(2))<1e-3,'follow-through settles');
assert.ok(pulse(0)>.95&&pulse(.6)<.01&&pulse(.3)>.5,'pulse: two peaks per beat and rest between them');
assert.equal(scramble('OUTPUT',.9,120),'OUTPUT');assert.equal(scramble('OUTPUT',.2,120),scramble('OUTPUT',.2,121),'scramble holds for two frames');
assert.equal(scramble('OUTPUT',.2,120).slice(0,1),'O');assert.notEqual(scramble('OUTPUT',.2,120),'OUTPUT');
for(const t of [20.4,21.3,22.05])assert.ok(Math.abs(loopPhase(t,.6,34,4)-loopPhase(t+2.4,.6,34,4))<1e-9,'loop phase repeats every 4 beats');
console.log('PASS: pop-in, anticipation, follow-through, pulse, text scramble and loop phase');
