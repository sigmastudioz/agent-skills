"""Serve this film locally with real byte-range support for media seeking."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import os
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parent


def byte_range(header,size):
    match=re.fullmatch(r'bytes=(\d*)-(\d*)',header)
    if not match or not any(match.groups()):raise ValueError('Unsupported range')
    a,b=match.groups()
    if a:
        first=int(a);last=min(size-1,int(b)) if b else size-1
    else:
        if int(b)<=0:raise ValueError('Invalid suffix')
        first=max(0,size-int(b));last=size-1
    if first>=size or first>last:raise ValueError('Range outside file')
    return first,last


class MediaHandler(SimpleHTTPRequestHandler):
    def send_head(self):
        self.selected_range=None
        if self.path.split('?',1)[0]=='/':self.path='/preview.html'
        path=Path(self.translate_path(self.path)).resolve()
        root=Path(self.directory).resolve()
        if root not in path.parents or not path.is_file():
            self.send_error(404);return None
        size=path.stat().st_size
        if self.headers.get('Range'):
            try:self.selected_range=byte_range(self.headers['Range'],size)
            except ValueError:
                self.send_response(416);self.send_header('Content-Range',f'bytes */{size}')
                self.send_header('Content-Length','0');self.end_headers();return None
        source=path.open('rb')
        if self.selected_range:
            first,last=self.selected_range;source.seek(first)
            self.send_response(206);self.send_header('Content-Range',f'bytes {first}-{last}/{size}')
            self.send_header('Content-Length',str(last-first+1))
        else:
            self.send_response(200);self.send_header('Content-Length',str(size))
        self.send_header('Content-Type',self.guess_type(str(path)))
        self.send_header('Accept-Ranges','bytes')
        self.send_header('Cache-Control','no-cache')
        self.end_headers();return source

    def copyfile(self,source,destination):
        remaining=self.selected_range[1]-self.selected_range[0]+1 if self.selected_range else None
        try:
            while remaining is None or remaining>0:
                block=source.read(65536 if remaining is None else min(65536,remaining))
                if not block:break
                destination.write(block)
                if remaining is not None:remaining-=len(block)
        except (BrokenPipeError,ConnectionResetError):pass


