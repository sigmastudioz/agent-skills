"""Original stereo music and synchronized synthesized foley. Lex from SigmaStudioz."""
import hashlib
import json
import math
from pathlib import Path
import subprocess
import wave
import numpy as np

ROOT=Path(__file__).resolve().parent
RATE=48000
KINDS={'bloom','fold','fly','wipe','pop','click','scan','tear','block','stitch','resolve','chime'}


def note(hz,duration,level=.1):
    t=np.arange(round(duration*RATE))/RATE
    envelope=(1-np.exp(-t*240))*np.exp(-t*3.1)*np.minimum(1,(duration-t)*10)
    # Detuned fundamentals and quiet partials make a soft felt-key attack.
    signal=.72*np.sin(2*np.pi*hz*t)+.20*np.sin(2*np.pi*hz*1.0015*t)
    signal+=.13*np.sin(2*np.pi*hz*2*t)*np.exp(-t*5)
    signal+=.035*np.sin(2*np.pi*hz*3*t)*np.exp(-t*8)
    return signal*envelope*level


def pad(frequencies,duration):
    t=np.arange(round(duration*RATE))/RATE
    envelope=np.minimum(1,t/.8)**2*np.minimum(1,(duration-t)/1.25)**2
    output=np.zeros((len(t),2))
    for j,hz in enumerate(frequencies):
        wave=(np.sin(2*np.pi*hz*t+.018*np.sin(t*2.7))+
              .22*np.sin(2*np.pi*hz*2*t)+.07*np.sin(2*np.pi*hz*3*t))
        wave+=.3*np.sin(2*np.pi*hz*.9984*t)
        output+=pan(wave*envelope*.017,(-.6+j*.4))
    return output


def room(signal):
    # Dark, short stereo reflections; the dry foreground remains precise.
    wet=np.zeros_like(signal)
    for delay,level in [(.037,.13),(.061,.11),(.097,.09),(.153,.075),(.239,.055),(.347,.035),(.463,.02)]:
        shift=round(delay*RATE)
        wet[shift:]+=signal[:-shift,::-1]*level
    return wet


def pan(mono,position):
    position=np.clip(position,-1,1)
    angle=(position+1)*np.pi/4
    return np.column_stack((mono*np.cos(angle),mono*np.sin(angle)))


def mix(target,signal,start):
    first=round(start*RATE)
    if first<0:raise ValueError('Negative cue time')
    n=min(len(signal),len(target)-first)
    if n>0:target[first:first+n]+=signal[:n]


def effect(kind,rng):
    if kind not in KINDS:raise ValueError('Unknown effect '+kind)
    duration={'fold':.34,'click':.18,'stitch':.18,'pop':.32,'tear':.78,'block':.55,
              'fly':.95,'wipe':.82,'scan':.85,'bloom':1.8,'resolve':2.3,'chime':1.5}[kind]
    t=np.arange(round(duration*RATE))/RATE
    noise=rng.uniform(-1,1,len(t))
    low=np.convolve(noise,np.ones(35)/35,'same')
    texture=low-np.convolve(low,np.ones(160)/160,'same')
    if kind in ('fly','wipe','scan'):
        env=np.sin(np.pi*t/duration)**2
        chirp=np.sin(2*np.pi*(95*t+290*t*t/duration))
        silk=noise-np.convolve(noise,np.ones(9)/9,'same')
        s=(texture*.85+silk*.035+chirp*.025)*env
    elif kind in ('fold','stitch'):
        env=np.exp(-t*22)*(1-np.exp(-t*250))
        s=(texture*1.1+.10*np.sin(2*np.pi*(410*t-120*t*t)))*env
        s+=.12*np.sin(2*np.pi*1240*t)*np.exp(-t*80)
    elif kind in ('click','pop'):
        s=(.26*np.sin(2*np.pi*(320*t-230*t*t))+.10*np.sin(2*np.pi*960*t))*np.exp(-t*38)
        s+=texture*.4*np.exp(-t*75)
    elif kind=='tear':
        s=texture*(.6+.4*np.sin(2*np.pi*37*t))*np.sin(np.pi*t/duration)**.5
        s+=.16*np.sin(2*np.pi*(90*t-40*t*t))*np.exp(-t*13)
    elif kind=='block':
        s=.22*np.sin(2*np.pi*(92*t-40*t*t))*np.exp(-t*12)
        s+=.07*np.sin(2*np.pi*270*t)*np.exp(-t*18)
    else:
        frequencies={'bloom':[293.66,440,523.25,659.25],
                     'resolve':[293.66,349.23,440,587.33],
                     'chime':[587.33,880]}[kind]
        s=np.zeros(len(t))
        for j,f in enumerate(frequencies):
            sound=note(f,max(.1,duration-j*.075),.15/len(frequencies))
            offset=round(j*.075*RATE);s[offset:offset+len(sound)]+=sound[:len(s)-offset]
    s*=np.minimum(1,t*300)*np.minimum(1,(duration-t)*120)
    return s


def write_wave(path,data):
    with wave.open(str(path),'wb') as f:
        f.setnchannels(2);f.setsampwidth(2);f.setframerate(RATE)
        f.writeframes(np.clip(data*32767,-32768,32767).astype('<i2').tobytes())


