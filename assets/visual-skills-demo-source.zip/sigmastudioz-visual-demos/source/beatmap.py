"""Measure the beat grid of a rendered score and write audio/<film>-beatmap.json.

Kick onsets are detected in the final normalized WAV (low band, energy rise), a constant grid is
fitted to them, and the residuals are reported. Picture events are authored on the grid declared in
timelines.json; this file is the measurement that says how far the audible beats sit from it.
Usage: python3 source/beatmap.py visualizer
"""
import hashlib
import json
from pathlib import Path
import sys
import wave
import numpy as np

ROOT = Path(__file__).resolve().parent.parent


def measure(name):
    spec = json.loads((ROOT/'source/timelines.json').read_text())['films'][name]
    path = ROOT/'audio'/f'{name}.wav'
    with wave.open(str(path)) as f:
        rate = f.getframerate()
        mono = np.frombuffer(f.readframes(f.getnframes()), dtype='<i2').reshape(-1, 2).mean(axis=1)/32768
    # Low band (the kick sweeps down toward 50 Hz): moving-average low-pass, then a 1 ms energy envelope.
    width = rate//200
    low = np.convolve(mono, np.ones(width)/width, 'same')
    hop = rate//1000
    energy = np.sqrt(np.mean(low[:len(low)//hop*hop].reshape(-1, hop)**2, axis=1))
    smooth = np.convolve(energy, np.ones(8)/8, 'same')
    rise = smooth[20:]-smooth[:-20]                          # energy gained over the next 20 ms
    threshold = .35*np.percentile(rise, 99.9)
    onsets, i = [], 0
    while i < len(rise):
        if rise[i] > threshold:
            j = i+int(np.argmax(rise[i:i+60]))               # steepest point of this attack
            floor = smooth[max(0, j-30):j+1].min()
            peak = smooth[j:j+60].max()
            k = j
            while k > 0 and smooth[k] > floor+.1*(peak-floor):   # walk back to 10 % of the attack
                k -= 1
            onsets.append(k*hop/rate)
            i = j+250                                        # one onset per kick
        else:
            i += 1
    beat = 60/spec['bpm']
    times = np.array(onsets)
    offsets = times-np.round(times/beat)*beat               # against the authored grid the picture uses
    on = np.abs(offsets) <= .05                             # within 50 ms of a beat: a beat onset
    index = np.round(times[on]/beat)
    slope, intercept = np.polyfit(index, times[on], 1)      # fitted seconds per beat and first-beat offset
    residual = offsets[on]
    result = {
        'film': name, 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'method': 'low-band onsets (10 % of each attack on a 1 ms energy envelope) in the final normalized WAV; least-squares grid fit over onsets within 50 ms of a beat',
        'declared_bpm': spec['bpm'], 'fitted_bpm': round(60/slope, 3), 'fitted_offset_ms': round(intercept*1000, 1),
        'beat_onsets': int(on.sum()), 'beats_matched': sorted(int(i) for i in set(index)),
        'residual_ms': {'mean': round(float(residual.mean())*1000, 1), 'max_abs': round(float(np.abs(residual).max())*1000, 1)},
        'frame_ms_at_60fps': 16.7,
        'off_grid_onsets_s': [round(float(t), 3) for t in times[~on]],
        'beat_onset_times_s': [round(float(t), 4) for t in times[on]],
        'limits': 'Only beats that carry a low-band attack are measured. The detector resolves about 10 ms, and it marks the start of an attack, so it reads slightly early. Off-grid onsets are sound effects placed by the cue sheet (sweeps, the wind-up and release). No listening review by the agent.',
    }
    (ROOT/'audio'/f'{name}-beatmap.json').write_text(json.dumps(result, indent=2)+'\n')
    print(name, 'fitted', result['fitted_bpm'], 'BPM; residual mean', result['residual_ms']['mean'], 'ms, max', result['residual_ms']['max_abs'], 'ms over', result['beat_onsets'], 'beat onsets;', len(result['off_grid_onsets_s']), 'off-grid')


if __name__ == '__main__':
    for film in sys.argv[1:] or ['visualizer']:
        measure(film)
