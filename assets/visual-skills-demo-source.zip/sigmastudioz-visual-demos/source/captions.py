"""Write exports/<film>.srt and .vtt from the scene captions in source/timelines.json.
Usage: python3 source/captions.py visualizer
"""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent.parent


def stamp(seconds, comma):
    ms = round(seconds*1000); h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f'{h:02d}:{m:02d}:{s:02d}{"," if comma else "."}{ms:03d}'


for film in sys.argv[1:] or ['visualizer']:
    scenes = json.loads((ROOT/'source/timelines.json').read_text())['films'][film]['scenes']
    cues = [(s['start'], s['start']+s['duration'], s['caption']) for s in scenes]
    (ROOT/'exports'/f'{film}.srt').write_text('\n\n'.join(f'{i}\n{stamp(a, True)} --> {stamp(b, True)}\n{t}' for i, (a, b, t) in enumerate(cues, 1))+'\n')
    (ROOT/'exports'/f'{film}.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f'{stamp(a, False)} --> {stamp(b, False)}\n{t}' for a, b, t in cues)+'\n')
    print(film, len(cues), 'caption cues written')
