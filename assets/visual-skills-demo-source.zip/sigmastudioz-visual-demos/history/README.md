# Earlier Visualizer cut

The first Visualizer film (2026-10-18) explained an illustrative fluid queue. Its render receipt,
captions, poster and contact sheet are kept here. The MP4 itself is not in this bundle; it is in
the repository history of `assets/visualizer-demo.mp4` before the 2026-11-13 re-cut.
