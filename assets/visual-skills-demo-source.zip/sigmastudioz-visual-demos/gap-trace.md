# Demo connected-path trace

Owner: Lex from SigmaStudioz. Scope: two local Three.js demonstration films and editable sources.
No marketplace plugin/version, account, publisher attestation or launch post changes are required.

| Path | Consumer and contract | Checks / current status |
| --- | --- | --- |
| `source/timelines.json` | Scene titles/captions, cue times,32s duration and60fps clock consumed by both render/audio adapters | Both timelines contiguous; six contiguous captions per film validated |
| `source/scene.js` / `scenario` | Deterministic illustrative queue and stable object identity, replayed by preview/export | Queue rises under overload and drains under recovery; boundary and repeated-time checks pass |
| `MotionScene` | Actual geometry/materials/camera, separate undistorted text overlay, actual evidence texture loader | GPU study120frames exported/fully decoded; both final1920-frame exports fully decoded |
| `source/soundtrack.py` → `shared/audio_synthesis.py` | Original score/cues → normalized WAV → hashed60fps RMS envelope | Both mastered near−16LUFS/−1.5dBTP; encoded results−16.2LUFS each; peaks−1.53/−1.40dBTP; no listening review claimed |
| `source/app.js` | Controls → absolute time → scene; explicit export operation → bounded two-frame target readback | Chapters/film switch/seeks observed; seek/replay/mute/volume/motion/switch and real context-loss fallback pass |
| `source/server.py` → `shared/media_server.py` | Same-origin loopback frames → FFmpeg → staged MP4 → full decode → atomic delivery | Study and original source exports succeed; foreign-origin write403, byte-range206, invalid-range416 and root containment checks pass; duplicate output409preserves finished hashes |
| Source film → released sampler → `prepare_evidence.py` | Original960×540/6s clip → actual PTS/images/hash → manifest → six selected images | Source SHA verified;11actual samples,6displayed; visual sample grid inspected |
| MP4/captions/poster/sourceZIP → review links | Full export → independent decoder/player and reusable package | both MP4s ready4/errornull/duration32; observed time advance; all scene/transition contact sheets inspected |

## Findings and resolutions

- D01 fixed: FFmpeg9 reports progress after loudnorm JSON. Parse exactly one JSON object rather
  than assuming the remainder of stderr is JSON. Both audio passes now succeed.
- D02 fixed: requested frame budget was incorrectly treated as a guaranteed sample count in the
  preparation adapter. Preserve the actual11returned samples and render that number in copy.
  Sparse sample coverage remains explicit, including an unsampled tail after5.5seconds.
- D03 fixed: stack-to-grid placement had a branch at9seconds which could produce a spatial jump.
  Use one continuous interpolation and smooth focus lifts. Check in final transition frames.
- D04 fixed: fixed screen-offset timestamps could overlap an enlarged evidence image. Project
  the label from its actual plane-local lower edge instead.
- D05 fixed: export used an unmultisampled target despite a smooth on-screen preview. Final
  exports read the antialiased display framebuffer; do not relabel the earlier study as that proof.
- D07 fixed: the illustrative overload initially left a nonzero queue at the recovery beat.
  Reduce overload input to5items/s against3items/s service, then1item/s recovery. Boundary
  and repeated-time checks prove queue6at12s and zero at15s. Output parcels now travel outward;
  the waiting queue is placed at input. The initial Visualizer export is retained as superseded.
- D08 fixed: offscreen render targets in pinned Three.js bypass the display transfer/tone-map
  path. The raw export was darker than the preview. Read the actual final antialiased display
  framebuffer so preview and export share the same color path. Preserve initial exports and
  regenerate source evidence and both final films. Check dark-slate/cream output pixels.
- D09 fixed: the analysis hero disappeared at9s and reappeared at26s without a spatial
  handoff. Ease its scale into/out of the evidence frames and collapse the grid before the end
  reveal. Re-render the analysis master; retain the preceding edit as superseded.
- D06 open: subjective listening review unavailable in the current agent tool surface. Measure
  encoded loudness, true peak, stereo/mono correlation and clipping; preserve this limit.

All new modules are inventoried above. Final `validation.json` binds completed checks to source
hashes and media hashes; static inspection does not establish unseen user environments.

## Final state

Both final delivery hashes, source hashes, actual encoded measurements and exact browser-control
observations are in `validation.json`. All eight inventoried connected paths have runtime evidence
for their successful consumer route. Encoder disk-full/disconnect recovery is statically traced,
not fault-injected. D06 remains a subjective listening-review limit. No universal gap-free or
realtime-performance claim is made. Final source package excludes superseded films and private media.
