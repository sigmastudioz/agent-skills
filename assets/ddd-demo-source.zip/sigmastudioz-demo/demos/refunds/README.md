# Refund workflow demo

By **Lex from SigmaStudioz**. Synthetic, in-memory teaching fixture; no credentials,
customer data, network service, dependencies or payment provider are required.

From the repository root, with Node.js 20 or later:

```sh
node demos/refunds/reproduce-gap.mjs
node --test demos/refunds/*.test.mjs
```

The first command safely reproduces a deliberately unsafe object-spread boundary
against an isolated in-memory store. It is an illustrative reconstruction of the
recorded tenant-authority bug, not a verbatim recording of the earlier edit.
The second command checks the repaired API, worker, shared billing services and read
consumer: 16 refund cases and 2 original payment regressions.

Follow `apps/api/src/index.mjs` and `apps/worker/src/index.mjs` into the public billing
facade, `services/refund-payment.mjs`, and `adapters/store.mjs`. Authenticated tenant
context wins over forged body/job fields. Both consumers share retry results;
`JSON.stringify([tenantId, requestId])` keeps compound identities distinct.

The store is process-local, keyed by the fixture's unique payment IDs. It models no
database transactions, concurrent writers, durable idempotency, network auth layer,
or payment-provider effects. Passing these cases does not establish production readiness.

The accompanying animation is a visual replay of this workflow. Historical fresh
Claude Code 1.0.5 evidence remains in [the validation receipt](../../docs/validation.json).
Branding release 1.0.6 did not rerun that native session. This fixture can be verified
independently today without pretending to be a new agent session.
