export function createApi({ billing }) {
  return {
    async request({ method, path, tenantId, body }) {
      if (method === 'GET' && path.startsWith('/payments/')) {
        const result = await billing.getPayment({ tenantId, paymentId: path.slice(10) });
        return result ? { status: 200, body: result } : { status: 404, body: { code: 'NOT_FOUND' } };
      }
      if (method === 'POST' && path === '/refunds') {
        try {
          const { paymentId, amountCents, requestId } = body ?? {};
          const result = await billing.refundPayment({ paymentId, amountCents, requestId, tenantId });
          return { status: 200, body: result };
        } catch (err) {
          const status = err.code === 'NOT_FOUND' ? 404
            : err.code === 'INVALID_AMOUNT' || err.code === 'INVALID_REQUEST_ID' ? 400
            : 409;
          return { status, body: { code: err.code } };
        }
      }
      return { status: 404, body: { code: 'ROUTE_NOT_FOUND' } };
    }
  };
}
