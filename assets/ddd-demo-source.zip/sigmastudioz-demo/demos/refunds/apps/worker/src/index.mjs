export function createWorker({ billing }) {
  const handlers = {
    'record-payment': job => billing.recordPayment({ ...job.payload, tenantId: job.tenantId }),
    'refund-payment': job => billing.refundPayment({ ...job.payload, tenantId: job.tenantId })
  };
  return {
    async run(job) {
      if (!handlers[job.type]) throw Object.assign(new Error('Unknown job'), { code: 'UNKNOWN_JOB' });
      return handlers[job.type](job);
    }
  };
}
