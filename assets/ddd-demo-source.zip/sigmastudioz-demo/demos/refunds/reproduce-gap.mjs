// An illustrative reconstruction of the recorded authority-field defect.
// This is a deliberately unsafe demonstration, never an exported app entrypoint.
import assert from 'node:assert/strict';
import {createBilling,createStore} from './packages/billing/src/index.mjs';
const store=createStore([{id:'pay-1',tenantId:'alpha',amountCents:1000,refundedCents:0}]);
const billing=createBilling({store});
const authenticatedTenant='beta';
const body={tenantId:'alpha',paymentId:'pay-1',amountCents:300,requestId:'example'};
const unsafeInput={tenantId:authenticatedTenant,...body};
const result=await billing.refundPayment(unsafeInput);
assert.equal(result.refundedCents,300);
console.log('GAP REPRODUCED: payload replaced trusted tenant; unauthorized refund reached billing.');
console.log('The repaired API explicitly selects body fields and supplies tenantId from auth.');
