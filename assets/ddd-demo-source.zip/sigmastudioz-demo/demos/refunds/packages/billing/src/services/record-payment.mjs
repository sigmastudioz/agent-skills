export function recordPayment(store, input) {
  if (!Number.isSafeInteger(input.amountCents) || input.amountCents <= 0) {
    throw Object.assign(new Error('Invalid amount'), { code: 'INVALID_AMOUNT' });
  }
  return store.savePayment({ id: input.id, tenantId: input.tenantId,
    amountCents: input.amountCents, refundedCents: 0 });
}
