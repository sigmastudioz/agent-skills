export function refundPayment(store, input) {
  const { tenantId, paymentId, amountCents, requestId } = input;

  if (!Number.isSafeInteger(amountCents) || amountCents <= 0) {
    throw Object.assign(new Error('Invalid amount'), { code: 'INVALID_AMOUNT' });
  }

  if (!requestId || typeof requestId !== 'string') {
    throw Object.assign(new Error('Invalid request ID'), { code: 'INVALID_REQUEST_ID' });
  }

  const payment = store.getPayment(paymentId);
  if (!payment || payment.tenantId !== tenantId) {
    throw Object.assign(new Error('Not found'), { code: 'NOT_FOUND' });
  }

  const key = JSON.stringify([tenantId, requestId]);
  const existing = store.getRequest(key);
  if (existing) {
    if (existing.paymentId === paymentId && existing.amountCents === amountCents) {
      return existing.result;
    }
    throw Object.assign(new Error('Idempotency conflict'), { code: 'IDEMPOTENCY_CONFLICT' });
  }

  if ((payment.amountCents - payment.refundedCents) < amountCents) {
    throw Object.assign(new Error('Refund exceeds remaining'), { code: 'REFUND_EXCEEDS_REMAINING' });
  }

  payment.refundedCents += amountCents;
  store.savePayment(payment);

  const result = {
    paymentId: payment.id,
    refundedCents: payment.refundedCents,
    remainingCents: payment.amountCents - payment.refundedCents,
    requestId
  };

  store.saveRequest(key, { paymentId, amountCents, result });

  return result;
}
