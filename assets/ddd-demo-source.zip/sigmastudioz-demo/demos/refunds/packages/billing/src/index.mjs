import { recordPayment } from './services/record-payment.mjs';
import { refundPayment } from './services/refund-payment.mjs';
export { createStore } from './adapters/store.mjs';
export function createBilling({ store }) {
  return {
    recordPayment(input) { return recordPayment(store, input); },
    getPayment({ tenantId, paymentId }) {
      const payment = store.getPayment(paymentId);
      return payment?.tenantId === tenantId ? payment : undefined;
    },
    refundPayment(input) { return refundPayment(store, input); }
  };
}
