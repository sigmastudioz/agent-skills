export function createStore(seed = []) {
  const payments = new Map(seed.map(p => [p.id, { ...p }]));
  const requests = new Map();
  return {
    getPayment(id) { const p = payments.get(id); return p ? { ...p } : undefined; },
    savePayment(p) { payments.set(p.id, { ...p }); return { ...p }; },
    getRequest(key) { return requests.get(key); },
    saveRequest(key, value) { requests.set(key, value); },
    listPayments() { return [...payments.values()].map(p => ({ ...p })); }
  };
}
