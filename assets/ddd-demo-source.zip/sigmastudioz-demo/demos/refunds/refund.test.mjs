import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL, fileURLToPath } from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const load=rel=>import(pathToFileURL(path.join(root,rel)).href);
const {createBilling,createStore}=await load('packages/billing/src/index.mjs');
const {createApi}=await load('apps/api/src/index.mjs');
const {createWorker}=await load('apps/worker/src/index.mjs');
function setup(){
 const store=createStore([{id:'pay-1',tenantId:'alpha',amountCents:1000,refundedCents:0},{id:'pay-2',tenantId:'alpha',amountCents:1000,refundedCents:0},{id:'pay-b',tenantId:'beta',amountCents:1000,refundedCents:0}]);
 const billing=createBilling({store});const api=createApi({billing});const worker=createWorker({billing});
 return {store,billing,api,worker,post:(body,tenantId='alpha')=>api.request({method:'POST',path:'/refunds',tenantId,body}),job:(payload,tenantId='alpha')=>worker.run({type:'refund-payment',tenantId,payload})};
}
const request=(extra={})=>({paymentId:'pay-1',amountCents:300,requestId:'request-1',...extra});
const verify=(body,total=300,remaining=700)=>{assert.equal(body.paymentId,'pay-1');assert.equal(body.refundedCents,total);assert.equal(body.remainingCents,remaining);assert.equal(body.requestId,'request-1');};
test('API entrypoint is wired to persisted refund behavior',async()=>{const c=setup(),r=await c.post(request());assert.equal(r.status,200);verify(r.body);assert.equal(c.store.getPayment('pay-1').refundedCents,300);});
test('worker registry is wired to persisted refund behavior',async()=>{const c=setup();verify(await c.job(request()));assert.equal(c.store.getPayment('pay-1').refundedCents,300);});
test('API-to-worker retries share idempotency and original result',async()=>{const c=setup(),a=await c.post(request()),b=await c.job(request());assert.equal(a.status,200);assert.deepEqual(b,a.body);assert.equal(c.store.getPayment('pay-1').refundedCents,300);});
test('worker-to-API retries share idempotency',async()=>{const c=setup(),a=await c.job(request()),b=await c.post(request());assert.equal(b.status,200);assert.deepEqual(b.body,a);assert.equal(c.store.getPayment('pay-1').refundedCents,300);});
test('reused request ID rejects a different amount without mutation',async()=>{const c=setup();await c.job(request());const r=await c.post(request({amountCents:400}));assert.equal(r.status,409);assert.equal(r.body.code,'IDEMPOTENCY_CONFLICT');assert.equal(c.store.getPayment('pay-1').refundedCents,300);});
test('reused request ID rejects a different payment across consumers',async()=>{const c=setup();await c.post(request());await assert.rejects(c.job(request({paymentId:'pay-2'})),e=>e.code==='IDEMPOTENCY_CONFLICT');assert.equal(c.store.getPayment('pay-2').refundedCents,0);});
test('request identity is isolated between tenants',async()=>{const c=setup();await c.job(request());const r=await c.post(request({paymentId:'pay-b'}),'beta');assert.equal(r.status,200);assert.equal(c.store.getPayment('pay-b').refundedCents,300);});
test('API cannot refund another tenant or trust a forged body tenant',async()=>{const c=setup(),r=await c.post(request({tenantId:'alpha'}),'beta');assert.equal(r.status,404);assert.equal(r.body.code,'NOT_FOUND');assert.equal(c.store.getPayment('pay-1').refundedCents,0);});
test('worker cannot refund another tenant or trust a forged payload tenant',async()=>{const c=setup();await assert.rejects(c.job(request({tenantId:'alpha'}),'beta'),e=>e.code==='NOT_FOUND');assert.equal(c.store.getPayment('pay-1').refundedCents,0);});
test('invalid amount classes are rejected without state changes',async()=>{for(const amountCents of [0,-1,1.5,NaN,Infinity,'300',Number.MAX_SAFE_INTEGER+1]){const c=setup(),r=await c.post(request({amountCents}));assert.equal(r.status,400,String(amountCents));assert.equal(r.body.code,'INVALID_AMOUNT');assert.equal(c.store.getPayment('pay-1').refundedCents,0);}});
test('remaining balance is enforced after previous refunds',async()=>{const c=setup();await c.job(request({amountCents:800}));const r=await c.post(request({amountCents:201,requestId:'second'}));assert.equal(r.status,409);assert.equal(r.body.code,'REFUND_EXCEEDS_REMAINING');assert.equal(c.store.getPayment('pay-1').refundedCents,800);});
test('missing request IDs reject without mutation',async()=>{for(const requestId of ['',null,undefined]){const c=setup(),r=await c.post(request({requestId}));assert.equal(r.status,400);assert.equal(r.body.code,'INVALID_REQUEST_ID');assert.equal(c.store.getPayment('pay-1').refundedCents,0);}});
test('failed requests do not poison a subsequent valid request',async()=>{const c=setup();assert.equal((await c.post(request({amountCents:0}))).status,400);const r=await c.post(request());assert.equal(r.status,200);verify(r.body);});
test('identical retry returns the original result after a later refund',async()=>{const c=setup(),first=await c.job(request());await c.job(request({amountCents:200,requestId:'second'}));const retry=await c.post(request());assert.equal(retry.status,200);assert.deepEqual(retry.body,first);assert.equal(c.store.getPayment('pay-1').refundedCents,500);});
test('read consumer sees updated totals and existing worker remains usable',async()=>{const c=setup();await c.job(request());const read=await c.api.request({method:'GET',path:'/payments/pay-1',tenantId:'alpha'});assert.equal(read.status,200);assert.equal(read.body.refundedCents,300);const saved=await c.worker.run({type:'record-payment',tenantId:'alpha',payload:{id:'new',amountCents:200}});assert.equal(saved.refundedCents,0);});
test('tenant/request identity tuples cannot collide through delimiters',async()=>{
 for(const delimiter of [':','\0']){
 const store=createStore([{id:'one',tenantId:'alpha'+delimiter+'x',amountCents:1000,refundedCents:0},{id:'two',tenantId:'alpha',amountCents:1000,refundedCents:0}]);
 const billing=createBilling({store}),worker=createWorker({billing}),api=createApi({billing});
 await worker.run({type:'refund-payment',tenantId:'alpha'+delimiter+'x',payload:{paymentId:'one',amountCents:100,requestId:'request'}});
 const result=await api.request({method:'POST',path:'/refunds',tenantId:'alpha',body:{paymentId:'two',amountCents:200,requestId:'x'+delimiter+'request'}});
 assert.equal(result.status,200);assert.equal(store.getPayment('two').refundedCents,200);
 }
});
