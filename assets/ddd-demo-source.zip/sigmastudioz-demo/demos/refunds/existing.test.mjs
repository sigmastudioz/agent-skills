import test from 'node:test';
import assert from 'node:assert/strict';
import { createStore, createBilling } from './packages/billing/src/index.mjs';
import { createApi } from './apps/api/src/index.mjs';
import { createWorker } from './apps/worker/src/index.mjs';
test('existing record job is available to the matching API tenant', async () => {
  const billing = createBilling({ store: createStore() });
  await createWorker({ billing }).run({ type:'record-payment', tenantId:'alpha', payload:{id:'one',amountCents:1000} });
  const result = await createApi({ billing }).request({method:'GET',path:'/payments/one',tenantId:'alpha'});
  assert.equal(result.status,200); assert.equal(result.body.amountCents,1000);
});
test('other tenants cannot read a payment', async () => {
  const billing = createBilling({ store: createStore([{id:'one',tenantId:'alpha',amountCents:1000,refundedCents:0}]) });
  assert.equal((await createApi({billing}).request({method:'GET',path:'/payments/one',tenantId:'beta'})).status,404);
});
