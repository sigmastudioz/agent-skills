"""Original stereo music and synchronized synthesized foley. Lex from SigmaStudioz."""
import hashlib
import json
import math
from pathlib import Path
import subprocess
import wave
import numpy as np

ROOT=Path(__file__).resolve().parent
RATE=48000
KINDS={'bloom','fold','fly','wipe','pop','click','scan','tear','block','stitch','resolve','chime'}


def note(hz,duration,level=.1):
    t=np.arange(round(duration*RATE))/RATE
    envelope=(1-np.exp(-t*240))*np.exp(-t*3.1)*np.minimum(1,(duration-t)*10)
    # Detuned fundamentals and quiet partials make a soft felt-key attack.
    signal=.72*np.sin(2*np.pi*hz*t)+.20*np.sin(2*np.pi*hz*1.0015*t)
    signal+=.13*np.sin(2*np.pi*hz*2*t)*np.exp(-t*5)
    signal+=.035*np.sin(2*np.pi*hz*3*t)*np.exp(-t*8)
    return signal*envelope*level


def pad(frequencies,duration):
    t=np.arange(round(duration*RATE))/RATE
    envelope=np.minimum(1,t/.8)**2*np.minimum(1,(duration-t)/1.25)**2
    output=np.zeros((len(t),2))
    for j,hz in enumerate(frequencies):
        wave=(np.sin(2*np.pi*hz*t+.018*np.sin(t*2.7))+
              .22*np.sin(2*np.pi*hz*2*t)+.07*np.sin(2*np.pi*hz*3*t))
        wave+=.3*np.sin(2*np.pi*hz*.9984*t)
        output+=pan(wave*envelope*.017,(-.6+j*.4))
    return output


def room(signal):
    # Dark, short stereo reflections; the dry foreground remains precise.
    wet=np.zeros_like(signal)
    for delay,level in [(.037,.13),(.061,.11),(.097,.09),(.153,.075),(.239,.055),(.347,.035),(.463,.02)]:
        shift=round(delay*RATE)
        wet[shift:]+=signal[:-shift,::-1]*level
    return wet


def pan(mono,position):
    position=np.clip(position,-1,1)
    angle=(position+1)*np.pi/4
    return np.column_stack((mono*np.cos(angle),mono*np.sin(angle)))


def mix(target,signal,start):
    first=round(start*RATE)
    if first<0:raise ValueError('Negative cue time')
    n=min(len(signal),len(target)-first)
    if n>0:target[first:first+n]+=signal[:n]


def effect(kind,rng):
    if kind not in KINDS:raise ValueError('Unknown effect '+kind)
    duration={'fold':.34,'click':.18,'stitch':.18,'pop':.32,'tear':.78,'block':.55,
              'fly':.95,'wipe':.82,'scan':.85,'bloom':1.8,'resolve':2.3,'chime':1.5}[kind]
    t=np.arange(round(duration*RATE))/RATE
    noise=rng.uniform(-1,1,len(t))
    low=np.convolve(noise,np.ones(35)/35,'same')
    texture=low-np.convolve(low,np.ones(160)/160,'same')
    if kind in ('fly','wipe','scan'):
        env=np.sin(np.pi*t/duration)**2
        chirp=np.sin(2*np.pi*(95*t+290*t*t/duration))
        silk=noise-np.convolve(noise,np.ones(9)/9,'same')
        s=(texture*.85+silk*.035+chirp*.025)*env
    elif kind in ('fold','stitch'):
        env=np.exp(-t*22)*(1-np.exp(-t*250))
        s=(texture*1.1+.10*np.sin(2*np.pi*(410*t-120*t*t)))*env
        s+=.12*np.sin(2*np.pi*1240*t)*np.exp(-t*80)
    elif kind in ('click','pop'):
        s=(.26*np.sin(2*np.pi*(320*t-230*t*t))+.10*np.sin(2*np.pi*960*t))*np.exp(-t*38)
        s+=texture*.4*np.exp(-t*75)
    elif kind=='tear':
        s=texture*(.6+.4*np.sin(2*np.pi*37*t))*np.sin(np.pi*t/duration)**.5
        s+=.16*np.sin(2*np.pi*(90*t-40*t*t))*np.exp(-t*13)
    elif kind=='block':
        s=.22*np.sin(2*np.pi*(92*t-40*t*t))*np.exp(-t*12)
        s+=.07*np.sin(2*np.pi*270*t)*np.exp(-t*18)
    else:
        frequencies={'bloom':[293.66,440,523.25,659.25],
                     'resolve':[293.66,349.23,440,587.33],
                     'chime':[587.33,880]}[kind]
        s=np.zeros(len(t))
        for j,f in enumerate(frequencies):
            sound=note(f,max(.1,duration-j*.075),.15/len(frequencies))
            offset=round(j*.075*RATE);s[offset:offset+len(sound)]+=sound[:len(s)-offset]
    s*=np.minimum(1,t*300)*np.minimum(1,(duration-t)*120)
    return s


def write_wave(path,data):
    with wave.open(str(path),'wb') as f:
        f.setnchannels(2);f.setsampwidth(2);f.setframerate(RATE)
        f.writeframes(np.clip(data*32767,-32768,32767).astype('<i2').tobytes())


def render(data):
    length=max(s['start']+s['duration'] for s in data['scenes'])
    rng=np.random.default_rng(42019)
    music=np.zeros((round(length*RATE),2),dtype=np.float32)
    foley=np.zeros_like(music);beat=60/96
    chords=[[146.83,174.61,220,261.63],[116.54,146.83,174.61,220],
            [98,116.54,146.83,174.61],[110,130.81,164.81,196]]
    # Harmonic beds overlap smoothly; sparse motifs develop with the story.
    for j,start in enumerate([0,6,12,19,26,32,38,43]):
        chord=chords[j%4]
        if start==43:chord=chords[0]
        mix(music,pad(chord,8.0 if start<43 else 7.0),start)
    motif=[0,None,2,1,None,3,2,None]
    for i in range(math.ceil(length/beat)):
        start=i*beat;chord=chords[(i//8)%4]
        if 6<=start<21.5 or 28.4<=start<46:
            degree=motif[i%len(motif)]
            if degree is not None:
                mix(music,pan(note(chord[degree]*2,1.35,.090),math.sin(i*.47)*.52),start)
            if 12<=start<19 and i%8 in (3,7):
                mix(music,pan(note(chord[2]*4,.7,.024),-.5 if i%2 else .5),start+beat*.55)
        if i%8 in (0,5):
            t=np.arange(round(1.8*RATE))/RATE
            bass=.075*np.sin(2*np.pi*(chord[0]/2)*t)*(1-np.exp(-t*38))*np.exp(-t*2.8)
            mix(music,pan(bass,0),start)
        if 6<=start<43 and not 21.5<start<28.4:
            if i%8 in (0,3,6):
                t=np.arange(round(.28*RATE))/RATE
                kick=.065*np.sin(2*np.pi*(48*t+4*(1-np.exp(-t*24))))*np.exp(-t*20)
                mix(music,pan(kick,0),start)
            if i%4==3:
                noise=rng.uniform(-1,1,round(.19*RATE))
                brush=np.convolve(noise,np.ones(16)/16,'same')*np.exp(-np.arange(len(noise))/RATE*28)*.030
                mix(music,pan(brush,.35 if i%8==3 else -.35),start+beat*.06)
    times=np.arange(len(music))/RATE
    shape=np.interp(times,[0,2,6,12,19,21.7,22,22.4,25.9,26,28.4,32,38,43,46,50],
                    [.1,.7,.65,.95,1,.7,.03,.16,.18,.35,1,.8,.7,.85,.55,0])
    music*=shape[:,None]
    for cue in data['cues']:
        s=effect(cue['kind'],rng)*cue['level']*1.4
        position=cue['pan']
        if cue['kind'] in ('fly','wipe','scan'):
            position=np.linspace(-.8,.8,len(s))*(1 if position>=0 else -1)
        stereo=pan(s,position);mix(foley,stereo,cue['time'])
        for delay,decay in [(.065,.18),(.13,.12),(.24,.07)]:
            mix(foley,stereo[:,::-1]*decay,cue['time']+delay)
    music+=room(music)*.70
    foley+=room(foley)*.45
    # A gentle, time-varying air bed adds space without a constant hiss.
    air=np.zeros_like(music)
    for channel in range(2):
        noise=rng.standard_normal(len(music))
        filtered=np.convolve(noise,np.ones(120)/120,'same')
        air[:,channel]=filtered*.006*(.5+.5*np.sin(times*.19+channel))
    result=music+foley+air
    result*=np.minimum(1,times/0.08)[:,None]*np.minimum(1,(length-times)/.9)[:,None]
    raw_peak=float(np.max(np.abs(result)))
    if raw_peak>.85:result*=.85/raw_peak
    return result


def main():
    data=json.loads((ROOT/'film.json').read_text());audio=render(data)
    raw=ROOT/'soundtrack-raw.wav';write_wave(raw,audio)
    target='I=-16:TP=-1.5:LRA=10'
    first=subprocess.run(['ffmpeg','-hide_banner','-i',str(raw),'-af',f'loudnorm={target}:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
    measured=json.JSONDecoder().raw_decode(first.stderr[first.stderr.rfind('{'):])[0]
    config=f'loudnorm={target}:measured_I={measured["input_i"]}:measured_TP={measured["input_tp"]}:measured_LRA={measured["input_lra"]}:measured_thresh={measured["input_thresh"]}:offset={measured["target_offset"]}:linear=true:print_format=json'
    second=subprocess.run(['ffmpeg','-hide_banner','-y','-i',str(raw),'-af',config,'-ar',str(RATE),str(ROOT/'soundtrack.wav')],capture_output=True,text=True,check=True)
    final=json.JSONDecoder().raw_decode(second.stderr[second.stderr.rfind('{'):])[0]
    with wave.open(str(ROOT/'soundtrack.wav'),'rb') as source:
        samples=np.frombuffer(source.readframes(source.getnframes()),dtype='<i2').astype(float).reshape(-1,2)/32768
    fps=data['fps'];block=RATE//fps
    blocks=samples[:len(samples)//block*block].reshape(-1,block,2)
    rms=np.sqrt(np.mean(blocks*blocks,axis=(1,2)));levels=np.clip(rms/(np.percentile(rms,95)+1e-9),0,1)
    for i in range(1,len(levels)):
        coefficient=.20 if levels[i]>levels[i-1] else .065
        levels[i]=levels[i-1]+coefficient*(levels[i]-levels[i-1])
    (ROOT/'audio-envelope.json').write_text(json.dumps({'fps':fps,'method':'Smoothed frame RMS of the final normalized stereo WAV; not FFT/live microphone analysis','source_sha256':hashlib.sha256((ROOT/'soundtrack.wav').read_bytes()).hexdigest(),'levels':[round(float(v),4) for v in levels]},separators=(',',':'))+'\n')
    (ROOT/'sound-report.json').write_text(json.dumps({'author':data['author'],'sample_rate':RATE,'channels':2,
        'cue_count':len(data['cues']),'mix_revision':'V3: sustained harmonic beds, sparse felt-key motifs, varied soft percussion, layered tactile cues, stereo room reflections','source':'Original deterministic synthesis; no third-party samples or cloned voice',
        'first_pass':measured,'normalization_pass':final,'listening_review':'pending'},indent=2)+'\n')
    print(json.dumps({'seconds':len(audio)/RATE,'cues':len(data['cues']),'integrated_lufs':final['output_i'],'true_peak_db':final['output_tp']}))


if __name__=='__main__':main()
