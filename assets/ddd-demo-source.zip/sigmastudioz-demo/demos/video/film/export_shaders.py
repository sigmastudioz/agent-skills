"""Bake the shared material shader with macOS Metal; retain the source audio stream."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parent


def export(source,output,seconds=None,poster=None):
    source,output=source.resolve(),output.resolve()
    if not source.is_file() or output.exists():raise ValueError('Input must exist and output must be a new file')
    for tool in ['swiftc','ffmpeg','ffprobe']:
        if not shutil.which(tool):raise RuntimeError(f'Required tool unavailable: {tool}')
    info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(source)]))
    video=next(s for s in info['streams'] if s['codec_type']=='video')
    fps=int(json.loads((ROOT/'film.json').read_text())['fps'])
    if video['r_frame_rate']!=f'{fps}/1':raise ValueError('Film and shader clocks differ')
    width,height=video['width'],video['height']
    if not any(s['codec_type']=='audio' for s in info['streams']):raise ValueError('Source soundtrack missing')
    if seconds is not None and not 0<seconds<=float(video['duration']):raise ValueError('Invalid smoke-test duration')
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='shader-export-',dir=output.parent) as temporary:
        tmp=Path(temporary);binary=tmp/'shader-export';target=tmp/'film.mp4'
        subprocess.run(['swiftc','-O','-module-cache-path',str(tmp/'modules'),str(ROOT/'shader_export.swift'),'-o',str(binary)],check=True)
        decode=['ffmpeg','-v','error','-i',str(source)]
        if seconds:decode+=['-t',str(seconds)]
        decode+=['-an','-f','rawvideo','-pix_fmt','rgba','pipe:1']
        encode=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgba','-s',f'{width}x{height}','-r',str(fps),'-i','pipe:0','-i',str(source),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart','-shortest']
        if seconds:encode+=['-t',str(seconds)]
        processes=[]
        with (tmp/'decode.log').open('w+') as dl,(tmp/'gpu.log').open('w+') as gl,(tmp/'encode.log').open('w+') as el:
            try:
                decoder=subprocess.Popen(decode,stdout=subprocess.PIPE,stderr=dl);processes.append(decoder)
                gpu=subprocess.Popen([str(binary),str(width),str(height),str(fps),str(ROOT/'material.glsl'),str(ROOT/'film.json')],stdin=decoder.stdout,stdout=subprocess.PIPE,stderr=gl);processes.append(gpu);decoder.stdout.close()
                encoder=subprocess.Popen(encode+[str(target)],stdin=gpu.stdout,stderr=el);processes.append(encoder);gpu.stdout.close()
                codes=[encoder.wait(),gpu.wait(),decoder.wait()]
                for log in (dl,gl,el):log.seek(0);print(log.read(),end='',flush=True)
                if any(codes):raise RuntimeError(f'Export failed (encoder/GPU/decoder): {codes}')
                subprocess.run(['ffmpeg','-v','error','-i',str(target),'-f','null','-'],check=True)
                target.replace(output)
            finally:
                for process in processes:
                    if process.poll() is None:process.kill();process.wait()
    if poster:
        if poster.exists():raise ValueError('Poster must be a new file')
        subprocess.run(['ffmpeg','-v','error','-ss',str(min(4,(seconds or 50)/2)),'-i',str(output),'-frames:v','1',str(poster)],check=True)
    print(json.dumps({'file':str(output),'width':width,'height':height,'shader':'material.glsl','audio':'copied without re-encoding'}),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--seconds',type=float);ap.add_argument('--poster',type=Path)
    args=ap.parse_args();export(args.input,args.output,args.seconds,args.poster)
