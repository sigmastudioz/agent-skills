# Principal Driven Domain Design — shader film

By **Lex from SigmaStudioz**. Original layered papercraft illustrations, animated
ownership and workflow metaphors, a 50-second stereo score and 33 synchronized cues.
Portrait: 1080×1920. Landscape: 1920×1080. Both 60fps, H264/AAC, 3,000 frames.

This V3 edit replaces sampled path jumps and stepped transforms with continuous
interpolation, quintic easing, softer transitions and a folding handoff. The richer
score combines sustained harmonic beds, sparse felt-key motifs, varied soft percussion,
layered tactile cues and stereo room reflections.

The Three.js preview adds relief lighting, pearlescent material sheen, restrained
refraction, moving paper caustics, and cue-synchronized ripples. Pointer movement
steers the light. It uses a pinned, locally bundled Three.js 0.186.1 with its MIT
license and registry integrity receipt in vendor/three. No CDN is needed.
This is a material pass over layered artwork, not reconstructed 3D geometry.
The sheen breathes with audio-envelope.json: a smoothed, 60fps RMS envelope measured
from the mastered WAV. Ripples follow scheduled sound cues. Neither uses a microphone
or FFT analysis. Picture and sound share one clock in the preview and GPU export.

## Reproduce and preview

The source archive intentionally excludes rendered videos and fonts. Generate the
following two base videos first; the preview expects these exact filenames.
Requires Python 3.10+, Pillow, NumPy, FFmpeg with libx264/AAC and local fonts.
Resolve font paths on your machine; fonts are not redistributed.

```sh
python sound_design.py
python render_film.py --font /path/to/body.ttf --italic-font /path/to/italic.ttf \
  --size 1080x1920 --output ddd-paper-portrait.mp4 --poster ddd-paper-portrait.png
python render_film.py --font /path/to/body.ttf --italic-font /path/to/italic.ttf \
  --size 1920x1080 --output ddd-paper-landscape.mp4 --poster ddd-paper-landscape.png
python serve_preview.py --port 8769
```

Open http://127.0.0.1:8769/preview.html. Play/pause, replay, mute, volume, chapter
jumps, aspect switching and shaders on/off work in the preview. Custom controls
remain available during GPU playback; native video controls return with effects off.
The original scene captions are burned into the picture; timed text also ships.
Reduced-motion preference starts effects off. Import, compile, render and GPU-context
failures expose the plain video. After context loss, reload to enable shaders again.
The GPU target is capped at 1280px on its longest edge, stops when paused/hidden,
and follows the media clock. The server is localhost-only and supports byte ranges.

## Bake shaders into video

The same material.glsl math runs in the Three.js ShaderMaterial and the offline
Metal adapter. The creative pass deliberately works in encoded display RGB in both
adapters, without automatic gamma conversion or tone mapping. Text/footer masks
limit distortion to the illustration region. This is not physically based shading.

Offline baking requires macOS, an available Metal GPU, and Swift command-line tools.
Plain rendering and browser review remain available on other supported platforms.
Use new output filenames; the exporter preserves originals and copies audio without
re-encoding. Both exported shader films have passed complete decoding checks. The GitHub demo
uses an additional CRF22 web encode under 25MB; full-quality masters remain separate.

```sh
python export_shaders.py --input ddd-paper-portrait.mp4 \
  --output ddd-shader-portrait.mp4 --poster ddd-shader-portrait.png
python export_shaders.py --input ddd-paper-landscape.mp4 \
  --output ddd-shader-landscape.mp4 --poster ddd-shader-landscape.png
```

film.json owns the 8 scenes and 33 sound cues. material.glsl owns effect math;
audio-envelope.json owns measured mix energy; shader-preview.js owns the Three.js playback adapter; shader_export.swift and
export_shaders.py own GPU baking and encoding. All render paths stream bounded
frames. The browser plain-video source remains unbaked to avoid applying effects twice.

Generated illustrations and prompts are included. sound_design.py composes original
stereo music, synthesized tactile foley, directional signals, tension and resolution.
sound-report.json retains loudness measurements and listening-review limitations;
shader-report.json records final export hashes and unchanged audio-stream checks.
No third-party sound samples, source-clip footage or cloned voice are used.

This is an illustrated workflow replay. Evidence refers to the historical Claude
Code 1.0.5 test; 1.0.6 changed branding only. The linked coding fixture is synthetic
and in-memory, not a production payment system.
