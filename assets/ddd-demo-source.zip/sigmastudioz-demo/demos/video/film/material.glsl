// Canonical material pass shared by WebGL and Metal. UV origin is top-left.
// The hosts supply film(), EVENT(), and SAMPLER_ARGS / SAMPLER_PASS.
float sigmaLuma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec4 shade(vec2 uv, vec2 size, float t, float strength, vec2 pointer, int count, float soundLevel SAMPLER_ARGS) {
    vec4 source = film(uv SAMPLER_PASS);
    float portrait = step(size.x, size.y);
    float region = mix(smoothstep(.46,.53,uv.x), 1.0, portrait);
    region *= smoothstep(mix(.16,.385,portrait),mix(.23,.43,portrait),uv.y);
    region *= 1.0-smoothstep(mix(.73,.735,portrait),mix(.81,.80,portrait),uv.y);
    float amount = region * strength;
    vec2 aspect = vec2(size.x/size.y,1.0);
    vec2 center = vec2(mix(.715,.5,portrait),mix(.505,.565,portrait));
    vec2 offset = vec2(0.0); float rings = 0.0; float energy = 0.0;
    for (int i=0;i<40;i++) {
        if(i>=count) break;
        vec4 event = EVENT(i);
        float dt=t-event.x;
        if(dt>=0.0 && dt<1.6) {
            vec2 origin=center+vec2(event.y*.13,0.0);
            vec2 delta=(uv-origin)*aspect;
            float distance=length(delta);
            float radius=.025+dt*.21;
            float ring=exp(-pow((distance-radius)/.009,2.0))*exp(-dt*1.9)*event.z;
            rings+=ring; energy+=exp(-dt*4.0)*event.z;
            offset+=normalize(delta+vec2(.0001))*ring*.0035/aspect;
        }
    }
    // Pointer is an additional light position, never a change to the film timeline.
    vec2 interactive=(pointer-vec2(.5))*.85;
    float flow=sin(uv.y*23.0+sin(uv.x*15.0-t*.43)*1.7-t*.65);
    offset+=vec2(sin(uv.y*17.0+t*.55),flow)*.0013;
    vec2 displaced=clamp(uv+offset*amount,vec2(.001),vec2(.999));
    vec3 base=film(displaced SAMPLER_PASS).rgb;
    vec2 px=1.5/size;
    float dx=sigmaLuma(film(clamp(displaced+vec2(px.x,0.0),vec2(0.0),vec2(1.0)) SAMPLER_PASS).rgb)-sigmaLuma(film(clamp(displaced-vec2(px.x,0.0),vec2(0.0),vec2(1.0)) SAMPLER_PASS).rgb);
    float dy=sigmaLuma(film(clamp(displaced+vec2(0.0,px.y),vec2(0.0),vec2(1.0)) SAMPLER_PASS).rgb)-sigmaLuma(film(clamp(displaced-vec2(0.0,px.y),vec2(0.0),vec2(1.0)) SAMPLER_PASS).rgb);
    vec3 normal=normalize(vec3(-dx*14.0,-dy*14.0,1.0));
    vec3 light=normalize(vec3(.8*sin(t*.29)+interactive.x,-.65+interactive.y,.82));
    float diffuse=dot(normal,light);
    float saturation=max(base.r,max(base.g,base.b))-min(base.r,min(base.g,base.b));
    float material=smoothstep(.10,.38,saturation)*smoothstep(.06,.24,sigmaLuma(base));
    float sweep=pow(.5+.5*sin(uv.x*7.0+uv.y*5.0-t*.64),6.0);
    vec3 pearl=.5+.5*cos(vec3(0.0,2.1,4.2)+uv.x*4.0+uv.y*3.0+t*.6);
    vec3 lit=base*(1.0+(diffuse-.73)*mix(.08,.48,material));
    lit+=material*sweep*pearl*(.21+.10*soundLevel+.075*min(energy,1.0));
    float specular=pow(max(0.0,dot(reflect(-light,normal),vec3(0.0,0.0,1.0))),18.0);
    lit+=material*specular*vec3(.30,.24,.18)*( .7+.5*soundLevel );
    lit+=rings*vec3(.21,.09,.25);
    // Slow orbiting motes create depth around the illustration, never the title/footer.
    for(int j=0;j<9;j++) {
        float k=float(j); float angle=k*2.39996+t*(.12+.012*k);
        vec2 orbit=center+vec2(cos(angle)*mix(.20,.35,portrait),sin(angle)*.145);
        float distance=length((uv-orbit)*aspect);
        float core=exp(-pow(distance/.0018,2.0));
        float halo=exp(-pow(distance/.010,2.0));
        lit+=(core*.19+halo*.035)*(vec3(.90,.55,.36)+.2*pearl);
    }
    // Thin, slow caustics on the surrounding paper make the light feel continuous.
    float paper=(1.0-material)*smoothstep(.60,.92,sigmaLuma(base));
    float caustic=pow(.5+.5*sin(uv.x*26.0+flow*1.8+t*.33),18.0);
    lit+=paper*caustic*vec3(.043,.027,.054);
    return vec4(clamp(mix(source.rgb,lit,amount),0.0,1.0),source.a);
}
