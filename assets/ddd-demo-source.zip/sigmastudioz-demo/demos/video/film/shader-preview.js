/* Three.js playback adapter. Canonical material math lives in material.glsl. */
export async function attachMaterial(video, canvas, button, label) {
  const motion=matchMedia('(prefers-reduced-motion: reduce)');
  let enabled=!motion.matches,renderer,texture,material,geometry,raf=0,disposed=false,lost=false,lastFrame=-1,textureSize='';
  const pointer=[.5,.5],cleanups=[];
  const on=(target,name,fn)=>{target.addEventListener(name,fn);cleanups.push(()=>target.removeEventListener(name,fn));};
  const fallback=message=>{enabled=false;button.setAttribute('aria-pressed','false');canvas.hidden=true;video.controls=true;video.classList.remove('shader-source');button.disabled=true;button.textContent='Plain video';label.textContent=message;cancelAnimationFrame(raf);raf=0;};
  try {
    const [THREE,body,timeline,envelope]=await Promise.all([import('./vendor/three/three.module.js'),fetch('material.glsl').then(r=>{if(!r.ok)throw Error('Material missing');return r.text()}),fetch('film.json').then(r=>{if(!r.ok)throw Error('Timeline missing');return r.json()}),fetch('audio-envelope.json').then(r=>{if(!r.ok)throw Error('Envelope missing');return r.json()})]);
    const duration=Math.max(...timeline.scenes.map(s=>s.start+s.duration));
    if(envelope.fps!==timeline.fps||envelope.levels.length!==timeline.fps*duration)throw Error('Soundtrack clock mismatch');
    if(timeline.cues.length>40)throw Error('Too many shader cues');
    renderer=new THREE.WebGLRenderer({canvas,alpha:false,antialias:false,powerPreference:'low-power'});
    // This creative pass works in encoded display RGB, exactly like the Metal export.
    // No automatic decode/tone mapping/encode is added to the canonical shader math.
    renderer.outputColorSpace=THREE.LinearSRGBColorSpace;renderer.toneMapping=THREE.NoToneMapping;renderer.setPixelRatio(1);
    const events=Array.from({length:40},(_,i)=>{const c=timeline.cues[i];return new THREE.Vector4(c?.time??0,c?.pan??0,c?.level??0,0)});
    const uniforms={image:{value:null},size:{value:new THREE.Vector2(1080,1920)},time:{value:0},strength:{value:.90},pointer:{value:new THREE.Vector2(.5,.5)},count:{value:timeline.cues.length},soundLevel:{value:0},events:{value:events}};
    material=new THREE.ShaderMaterial({uniforms,depthTest:false,depthWrite:false,toneMapped:false,
      vertexShader:'varying vec2 filmUv; void main(){filmUv=vec2(uv.x,1.0-uv.y);gl_Position=vec4(position.xy,0.0,1.0);}',
      fragmentShader:`varying vec2 filmUv; uniform sampler2D image; uniform vec2 size; uniform float time; uniform float strength; uniform vec2 pointer; uniform int count; uniform float soundLevel; uniform vec4 events[40];\n#define SAMPLER_ARGS\n#define SAMPLER_PASS\n#define EVENT(i) events[i]\nvec4 film(vec2 p){return texture2D(image,p);}\n${body}\nvoid main(){gl_FragColor=shade(filmUv,size,time,strength,pointer,count,soundLevel);}`});
    const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-1,1,1,-1,0,1);geometry=new THREE.PlaneGeometry(2,2);scene.add(new THREE.Mesh(geometry,material));
    renderer.debug.onShaderError=(gl,program,vertex,fragment)=>{throw Error([gl.getProgramInfoLog(program),gl.getShaderInfoLog(vertex),gl.getShaderInfoLog(fragment)].filter(Boolean).join('\n')||'Material compilation failed')};
    await renderer.compileAsync(scene,camera);
    canvas.dataset.engine=`Three.js r${THREE.REVISION}`;
    const sync=()=>{const visible=enabled&&video.readyState>=2;canvas.hidden=!visible;video.controls=!visible;video.classList.toggle('shader-source',visible);button.textContent=enabled?'Shaders on':'Shaders off';button.setAttribute('aria-pressed',String(enabled));label.textContent=enabled?'Three.js · paper relief · pearlescent light · soundtrack-driven sheen · cue ripples':'Original paper film · effects disabled';};
    const draw=()=>{if(disposed||lost||!enabled||video.readyState<2)return;
      try {
        const scale=Math.min(1,1280/Math.max(video.videoWidth,video.videoHeight)),w=Math.round(video.videoWidth*scale),h=Math.round(video.videoHeight*scale);
        if(canvas.width!==w||canvas.height!==h)renderer.setSize(w,h,false);
        const dimensions=`${video.videoWidth}x${video.videoHeight}`;
        if(textureSize!==dimensions){texture?.dispose();texture=new THREE.VideoTexture(video);texture.flipY=false;texture.colorSpace=THREE.NoColorSpace;texture.minFilter=texture.magFilter=THREE.LinearFilter;uniforms.image.value=texture;textureSize=dimensions;}
        texture.needsUpdate=true;uniforms.size.value.set(video.videoWidth,video.videoHeight);uniforms.time.value=video.currentTime;uniforms.soundLevel.value=envelope.levels[Math.min(envelope.levels.length-1,Math.floor(video.currentTime*timeline.fps))]??0;uniforms.pointer.value.set(...pointer);
        renderer.render(scene,camera);canvas.hidden=false;video.controls=false;video.classList.add('shader-source');lastFrame=Math.floor(video.currentTime*timeline.fps);canvas.dataset.frame=String(lastFrame);
      } catch(error) {lost=true;fallback('Material render failed · plain video remains playable');console.warn(error.message)}
    };
    const loop=()=>{raf=0;if(!enabled||video.paused||document.hidden||disposed||lost)return;if(Math.floor(video.currentTime*timeline.fps)!==lastFrame)draw();raf=requestAnimationFrame(loop)};
    const wake=()=>{draw();if(!raf&&!video.paused&&!document.hidden&&!lost)raf=requestAnimationFrame(loop)};
    on(button,'click',()=>{enabled=!enabled;sync();if(enabled)wake();else{cancelAnimationFrame(raf);raf=0}});
    for(const name of ['loadeddata','seeked','pause','play','resize'])on(video,name,wake);
    on(video,'emptied',()=>{canvas.hidden=true;video.controls=true;video.classList.remove('shader-source');texture?.dispose();texture=null;textureSize='';});
    on(document,'visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf);raf=0}else wake()});
    on(canvas,'pointermove',event=>{const box=canvas.getBoundingClientRect();pointer[0]=(event.clientX-box.left)/box.width;pointer[1]=(event.clientY-box.top)/box.height;if(video.paused)draw()});
    on(canvas,'pointerleave',()=>{pointer[0]=pointer[1]=.5;if(video.paused)draw()});
    on(motion,'change',()=>{if(motion.matches){enabled=false;sync();cancelAnimationFrame(raf);raf=0}});
    on(canvas,'webglcontextlost',event=>{event.preventDefault();lost=true;fallback('GPU context lost · plain video remains available')});
    on(canvas,'webglcontextrestored',()=>{label.textContent='GPU restored · reload to enable shaders; plain video is available'});
    const dispose=()=>{disposed=true;cancelAnimationFrame(raf);cleanups.forEach(fn=>fn());texture?.dispose();geometry?.dispose();material?.dispose();renderer?.dispose()};
    on(window,'pagehide',event=>{if(event.persisted){cancelAnimationFrame(raf);raf=0}else dispose()});on(window,'pageshow',event=>{if(event.persisted)wake()});
    sync();wake();
  } catch(error) {texture?.dispose();geometry?.dispose();material?.dispose();renderer?.dispose();console.warn('Material fallback:',error.message);fallback('Shaders unavailable · plain video remains playable');}
}
