"""Original papercraft motion film. By Lex from SigmaStudioz. Pillow + FFmpeg."""
import argparse
from functools import lru_cache
import json
import math
from pathlib import Path
import subprocess
import tempfile
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageFilter

ROOT = Path(__file__).resolve().parent
INK, CREAM, PINK, CORAL, GREEN, PURPLE = '#252035', '#F2EBDD', '#E14783', '#FF7957', '#C1D85B', '#8B76C1'


def clamp(v): return max(0., min(1., v))
def ease(v):
    v=clamp(v); return v*v*v*(v*(v*6-15)+10)
def smooth(v):
    v=clamp(v); return v*v*(3-2*v)
def lerp(a,b,t): return a+(b-a)*t


def validate(film):
    t=0; ids=set()
    for scene in film['scenes']:
        assert scene['id'] not in ids, 'Duplicate scene'; ids.add(scene['id'])
        assert scene['start']==t and scene['duration']>0, 'Timeline must be contiguous'
        t+=scene['duration']
    for cue in film['cues']:
        assert 0<=cue['time']<t and -1<=cue['pan']<=1 and 0<cue['level']<=1, 'Invalid audio cue'
    return t


class Film:
    def __init__(self, data, width, height, font, italic):
        self.data, self.w, self.h = data,width,height
        self.p = height>width
        self.z = width/1080 if self.p else height/1080
        self.font_path,self.italic_path=font,italic
        self.total=validate(data)
        self.sources={n:Image.open(ROOT/'assets'/f).convert('RGBA') for n,f in
            [('flower','engine-flower.png'),('bird','signal-bird-clean.png'),('petal','petal.png')]}
        self.paper=ImageOps.fit(Image.open(ROOT/'assets/paper.png').convert('RGB'),(width,height)).convert('RGBA')
        self.dark=Image.blend(self.paper,Image.new('RGBA',(width,height),'#242032'),.94)
        self.cx,self.cy=(width*.5,height*.565) if self.p else (width*.715,height*.505)
        self.gw,self.gh=(width*.86,height*.35) if self.p else (width*.47,height*.57)

    @lru_cache(maxsize=40)
    def font(self, n, italic=False):
        return ImageFont.truetype(str(self.italic_path if italic else self.font_path),max(10,round(n*self.z)))

    def text(self, im, s, x, y, n, color=INK, max_width=None, center=False, italic=False):
        d=ImageDraw.Draw(im); f=self.font(n,italic)
        for i,line in enumerate(s.split('\n')):
            length=d.textlength(line,font=f)
            if max_width and length>max_width: raise ValueError(f'Text overflow: {line}')
            d.text((x-length/2 if center else x,y+i*n*1.04*self.z),line,font=f,fill=color)

    def paragraph(self,im,s,x,y,n,width,color=INK,max_lines=2):
        d=ImageDraw.Draw(im); f=self.font(n);lines=[];line=''
        for word in s.split():
            candidate=(line+' '+word).strip()
            if d.textlength(candidate,font=f)>width and line: lines.append(line);line=word
            else: line=candidate
        lines.append(line)
        if len(lines)>max_lines: raise ValueError(f'Caption overflow: {s}')
        self.text(im,'\n'.join(lines),x,y,n,color,max_width=width)

    @lru_cache(maxsize=48)
    def sized_sprite(self,name,width):
        image=self.sources[name]
        return image.resize((max(4,width),max(4,round(width*image.height/image.width))),Image.Resampling.LANCZOS)

    @lru_cache(maxsize=96)
    def sprite(self,name,width,angle):
        return self.sized_sprite(name,width).rotate(angle,Image.Resampling.BICUBIC,expand=True)

    def put(self,im,name,x,y,width,angle=0):
        sprite=self.sprite(name,max(8,round(width)),round(angle*10)/10)
        im.alpha_composite(sprite,(round(x-sprite.width/2),round(y-sprite.height/2)))

    def blob(self,im,x,y,r,color,phase=0):
        points=[]
        for j in range(80):
            a=j*math.tau/80; radius=r*(1+.055*math.sin(a*5+phase)+.028*math.cos(a*7-phase))
            points.append((x+radius*math.cos(a),y+radius*math.sin(a)))
        d=ImageDraw.Draw(im);d.polygon([(a+6*self.z,b+8*self.z) for a,b in points],fill='#C6BAA9')
        d.polygon(points,fill=color)
        for j in range(16):
            a=j*2.399+phase;rr=r*((j%7+1)/8)
            qx,qy=x+rr*math.cos(a),y+rr*math.sin(a)
            d.line((qx-2*self.z,qy,qx+2*self.z,qy+2*self.z),fill=INK,width=max(1,round(self.z)))

    def rings(self,im,x,y,r,t,color=INK,count=4):
        d=ImageDraw.Draw(im)
        for j in range(count):
            rr=r*(.4+j*.16)+math.sin(t*.7+j)*3*self.z
            d.ellipse((x-rr,y-rr,x+rr,y+rr),outline=color,width=max(1,round(self.z)))

    def path(self,im,points,color,width,progress=1):
        position=(len(points)-1)*clamp(progress);index=int(position);fraction=position-index
        visible=points[:index+1]
        if index<len(points)-1:visible.append((lerp(points[index][0],points[index+1][0],fraction),lerp(points[index][1],points[index+1][1],fraction)))
        if len(visible)>1:ImageDraw.Draw(im).line(visible,fill=color,width=max(1,round(width*self.z)),joint='curve')

    def curve(self,a,b,bend=0):
        points=[]
        for j in range(101):
            q=j/100
            points.append((lerp(a[0],b[0],q)+math.sin(q*math.pi)*bend,
                           lerp(a[1],b[1],q)+math.sin(q*math.tau)*bend*.35))
        return points

    def bird_on(self,im,points,q,width=105):
        position=clamp(q)*(len(points)-1);j=min(len(points)-2,int(position));fraction=position-j
        x,y=lerp(points[j][0],points[j+1][0],fraction),lerp(points[j][1],points[j+1][1],fraction)
        x2,y2=points[j+1][0]-points[j][0],points[j+1][1]-points[j][1]
        self.put(im,'bird',x,y,width*self.z,-math.degrees(math.atan2(y2,x2)))

    def flower(self,im,x,y,width,t,bloom=True):
        if bloom:
            for j in range(9):
                q=ease((t-j*.08)/1.3);a=j*math.tau/9-.7
                radius=width*.39*q
                self.put(im,'petal',x+radius*math.cos(a),y+radius*math.sin(a),width*.22*q,math.degrees(-a)-90)
        self.put(im,'flower',x,y,width*(.12+.88*ease(t/.95)),t*3.1)

    def heading(self,im,scene,t,dark=False):
        color=CREAM if dark else INK
        x=self.w*.075 if self.p else self.w*.05
        n=104 if self.p else 91
        title=scene['title']
        if scene['id']=='end': n=94 if self.p else 92
        self.text(im,title,x,self.h*(.145 if self.p else .20)+14*self.z*(1-ease(t/.6)),n,color,
                  max_width=self.w*(.87 if self.p else .43))

    def chrome(self,im,index,scene,dark):
        color=CREAM if dark else INK
        self.text(im,'SIGMASTUDIOZ / PRINCIPAL DESIGN',self.w*.075 if self.p else self.w*.05,self.h*.055,25,color)
        if scene['id']!='end':
            self.paragraph(im,scene['caption'],self.w*.075 if self.p else self.w*.05,self.h*.855,
                           35 if self.p else 34,self.w*(.85 if self.p else .90),color)
        footer='Lex from SigmaStudioz  /  Visual replay'
        self.text(im,footer,self.w*.075 if self.p else self.w*.05,self.h*.952,25 if self.p else 24,color)
        self.text(im,f'{index+1:02d}',self.w*.875 if self.p else self.w*.94,self.h*.055,25,color)

    def scene(self,index,t):
        s=self.data['scenes'][index];sid=s['id'];dark=sid=='trace'
        im=(self.dark if dark else self.paper).copy()
        d=ImageDraw.Draw(im);cx,cy,gw,gh,z=self.cx,self.cy,self.gw,self.gh,self.z
        self.heading(im,s,t,dark)
        if sid=='bloom':
            width=gw*(.98+.035*math.sin(t*.8))
            self.rings(im,cx,cy,width*.56,t,PURPLE,5)
            self.flower(im,cx,cy,width,t)
            for j in range(3):
                a=t*.43+j*math.tau/3;radius=width*.48
                self.put(im,'bird',cx+math.cos(a)*radius,cy+math.sin(a)*radius*.62,150*z,-math.degrees(a)-90)
        elif sid=='domains':
            centers=[(cx-gw*.28,cy-gh*.16),(cx+gw*.27,cy-gh*.10),(cx,cy+gh*.30)]
            for j,((x,y),label,color) in enumerate(zip(centers,['BILLING','IDENTITY','CONTENT'],[PINK,PURPLE,GREEN])):
                q=ease((t-j*.25)/.9);r=gw*.225*q
                self.blob(im,x,y+40*z*(1-q)+math.sin(t+j)*8*z,r,color,j)
                self.put(im,'petal',x,y-12*z,170*z*q,t*7+j*50)
                self.text(im,label,x,y+r*.45,31,INK,center=True)
            for j in range(2):
                a=centers[j];b=centers[2];points=self.curve(a,b,40*z)
                self.path(im,points,INK,2,ease(t-.8));self.bird_on(im,points,(.5-.5*math.cos((t*.3+j*.4)*math.pi)),90)
        elif sid=='engine':
            center=(cx,cy+gh*.06);left=(cx-gw*.36,cy-gh*.29);right=(cx+gw*.36,cy-gh*.29)
            for j,(pos,label,color) in enumerate([(left,'API',CORAL),(right,'WORKER',PURPLE)]):
                points=self.curve(pos,center,(-1 if j else 1)*85*z)
                self.path(im,points,INK,3,ease((t-.6-j*.2)/1.1))
                self.bird_on(im,points,(.5-.5*math.cos((t*.27+j*.5)*math.pi)),112)
                self.blob(im,*pos,74*z*ease(t/.6),color,j)
                self.text(im,label,pos[0],pos[1]-16*z,30,INK,center=True)
            self.flower(im,*center,gw*.61,t,False)
            self.text(im,'BILLING / SHARED CAPABILITY',cx,cy+gh*.43,28,center=True)
        elif sid=='trace':
            start=(cx-gw*.39,cy+gh*.10);end=(cx+gw*.39,cy-gh*.10)
            points=self.curve(start,end,80*z);broken=t>=3
            self.path(im,points,'#B8A5DC',8,ease(t/.9))
            for j in range(5):
                x,y=points[j*24];d.ellipse((x-9*z,y-9*z,x+9*z,y+9*z),fill=CREAM)
            if broken:
                self.path(im,points[40:60],'#242032',24)
                for j in range(4):
                    x,y=points[45+j*4]
                    d.line((x-8*z,y-20*z,x+6*z,y+24*z),fill=CORAL,width=round(4*z))
                self.text(im,'GAP FOUND',cx,cy+gh*.32,40,CORAL,center=True)
                self.bird_on(im,points,.38,145)
            else: self.bird_on(im,points,.1+t*.12,145)
            q=min(.48,t*.15);x,y=points[round(q*100)]
            rr=174*z
            d.ellipse((x-rr,y-rr,x+rr,y+rr),fill=CREAM,outline=CORAL,width=round(7*z))
            detail=[(x-rr*.77+j/100*rr*1.54,y+math.sin(j/100*math.pi*2)*rr*.16) for j in range(101)]
            self.path(im,detail,PURPLE,13)
            if broken:
                d.rectangle((x-27*z,y-44*z,x+27*z,y+44*z),fill=CREAM)
                for j in (-1,1):
                    d.line((x+j*26*z,y-45*z,x+j*40*z,y-15*z,x+j*22*z,y+16*z,x+j*38*z,y+44*z),fill=CORAL,width=round(5*z))
            else:
                for j in (20,50,80):
                    dx,dy=detail[j];d.ellipse((dx-12*z,dy-12*z,dx+12*z,dy+12*z),fill=GREEN)
            d.line((x+rr*.7,y+rr*.7,x+rr*1.4,y+rr*1.4),fill=CREAM,width=round(15*z))
            self.put(im,'flower',cx-gw*.34,cy-gh*.28,290*z,t*8)
        elif sid=='repair':
            a,b=(cx-gw*.39,cy),(cx+gw*.39,cy)
            self.blob(im,cx,cy,gw*.23,'#D9CFE8',t*.04)
            points=self.curve(a,b,0);self.path(im,points,PURPLE,11)
            self.path(im,points[41:60],CREAM,24)
            for j in range(7):
                if t>1.1+j*.085:
                    x=cx+(j-3)*20*z
                    d.line((x-8*z,cy-30*z,x+8*z,cy+30*z),fill='#357E6B',width=round(5*z))
            self.blob(im,a[0],a[1],87*z,CORAL,1);self.blob(im,b[0],b[1],87*z,GREEN,2)
            self.text(im,'BODY',a[0],a[1]-16*z,31,center=True)
            self.text(im,'AUTH',b[0],b[1]-16*z,31,center=True)
            if t>2.4:
                self.rings(im,cx,cy,190*z,t,'#357E6B',3)
                self.text(im,'TRUSTED CONTEXT',cx,cy+gh*.31,34,center=True)
                self.bird_on(im,points,clamp((t-2.4)/2.5),150)
            else:
                self.text(im,'tenant: alpha',a[0],cy+150*z,27,center=True)
                self.text(im,'tenant: beta',b[0],cy+150*z,27,center=True)
        elif sid=='handoff':
            ew,eh=gw*.76,gh*.54;x,y=cx-ew/2,cy-eh/2
            d.polygon([(x+8*z,y+eh+12*z),(x+ew+8*z,y+eh+12*z),(x+ew+8*z,y+12*z),(x+8*z,y+12*z)],fill='#C6BAA9')
            d.rectangle((x,y,x+ew,y+eh),fill=CORAL)
            d.polygon([(x,y),(cx,y+eh*.6),(x+ew,y)],fill=PINK)
            d.polygon([(x,y+eh),(cx,y+eh*.4),(x+ew,y+eh)],fill='#F8B283')
            for j,label in enumerate(['SCOPE','CONTRACTS','CHECKS']):
                q=ease((t-.3-j*.5)/1.1);px=lerp(cx+(-1 if j%2 else 1)*gw*.6,cx+(j-1)*95*z,q)
                py=lerp(cy-gh*.45,cy-eh*.35,q)
                if t<3.65:
                    py+=80*z*smooth((t-2.9)/.75)
                    card=Image.new('RGBA',im.size);cd=ImageDraw.Draw(card)
                    cd.rectangle((px-100*z,py-38*z,px+100*z,py+42*z),fill=CREAM,outline=INK,width=round(2*z))
                    self.text(card,label,px,py-18*z,23,center=True)
                    card.putalpha(card.getchannel('A').point(lambda a:round(a*(1-smooth((t-2.9)/.75)))))
                    im.alpha_composite(card)
            if t>=3.0:
                fold=smooth((t-3.0)/.85)
                d.polygon([(x,y),(cx,lerp(y-eh*.55,y+eh*.63,fold)),(x+ew,y)],fill=PURPLE)
            if t>=3.8:
                d.ellipse((cx-42*z,cy-42*z,cx+42*z,cy+42*z),fill=GREEN)
                d.line((cx-18*z,cy,cx-2*z,cy+17*z,cx+24*z,cy-18*z),fill=INK,width=round(5*z))
            self.put(im,'bird',cx+math.sin(t*.8)*gw*.38,cy+eh*.9,165*z,-10*math.sin(t))
        elif sid=='proof':
            positions=[(cx-gw*.29,cy-gh*.16),(cx+gw*.29,cy-gh*.08),(cx,cy+gh*.32)]
            for j,((x,y),number,label,color) in enumerate(zip(positions,['16','2','1'],['FEATURES','REGRESSIONS','TEAMMATE'],[PINK,PURPLE,GREEN])):
                q=ease((t-j*.35)/.8);self.blob(im,x,y,gw*.20*q,color,j)
                self.rings(im,x,y,gw*.17*q,t,INK,3)
                if q>.9:
                    self.text(im,number,x,y-70*z,126,CREAM if j<2 else INK,center=True,italic=True)
                    self.text(im,label,x,y+58*z,23,INK,center=True)
            self.text(im,'CLAUDE CODE 1.0.5 / RECORDED VALIDATION',cx,cy+gh*.57,23,center=True)
        elif sid=='end':
            width=gw*(.85 if self.p else .90)
            self.flower(im,cx,cy-(20*z if self.p else 0),width,t,False)
            for j in range(3):
                a=t*.3+j*math.tau/3
                self.put(im,'bird',cx+math.cos(a)*width*.5,cy+math.sin(a)*width*.38,120*z,-math.degrees(a)-90)
            if self.p:
                self.text(im,self.data['author'],cx,self.h*.79,42,center=True)
                self.text(im,self.data['website'],cx,self.h*.835,45,center=True)
                self.paragraph(im,s['caption'],self.w*.075,self.h*.895,30,self.w*.85)
            else:
                self.text(im,self.data['author'],self.w*.05,self.h*.69,39)
                self.text(im,self.data['website'],self.w*.05,self.h*.76,43)
                self.text(im,s['caption'],self.w*.05,self.h*.86,31)
        self.chrome(im,index,s,dark)
        return im

    def frame(self,t):
        index=max(i for i,s in enumerate(self.data['scenes']) if t>=s['start'])
        s=self.data['scenes'][index];local=t-s['start'];im=self.scene(index,local)
        if index and local<.75:
            prev=self.scene(index-1,self.data['scenes'][index-1]['duration']-.01)
            mask=Image.new('L',(self.w,self.h));d=ImageDraw.Draw(mask)
            radius=math.hypot(self.w,self.h)*ease(local/.75)
            d.ellipse((self.cx-radius,self.cy-radius,self.cx+radius,self.cy+radius),fill=255)
            mask=mask.filter(ImageFilter.GaussianBlur(20*self.z))
            im=Image.composite(im,prev,mask)
        return im.convert('RGB')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--size',default='1080x1920');ap.add_argument('--output',type=Path)
    ap.add_argument('--font',type=Path,required=True);ap.add_argument('--italic-font',type=Path,required=True)
    ap.add_argument('--duration',type=float);ap.add_argument('--still',type=float);ap.add_argument('--poster',type=Path);ap.add_argument('--validate-only',action='store_true')
    args=ap.parse_args();data=json.loads((ROOT/'film.json').read_text());size=tuple(map(int,args.size.split('x')))
    assert len(size)==2 and all(n%2==0 and 640<=n<=3840 for n in size),'Invalid size'
    film=Film(data,*size,args.font,args.italic_font)
    fps=data['fps'];duration=args.duration or film.total
    assert fps in (30,60) and 0<duration<=film.total,'Invalid output clock'
    for s in data['scenes']: film.frame(s['start']+s['duration']/2)
    if args.validate_only: print('Validated 8 scene compositions');return
    if args.still is not None:
        assert args.poster and 0<=args.still<film.total;film.frame(args.still).save(args.poster);return
    assert args.output and not args.output.exists(),'Use a new output filename'
    assert (ROOT/'soundtrack.wav').exists(),'Render sound_design.py first'
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='paper-film-',dir=args.output.parent) as tmp:
        target=Path(tmp)/'film.mp4'
        cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',args.size,'-r',str(fps),'-i','pipe:0',
             '-i',str(ROOT/'soundtrack.wav'),'-c:v','libx264','-preset','fast','-crf','21','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k',
             '-movflags','+faststart','-t',str(duration),str(target)]
        with (Path(tmp)/'encoder.log').open('w+') as log:
            p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log)
            try:
                for i in range(round(duration*fps)):p.stdin.write(film.frame(i/fps).tobytes())
                p.stdin.close();assert p.wait()==0,'Encoder failed'
            except BaseException:
                p.kill();p.wait();log.seek(0);print(log.read());raise
        target.replace(args.output)
    if args.poster:film.frame(4).save(args.poster)
    print(json.dumps({'output':str(args.output),'duration':duration,'frames':round(duration*fps)}))


if __name__=='__main__':main()
