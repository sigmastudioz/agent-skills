// Offline Metal adapter for material.glsl. Reads/writes one RGBA frame at a time.
import Foundation
import Metal
func fail(_ message:String) -> Never { FileHandle.standardError.write(Data((message+"\n").utf8)); exit(1) }
let args=CommandLine.arguments
if args.count != 6 { fail("Usage: shader-export WIDTH HEIGHT FPS material.glsl film.json") }
guard let width=Int(args[1]),let height=Int(args[2]),let fps=Float(args[3]),width>0,height>0,width<=3840,height<=3840,fps>0 else { fail("Invalid frame contract") }
guard let device=MTLCreateSystemDefaultDevice(),let queue=device.makeCommandQueue() else { fail("Metal GPU unavailable") }
let body=try String(contentsOfFile:args[4],encoding:.utf8)
let data=try Data(contentsOf:URL(fileURLWithPath:args[5]))
let timeline=try JSONSerialization.jsonObject(with:data) as! [String:Any]
guard let cues=timeline["cues"] as? [[String:Any]],cues.count<=40 else { fail("Invalid cue sheet") }
let header="""
#include <metal_stdlib>
using namespace metal;
#define vec2 float2
#define vec3 float3
#define vec4 float4
#define SAMPLER_ARGS , texture2d<float, access::sample> image, sampler linearSampler, constant float4 *events
#define SAMPLER_PASS , image, linearSampler, events
#define EVENT(i) events[i]
float4 film(float2 p SAMPLER_ARGS) { return image.sample(linearSampler,p); }
"""
let tail="""
kernel void material(texture2d<float,access::sample> image [[texture(0)]], texture2d<float,access::write> output [[texture(1)]],constant float4 *params [[buffer(0)]],uint2 p [[thread_position_in_grid]]) {
 if(p.x>=output.get_width()||p.y>=output.get_height())return;
 constexpr sampler linearSampler(coord::normalized,address::clamp_to_edge,filter::linear);
 float2 size=params[0].xy; float2 uv=(float2(p)+.5)/size;
 output.write(shade(uv,size,params[0].z,params[0].w,params[1].xy,int(params[1].z),params[1].w,image,linearSampler,params+2),p);
}
"""
let library:MTLLibrary
 do { library=try device.makeLibrary(source:header+"\n"+body+"\n"+tail,options:nil) } catch { fail("Shader compile failed: \(error)") }
guard let function=library.makeFunction(name:"material") else { fail("Material entry missing") }
let pipeline=try device.makeComputePipelineState(function:function)
let descriptor=MTLTextureDescriptor.texture2DDescriptor(pixelFormat:.rgba8Unorm,width:width,height:height,mipmapped:false)
descriptor.storageMode = .shared;descriptor.usage=[.shaderRead,.shaderWrite]
guard let input=device.makeTexture(descriptor:descriptor),let output=device.makeTexture(descriptor:descriptor) else { fail("Texture allocation failed") }
var uniforms=[Float](repeating:0,count:168)
uniforms[0]=Float(width);uniforms[1]=Float(height);uniforms[3]=0.90
uniforms[4]=0.5;uniforms[5]=0.5;uniforms[6]=Float(cues.count)
for (i,cue) in cues.enumerated() {
 guard let time=cue["time"] as? NSNumber,let pan=cue["pan"] as? NSNumber,let level=cue["level"] as? NSNumber else { fail("Invalid cue") }
 uniforms[8+i*4]=time.floatValue;uniforms[9+i*4]=pan.floatValue;uniforms[10+i*4]=level.floatValue
}
let envelopeURL=URL(fileURLWithPath:args[5]).deletingLastPathComponent().appendingPathComponent("audio-envelope.json")
let envelope=try JSONSerialization.jsonObject(with:Data(contentsOf:envelopeURL)) as! [String:Any]
guard let levels=envelope["levels"] as? [NSNumber],let envelopeFPS=envelope["fps"] as? NSNumber,envelopeFPS.floatValue==fps else { fail("Soundtrack envelope mismatch") }
let frameBytes=width*height*4
var frame=0
while true {
 var bytes=Data();bytes.reserveCapacity(frameBytes)
 while bytes.count<frameBytes {
  guard let part=try FileHandle.standardInput.read(upToCount:frameBytes-bytes.count),!part.isEmpty else { break }
  bytes.append(part)
 }
 if bytes.isEmpty { break }
 if bytes.count != frameBytes { fail("Truncated input frame \(frame)") }
 uniforms[2]=Float(frame)/fps
 if frame>=levels.count { fail("Soundtrack envelope exhausted") };uniforms[7]=levels[frame].floatValue
 bytes.withUnsafeBytes { input.replace(region:MTLRegionMake2D(0,0,width,height),mipmapLevel:0,withBytes:$0.baseAddress!,bytesPerRow:width*4) }
 guard let command=queue.makeCommandBuffer(),let encoder=command.makeComputeCommandEncoder() else { fail("GPU command allocation failed") }
 encoder.setComputePipelineState(pipeline);encoder.setTexture(input,index:0);encoder.setTexture(output,index:1)
 uniforms.withUnsafeBytes { encoder.setBytes($0.baseAddress!,length:$0.count,index:0) }
 encoder.dispatchThreads(MTLSize(width:width,height:height,depth:1),threadsPerThreadgroup:MTLSize(width:16,height:16,depth:1));encoder.endEncoding();command.commit();command.waitUntilCompleted()
 if command.status == .error { fail("GPU frame \(frame) failed: \(String(describing:command.error))") }
 bytes.withUnsafeMutableBytes { output.getBytes($0.baseAddress!,bytesPerRow:width*4,from:MTLRegionMake2D(0,0,width,height),mipmapLevel:0) }
 try FileHandle.standardOutput.write(contentsOf:bytes);frame+=1
}
FileHandle.standardError.write(Data("Metal rendered \(frame) frames on \(device.name)\n".utf8))
