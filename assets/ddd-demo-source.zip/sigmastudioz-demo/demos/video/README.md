# Illustrated demo sources

By Lex from SigmaStudioz. Open `film/README.md` for the50-second film, original
illustration prompts, stereo sound-design code, scene source and interactive preview.
Use `../refunds/README.md` for the runnable synthetic coding fixture. Both are teaching
materials; native coding evidence stays tied to the recorded1.0.5 validation receipt.
