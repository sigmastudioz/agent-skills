import data from '../storyboard.json';
import {useSyncExternalStore} from 'react';
export const film = data;
let time = 0;
const listeners = new Set<() => void>();
export const clamp = (value:number) => Math.max(0,Math.min(1,value));
export const ease = (value:number) => {const x=clamp(value);return x*x*(3-2*x);};
export function setFilmTime(value:number) {
  if(!Number.isFinite(value)) throw new Error('Film time must be finite');
  time=Math.max(0,Math.min(film.duration,value));
  for(const listener of listeners)listener();
}
export function useFilmTime() {
  return useSyncExternalStore(callback=>{listeners.add(callback);return ()=>{listeners.delete(callback);};},()=>time,()=>0);
}
export function beatAt(t:number) {return film.beats.find(beat=>t>=beat.start&&t<beat.end)??film.beats[film.beats.length-1];}
