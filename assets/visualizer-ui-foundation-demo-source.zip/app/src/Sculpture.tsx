import {memo,useEffect,useMemo} from 'react';
import {useThree} from '@react-three/fiber';
import {World,GlassMaterial,ExplodedAssembly,ReflectiveFloor} from '@sigmastudioz/ui-foundation/three';
import type {AssemblyPart} from '@sigmastudioz/ui-foundation/three';
import {ease,useFilmTime} from './timeline';

declare global {interface Window {filmScene?:{advance:(time:number)=>void;ready:boolean;info:()=>unknown};}}

function CaptureClock() {
  const get=useThree(state=>state.get);
  const setFrameloop=useThree(state=>state.setFrameloop);
  useEffect(()=>{
    const state=get();
    // World owns Canvas/environment/lighting. The film adapter only controls its clock.
    state.setFrameloop('never');
    window.filmScene={ready:true,advance:(seconds)=>{get().setFrameloop('never');get().advance(seconds,true);},info:()=>({
      frameloop:get().frameloop,calls:state.gl.info.render.calls,
      renderer:state.gl.getContext().getParameter(state.gl.getContext().RENDERER),
      environment:!!state.scene.environment,
    })};
    return ()=>{delete window.filmScene;};
  },[get,setFrameloop]);
  return null;
}

function Form() {
  const t=useFilmTime();
  const amount=1-ease((t-1.3)/4.2);
  const orbit=ease((t-4.5)/4.3);
  const finish=ease((t-9.3)/1.4);
  const parts=useMemo<AssemblyPart[]>(()=>Array.from({length:12},(_,i)=>{
    const angle=i*Math.PI/6;
    return {id:`arc-${i}`,rotation:[0,0,angle],offset:[Math.cos(angle+.15)*.8,Math.sin(angle+.15)*.8,(i%2?1:-1)*.65],
      spin:[(i%3-1)*.18,(i%2?1:-1)*.35,0],children:<mesh castShadow>
        <torusGeometry args={[1.27,.15,12,24,.39]}/>
        <meshStandardMaterial color={i%3===0?'#d8c19b':'#c1d6ce'} metalness={.93} roughness={.24}/>
      </mesh>};
  }),[]);
  return <>
    <group position={[0,.05,0]} rotation={[.12+orbit*.32, -.42+orbit*.82-finish*.24, -.18+t*.035]} scale={.95+orbit*.12-finish*.08-amount*.15}>
      <ExplodedAssembly parts={parts} amount={amount}/>
      <mesh rotation={[Math.PI/2.1,.15,0]}>
        <torusGeometry args={[1.03,.055,12,96]}/><meshStandardMaterial color="#dfaf62" metalness={.8} roughness={.24}/>
      </mesh>
      <mesh rotation={[.15,Math.PI/2,0]}>
        <torusGeometry args={[1.1,.04,12,96]}/><meshStandardMaterial color="#cbdcd7" metalness={.95} roughness={.2}/>
      </mesh>
      <mesh position={[0,0,.05]} rotation={[t*.035,t*.07,0]}>
        <icosahedronGeometry args={[.72,3]}/>
        <GlassMaterial preset="amber" transmission={.88} roughness={.13} thickness={1.4} color="#ffdba0" envMapIntensity={1.4}/>
      </mesh>
      <mesh><icosahedronGeometry args={[.26,1]}/><meshStandardMaterial color="#ffdba0" emissive="#ffb14d" emissiveIntensity={.55} roughness={.3}/></mesh>
    </group>
    <mesh position={[0,-1.63,0]}><cylinderGeometry args={[1.3,1.37,.2,96]}/><meshStandardMaterial color="#263b37" metalness={.7} roughness={.26}/></mesh>
    <ReflectiveFloor position={[0,-1.74,0]} size={[14,14]} color="#112422" strength={.34} blur={2} resolution={512}/>
    <CaptureClock/>
  </>;
}

// Stable parent props keep World from resetting the frame-driven Canvas policy on each tick.
export const Sculpture=memo(function Sculpture(){return <World preset="studio" camera={{position:[.1,.8,6.9],fov:38}}
  background="#102322" fog={false} environment ground={false} autoRotate={false} orbit={false}
  style={{width:'100%',height:'100%'}}><Form/></World>;});
