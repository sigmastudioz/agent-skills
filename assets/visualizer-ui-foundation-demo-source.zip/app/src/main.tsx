import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import {Gradient} from '@sigmastudioz/ui-foundation/gradient';
import {PaperReveal,BrushWipe} from '@sigmastudioz/ui-foundation/paper-motion';
import {Sculpture} from './Sculpture';
import {film,useFilmTime,setFilmTime,beatAt,ease,clamp} from './timeline';
import './style.css';

declare global {interface Window {renderFilmFrame?:(seconds:number)=>Promise<unknown>;filmMeta?:unknown;}}
const nextPaint=()=>new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));

function Backdrop(){const t=useFilmTime();return <div className="field">
  <Gradient paused speed={0} colors={['#071a19','#1c4940','#b8aa72']} shape="sphere" amplitude={.75+.15*Math.sin(t*.3)} frequency={1.2+.05*t} style={{width:'100%',height:'100%'}}/>
</div>;}

function Copy(){
  const t=useFilmTime(),beat=beatAt(t);
  const local=t-beat.start;
  const fade=ease(local/.4)*(t<11.5?1:1-.3*ease((t-11.5)/.5));
  return <>
    <header><b>SIGMASTUDIOZ</b><span>LIGHT TAKES FORM</span><span>STUDY / 001</span></header>
    <div className="copy" style={{opacity:fade,transform:`translateY(${(1-ease(local/.7))*12}px)`}}>
      <p className="eyebrow">{beat.eyebrow}</p>
      <PaperReveal progress={ease(local/.8)} kind={t>9?'torn':'brush'} seed={71} roughness={.7}>
        <h1>{beat.title[0]}<br/><em>{beat.title[1]}</em></h1>
      </PaperReveal>
      <p className="caption">{beat.caption}</p>
    </div>
    <div className="caption-rule"/>
    <footer><span>ORIGINAL COMPOSITION<br/><b>BUNDLED EFFECTS</b></span><span>SHARED PARTS.<br/><b>NEW POSSIBILITIES.</b></span></footer>
    <div className="track"><i style={{transform:`scaleX(${clamp(t/film.duration)})`}}/></div>
    <div className="wipe"><BrushWipe progress={clamp((t-(film.beats[3].start-.425))/.85)} color="#d9c697" direction="right" seed={21}/></div>
  </>;
}

createRoot(document.getElementById('root')!).render(<main><Backdrop/><div className="scene"><Sculpture/></div><div className="vignette"/><Copy/></main>);
window.filmMeta={width:film.width,height:film.height,fps:film.fps,duration:film.duration};
window.renderFilmFrame=async(seconds:number)=>{
  if(!window.filmScene?.ready)throw new Error('Scene is not ready');
  flushSync(()=>setFilmTime(seconds));
  // Controlled paper progress and shader configuration commit in effects.
  await nextPaint();await nextPaint();
  window.filmScene.advance(seconds);
  await nextPaint();
  if(document.querySelectorAll('canvas').length!==2)throw new Error('Expected one shader canvas and one World canvas');
  return window.filmScene.info();
};
