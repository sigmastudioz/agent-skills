# Light takes form

A 12-second, 1280 × 720, 24 fps material study made with the updated
**Visualization Videos by SigmaStudioz** skill and its `ui-foundation-reuse` companion.
The picture contains actual bundled React/WebGL effects and a real Three.js scene.
The soundtrack is an original synthesized pad/bell score, with no narration.
The WebVTT file describes the on-screen message; it is not a speech transcript.

## Reproduce

Requirements: Node.js, Python 3 (standard library), FFmpeg, and Google Chrome.
To use another installed Chromium executable, set `CHROME_PATH` to its path.

```sh
npm ci
node scripts/verify-install.mjs
npm run build
npm run draft
npm run render
```

Public React/Three/Vite/Playwright dependencies install normally. The UI runtime
is installed exclusively from `vendor/ui-foundation/ui-foundation.tgz`; neither
a library checkout nor a library download is required. Its version is **0.5.0**.
The local archive checksum is in `vendor/ui-foundation/bundle.json`, alongside
its MIT license and third-party notices. Preserve these when redistributing it.

The renderer writes to the sibling `../output/` directory: MP4, poster,
four draft frames, original WAV score and captions. `--draft` skips the full encode.
An optional `PLAYWRIGHT_MODULE` environment variable can select an existing
Playwright module of the locked version instead of the app-local installation;
this host used its bundled Playwright 1.62.1 and a separate, temporary Chrome profile.

## Checkout isolation

The tested install, build and browser export ran under a macOS OS sandbox that
denied reads from the original library checkout and the original reuse skill
installation, and denied all outbound network access. The skill ZIP was extracted
to a separate directory before the test; the local runtime was staged from that copy.
Public peer dependencies were copied from the earlier standalone React test app,
not from the library checkout. The offline local runtime install then replaced
the app's library package. Rendering-tool dependency metadata was resolved separately
from the public package registry while checkout reads remained blocked.

To repeat checkout denial on macOS after installing public dependencies:

```sh
export BLOCKED_CHECKOUT="/absolute/path/to/library-checkout"
sandbox-exec -D CHECKOUT="$BLOCKED_CHECKOUT" -f scripts/isolation.sb node scripts/verify-install.mjs
sandbox-exec -D CHECKOUT="$BLOCKED_CHECKOUT" -f scripts/isolation.sb npm run build
sandbox-exec -D CHECKOUT="$BLOCKED_CHECKOUT" -f scripts/isolation.sb npm run render
```

The verifier requires checkout reads to fail with an access-denied error when
`BLOCKED_CHECKOUT` is set. It also checks the local-file lock entry, archive SHA-256
and SHA-512 integrity, app-local resolution and included license/notices. The app
has no source aliases or links to a checkout. Use a container without the checkout
mounted for a comparable test on another OS; macOS sandbox tooling is not portable.

## What is reused

| Public export | Role in the encoded picture |
| --- | --- |
| `Gradient` from `/gradient` | Real shader field; `speed=0` keeps shader time fixed while amplitude/frequency are sampled from the film timeline |
| `World` from `/three` | Existing `Scene`/Canvas host, procedural room environment and studio lighting; automatic orbit is disabled |
| `ExplodedAssembly` from `/three` | Controlled assembly poses for twelve original arc parts |
| `GlassMaterial` from `/three` | Amber transmission material on the original core geometry |
| `ReflectiveFloor` from `/three` | Existing reflection pass beneath the sculpture |
| `PaperReveal`, `BrushWipe` from `/paper-motion` | Seeded, controlled text reveals and the final brush transition |

The app owns sculpture geometry, typography, composition, cue data and encoding.
It does not copy library shaders, create another Canvas, build another environment,
or reconstruct the library's lifecycle/assembly/reflection implementations.

## The required timing adapter

`World` is a live scene host, not a video-export API. `CaptureClock` accesses its
existing Fiber root and selects `frameloop='never'`. The capture script sets a
canonical timestamp, commits controlled React effects, and calls the existing
Fiber `advance(seconds)` API. World orbit is off; the sculpture's rotations and
assembly amount are pure functions of the timestamp. The seeded paper masks use
controlled progress. The final scene changes when the brush is fully covered.

This is an app-specific capture adapter, not a claim that every bundled effect
supports seeking. In particular, the Gradient's live RAF clock is not used for
arbitrary-time capture. Its public configuration is sampled at a fixed shader time.
The adapter leaves the library package unchanged and does not bypass a paused
interactive host. Capture uses a fixed, explicit motion policy; the poster is a
static companion. The encoded film itself is linear, not an interactive player.

Before encoding, the renderer captures 2.4 s, seeks forward to 8.2 s, then back to
2.4 s and requires byte-identical PNGs. It requires a rendered scene, procedural
environment, exactly one shader canvas and one World canvas, no page/console errors,
and no page network requests. It samples every frame at `frame / 24`, streaming
PNGs through one FFmpeg process instead of accumulating the film in memory.

## Connected source and verification boundary

`storyboard.json` feeds the React timeline, captions and score cues.
`src/timeline.ts` drives `Backdrop`/`Copy` and `Form`; `Sculpture.tsx` composes
public helpers and exposes the existing scene clock to `scripts/render.mjs`.
The capture script connects the production Vite build to PNG frames and FFmpeg.
`scripts/make-score.py` produces original audio and WebVTT from the same scene data.
The runtime package owns shared GPU resources and scene disposal; browser shutdown
closes the scene after capture. Renderer/browser failures fail the export.

The isolation verifier and TypeScript/Vite build passed. Drafts were visually
reviewed at full size, including the assembly, material view and final statement.
The final MP4 is decoded and checked separately; measured results are recorded below.
This tests the selected exports on this host. GPU context loss, missing-peer fallback,
different browsers and hardware performance are not newly tested by this film.
Audio is structurally measured; a listening review is not claimed.

Editable sources include the runtime archive and licenses. Dependency installations,
browser profiles, build output, machine-specific paths and temporary test logs are
excluded from the source ZIP.

## Final checked export

- Exactly 12.000 s; H.264, 1280 × 720, 24 fps, 288 decoded frames.
- AAC stereo, 48 kHz. Measured encoded mix: -20.01 LUFS integrated,
  -8.18 dBTP true peak, 1.70 LU loudness range. No clipping detected.
- All 288 video frames and the audio stream decoded without errors. 283 distinct
  decoded frame hashes; repeated frames occur while the brush deliberately covers the picture.
- First/last frames, a one-second contact sheet and full-size chapter frames were visually
  reviewed. The final cut is timed to the brush's full-coverage midpoint.
- Exact-time backward seeking reproduced a byte-identical frame. Browser capture reported
  no page errors, console errors or page network requests.
- MP4 SHA-256: `0220dd1677aff54923ca7a6df3aee363ea905419f80e9b64d0397b3e07ed7177`.
- Runtime tarball SHA-256: `6247098e8bce41a372c3edb41abc5f9965e0c03d994f7c2966728d9622a2714f`.

No publication or external upload was performed.
