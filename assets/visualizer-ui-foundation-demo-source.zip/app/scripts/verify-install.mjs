import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const require=createRequire(path.join(root,'package.json'));
const manifestFile=require.resolve('@sigmastudioz/ui-foundation/package.json');
const installed=path.dirname(manifestFile);
assert.ok(fs.realpathSync(installed).startsWith(path.join(root,'node_modules')+path.sep));
assert.equal(fs.lstatSync(installed).isSymbolicLink(),false);
const pkg=JSON.parse(fs.readFileSync(manifestFile));
const metadata=JSON.parse(fs.readFileSync(path.join(root,'vendor/ui-foundation/bundle.json')));
const tarball=fs.readFileSync(path.join(root,'vendor/ui-foundation/ui-foundation.tgz'));
assert.equal(crypto.createHash('sha256').update(tarball).digest('hex'),metadata.sha256);
assert.equal(pkg.version,metadata.version);
const lock=JSON.parse(fs.readFileSync(path.join(root,'package-lock.json')));
assert.equal(lock.packages['node_modules/@sigmastudioz/ui-foundation'].resolved,'file:vendor/ui-foundation/ui-foundation.tgz');
assert.equal(lock.packages['node_modules/@sigmastudioz/ui-foundation'].integrity,'sha512-'+crypto.createHash('sha512').update(tarball).digest('base64'));
assert.ok(fs.existsSync(path.join(installed,'LICENSE')));
assert.ok(fs.existsSync(path.join(installed,'THIRD_PARTY_NOTICES.md')));
if(process.env.BLOCKED_CHECKOUT) {
  assert.throws(()=>fs.readFileSync(path.join(process.env.BLOCKED_CHECKOUT,'package.json')),error=>['EPERM','EACCES'].includes(error.code));
  console.log('OS sandbox blocks checkout reads.');
}
console.log(`Verified bundled runtime ${pkg.version}: app-local package, local-file lock entry, archive integrity and notices.`);
