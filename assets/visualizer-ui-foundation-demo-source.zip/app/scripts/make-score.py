"""Original synthesized pad/bell score and captions, on the film's canonical clock."""
import array,json,math,wave
from pathlib import Path

root=Path(__file__).resolve().parents[1]
film=json.loads((root/'storyboard.json').read_text())
out=root.parent/'output';out.mkdir(exist_ok=True)
rate=48000
samples=array.array('h')
for frame in range(round(rate*film['duration'])):
    t=frame/rate
    fade=min(1,t/.8,max(0,(film['duration']-t)/1.3))
    pad=sum(math.sin(2*math.pi*frequency*t+.2*math.sin(t*.3))/(i+3)
            for i,frequency in enumerate([110,164.8138,220,261.6256,329.6276]))*.12
    left=right=pad*fade
    for i,cue in enumerate(film['cues']):
        dt=t-cue['time']
        if 0<=dt<2.5:
            frequency=440*2**((cue['note']-69)/12)
            bell=(math.sin(2*math.pi*frequency*dt)*math.exp(-dt*2.5)
                  +.23*math.sin(2*math.pi*frequency*2.003*dt)*math.exp(-dt*5))
            envelope=min(1,dt/.015)*.11*fade
            left+=bell*envelope*(.8 if i%2 else 1)
            right+=bell*envelope*(1 if i%2 else .8)
    sweep=math.exp(-((t-(film['beats'][-1]['start']-.15))/.25)**2)*math.sin(2*math.pi*(70*t+22*t*t))*.025
    left+=sweep;right+=sweep
    for value in (left,right):
        samples.append(round(max(-1,min(1,value))*32767))
with wave.open(str(out/'score.wav'),'wb') as stream:
    stream.setnchannels(2);stream.setsampwidth(2);stream.setframerate(rate);stream.writeframes(samples.tobytes())
def stamp(t):
    ms=round(t*1000)
    return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}.{ms%1000:03}'
captions=['WEBVTT','']
for beat in film['beats']:
    captions.extend([f"{stamp(beat['start'])} --> {stamp(beat['end'])}",
                     ' '.join(beat['title']),beat['caption'],''])
(out/'captions.vtt').write_text('\n'.join(captions))
print('Original stereo synth score and timed captions generated.')
