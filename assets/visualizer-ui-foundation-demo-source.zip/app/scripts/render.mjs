import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {spawn,execFileSync} from 'node:child_process';
import {once} from 'node:events';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.resolve(root,'../output');
fs.mkdirSync(out,{recursive:true});
const film=JSON.parse(fs.readFileSync(path.join(root,'storyboard.json')));
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE||'playwright');
const browser=await chromium.launch({headless:true,...(process.env.CHROME_PATH?{executablePath:process.env.CHROME_PATH}:{channel:'chrome'}),
  args:['--no-sandbox','--allow-file-access-from-files','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:film.width,height:film.height},deviceScaleFactor:1,reducedMotion:'no-preference'});
const errors=[];
page.on('pageerror',error=>errors.push(error.message));
page.on('console',message=>{if(message.type()==='error')errors.push(message.text());});
page.on('request',request=>{if(!['file:','data:','blob:'].includes(new URL(request.url()).protocol))errors.push(`Unexpected network request: ${request.url()}`);});
let encoder;
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
async function frame(t) {
  const info=await page.evaluate(async time=>window.renderFilmFrame(time),t);
  assert.equal(info.frameloop,'never');
  assert.ok(info.calls>0,'World must render actual geometry');
  assert.ok(info.environment,'World must supply its procedural environment');
  assert.deepEqual(errors,[],'Browser errors');
  return page.screenshot({type:'png',animations:'disabled',caret:'hide'});
}
try {
  await page.goto(pathToFileURL(path.join(root,'dist/index.html')).href);
  await page.waitForFunction(()=>window.filmScene?.ready,{timeout:30000});
  await page.evaluate(()=>document.fonts.ready);
  // Allow lazy shared staging peers to mount before testing exact-time captures.
  await page.waitForTimeout(900);
  const a=await frame(2.4);
  await frame(8.2);
  const b=await frame(2.4);
  assert.equal(hash(a),hash(b),'Seeking backward must reproduce the exact same frame');
  for(const time of [1.6,5.5,8.2,10.8])fs.writeFileSync(path.join(out,`frame-${time}.png`),await frame(time));
  fs.writeFileSync(path.join(out,'poster.png'),await frame(5.5));
  console.log('Exact-time seek test passed; draft frames rendered.');
  if(process.argv.includes('--draft'))process.exitCode=0;
  else {
    execFileSync(process.env.PYTHON||'python3',[path.join(root,'scripts/make-score.py')],{stdio:'inherit'});
    encoder=spawn('ffmpeg',['-hide_banner','-loglevel','warning','-y','-f','image2pipe','-framerate',String(film.fps),'-vcodec','png','-i','pipe:0',
      '-i',path.join(out,'score.wav'),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p',
      '-c:a','aac','-ar','48000','-b:a','160k','-af','loudnorm=I=-20:TP=-2:LRA=8','-t',String(film.duration),'-movflags','+faststart',path.join(out,'light-takes-form.mp4')],
      {stdio:['pipe','ignore','inherit']});
    const completed=once(encoder,'close');
    encoder.stdin.on('error',error=>{if(error.code!=='EPIPE')throw error;});
    for(let index=0;index<film.duration*film.fps;index++) {
      const png=await frame(index/film.fps);
      if(!encoder.stdin.write(png))await once(encoder.stdin,'drain');
      if(index%film.fps===0)console.log(`Encoded frame ${index}/${film.duration*film.fps}`);
    }
    encoder.stdin.end();
    const [code]=await completed;
    assert.equal(code,0,'Encoder failed');
    assert.deepEqual(errors,[]);
    console.log(`Finished ${film.duration}s / ${film.duration*film.fps} distinct timeline samples; no browser errors or network requests.`);
  }
} finally {
  if(encoder&&encoder.exitCode===null)encoder.kill('SIGTERM');
  await browser.close();
}
