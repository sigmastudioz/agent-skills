# React Native visualizer

The visualizer now has a native Skia backend for iOS and Android. The web backend
continues using WebGL. Both consume the same kind catalog, presets, audio frame
sampling, and seven shared SkSL sources; Liquid Metal has an equivalent unmasked
SkSL implementation of its analytic reflection shader.

This support is in local source. It does not change previously published package
versions or automatically upgrade consumers such as Galaxy Radio.

## Import and install

Use the explicit entry point for portable Metro **and TypeScript** resolution:

```tsx
import { Visualizer, EffectsProvider } from '@sigmastudioz/ui-foundation/visualizer/native';

<EffectsProvider maxFps={25} maxDpr={1.5}>
  <Visualizer
    kind="nebula"
    width={390}
    height={220}
    visible={isScreenFocused && isCardVisible}
    enabled={!skipSkiaOnThisDevice}
    performanceTier="ambient"
    audio={audioSource}
    paused={!isPlaying}
  />
</EffectsProvider>
```

`react-native` and `@shopify/react-native-skia` are optional peers. Install/link
compatible versions in the host app, rebuild native binaries, and run the normal
iOS pod setup. Development validation uses React 18.3.1, RN 0.77.0, and Skia
1.12.4. Other peer-range combinations require their own native validation.
`react-dom` is now optional for native-only consumers.

Metro consumers with package exports and the `react-native` condition enabled can
also import `@sigmastudioz/ui-foundation/visualizer`. TypeScript must select that
condition as well to obtain the native props. The explicit `/visualizer/native`
path avoids that configuration dependency. The package root remains web-first;
do not import native effects from the root barrel.

## Shared interface

The eight kinds are `liquid`, `liquid-metal`, `cosmic`, `nebula`, `wave`, `bars`,
`ribbon`, and `radial`. The common options include bins, waveform, amplitude,
beat, colors, speed, dim, metalPreset, audio, sensitivity, paused, and adaptive.
Native Liquid Metal also accepts `metalLow`, `metalHigh`, and `tint` overrides
for host branding (a follow-up fix after 0.3.0).

Presentation differs: native uses RN `StyleProp<ViewStyle>` instead of CSS and
has no className. Liquid Metal uses its preset tones; image/text masks from the
standalone web LiquidMetal component are not part of the visualizer API.

The native entry also exports `VisualizerOptions`, `VisualizerAudioSource`,
`VisualizerAudioFrame`, `createAudioFrame`, and `EffectsProvider`. Browser audio
capture hooks are deliberately not exported from the native entry.

A native audio source is a stable object with a synchronous `sample()` method
returning the current frame: 16 normalized spectrum bins, waveform samples,
peaks, amplitude, bass, mid, treble, and beat envelope. Existing native FFT hooks
can fill a retained frame and expose it through this interface. No microphone
permission or recording is initiated by this library. The host owns capture
and must release/suspend it when no consumer needs it; stopping sample calls
does not stop an externally owned audio engine.

## Lifecycle and fallback

- Backgrounding the app or setting `visible={false}` releases the Skia surface
  and stops frame/audio sampling. Native navigation and scroll visibility must
  be passed explicitly; there is no native IntersectionObserver.
- Reduced motion uses a static fallback. Rendering waits for the OS preference
  before starting animations and for interactions before creating a surface.
- `paused`, provider pause, and zero speed stop the animation scheduler. Prop
  changes can still paint a single static frame. Resuming excludes paused time.
- `enabled={false}` never imports Skia. Galaxy Radio should keep its existing
  Android emulator guard and pass the result here.
- Missing/unlinked Skia or shader compilation failures display `fallback` and
  call `onError` when provided. The default fallback is a solid preset color.
- Canvas sizes are explicit on both platforms. Heavy shaders target at most
  25 updates/s, light shaders 30, and ambient surfaces 20. `maxFps` can lower
  these budgets. Timer/frame alignment can produce a lower actual rate.
- Resolution is capped by density, effect cost, and performance tier. Adaptive
  resolution uses hysteresis; it reduces load on sustained slow frame delivery
  and recovers gradually. These are conservative budgets, not measured FPS.

## Verification

`npm run verify` builds CJS and ESM, tests packed conditional/native exports
without optional renderers, compiles all eight shaders through real Skia
(CanvasKit), verifies nonblank spatial detail and motion via pixel readback,
and runs the Jest suite with coverage. `npm run lint` is also required.

The CanvasKit raster test verifies shader compatibility and uniform wiring. It
does not replace iOS/Android release builds, navigation stress, native Skia
linking checks, GPU/energy profiling, or screenshot parity on physical devices.

## Galaxy Radio adoption

Keep Galaxy Radio's existing Skia renderer until a version containing this
entry point is released through ui-foundation CI. Then upgrade its registry
version and committed lockfile, replace its native adapter with this entry,
and pass the existing analyzer refs through a stable audio source. Preserve
its emulator guard, focus/visibility handling, and brand colors. Do not point
production manifests at a developer-local directory or an unpublished version.
