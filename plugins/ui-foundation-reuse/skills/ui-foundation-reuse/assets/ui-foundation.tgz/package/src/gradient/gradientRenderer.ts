import {
  FRAGMENT_SRC,
  FULLSCREEN_TRIANGLE,
  hexToRgb01,
  VERTEX_SRC,
} from './gradientShader.js';
import type { ResolvedGradientConfig } from './types.js';

const SHAPE_INDEX: Record<ResolvedGradientConfig['shape'], number> = {
  plane: 0,
  sphere: 1,
  waterPlane: 2,
};

export interface GradientRenderer {
  /** Draw one frame. `timeSeconds` drives motion; pass a fixed value to freeze. */
  render(config: ResolvedGradientConfig, timeSeconds: number): void;
  /** Resize the drawing buffer to CSS size × dpr. */
  resize(cssWidth: number, cssHeight: number, dpr: number): void;
  dispose(): void;
}

function compile(
  gl: WebGLRenderingContext,
  type: number,
  src: string,
): WebGLShader | null {
  const sh = gl.createShader(type);
  if (!sh) return null;
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    gl.deleteShader(sh);
    return null;
  }
  return sh;
}

/**
 * Build a renderer bound to `canvas`, or `null` when WebGL is unavailable
 * (old browsers, jsdom, blocked contexts). Callers fall back to CSS.
 */
export function createGradientRenderer(
  canvas: HTMLCanvasElement,
): GradientRenderer | null {
  const gl =
    (canvas.getContext('webgl', { antialias: false, alpha: false }) as
      | WebGLRenderingContext
      | null) ??
    (canvas.getContext('experimental-webgl') as WebGLRenderingContext | null);
  if (!gl) return null;

  const vs = compile(gl, gl.VERTEX_SHADER, VERTEX_SRC);
  const fs = compile(gl, gl.FRAGMENT_SHADER, FRAGMENT_SRC);
  const program = gl.createProgram();
  if (!vs || !fs || !program) return null;

  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    gl.deleteProgram(program);
    return null;
  }
  gl.useProgram(program);

  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, FULLSCREEN_TRIANGLE, gl.STATIC_DRAW);

  const aPosition = gl.getAttribLocation(program, 'aPosition');
  gl.enableVertexAttribArray(aPosition);
  gl.vertexAttribPointer(aPosition, 2, gl.FLOAT, false, 0, 0);

  const u = {
    resolution: gl.getUniformLocation(program, 'uResolution'),
    time: gl.getUniformLocation(program, 'uTime'),
    amplitude: gl.getUniformLocation(program, 'uAmplitude'),
    frequency: gl.getUniformLocation(program, 'uFrequency'),
    shape: gl.getUniformLocation(program, 'uShape'),
    colorCount: gl.getUniformLocation(program, 'uColorCount'),
    color0: gl.getUniformLocation(program, 'uColor0'),
    color1: gl.getUniformLocation(program, 'uColor1'),
    color2: gl.getUniformLocation(program, 'uColor2'),
  };

  let previousConfig: ResolvedGradientConfig | undefined;
  let colors = [[0,0,0], [0,0,0], [0,0,0]];

  return {
    resize(cssWidth, cssHeight, dpr) {
      const w = Math.max(1, Math.floor(cssWidth * dpr));
      const h = Math.max(1, Math.floor(cssHeight * dpr));
      if (canvas.width !== w) canvas.width = w;
      if (canvas.height !== h) canvas.height = h;
      gl.viewport(0, 0, w, h);
    },
    render(config, timeSeconds) {
      if (previousConfig !== config) {
        colors = config.colors.map(hexToRgb01);
        previousConfig = config;
      }
      const [c0, c1, c2] = colors;
      gl.uniform2f(u.resolution, canvas.width, canvas.height);
      gl.uniform1f(u.time, timeSeconds * config.speed);
      gl.uniform1f(u.amplitude, config.amplitude);
      gl.uniform1f(u.frequency, config.frequency);
      gl.uniform1i(u.shape, SHAPE_INDEX[config.shape]);
      gl.uniform1i(u.colorCount, config.colorCount);
      gl.uniform3f(u.color0, c0[0], c0[1], c0[2]);
      gl.uniform3f(u.color1, c1[0], c1[1], c1[2]);
      gl.uniform3f(u.color2, c2[0], c2[1], c2[2]);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    },
    dispose() {
      gl.deleteBuffer(buffer);
      gl.deleteProgram(program);
      gl.deleteShader(vs);
      gl.deleteShader(fs);
    },
  };
}

/** CSS `linear-gradient` string used when WebGL is unavailable (also SSR paint). */
export function cssFallbackGradient(config: ResolvedGradientConfig): string {
  const stops =
    config.colorCount === 3
      ? config.colors
      : [config.colors[0], config.colors[1]];
  return `linear-gradient(135deg, ${stops.join(', ')})`;
}
