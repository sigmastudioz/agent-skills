/** Recipes are plain data, frozen recursively without importing React or a renderer. */
export function freezeRecipe<T>(value: T): T {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) freezeRecipe(child);
    Object.freeze(value);
  }
  return value;
}
