import type { CymaticsConfig, CymaticsShape } from './types.js';

export const CYMATICS_GRID = 112;
export interface CymaticsMode { m: number; n: number; root: number; values: Float32Array }
// Zeros of J_m. Mathematical constants; no third-party animation/code/assets.
const ROOTS = [
  [2.404826, 5.520078, 8.653728, 11.791534], [3.831706, 7.015587, 10.173468, 13.323692],
  [5.135622, 8.417244, 11.619841, 14.795952], [6.380162, 9.761023, 13.015201, 16.223466],
  [7.588342, 11.064709, 14.372537, 17.615966], [8.771484, 12.338604, 15.700174, 18.980134],
  [9.936110, 13.589290, 17.003820, 20.320789],
];

/** Integer-order Bessel J, convergent power series on the bounded mode domain. */
export function besselJ(order: number, x: number): number {
  let term = 1;
  for (let i = 1; i <= order; i++) term *= x / (2 * i);
  let sum = term;
  for (let k = 1; k < 75; k++) {
    term *= -x * x / (4 * k * (k + order)); sum += term;
    if (Math.abs(term) < 1e-13) break;
  }
  return sum;
}

export function modeFrequency(mode: Pick<CymaticsMode, 'root'>, config: CymaticsConfig): number {
  const ratio = mode.root / (config.shape === 'circle' ? ROOTS[0][0] : Math.sqrt(2));
  return config.fundamental * Math.sqrt(config.tension) / config.size * ratio * Math.sqrt(1 - config.stiffness + config.stiffness * ratio * ratio);
}

/** Only rebuilt on shape changes. Radial lookup avoids per-cell Bessel evaluations. */
export function buildCymaticsModes(shape: CymaticsShape): CymaticsMode[] {
  const modes: CymaticsMode[] = [];
  const definitions = shape === 'circle'
    ? ROOTS.flatMap((roots, m) => roots.map((root, n) => ({ m, n: n + 1, root })))
    : Array.from({ length: 7 }, (_, n) => Array.from({ length: n + 1 }, (_, m) => ({ m, n: n + 1, root: Math.hypot(m + 1, n + 1) }))).flat();
  for (const definition of definitions) {
    const { m, n, root } = definition, values = new Float32Array(CYMATICS_GRID * CYMATICS_GRID);
    const radial = shape === 'circle' ? Float32Array.from({ length: 513 }, (_, i) => besselJ(m, root * i / 512)) : null;
    let maximum = 0;
    for (let y = 0; y < CYMATICS_GRID; y++) for (let x = 0; x < CYMATICS_GRID; x++) {
      const px = x / (CYMATICS_GRID - 1) * 2 - 1, py = y / (CYMATICS_GRID - 1) * 2 - 1;
      const r = Math.hypot(px, py), index = Math.min(512, r * 512), lo = Math.floor(index);
      const value = shape === 'circle'
        ? r >= 1 ? 0 : (radial![lo] + (radial![Math.min(512, lo + 1)] - radial![lo]) * (index - lo)) * Math.cos(m * Math.atan2(py, px))
        : Math.cos((m + 1) * Math.PI * (px + 1) / 2) * Math.cos(n * Math.PI * (py + 1) / 2)
          - (m + 1 === n ? 0 : Math.cos(n * Math.PI * (px + 1) / 2) * Math.cos((m + 1) * Math.PI * (py + 1) / 2));
      values[y * CYMATICS_GRID + x] = value; maximum = Math.max(maximum, Math.abs(value));
    }
    if (maximum) for (let i = 0; i < values.length; i++) values[i] /= maximum;
    modes.push({ ...definition, values });
  }
  return modes;
}
