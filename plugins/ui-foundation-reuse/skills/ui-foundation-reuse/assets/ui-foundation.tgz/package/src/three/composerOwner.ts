const owners = new WeakMap<object, string>();

/** One post-processing chain may draw a Canvas. Throws when another already does. */
export function claimComposer(renderer: object, name: string): () => void {
  const current = owners.get(renderer);
  if (current === name) throw new Error(`Only one ${name} may own a Canvas.`);
  if (current) throw new Error(`Only one post-processing chain may own a Canvas: ${current} is already mounted. Use PostEffects for bloom together with other effects.`);
  owners.set(renderer, name);
  return () => { if (owners.get(renderer) === name) owners.delete(renderer); };
}
