import { clampNumber } from '../core/numberOps.js';

export interface FrameLoaderOptions {
  /** Maximum decoded frames retained (2..256). Default 24. */
  cacheSize?: number;
  /** Concurrent image requests (1..8). Default 4. */
  concurrency?: number;
  /** Neighbors requested on either side of the target. Default 6. */
  preload?: number;
  onFrame: (image: HTMLImageElement, index: number) => void;
  /** Cache notification, including neighbors that do not replace the current frame. */
  onLoad?: (image: HTMLImageElement, index: number) => void;
  /** Failed frames are skipped for this loader's lifetime. */
  onError?: (index: number, src: string) => void;
}

export interface FrameSequenceLoader {
  seek(index: number): void;
  peek(index: number): HTMLImageElement | null;
  dispose(): void;
}

/** Bounded LRU cache with target-first loading and nearest-available fallback. No work until seek(). */
export function createFrameSequenceLoader(sources: readonly string[], options: FrameLoaderOptions): FrameSequenceLoader {
  const frames = [...sources];
  const capacity = Math.floor(clampNumber(options.cacheSize, 2, 256, 24));
  const concurrency = Math.floor(clampNumber(options.concurrency, 1, 8, 4));
  const radius = Math.min(Math.floor((capacity - 1) / 2), Math.floor(clampNumber(options.preload, 0, 128, 6)));
  const cache = new Map<number, HTMLImageElement>();
  const pending = new Map<number, HTMLImageElement>();
  const failed = new Set<number>();
  let target = -1;
  let displayed: HTMLImageElement | null = null;
  let disposed = false;

  function publish() {
    let index = -1;
    for (const key of cache.keys()) {
      if (index < 0 || Math.abs(key - target) < Math.abs(index - target)) index = key;
    }
    const image = cache.get(index);
    if (!image || image === displayed) return;
    cache.delete(index); cache.set(index, image);
    displayed = image;
    options.onFrame(image, index);
  }

  function queue(): number[] {
    const indices = [target];
    for (let distance = 1; distance <= radius; distance++) indices.push(target + distance, target - distance);
    return indices.filter(index => index >= 0 && index < frames.length && !cache.has(index) && !pending.has(index) && !failed.has(index));
  }

  function pump() {
    if (disposed || target < 0) return;
    for (const index of queue()) {
      if (pending.size >= concurrency) break;
      const image = new Image();
      pending.set(index, image);
      image.crossOrigin = 'anonymous';
      image.decoding = 'async';
      const finish = (ok: boolean) => {
        if (disposed || !pending.has(index)) return;
        pending.delete(index);
        image.onload = null; image.onerror = null;
        if (ok && image.naturalWidth && image.naturalHeight) {
          cache.set(index, image);
          // Preserve the requested frame; stale completions must not evict it.
          while (cache.size > capacity) {
            const oldest = [...cache.keys()].find(key => key !== target)!;
            cache.delete(oldest);
          }
          publish();
          options.onLoad?.(image, index);
        } else {
          failed.add(index);
          options.onError?.(index, frames[index]);
        }
        pump();
      };
      image.onload = () => {
        if (image.decode) image.decode().then(() => finish(true), () => finish(false));
        else finish(true);
      };
      image.onerror = () => finish(false);
      image.src = frames[index];
    }
  }

  return {
    peek: index => disposed ? null : cache.get(index) ?? null,
    seek(index) {
      if (disposed || !frames.length) return;
      target = Math.round(clampNumber(index, 0, frames.length - 1, 0));
      publish(); pump();
    },
    dispose() {
      disposed = true;
      pending.forEach(image => { image.onload = null; image.onerror = null; image.src = ''; });
      pending.clear(); cache.clear(); failed.clear(); displayed = null;
    },
  };
}
