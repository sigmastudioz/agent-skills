import { clampNumber } from '../core/numberOps.js';
import type { FoilSurfaceProps, ResolvedFoilConfig } from './types.js';

export function resolveFoilConfig(props: Partial<FoilSurfaceProps>): ResolvedFoilConfig {
  return {
    imageFit: props.imageFit === 'cover' ? 'cover' : 'stretch',
    aspectRatio: clampNumber(props.aspectRatio, .25, 2, .56),
    tearAt: clampNumber(props.tearAt, .2, .9, .76),
    ...(props.inset === undefined ? {} : { inset: clampNumber(props.inset, 0, .25, 0) }),
    cornerRadius: clampNumber(props.cornerRadius, 0, .25, 0),
    shadowOpacity: clampNumber(props.shadowOpacity, 0, 1, .14),
    tearable: props.tearable ?? true,
    debug: props.debug ?? false,
    stiffness: clampNumber(props.stiffness, 0, 1, .55),
    iridescence: clampNumber(props.iridescence, 0, 1, 1),
    intensity: clampNumber(props.intensity, 0, 1, .7),
    hue: clampNumber(props.hue, 0, 1, 0),
    foilTint: [0,1,2].map(i => clampNumber(props.foilTint?.[i],0,1,1)) as [number,number,number],
    idleMotion: clampNumber(props.idleMotion, 0, 1, .15),
  };
}

/** Vertical field of view in sheet units; preserves margins in narrow containers. */
export function foilViewHeight(width: number, height: number, ratio: number, inset?: number): number {
  if (inset !== undefined) return Math.max(2.8, 2.8 * ratio / Math.max(.1, width / Math.max(1, height))) / (1 - inset * 2);
  return Math.max(3.12, 2.8 * ratio * 1.35 / Math.max(.1, width / Math.max(1, height)));
}

/** Projection shared by drawing and pointer picking. Input UVs remain attached to the mesh. */
export function projectFoilPoint(x: number, y: number, z: number, turn: number): [number, number, number] {
  const px = Math.cos(turn) * x + Math.sin(turn) * z;
  const pz = -Math.sin(turn) * x + Math.cos(turn) * z;
  const perspective = 1 / (1 - pz * .12);
  return [px * perspective, y * perspective, pz];
}

/** UV range for center-cropped, undistorted artwork on a sheet. */
export function foilCoverScale(imageRatio: number, sheetRatio: number): [number, number] {
  const ratio = Number.isFinite(imageRatio) && imageRatio > 0 ? imageRatio : sheetRatio;
  return ratio > sheetRatio ? [sheetRatio / ratio, 1] : [1, ratio / sheetRatio];
}
