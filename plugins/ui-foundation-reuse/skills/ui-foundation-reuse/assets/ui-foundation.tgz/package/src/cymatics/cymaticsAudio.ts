import type { CymaticsAudioFrame, CymaticsAudioSource } from './types.js';

/** Wrap a caller-owned analyser; reading never changes its graph or FFT settings. */
export function createCymaticsAnalyser(analyser: AnalyserNode): CymaticsAudioSource {
  let fft = 0, db = new Float32Array(0), wave = new Float32Array(0), spectrum = new Float32Array(0);
  const frame: CymaticsAudioFrame = { spectrum, sampleRate: 48000, fftSize: 2048, amplitude: 0 };
  return { sample() {
    if (fft !== analyser.fftSize) {
      fft = analyser.fftSize; db = new Float32Array(analyser.frequencyBinCount);
      spectrum = new Float32Array(db.length); wave = new Float32Array(fft); frame.spectrum = spectrum;
    }
    analyser.getFloatFrequencyData(db); analyser.getFloatTimeDomainData(wave);
    for (let i = 0; i < db.length; i++) spectrum[i] = Number.isFinite(db[i]) ? Math.min(1, Math.pow(10, db[i] / 20)) : 0;
    let sum = 0;
    for (let i = 0; i < wave.length; i++) { const v = Number.isFinite(wave[i]) ? wave[i] : 0; sum += v * v; }
    frame.amplitude = Math.min(1, Math.sqrt(sum / Math.max(1, wave.length)));
    frame.sampleRate = analyser.context.sampleRate; frame.fftSize = fft;
    return frame;
  } };
}

/** Visual insert for any Web Audio graph. Unity dry output; no automatic speaker connection. */
export function createCymaticsEffect(context: BaseAudioContext) {
  const nodes: AudioNode[] = [];
  let input: GainNode, output: GainNode, analyser: AnalyserNode;
  try {
    input = context.createGain(); nodes.push(input);
    output = context.createGain(); nodes.push(output);
    analyser = context.createAnalyser(); nodes.push(analyser);
    analyser.fftSize = 4096; analyser.smoothingTimeConstant = .15;
    input.connect(output); input.connect(analyser);
  } catch (error) { nodes.forEach(node => node.disconnect()); throw error; }
  let disposed = false;
  const audio = createCymaticsAnalyser(analyser);
  return { input, output, analyser, audio, dispose() {
    if (disposed) return; disposed = true;
    input.disconnect(); output.disconnect(); analyser.disconnect();
  } };
}
