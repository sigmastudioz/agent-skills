import { clampNumber } from '../core/numberOps.js';
export interface VisualizerAudioFrame {
  bins: number[]; waveform: number[]; peaks: number[];
  amplitude: number; bass: number; mid: number; treble: number; beat: number;
}
/** A retained frame, sampled by the visualizer only while it renders. */
export interface VisualizerAudioSource { sample(): VisualizerAudioFrame }
export const createAudioFrame = (): VisualizerAudioFrame => ({bins:Array(16).fill(0),waveform:Array(16).fill(0),peaks:Array(16).fill(0),amplitude:0,bass:0,mid:0,treble:0,beat:0});
export function frequencyBands(sampleRate:number,fftSize:number): [number,number][] {
  const nyquist=Math.max(1,sampleRate/2),max=Math.min(16000,nyquist),count=fftSize/2;
  return Array.from({length:16},(_,i)=>{
    const low=20*Math.pow(max/20,i/16),high=20*Math.pow(max/20,(i+1)/16);
    const start=Math.min(count-1,Math.max(0,Math.floor(low/nyquist*count)));
    return [start,Math.min(count,Math.max(start+1,Math.ceil(high/nyquist*count)))];
  });
}
export interface AudioHistory { baseline:number; cooldown:number }
/** Log-frequency aggregation, time-based envelopes, RMS and an onset envelope. No allocations. */
export function analyzeAudio(frequency:Uint8Array,wave:Uint8Array,bands:[number,number][],frame:VisualizerAudioFrame,history:AudioHistory,delta:number):void {
  const dt=clampNumber(delta,0,.1,1/60);
  for(let i=0;i<16;i++){
    const [start,end]=bands[i];let sum=0,loud=0;
    for(let j=start;j<end;j++){const v=(frequency[j]??0)/255;sum+=v;if(v>loud)loud=v;}
    // Wide treble bands used to average a hit down to silence. Keep the mean,
    // and let the loudest bin in the band reach that column.
    const target=Math.min(1,sum/Math.max(1,end-start)*.35+loud*.7),blend=1-Math.exp(-dt/(target > frame.bins[i] ? .035 : .22));
    frame.bins[i]+=(target-frame.bins[i])*blend;
    frame.peaks[i]=Math.max(frame.bins[i],frame.peaks[i]-dt*.28);
    let total=0;const a=Math.floor(i*wave.length/16),b=Math.max(a+1,Math.floor((i+1)*wave.length/16));
    for(let j=a;j<b;j++)total+=((wave[j]??128)-128)/128;
    frame.waveform[i]=total/(b-a);
  }
  let energy=0;for(let i=0;i<wave.length;i++){const v=(wave[i]-128)/128;energy+=v*v;}
  const level=Math.min(1,Math.sqrt(energy/Math.max(1,wave.length))*2.2);
  frame.amplitude+=(level-frame.amplitude)*(1-Math.exp(-dt/.08));
  frame.bass=(frame.bins[0]+frame.bins[1]+frame.bins[2]+frame.bins[3]+frame.bins[4])/5;
  frame.mid=(frame.bins[5]+frame.bins[6]+frame.bins[7]+frame.bins[8]+frame.bins[9]+frame.bins[10])/6;
  frame.treble=(frame.bins[11]+frame.bins[12]+frame.bins[13]+frame.bins[14]+frame.bins[15])/5;
  history.cooldown=Math.max(0,history.cooldown-dt);
  const onset=frame.bass>Math.max(.12,history.baseline*1.35+.025)&&history.cooldown===0;
  history.baseline+=(frame.bass-history.baseline)*(1-Math.exp(-dt/.7));
  frame.beat=onset?1:frame.beat*Math.exp(-dt*7);
  if(onset)history.cooldown=.22;
}
