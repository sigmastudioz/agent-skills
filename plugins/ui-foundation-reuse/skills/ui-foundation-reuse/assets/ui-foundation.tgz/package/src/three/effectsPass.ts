import { createRenderState } from './captureState.js';
import { claimComposer } from './composerOwner.js';
import { captureTargetSize } from './renderTargetOps.js';
import { postEffectsIdle, postEffectsShape, type PostEffectsConfig } from './effectsOps.js';

/**
 * One composer for the Canvas: scene → ambient occlusion → depth of field → bloom → output.
 * Order matters: occlusion belongs to the lit scene, blur comes from the lens, glow from the
 * sensor, and the output pass applies the renderer's tone curve and colour space last.
 */
export function createEffectsPass(three: any, addons: any, renderer: any, scene: any, camera: any, initial: PostEffectsConfig) {
  const release = claimComposer(renderer, 'PostEffects');
  const preserve = createRenderState(three), size = new three.Vector2();
  const shape = postEffectsShape(initial);
  const passes: any[] = [];
  let target: any, composer: any, renderPass: any, ao: any, dof: any, bloom: any, disposed = false, config = initial;
  const dispose = () => {
    if (disposed) return; disposed = true; release();
    passes.forEach(pass => pass.dispose?.());
    // Three r160's UnrealBloomPass leaves this owned material out of dispose().
    bloom?.materialHighPassFilter?.dispose();
    if (composer) composer.dispose(); else target?.dispose();
  };
  try {
    target = new three.WebGLRenderTarget(1, 1, { type: three.HalfFloatType });
    composer = new addons.EffectComposer(renderer, target); composer.setPixelRatio(1);
    const add = (pass: any) => { passes.push(pass); composer.addPass(pass); return pass; };
    renderPass = add(new addons.RenderPass(scene, camera));
    if (initial.ambientOcclusion) ao = add(new addons.GTAOPass(scene, camera, 1, 1));
    if (initial.depthOfField) dof = add(new addons.BokehPass(scene, camera, { focus: 1, aperture: 0, maxblur: 0 }));
    if (initial.bloom) bloom = add(new addons.UnrealBloomPass(new three.Vector2(1, 1), 0, 0, 1));
    add(new addons.OutputPass());
    const configure = (next: PostEffectsConfig): boolean => {
      if (postEffectsShape(next) !== shape) return false;       // the caller rebuilds the chain
      config = next;
      if (ao && next.ambientOcclusion) { ao.updateGtaoMaterial({ radius: next.ambientOcclusion.radius }); ao.blendIntensity = next.ambientOcclusion.intensity; }
      if (dof && next.depthOfField) {
        dof.uniforms.focus.value = next.depthOfField.focus;
        dof.uniforms.aperture.value = next.depthOfField.aperture;
        dof.uniforms.maxblur.value = next.depthOfField.maxBlur;
      }
      if (bloom && next.bloom) { bloom.strength = next.bloom.strength; bloom.radius = next.bloom.radius; bloom.threshold = next.bloom.threshold; }
      return true;
    };
    configure(initial);
    let lastWidth = 0, lastHeight = 0;
    return { configure, dispose, shape,
      render(nextScene = scene, nextCamera = camera, delta = 0) {
        if (disposed) return;
        preserve(renderer, () => {
          if (postEffectsIdle(config)) { renderer.render(nextScene, nextCamera); return; }
          renderer.getDrawingBufferSize(size);
          const [width, height] = captureTargetSize(size.x, size.y, config.resolution);
          if (width !== lastWidth || height !== lastHeight) { composer.setSize(width, height); lastWidth = width; lastHeight = height; }
          for (const pass of [renderPass, ao, dof]) if (pass) { pass.scene = nextScene; pass.camera = nextCamera; }
          composer.render(delta);
        });
      },
    };
  } catch (error) { dispose(); throw error; }
}
