/** Stylized procedural head surface shared by neural and particle artwork. Not anatomical data. */
type Vec3 = readonly [number, number, number];
const mix = (a: number, b: number, t: number) => a + (b - a) * t;

// y, back, front, half-width. Front faces +X; Z is the left/right axis.
const PROFILE = [
  [-1.35, -0.19, 0.38, 0.29], [-1.08, -0.27, 0.4, 0.31], [-0.86, -0.38, 0.73, 0.36],
  [-0.72, -0.67, 0.81, 0.43], [-0.62, -0.84, 0.78, 0.48], [-0.53, -0.93, 0.91, 0.51],
  [-0.43, -1.01, 0.82, 0.54], [-0.29, -1.07, 1.1, 0.58], [-0.18, -1.09, 1.04, 0.61],
  [-0.02, -1.11, 0.86, 0.66], [0.13, -1.1, 0.89, 0.7], [0.38, -1.02, 0.83, 0.75],
  [0.65, -0.88, 0.64, 0.72], [0.88, -0.65, 0.4, 0.59], [1.04, -0.42, 0.12, 0.37], [1.12, -0.16, -0.15, 0.005],
];
export function headPoint(t: number, angle: number): Vec3 {
  const p = Math.max(0, Math.min(1, t)) * (PROFILE.length - 1), i = Math.min(PROFILE.length - 2, Math.floor(p));
  const f = p - i, a = PROFILE[i], b = PROFILE[i + 1];
  const smooth = (axis: number) => {
    const p0 = PROFILE[Math.max(0, i - 1)][axis], p1 = a[axis], p2 = b[axis], p3 = PROFILE[Math.min(PROFILE.length - 1, i + 2)][axis];
    return 0.5 * ((2 * p1) + (-p0 + p2) * f + (2 * p0 - 5 * p1 + 4 * p2 - p3) * f * f + (-p0 + 3 * p1 - 3 * p2 + p3) * f * f * f);
  };
  const y = mix(a[0], b[0], f);
  let back = smooth(1), front = smooth(2), width = Math.max(0, smooth(3));
  if (y > .13) {
    const radius = Math.sqrt(Math.max(0, 1 - Math.pow(y - .12, 2)));
    const blend = Math.min(1, (y - .13) / .12);
    back = mix(back, -.15 - radius, blend); front = mix(front, -.15 + radius, blend); width = mix(width, radius * .75, blend);
  }
  // Front profile narrows toward the nose; broad back of skull stays rounded.
  const c = Math.cos(angle), s = Math.sin(angle);
  return [mix(back, front, (c + 1) / 2), y, s * width * (c > 0.4 && y < 0.15 ? 0.7 : 1)];
}

