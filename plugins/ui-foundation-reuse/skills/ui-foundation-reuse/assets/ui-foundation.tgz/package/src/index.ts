// Root barrel. Prefer subpath imports for the smallest bundles, e.g.:
//   import { Gradient }    from '@sigmastudioz/ui-foundation/gradient';
//   import { LiquidGlass } from '@sigmastudioz/ui-foundation/liquid-glass';
// This root re-export exists for discoverability and is fully tree-shakeable.
// Note: /three is NOT re-exported here so the root entry never references the
// optional three peers even lazily — import it from its subpath.

export * from './core/index.js';
export * from './gradient/index.js';
export * from './liquid-metal/index.js';
export * from './liquid-glass/index.js';
export * from './mouse-parallax/index.js';
export * from './scroll-3d/index.js';
export * from './scroll-scrub/index.js';
export * from './particles/index.js';
export * from './warp/index.js';
export * from './scroll-reveal/index.js';
export * from './grain/index.js';
export * from './visualizer/index.js';
export * from './force-2d/index.js';
export * from './iridescence/index.js';
export * from './fluid-field/index.js';
export * from './image-transition/index.js';
export * from './magnetic/index.js';
export * from './kinetic-text/index.js';
export * from './geometric/index.js';
export * from './image-filter/index.js';
export * from './heatmap/index.js';
export * from './fluted-glass/index.js';
export * from './presets/index.js';
export * from './layout-morph/index.js';
export * from './object-stack/index.js';
export * from './recursive-viewport/index.js';
export * from './media-strip/index.js';
export * from './scene-panel/index.js';
export * from './media-disclosure/index.js';
export * from './motion-video/index.js';
export * from './adaptive-surface/index.js';
export * from './media-carousel/index.js';
export * from './camera-journey/index.js';
export * from './neural-field/index.js';
export * from './cymatics/index.js';
export * from './square-tile-reveal/index.js';
export * from './particle-form/index.js';
export * from './luminous-trails/index.js';
export * from './glyph-curtain/index.js';
export * from './scratch-reveal/index.js';
export * from './cursor-video/index.js';
export * from './aperture-reveal/index.js';
export * from './text-portrait/index.js';
export * from './foil-surface/index.js';
export * from './spectral-ribbon/index.js';
export * from './tilt-shift/index.js';
export * from './light-glow/index.js';
export * from './weather/index.js';
export * from './paper-motion/index.js';

export * from './particle-nebula/index.js';
export * from './plasma-vortex/index.js';

export * from './spatial-canvas/index.js';
export * from './floating-objects/index.js';
export * from './crt-surface/index.js';
export * from './disc-carousel/index.js';

export * from './posterize/index.js';
export * from './stipple-duotone/index.js';
export * from './glyph-grid/index.js';
export * from './thermal-noise/index.js';
export * from './phosphor-ghost/index.js';

export * from './liquid-screen/index.js';
export * from './xerox-collage/index.js';
export * from './raster-lines/index.js';
export * from './solarized-streak/index.js';
export * from './teletext-pattern/index.js';
