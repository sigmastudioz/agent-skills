/** Image-space distortions, measured in CSS pixels and normalized short-side units.
 * All samples use the host's cover transform, alpha and clamp-to-edge policy. */
export const DISTORTION_FILTER_FUNCTIONS = `
vec2 distortionPoint(vec2 uv) {
  return (uv - uCenter) * uResolution / min(uResolution.x, uResolution.y);
}
vec2 distortionUv(vec2 point) {
  return uCenter + point * min(uResolution.x, uResolution.y) / uResolution;
}
float localInfluence(vec2 p) {
  return 1. - smoothstep(0., uRadius, length(p));
}
vec4 distortionFilter(vec4 original) {
  vec2 p = distortionPoint(vUv);
  // Nonzero phase zero gives a useful static treatment under reduced motion.
  float pulse = .85 + .15 * cos(uTime * 1.3);
  float amount = uDistortion * pulse;
  if (uKind < 14.5) {
    float influence = localInfluence(p);
    vec2 uv = distortionUv(p * (1. - amount * .8 * influence));
    vec2 fringe = p * influence * uDistortion * uOffset * 5. / uResolution;
    vec4 source = sampleImage(uv);
    // Weight transparent samples before unpremultiplying: no colored alpha fringes.
    vec4 red = sampleImage(uv + fringe), blue = sampleImage(uv - fringe);
    float alpha = (red.a + source.a + blue.a) / 3.;
    vec3 rgb = vec3(red.r * red.a, source.g * source.a, blue.b * blue.a);
    return vec4(rgb / max(alpha, .00001), alpha);
  }
  if (uKind < 15.5) {
    vec2 warped = p;
    for (int i = 0; i < 5; i++) {
      float n = float(i);
      vec2 orbit = vec2(sin(n * 2.4 + uTime * .7), cos(n * 1.9 + uTime * .6)) * uRadius * .55;
      vec2 delta = p - orbit;
      float falloff = 1. - smoothstep(0., uRadius * .65, length(delta));
      vec2 swirl = vec2(-delta.y, delta.x);
      warped += (delta * .65 + swirl * sin(n + uTime) * .7) * falloff * amount;
    }
    return sampleImage(distortionUv(warped));
  }
  if (uKind < 16.5) {
    // Bands run perpendicular to the displacement axis; hash stays stable at rest.
    float span = dot(abs(uDirection), uResolution);
    float strip = floor(dot(vUv * uResolution, uDirection) / span * uSlices);
    float shift = sin(strip * 12.9898 + 4.1 + uTime) * amount * .22;
    return sampleImage(vUv + uDirection * shift * min(uResolution.x, uResolution.y) / uResolution);
  }
  if (uKind < 17.5) {
    vec2 axis = uDirection;
    vec2 side = vec2(-axis.y, axis.x);
    float along = dot(p, axis), across = dot(p, side);
    float band = 1. - smoothstep(uRadius * .75, uRadius, abs(across));
    float reach = uRadius * (1. + .2 * sin(uTime));
    float region = smoothstep(0., .015, along) * (1. - smoothstep(reach * .85, reach, along));
    // Repeat the source line at full strength, smoothly returning at the boundary.
    return sampleImage(distortionUv(p - axis * along * amount * band * region));
  }
  float influence = localInfluence(p);
  float rotation = amount * 3.5 * influence;
  mat2 turn = mat2(cos(rotation), -sin(rotation), sin(rotation), cos(rotation));
  vec2 bent = turn * p - uDirection * amount * influence * uRadius * .5;
  return sampleImage(distortionUv(bent));
}`;
