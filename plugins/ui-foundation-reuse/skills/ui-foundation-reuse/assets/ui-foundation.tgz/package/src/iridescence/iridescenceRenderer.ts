import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import type { ResolvedIridescenceConfig } from './types.js';
import { IRIDESCENCE_FRAGMENT, IRIDESCENCE_VERTEX } from './iridescenceShader.js';

export interface IridescenceRenderer extends WebGLRendererLike {
  render(config: ResolvedIridescenceConfig, time: number, pointer: [number, number]): void;
}

function rgb(hex: string): [number, number, number] {
  const text = hex.length === 4 ? hex.slice(1).split('').map(c => c + c).join('') : hex.slice(1);
  const n = parseInt(text, 16);
  return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255];
}

export function createIridescenceRenderer(canvas: HTMLCanvasElement): IridescenceRenderer | null {
  const gl = canvas.getContext('webgl', { alpha: false, antialias: false });
  if (!gl) return null;
  const shaders: WebGLShader[] = [];
  let program: WebGLProgram | null = null;
  let buffer: WebGLBuffer | null = null;
  const dispose = () => {
    if (buffer) gl.deleteBuffer(buffer);
    if (program) gl.deleteProgram(program);
    shaders.forEach(shader => gl.deleteShader(shader));
  };
  try {
    for (const [type, source] of [[gl.VERTEX_SHADER, IRIDESCENCE_VERTEX], [gl.FRAGMENT_SHADER, IRIDESCENCE_FRAGMENT]] as const) {
      const shader = gl.createShader(type);
      if (!shader) throw new Error('Shader allocation failed');
      shaders.push(shader);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error('Shader compilation failed');
    }
    program = gl.createProgram();
    if (!program) throw new Error('Program allocation failed');
    shaders.forEach(shader => gl.attachShader(program!, shader));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error('Program linking failed');
    buffer = gl.createBuffer();
    if (!buffer) throw new Error('Buffer allocation failed');
    gl.useProgram(program);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const position = gl.getAttribLocation(program, 'aPosition');
    gl.enableVertexAttribArray(position);
    gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
    const uniforms = Object.fromEntries([
      'uResolution', 'uPointer', 'uTime', 'uScale', 'uRotation', 'uIntensity', 'uRoughness', 'uBase', 'uAccent',
    ].map(name => [name, gl.getUniformLocation(program!, name)]));
    return {
      resize(width, height, dpr) {
        canvas.width = Math.max(1, Math.round(width * dpr));
        canvas.height = Math.max(1, Math.round(height * dpr));
        gl.viewport(0, 0, canvas.width, canvas.height);
      },
      render(config, time, pointer) {
        gl.useProgram(program);
        gl.uniform2f(uniforms.uResolution, canvas.width, canvas.height);
        gl.uniform2f(uniforms.uPointer, ...pointer);
        gl.uniform1f(uniforms.uTime, time * config.speed);
        gl.uniform1f(uniforms.uScale, config.scale);
        gl.uniform1f(uniforms.uRotation, config.rotation * Math.PI / 180);
        gl.uniform1f(uniforms.uIntensity, config.intensity);
        gl.uniform1f(uniforms.uRoughness, config.roughness);
        gl.uniform3f(uniforms.uBase, ...rgb(config.baseColor));
        gl.uniform3f(uniforms.uAccent, ...rgb(config.accentColor));
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      },
      dispose,
    };
  } catch {
    dispose();
    return null;
  }
}
