export const FLUID_SIMULATION = `precision highp float;
varying vec2 vUv; uniform sampler2D uPrevious;
uniform vec2 uPointer,uLastPointer,uSize; uniform float uTime,uDelta,uActive,uPersistence;
vec2 field(vec2 p){
 float a=sin(p.x*5.0+sin(p.y*4.0+uTime*.23));
 float b=cos(p.y*5.0+sin(p.x*3.0-uTime*.19));
 return vec2(b,-a)*.13+vec2(sin(p.y*13.0+uTime*.3),cos(p.x*11.0-uTime*.2))*.018;
}
void main(){
 vec2 aspect=vec2(uSize.x/uSize.y,1.0),p=vUv*aspect;
 vec2 d=(vUv-uPointer)*aspect;
 vec2 swirl=vec2(-d.y,d.x)*exp(-dot(d,d)*18.0)*uActive*3.0;
 vec2 previous=vUv-(field(p)+swirl)/aspect*uDelta;
 vec3 dye=texture2D(uPrevious,clamp(previous,.001,.999)).rgb*pow(uPersistence,uDelta*60.0);
 vec2 segment=(uPointer-uLastPointer)*aspect;
 float along=clamp(dot((vUv-uLastPointer)*aspect,segment)/max(dot(segment,segment),.00001),0.0,1.0);
 float stroke=exp(-pow(length((vUv-mix(uLastPointer,uPointer,along))*aspect)*28.0,2.0))*uActive;
 float ribbon=sin(p.x*4.0+sin(p.y*5.0-uTime*.18)*1.8+sin(p.x*3.0+p.y*2.0+uTime*.12));
 float source=exp(-abs(ribbon)*38.0)*(.5+.5*sin(p.y*3.0+uTime*.3));
 dye+=vec3(source*.75,source*.28,source*.1)*uDelta*.85;
 dye+=vec3(stroke*.35,stroke*.7,stroke)*uDelta*3.5;
 gl_FragColor=vec4(clamp(dye,0.0,1.0),1.0);
}`;
export const FLUID_DISPLAY = `precision highp float;
varying vec2 vUv; uniform sampler2D uDye;
uniform vec2 uSize; uniform vec3 uColor,uAccent; uniform float uTime;
void main(){
 vec2 p=(vUv-.5)*vec2(uSize.x/uSize.y,1.0);
 vec2 q=p;
 for(int i=0;i<3;i++){float f=float(i)+1.0;q+=vec2(sin(q.y*3.0*f+uTime*.12),cos(q.x*3.0*f-uTime*.1))*.22/f;}
 float folds=.5+.5*sin(q.x*8.0+q.y*4.0);
 float veins=pow(.5+.5*sin(q.y*35.0+q.x*22.0),18.0);
 vec3 dye=texture2D(uDye,vUv).rgb;
 float density=dot(dye,vec3(.4,.8,.7));
 vec3 col=mix(uColor*.075,uColor,folds*.65+density*.3);
 col=mix(col,uAccent,clamp(pow(folds,7.0)*.7+dye.b*.85,0.0,1.0));
 col+=uAccent*veins*.09+uAccent*density*.15;
 col*=1.0-.4*dot(vUv-.5,vUv-.5);
 gl_FragColor=vec4(col,1.0);
}`;
