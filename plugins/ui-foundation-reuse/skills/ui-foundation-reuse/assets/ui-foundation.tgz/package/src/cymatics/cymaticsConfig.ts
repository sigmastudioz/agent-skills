import { clampNumber } from '../core/numberOps.js';
import type { CymaticsConfig, CymaticsProps } from './types.js';

export function resolveCymaticsConfig(props: CymaticsProps = {}): CymaticsConfig {
  return {
    frequency: clampNumber(props.frequency, 20, 20000, 824), amplitude: clampNumber(props.amplitude, 0, 1, .65),
    shape: props.shape === 'square' ? 'square' : 'circle', material: props.material === 'liquid' ? 'liquid' : 'sand',
    fundamental: clampNumber(props.fundamental, 20, 500, 80), tension: clampNumber(props.tension, .25, 4, 1),
    size: clampNumber(props.size, .5, 2, 1), stiffness: clampNumber(props.stiffness, 0, 1, .6),
    resonance: clampNumber(props.resonance, 2, 80, 24), sensitivity: clampNumber(props.sensitivity, 0, 8, 1),
    settle: clampNumber(props.settle, .1, 3, 1), damping: clampNumber(props.damping, 1, 20, 6),
    count: Math.round(clampNumber(props.count, 2000, 80000, 42000)), seed: Math.round(clampNumber(props.seed, 0, 2147483647, 17)),
    grainSize: clampNumber(props.grainSize, .5, 3, 1.15), color: /^#[0-9a-f]{6}$/i.test(props.color ?? '') ? props.color! : '#e5d3a9',
  };
}
