/** Seeded still-image glitches. Every value is a function of phase, seed and position. */
export const GLITCH_FILTER_FUNCTIONS = `
float glitchHash(vec2 p) { return retroHash(p + uSeed * vec2(.731, 1.37)); }
float glitchBurst() {
  if (uInterval <= 0.) return 1.;
  float cycle = floor(uTime / uInterval);
  float local = uTime - cycle * uInterval;
  // Bursts close each cycle, so phase zero (and a reduced-motion frame) is clean.
  float span = min(uInterval, .18 + .32 * glitchHash(vec2(cycle, 3.)));
  return step(uInterval - span, local);
}
vec4 glitchFilter(vec4 original, vec2 point) {
  float amount = uDistortion * glitchBurst();
  if (amount <= 0.) return original;
  float frame = floor(uTime * 10.);
  if (uMode < .5) {
    // Datamosh: stuck macroblocks keep drifting along their motion vector.
    float block = max(8., uCell * 2.);
    vec2 cell = floor(point / block);
    float mosh = step(1. - amount * .7, glitchHash(cell + floor(uTime * 2.)));
    vec2 vector = vec2(glitchHash(cell + 11.), glitchHash(cell + 23.)) * 2. - 1.;
    float drift = fract(uTime * .5 + glitchHash(cell + 5.));
    vec2 uv = vUv + vector * block * (1. + drift * 6. * amount) / uResolution * mosh;
    vec4 moshed = sampleImage(uv);
    vec4 macro = sampleImage((cell + .5) * block / uResolution + vector * block * amount / uResolution);
    return vec4(mix(moshed.rgb, macro.rgb, mosh * .35 * amount), original.a);
  }
  if (uMode < 1.5) {
    // RGB split with horizontal tearing of a few seeded rows.
    vec2 shift = uOffset * amount * (1.5 + glitchHash(vec2(frame, 1.)) * 2. - 1.);
    float row = floor(point.y / max(2., uCell));
    float tear = step(1. - amount * .25, glitchHash(vec2(row, frame)));
    vec2 uv = vUv + vec2(tear * (glitchHash(vec2(row, frame + 7.)) - .5) * amount * .15, 0.);
    vec4 red = sampleImage(uv + shift), green = sampleImage(uv), blue = sampleImage(uv - shift);
    return vec4(red.r, green.g, blue.b, max((red.a + green.a + blue.a) / 3., original.a));
  }
  // Block shift: seeded horizontal bands jump sideways with a small channel split.
  float row = floor(point.y / (uResolution.y / uSlices));
  float active = step(1. - amount * .6, glitchHash(vec2(row, frame)));
  vec2 uv = vUv + vec2((glitchHash(vec2(row, frame + 13.)) - .5) * amount * .35 * active, 0.);
  vec2 split = vec2(active * amount * 4. / uResolution.x, 0.);
  return vec4(sampleImage(uv + split).r, sampleImage(uv).g, sampleImage(uv - split).b, original.a);
}
`;
