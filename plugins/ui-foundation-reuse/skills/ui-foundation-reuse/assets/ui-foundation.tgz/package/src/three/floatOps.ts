import { clampNumber, finiteNumberOr } from '../core/numberOps.js';
import type { FloatProps } from './Float.js';

export interface FloatConfig {
  speed: number;
  floatIntensity: number;
  rotationIntensity: number;
  floatingRange: [number, number];
  phase: number;
}
export function resolveFloatConfig(props: FloatProps = {}): FloatConfig {
  const low = clampNumber(props.floatingRange?.[0], -100, 100, -.1);
  const high = clampNumber(props.floatingRange?.[1], -100, 100, .1);
  return {
    speed: clampNumber(props.speed, 0, 10, 1),
    floatIntensity: clampNumber(props.floatIntensity, 0, 10, 1),
    rotationIntensity: clampNumber(props.rotationIntensity, 0, 10, 1),
    floatingRange: [Math.min(low, high), Math.max(low, high)],
    phase: finiteNumberOr(props.phase, 0) % (Math.PI * 2),
  };
}
/** Deterministic hover at an accumulated phase: Y offset and XYZ rotations, relative to an outer group. */
export function sampleFloatMotion(time: number, config: FloatConfig): [number, number, number, number] {
  const t = finiteNumberOr(time, 0) + config.phase;
  const [low, high] = config.floatingRange;
  return [
    (low + (Math.sin(t) * .5 + .5) * (high - low)) * config.floatIntensity,
    Math.sin(t * .7) * .08 * config.rotationIntensity,
    Math.sin(t * .5) * .12 * config.rotationIntensity,
    Math.sin(t * .9) * .06 * config.rotationIntensity,
  ];
}
