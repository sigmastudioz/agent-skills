'use client';
import { useEffect, useRef, useState } from 'react';
import { useEffectsSettings } from './EffectsProvider.js';
import { useRafLoop } from './useRafLoop.js';

import { createQualityHistory, sampleQuality } from './qualityOps.js';
export { createQualityHistory, sampleQuality } from './qualityOps.js';
export type { QualityHistory } from './qualityOps.js';
/** Use the returned multiplier for resolution or detail budgets. Sampling stops when inactive. */
export function useAdaptiveQuality(active = true): number {
  const { maxFps } = useEffectsSettings();
  const history = useRef(createQualityHistory());
  const [scale, setScale] = useState(1);
  useEffect(() => { history.current = { ...createQualityHistory(), scale: history.current.scale }; }, [active, maxFps]);
  useRafLoop(delta => {
    const previous = history.current.scale;
    const next = sampleQuality(history.current, delta, 1000 / maxFps);
    if (next !== previous) setScale(next);
  }, active);
  return scale;
}
