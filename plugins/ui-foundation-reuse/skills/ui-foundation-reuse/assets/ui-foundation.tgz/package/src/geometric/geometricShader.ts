export const GEOMETRIC_VERTEX = `
attribute vec2 aPosition;
varying vec2 vUv;
void main() {
  vUv = aPosition * 0.5 + 0.5;
  gl_Position = vec4(aPosition, 0.0, 1.0);
}
`;

export const GEOMETRIC_FRAGMENT = `
precision mediump float;
varying vec2 vUv;
uniform vec2 uResolution;
uniform vec2 uPointer;
uniform vec2 uTexel;
uniform float uPull;
uniform float uTime;
uniform float uLevels;
uniform float uContour;
uniform float uFlow;
uniform float uCurtain;
uniform float uDither;
uniform float uMemory;
uniform float uGrain;
uniform float uSource;
uniform float uInkOpacity;
uniform vec3 uBackground;
uniform vec3 uInk;
uniform vec3 uAccent;
uniform sampler2D uSourceTex;

float luma(vec3 color) { return dot(color, vec3(0.2126, 0.7152, 0.0722)); }

vec2 warp(vec2 uv) {
  vec2 delta = uPointer - uv;
  float dist = length(delta) + 0.001;
  float pull = exp(-dist * 3.2) * 0.18 * uPull;
  return clamp(uv + delta / dist * pull, 0.0, 1.0);
}

float lumAt(vec2 uv) { return luma(texture2D(uSourceTex, clamp(uv, 0.001, 0.999)).rgb); }

float edgeAt(vec2 uv) {
  float dx = lumAt(uv + vec2(uTexel.x * 2.0, 0.0)) - lumAt(uv - vec2(uTexel.x * 2.0, 0.0));
  float dy = lumAt(uv + vec2(0.0, uTexel.y * 2.0)) - lumAt(uv - vec2(0.0, uTexel.y * 2.0));
  return clamp(length(vec2(dx, dy)) * 2.4, 0.0, 1.0);
}

float bayer4(vec2 p) {
  float x = mod(floor(p.x), 4.0);
  float y = mod(floor(p.y), 4.0);
  float v = 0.0;
  if (y < 0.5) v = x < 0.5 ? 0.0 : x < 1.5 ? 8.0 : x < 2.5 ? 2.0 : 10.0;
  else if (y < 1.5) v = x < 0.5 ? 12.0 : x < 1.5 ? 4.0 : x < 2.5 ? 14.0 : 6.0;
  else if (y < 2.5) v = x < 0.5 ? 3.0 : x < 1.5 ? 11.0 : x < 2.5 ? 1.0 : 9.0;
  else v = x < 0.5 ? 15.0 : x < 1.5 ? 7.0 : x < 2.5 ? 13.0 : 5.0;
  return v / 16.0;
}

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

void main() {
  vec2 uv = warp(vUv);
  vec3 src = texture2D(uSourceTex, uv).rgb;
  float lum = luma(src);
  float edge = edgeAt(uv);
  float bands = abs(fract(lum * uLevels + uTime * 0.12) - 0.5);
  float majorBands = abs(fract(lum * max(uLevels / 3.0, 2.0) + uTime * 0.07) - 0.5);
  float fine = exp(-bands * bands * 2200.0);
  float major = exp(-majorBands * majorBands * 520.0);

  vec2 gradient = vec2(
    lumAt(uv + vec2(uTexel.x, 0.0)) - lumAt(uv - vec2(uTexel.x, 0.0)),
    lumAt(uv + vec2(0.0, uTexel.y)) - lumAt(uv - vec2(0.0, uTexel.y))
  );
  vec2 tangent = normalize(vec2(-gradient.y, gradient.x) + 1e-4);
  float flow = 0.0;
  for (int i = 1; i <= 5; i++) {
    float span = float(i) / 5.0;
    float sampleLum = lumAt(uv + tangent * span * 0.05);
    float band = abs(fract(sampleLum * uLevels + uTime * 0.2 + span) - 0.5);
    flow = max(flow, 1.0 - smoothstep(0.0, 0.055, band));
  }

  float best = 0.0;
  float bestSpan = 1.0;
  vec3 curtainColor = src;
  for (int i = 0; i < 12; i++) {
    float span = float(i) / 12.0;
    vec2 probe = vec2(uv.x, clamp(uv.y + span * 0.42, 0.0, 1.0));
    float probeEdge = edgeAt(probe);
    if (probeEdge > best) {
      best = probeEdge;
      bestSpan = span;
      curtainColor = texture2D(uSourceTex, probe).rgb;
    }
  }
  float curtain = best * exp(-bestSpan * 3.2);

  float pitch = max(uResolution.y / 120.0, 6.0);
  vec2 cell = floor(gl_FragCoord.xy / pitch);
  float cellLum = lumAt((cell + 0.5) * pitch / uResolution);
  float echo = lumAt(uv - vec2(0.055, 0.0));
  float binary = step(0.46, cellLum);
  vec3 memory = mix(uBackground, mix(uAccent, src, echo), binary);

  float inkOn = step(bayer4(gl_FragCoord.xy), clamp(lum * 1.05 + edge * 0.4, 0.0, 1.0));
  vec3 dithered = mix(uBackground, uInk, inkOn);

  vec3 voidColor = mix(uBackground * 0.62, uBackground + uAccent * 0.07, smoothstep(0.05, 0.8, uv.y));
  vec3 color = mix(voidColor, src, clamp(uSource * (0.42 + lum * 0.7), 0.0, 1.0));
  color += uAccent * pow(lum, 1.7) * uSource * 0.18;
  color += uAccent * (fine * 0.45 + major * 0.9) * uContour * uInkOpacity;
  color = mix(color, uInk, clamp(major * uContour * uInkOpacity, 0.0, 0.82));
  color += uInk * fine * uContour * uInkOpacity * 0.55;
  color += uAccent * flow * edge * uFlow * uInkOpacity;
  color = mix(color, curtainColor, clamp(curtain * uCurtain, 0.0, 1.0));
  color += uAccent * pow(edge, 1.35) * 0.28 * (1.0 - uDither) * (1.0 - uMemory);
  color = mix(color, dithered, uDither);
  color = mix(color, memory, uMemory);
  color += (hash(gl_FragCoord.xy + fract(uTime) * 37.0) - 0.5) * uGrain * 0.12;
  float vignette = smoothstep(1.15, 0.22, length((vUv - 0.5) * vec2(1.2, 1.0)));
  color *= mix(0.42, 1.0, vignette);
  vec3 graded = color / (color + vec3(0.7)) * 1.32;
  color = mix(graded, color, max(uDither, uMemory));
  gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
`;
