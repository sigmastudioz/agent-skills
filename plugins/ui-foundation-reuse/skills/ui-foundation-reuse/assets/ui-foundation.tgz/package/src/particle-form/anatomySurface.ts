import { HEAD_MESH } from './headMeshData.js';
import { BRAIN_MESH } from './brainMeshData.js';

type Point = readonly [number, number, number];
interface SurfaceSample { position: Point; normal: Point }
const cache: Partial<Record<'head' | 'brain', Float32Array>> = {};

/** Decode only when geometry is requested, after WebGL has been acquired. */
function samplesFor(shape: 'head' | 'brain'): Float32Array {
  const existing = cache[shape];
  if (existing) return existing;
  const packed = shape === 'head' ? HEAD_MESH : BRAIN_MESH;
  const binary = atob(packed.samples), bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const view = new DataView(bytes.buffer), samples = new Float32Array(binary.length / 2);
  for (let i = 0; i < samples.length; i++) samples[i] = view.getInt16(i * 2, true) / 32767 * (i % 6 < 3 ? 1.5 : 1);
  return cache[shape] = samples;
}

/** Both reference meshes share angular coordinates, keeping neighboring particles
 * together through the morph. Bilinear sampling avoids a fixed point-count grid.
 */
export function sampleAnatomy(shape: 'head' | 'brain', u: number, v: number): SurfaceSample {
  const { width, height } = shape === 'head' ? HEAD_MESH : BRAIN_MESH;
  const samples = samplesFor(shape);
  const x = ((u % 1 + 1) % 1) * width, y = Math.max(0, Math.min(1, v)) * height;
  const col = Math.floor(x), row = Math.min(height - 1, Math.floor(y));
  const fx = x - col, fy = y - row;
  const offsets = [row * width + col, row * width + (col + 1) % width,
    (row + 1) * width + col, (row + 1) * width + (col + 1) % width];
  const weights = [(1 - fx) * (1 - fy), fx * (1 - fy), (1 - fx) * fy, fx * fy];
  const sample = (axis: number) => offsets.reduce((sum, offset, i) => sum + samples[offset * 6 + axis] * weights[i], 0);
  const normal = [sample(3), sample(4), sample(5)], length = Math.hypot(...normal);
  return { position: [sample(0), sample(1), sample(2)],
    normal: length > 1e-8 ? [normal[0] / length, normal[1] / length, normal[2] / length] : [0, 1, 0] };
}
