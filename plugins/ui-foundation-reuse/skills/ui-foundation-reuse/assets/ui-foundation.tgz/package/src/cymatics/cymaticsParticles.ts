import { CYMATICS_GRID } from './cymaticsModes.js';
import type { CymaticsConfig } from './types.js';

export interface CymaticsParticles { positions: Float32Array; velocity: Float32Array; grain: Float32Array; random: number }
export function createCymaticsParticles(count: number, seed: number, circle: boolean): CymaticsParticles {
  let state = seed | 0;
  const random = () => { state = Math.imul(state, 1664525) + 1013904223 | 0; return (state >>> 0) / 4294967296; };
  const positions = new Float32Array(count * 2), grain = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    const a = random() * Math.PI * 2, r = Math.sqrt(random()) * .987;
    positions[i * 2] = circle ? Math.cos(a) * r : (random() * 2 - 1) * .987;
    positions[i * 2 + 1] = circle ? Math.sin(a) * r : (random() * 2 - 1) * .987;
    grain[i] = random();
  }
  return { positions, grain, velocity: new Float32Array(count * 2), random: state };
}

/** Overdamped grain transport toward low-displacement regions of the modal field. */
export function stepCymaticsParticles(particles: CymaticsParticles, field: Float32Array, gradient: Float32Array, config: CymaticsConfig, amplitude: number, delta: number): void {
  const dt = Math.max(0, Math.min(1 / 30, Number.isFinite(delta) ? delta : 0));
  if (dt === 0 || amplitude < .0001) return;
  const { positions: p, velocity: v } = particles, scale = (CYMATICS_GRID - 1) / 2;
  const drag = Math.exp(-config.damping * dt), force = config.settle * 9 * amplitude, limit = .9;
  for (let i = 0; i < p.length; i += 2) {
    const x = Math.max(0, Math.min(CYMATICS_GRID - 1.001, (p[i] + 1) * scale));
    const y = Math.max(0, Math.min(CYMATICS_GRID - 1.001, (p[i + 1] + 1) * scale));
    const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
    const index = (iy * CYMATICS_GRID + ix) * 2;
    const stride = CYMATICS_GRID * 2;
    const ax = gradient[index], bx = gradient[index + 2], cx = gradient[index + stride], dx = gradient[index + stride + 2];
    const ay = gradient[index + 1], by = gradient[index + 3], cy = gradient[index + stride + 1], dy = gradient[index + stride + 3];
    const gx = (ax + (bx - ax) * fx) * (1 - fy) + (cx + (dx - cx) * fx) * fy;
    const gy = (ay + (by - ay) * fx) * (1 - fy) + (cy + (dy - cy) * fx) * fy;
    const cell = index / 2, a = field[cell], b = field[cell + 1], c = field[cell + CYMATICS_GRID], d = field[cell + CYMATICS_GRID + 1];
    const energy = (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy;
    const target = .001 + particles.grain[i / 2] * particles.grain[i / 2] * .045;
    const attraction = Math.max(-.3, Math.min(1, (energy - target) / Math.max(.01, energy)));
    const magnitude = Math.max(1, Math.hypot(gx, gy));
    v[i] = v[i] * drag - gx / magnitude * force * dt * attraction;
    v[i + 1] = v[i + 1] * drag - gy / magnitude * force * dt * attraction;
    const speed = Math.hypot(v[i], v[i + 1]), bound = speed > limit ? limit / speed : 1;
    v[i] *= bound; v[i + 1] *= bound;
    p[i] += v[i] * dt; p[i + 1] += v[i + 1] * dt;
    if (config.shape === 'circle') {
      const r = Math.hypot(p[i], p[i + 1]);
      if (r > .988) { p[i] *= .988 / r; p[i + 1] *= .988 / r; v[i] *= -.2; v[i + 1] *= -.2; }
    } else {
      if (Math.abs(p[i]) > .988) { p[i] = Math.sign(p[i]) * .988; v[i] *= -.2; }
      if (Math.abs(p[i + 1]) > .988) { p[i + 1] = Math.sign(p[i + 1]) * .988; v[i + 1] *= -.2; }
    }
  }
}
