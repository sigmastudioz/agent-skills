import { clampNumber } from '../core/numberOps.js';
import type { FlutedGlassProps, ResolvedFlutedGlassConfig } from './types.js';

/** All optical distances use CSS pixels, independent of canvas DPR. */
export function resolveFlutedGlassConfig(props: Partial<FlutedGlassProps> = {}): ResolvedFlutedGlassConfig {
  return {
    ribWidth: clampNumber(props.ribWidth, 2, 128, 9),
    refraction: clampNumber(props.refraction, 0, 1, 0.65),
    blur: clampNumber(props.blur, 0, 16, 1.5),
    chromaticSeparation: clampNumber(props.chromaticSeparation, 0, 12, 1),
    highlight: clampNumber(props.highlight, 0, 1, 0.25),
  };
}
