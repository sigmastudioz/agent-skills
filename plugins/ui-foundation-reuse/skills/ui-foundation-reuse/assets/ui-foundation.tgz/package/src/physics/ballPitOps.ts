import { hexToRgb01 } from '../gradient/gradientShader.js';

export const BALL_PIT_COLORS = ['#ff5db1', '#ffd23f', '#4fd6e6', '#39c07a', '#ff7a3d', '#9b5de5', '#2f6fe0', '#ff3b4e'];

/** Instance colors must be linear, matching Three's color-managed material inputs. */
export function ballPitLayout(count: number, bounds: number, colors: string[], rand: () => number) {
  const length = Number.isFinite(count) ? Math.max(0, Math.min(1000, Math.floor(count))) : 46;
  const palette = colors.length ? colors : BALL_PIT_COLORS;
  const colorBuffer = new Float32Array(length * 3);
  const instances = Array.from({ length }, (_, i) => {
    const rgb = hexToRgb01(palette[i % palette.length]);
    rgb.forEach((c, channel) => {
      colorBuffer[i * 3 + channel] = c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    });
    return {
      key: i,
      position: [(rand() - 0.5) * bounds, 4 + i * 0.4, (rand() - 0.5) * bounds] as [number, number, number],
    };
  });
  return { instances, colorBuffer };
}
