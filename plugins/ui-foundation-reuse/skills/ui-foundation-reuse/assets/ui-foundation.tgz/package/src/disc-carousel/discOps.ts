import { clampNumber } from '../core/numberOps.js';
export function resolveDiscIndex(index: number, length: number) {
  return Math.floor(clampNumber(index, 0, Math.max(0, length - 1), 0));
}
export function discPose(position: number, selected: number, depth = 0) {
  const distance = position - selected, amount = clampNumber(depth, 0, 1, 0);
  const flat = distance === 0 ? 1 : Math.max(.62, .8 - Math.abs(distance) * .04);
  return { x: distance * (68 + amount * 18), y: -distance * 25 * amount, scale: flat * (1 - amount) + clampNumber(.85 + distance * .24, .35, 1.4, .85) * amount,
    rotate: distance * 13, layer: 100 - Math.min(99, Math.abs(distance)), visible: Math.abs(distance) <= 2 };
}
export function discMask(hole: number) {
  const radius = clampNumber(hole, .04, .5, .12) * 100;
  return `radial-gradient(circle closest-side, transparent ${radius}%, #000 calc(${radius}% + 1px))`;
}
