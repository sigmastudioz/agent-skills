import { clampNumber } from '../core/numberOps.js';
import type { AperturePoint } from './types.js';

export function apertureImageRect(aspect: number, width: number, height: number): { x: number; y: number; width: number; height: number } {
  if (!Number.isFinite(aspect) || aspect <= 0) throw new RangeError('Image aspect must be finite and positive.');
  if (![width, height].every(value => Number.isFinite(value) && value > 0)) return { x: 0, y: 0, width: 0, height: 0 };
  const imageWidth = Math.max(width, height * aspect), imageHeight = imageWidth / aspect;
  return { x: (width - imageWidth) / 2, y: (height - imageHeight) / 2, width: imageWidth, height: imageHeight };
}

/** Registers a source-space polygon to the same centered cover crop as the image. */
export function apertureClipPath(points: readonly AperturePoint[], aspect: number, width: number, height: number): string {
  if (points.length < 3 || !points.every(point => point.length === 2 && point.every(Number.isFinite))) {
    throw new RangeError('An aperture needs at least three finite normalized points.');
  }
  const rect = apertureImageRect(aspect, width, height);
  return `polygon(${points.map(point => `${(rect.x + clampNumber(point[0], 0, 1, 0) * rect.width).toFixed(2)}px ${(rect.y + clampNumber(point[1], 0, 1, 0) * rect.height).toFixed(2)}px`).join(', ')})`;
}

export function spotlightMask(radius: number, feather: number, width: number, height: number): string {
  const pixels = Math.max(1, Math.min(width, height) * clampNumber(radius, .02, 1, .22));
  const hard = (1 - clampNumber(feather, 0, 1, .45)) * 100;
  return `radial-gradient(circle ${pixels.toFixed(2)}px at var(--aperture-x, 50%) var(--aperture-y, 50%), #000 ${hard}%, transparent 100%)`;
}
