import { createTexture } from '../core/fullscreenPass.js';
import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import { foilViewHeight } from './foilOps.js';
import type { FoilMesh } from './foilPhysics.js';
import { FOIL_VERTEX, FOIL_FRAGMENT } from './foilShader.js';
import type { FoilArtwork, ResolvedFoilConfig } from './types.js';

export interface FoilRenderer extends WebGLRendererLike {
  load(artwork: FoilArtwork, ready: (error?: string) => void): () => void;
  render(mesh: FoilMesh, config: ResolvedFoilConfig): void;
}

/** Owned mesh pass; no Three/Fiber dependency and no full-screen shader abstraction. */
export function createFoilRenderer(canvas: HTMLCanvasElement): FoilRenderer | null {
  const gl = canvas.getContext('webgl', { alpha: true, antialias: true, premultipliedAlpha: false });
  if (!gl) return null;
  const cleanups: (() => void)[] = [];
  let disposed = false, loaded = false, width = 1, height = 1;
  let cancel = () => {};
  const dispose = () => {
    if (disposed) return;
    disposed = true; cancel(); cleanups.splice(0).reverse().forEach(fn => fn());
  };
  try {
    const program = gl.createProgram(); if (!program) throw Error('Program allocation failed');
    cleanups.push(() => gl.deleteProgram(program));
    for (const [type, source] of [[gl.VERTEX_SHADER,FOIL_VERTEX],[gl.FRAGMENT_SHADER,FOIL_FRAGMENT]] as const) {
      const shader = gl.createShader(type); if (!shader) throw Error('Shader allocation failed');
      cleanups.push(() => gl.deleteShader(shader));
      gl.shaderSource(shader, source); gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(shader) || 'Shader compilation failed');
      gl.attachShader(program, shader);
    }
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw Error('Shader link failed');
    const vertices = gl.createBuffer(), elements = gl.createBuffer();
    if (vertices) cleanups.push(() => gl.deleteBuffer(vertices));
    if (elements) cleanups.push(() => gl.deleteBuffer(elements));
    if (!vertices || !elements) throw Error('Buffer allocation failed');
    const textures = [0,1,2,3].map(() => { const t = createTexture(gl); cleanups.push(() => gl.deleteTexture(t)); return t; });
    const attributes = ['aPosition','aNormal','aUv'].map(name => gl.getAttribLocation(program,name));
    const u = Object.fromEntries(['uView','uTurn','uShadow','uFront','uBack','uMask','uBackMask','uIntensity','uHue','uFoilTint','uTearFromRight','uTearAt','uProgress','uTearable','uDebug']
      .map(name => [name, gl.getUniformLocation(program,name)]));
    let data = new Float32Array(0), normals = new Float32Array(0), currentMesh: FoilMesh | null = null;
    return {
      resize(cssWidth, cssHeight, dpr) {
        width = Math.max(1,cssWidth); height = Math.max(1,cssHeight);
        canvas.width = Math.max(1,Math.round(width*dpr)); canvas.height = Math.max(1,Math.round(height*dpr));
        gl.viewport(0,0,canvas.width,canvas.height);
      },
      load(artwork, ready) {
        cancel(); loaded = false;
        let cancelled = false, remaining = 4, failed = false;
        const images: HTMLImageElement[] = [];
        cancel = () => { cancelled = true; images.forEach(image => { image.onload = null; image.onerror = null; }); };
        const complete = () => { if (--remaining === 0 && !failed && !cancelled && !disposed) { loaded = true; ready(); } };
        const fail = () => {
          if (!cancelled && !disposed && !failed) {
            failed = true; ready('Foil artwork could not be loaded. Use same-origin or CORS-enabled images.');
          }
        };
        [artwork.front, artwork.back || artwork.front, artwork.mask, artwork.backMask || artwork.mask].forEach((src, index) => {
          const upload = (image?: HTMLImageElement) => {
            if (cancelled || disposed || failed) return;
            try {
              gl.activeTexture(gl.TEXTURE0+index); gl.bindTexture(gl.TEXTURE_2D,textures[index]);
              gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
              if (image) gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);
              else gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,255,255,255]));
              if (gl.getError() !== gl.NO_ERROR) throw Error('Texture upload failed');
              complete();
            } catch { fail(); }
          };
          if (!src) { upload(); return; }
          const image = new Image(); images.push(image); image.crossOrigin = 'anonymous';
          image.onload = () => upload(image); image.onerror = fail; image.src = src;
        });
        return cancel;
      },
      render(mesh, config) {
        if (disposed || !loaded) return;
        if (currentMesh !== mesh) {
          currentMesh = mesh; data = new Float32Array(mesh.positions.length / 3 * 8); normals = new Float32Array(mesh.positions.length);
          gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,elements); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,mesh.indices,gl.STATIC_DRAW);
        }
        const p = mesh.positions; normals.fill(0);
        for (let i=0; i<mesh.indices.length; i+=3) {
          const a=mesh.indices[i]*3,b=mesh.indices[i+1]*3,c=mesh.indices[i+2]*3;
          const ax=p[b]-p[a], ay=p[b+1]-p[a+1], az=p[b+2]-p[a+2];
          const bx=p[c]-p[a], by=p[c+1]-p[a+1], bz=p[c+2]-p[a+2];
          const nx=ay*bz-az*by,ny=az*bx-ax*bz,nz=ax*by-ay*bx;
          for (const j of [a,b,c]) { normals[j]+=nx; normals[j+1]+=ny; normals[j+2]+=nz; }
        }
        for (let i=0;i<p.length/3;i++) {
          const j=i*3,k=i*8,length=Math.hypot(normals[j],normals[j+1],normals[j+2])||1;
          data[k]=p[j]; data[k+1]=p[j+1]; data[k+2]=p[j+2];
          data[k+3]=normals[j]/length; data[k+4]=normals[j+1]/length; data[k+5]=normals[j+2]/length;
          data[k+6]=mesh.uv[i*2]; data[k+7]=mesh.uv[i*2+1];
        }
        gl.useProgram(program); gl.bindBuffer(gl.ARRAY_BUFFER,vertices); gl.bufferData(gl.ARRAY_BUFFER,data,gl.DYNAMIC_DRAW);
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,elements);
        attributes.forEach((location,i) => { gl.enableVertexAttribArray(location); gl.vertexAttribPointer(location,i===2?2:3,gl.FLOAT,false,32,i===0?0:i===1?12:24); });
        textures.forEach((texture,index) => { gl.activeTexture(gl.TEXTURE0+index); gl.bindTexture(gl.TEXTURE_2D,texture); });
        gl.uniform1i(u.uFront,0); gl.uniform1i(u.uBack,1); gl.uniform1i(u.uMask,2); gl.uniform1i(u.uBackMask,3);
        const viewHeight=foilViewHeight(width,height,config.aspectRatio);
        gl.uniform2f(u.uView,viewHeight*width/height,viewHeight);
        gl.uniform3f(u.uFoilTint,...config.foilTint); gl.uniform1f(u.uTearFromRight,mesh.tearFromRight?1:0);
        gl.uniform1f(u.uTurn,mesh.turn); gl.uniform1f(u.uIntensity,config.intensity); gl.uniform1f(u.uHue,config.hue);
        gl.uniform1f(u.uDebug,config.debug?1:0); gl.uniform1f(u.uTearAt,config.tearAt); gl.uniform1f(u.uProgress,mesh.progress); gl.uniform1f(u.uTearable,config.tearable?1:0);
        gl.clearColor(0,0,0,0); gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
        gl.disable(gl.CULL_FACE); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
        gl.disable(gl.DEPTH_TEST);
        for (let pass=1;pass<=3;pass++) { gl.uniform1f(u.uShadow,pass); gl.drawElements(gl.TRIANGLES,mesh.indices.length,gl.UNSIGNED_SHORT,0); }
        gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.uniform1f(u.uShadow,0);
        gl.drawElements(gl.TRIANGLES,mesh.indices.length,gl.UNSIGNED_SHORT,0);
      },
      dispose,
    };
  } catch { dispose(); return null; }
}
