import { clampNumber } from '../core/numberOps.js';
import type { GlowPoint, ResolvedGlowPoint } from './types.js';

export function resolveGlowPoints(points: readonly GlowPoint[], intensity = 1): ResolvedGlowPoint[] {
  const strength = clampNumber(intensity, 0, 2, 1);
  return points.slice(0, 128).map(point => ({
    x: clampNumber(point.x, 0, 1, .5), y: clampNumber(point.y, 0, 1, .5),
    radius: clampNumber(point.radius, 0, 300, 36),
    color: point.color ?? '#ffcb82',
    opacity: Math.min(1, clampNumber(point.opacity, 0, 1, .7) * strength),
  }));
}
