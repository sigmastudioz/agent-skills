import { clampNumber, finiteNumberOr } from './numberOps.js';

/**
 * Raw device angles turned into screen-space tilt: x is left/right, y is towards/away,
 * independent of how the phone is rotated. `beta` (front-back) and `gamma` (left-right) are
 * the DeviceOrientationEvent angles in degrees; `screenAngle` is screen.orientation.angle.
 */
export function screenTilt(beta: number, gamma: number, screenAngle: number): [number, number] {
  const b = finiteNumberOr(beta, 0), g = finiteNumberOr(gamma, 0);
  switch (((Math.round(finiteNumberOr(screenAngle, 0) / 90) % 4) + 4) % 4) {
    case 1: return [b, -g];
    case 2: return [-g, -b];
    case 3: return [-b, g];
    default: return [g, b];
  }
}

/**
 * Tilt relative to a neutral pose, scaled so `range` degrees reaches ±1. Clamped to [-1, 1].
 */
export function normalizeTilt(angles: readonly [number, number], neutral: readonly [number, number], range: number): [number, number] {
  const r = clampNumber(range, 1, 90, 30);
  return [
    clampNumber((angles[0] - neutral[0]) / r, -1, 1, 0),
    clampNumber((angles[1] - neutral[1]) / r, -1, 1, 0),
  ];
}

/** Pointer position in the viewport mapped to [-1, 1] on both axes (centre is 0). */
export function pointerTilt(clientX: number, clientY: number, width: number, height: number): [number, number] {
  const w = Math.max(1, finiteNumberOr(width, 1)), h = Math.max(1, finiteNumberOr(height, 1));
  return [clampNumber((clientX / w) * 2 - 1, -1, 1, 0), clampNumber((clientY / h) * 2 - 1, -1, 1, 0)];
}

export type TiltPermission = 'granted' | 'denied' | 'prompt' | 'unsupported';

/** What this browser needs before orientation events arrive. Safe on the server. */
export function tiltPermissionState(): TiltPermission {
  if (typeof window === 'undefined' || typeof (window as any).DeviceOrientationEvent === 'undefined') return 'unsupported';
  return typeof (window as any).DeviceOrientationEvent.requestPermission === 'function' ? 'prompt' : 'granted';
}
