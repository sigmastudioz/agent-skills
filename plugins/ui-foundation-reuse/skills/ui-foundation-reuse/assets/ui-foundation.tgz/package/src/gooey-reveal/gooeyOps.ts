import { clampNumber } from '../core/numberOps.js';
import type { TrailPoint } from './types.js';

/** Frame-rate independent chain: the head chases the pointer, each blob chases the one ahead.
 * `follow` is the fraction closed per 60 Hz frame. */
export function stepTrail(points: readonly TrailPoint[], target: TrailPoint, follow: number, deltaMs: number): TrailPoint[] {
  const rate = clampNumber(follow, .05, 1, .32);
  const t = 1 - Math.pow(1 - rate, clampNumber(deltaMs, 0, 100, 16.7) / 16.7);
  let lead = target;
  return points.map(point => {
    const next = { x: point.x + (lead.x - point.x) * t, y: point.y + (lead.y - point.y) * t };
    lead = next;
    return next;
  });
}

/** True once every blob is within `epsilon` CSS pixels of the target; the loop may sleep. */
export function trailSettled(points: readonly TrailPoint[], target: TrailPoint, epsilon = .5): boolean {
  return points.every(point => Math.abs(point.x - target.x) < epsilon && Math.abs(point.y - target.y) < epsilon);
}

/** Head first, tapering to ~35% of the head so the tail reads as a droplet. */
export function trailRadii(count: number, radius: number): number[] {
  const head = clampNumber(radius, 12, 240, 70);
  const n = Math.round(clampNumber(count, 0, 12, 6)) + 1;
  return Array.from({ length: n }, (_, i) => head * (1 - .65 * (n > 1 ? i / (n - 1) : 0)));
}

/** Eases the reveal scale toward 1 while hovering and 0 after leaving. */
export function stepPresence(scale: number, active: boolean, deltaMs: number): number {
  const t = 1 - Math.pow(.82, clampNumber(deltaMs, 0, 100, 16.7) / 16.7);
  const next = scale + ((active ? 1 : 0) - scale) * t;
  return Math.abs(next - (active ? 1 : 0)) < .002 ? (active ? 1 : 0) : next;
}

/** feColorMatrix values: keep color, sharpen the blurred alpha into a hard gooey edge. */
export const GOO_MATRIX = '1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -10';
