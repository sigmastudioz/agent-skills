'use client';
import { useMemo, type PointerEvent, type FocusEvent } from 'react';
import { clampNumber } from './numberOps.js';

export interface InteractionState {
  x: number; y: number; pressure: number; active: boolean; pressed: boolean; focused: boolean;
  revision: number;
}
/** Mutable input shared by effects without React renders. Coordinates are -1..1, Y points up. */
export interface InteractionSignal { current: InteractionState }
export function createInteractionSignal(): InteractionSignal {
  return { current: { x: 0, y: 0, pressure: 0, active: false, pressed: false, focused: false, revision: 0 } };
}
export function normalizePointer(x: number, y: number, width: number, height: number): [number, number] {
  if (!(width > 0 && height > 0) || !Number.isFinite(x + y + width + height)) return [0, 0];
  return [clampNumber(x / width * 2 - 1, -1, 1, 0), clampNumber(1 - y / height * 2, -1, 1, 0)];
}
/** Spread handlers on a stable interaction surface; pass the signal to multiple effects. */
export function useInteraction(external?: InteractionSignal) {
  const local = useMemo(createInteractionSignal, []);
  const signal = external ?? local;
  const handlers = useMemo(() => {
    const move = (event: PointerEvent<HTMLElement>) => {
      const box = event.currentTarget.getBoundingClientRect();
      const [x, y] = normalizePointer(event.clientX - box.left, event.clientY - box.top, box.width, box.height);
      Object.assign(signal.current, { x, y, active: true, pressure: event.pressure || .5 });
      signal.current.revision++;
    };
    const reset = () => { Object.assign(signal.current, { x: 0, y: 0, active: false, pressed: false, pressure: 0 }); signal.current.revision++; };
    return {
      onPointerMove: move,
      onPointerDown: (event: PointerEvent<HTMLElement>) => { move(event); signal.current.pressed = true; },
      onPointerUp: (event: PointerEvent<HTMLElement>) => { signal.current.pressed = false; if (event.pointerType !== 'mouse') reset(); },
      onPointerLeave: reset, onPointerCancel: reset,
      onFocusCapture: () => { signal.current.focused = true; },
      onBlurCapture: (event: FocusEvent<HTMLElement>) => {
        if (!event.currentTarget.contains(event.relatedTarget as Node | null)) signal.current.focused = false;
      },
    };
  }, [signal]);
  return { signal, handlers };
}
