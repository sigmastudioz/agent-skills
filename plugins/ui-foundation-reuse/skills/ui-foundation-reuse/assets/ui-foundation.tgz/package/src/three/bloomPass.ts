import { createRenderState } from './captureState.js';
import { captureTargetSize } from './renderTargetOps.js';
import type { BloomConfig } from './stagingOps.js';

const owners = new WeakSet<object>();
/** A single root composer; Three's peer supplies the HDR bloom and output conversion passes. */
export function createBloomPass(three: any, addons: any, renderer: any, scene: any, camera: any, initial: BloomConfig) {
  if (owners.has(renderer)) throw new Error('Only one Bloom may own a Canvas.');
  owners.add(renderer);
  const preserve = createRenderState(three), size = new three.Vector2();
  let target: any, composer: any, renderPass: any, bloom: any, output: any, disposed = false, config = initial;
  const dispose = () => {
    if (disposed) return; disposed = true; owners.delete(renderer);
    renderPass?.dispose(); bloom?.dispose(); output?.dispose();
    // Three r160's UnrealBloomPass leaves this owned material out of dispose().
    bloom?.materialHighPassFilter?.dispose();
    if (composer) composer.dispose(); else target?.dispose();
  };
  try {
    target = new three.WebGLRenderTarget(1, 1, { type: three.HalfFloatType });
    composer = new addons.EffectComposer(renderer, target); composer.setPixelRatio(1);
    renderPass = new addons.RenderPass(scene, camera);
    bloom = new addons.UnrealBloomPass(new three.Vector2(1, 1), initial.strength, initial.radius, initial.threshold);
    output = new addons.OutputPass();
    composer.addPass(renderPass); composer.addPass(bloom); composer.addPass(output);
    const configure = (next: BloomConfig) => { config = next; bloom.strength = next.strength; bloom.radius = next.radius; bloom.threshold = next.threshold; };
    configure(initial);
    let lastWidth = 0, lastHeight = 0;
    return { configure, dispose,
      render(nextScene = scene, nextCamera = camera, delta = 0) {
        if (disposed) return;
        preserve(renderer, () => {
          if (!config.enabled || config.strength === 0) { renderer.render(nextScene, nextCamera); return; }
          renderer.getDrawingBufferSize(size);
          const [width, height] = captureTargetSize(size.x, size.y, config.resolution);
          if (width !== lastWidth || height !== lastHeight) { composer.setSize(width, height); lastWidth = width; lastHeight = height; }
          renderPass.scene = nextScene; renderPass.camera = nextCamera;
          composer.render(delta);
        });
      },
    };
  } catch (error) { dispose(); throw error; }
}
