type MixerBands = { bass: number; mid: number; treble: number; energy: number };

/** Slow wash around the color wheel. 12 = lava-lamp, 40 = club strobe. */
export const GLOW_HUE_DEG_PER_SEC = 18;
/** Extra hue kick when the analyzer flags a beat. */
export const GLOW_BEAT_HUE_JUMP = 42;

export type AmbientGlowInput = MixerBands & {
  beat: boolean;
  playing: boolean;
  timeSec: number;
  beatBoostDeg: number;
};

export type AmbientGlowFrame = {
  /** Top stop of the halo gradient (already includes alpha). */
  color: string;
  /** Opaque hex for the listener ring stroke. */
  hex: string;
  opacity: number;
  scale: number;
};

function clamp01(n: number): number {
  return n < 0 ? 0 : n > 1 ? 1 : n;
}

function hue2rgb(p: number, q: number, t: number): number {
  let tt = t;
  if (tt < 0) tt += 1;
  if (tt > 1) tt -= 1;
  if (tt < 1 / 6) return p + (q - p) * 6 * tt;
  if (tt < 1 / 2) return q;
  if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
  return p;
}

/** h in degrees, s/l/a in 0–1. */
export function hslToRgba(h: number, s: number, l: number, a: number): string {
  const hh = ((h % 360) + 360) % 360;
  const sat = clamp01(s);
  const light = clamp01(l);
  const alpha = clamp01(a);
  const q = light < 0.5 ? light * (1 + sat) : light + sat - light * sat;
  const p = 2 * light - q;
  const hk = hh / 360;
  const r = Math.round(hue2rgb(p, q, hk + 1 / 3) * 255);
  const g = Math.round(hue2rgb(p, q, hk) * 255);
  const b = Math.round(hue2rgb(p, q, hk - 1 / 3) * 255);
  return `rgba(${r}, ${g}, ${b}, ${alpha.toFixed(3)})`;
}

export function hslToHex(h: number, s: number, l: number): string {
  const rgba = hslToRgba(h, s, l, 1);
  const match = /rgba\((\d+), (\d+), (\d+)/.exec(rgba);
  if (!match) return '#FFAC1D';
  const toHex = (n: string) => Number(n).toString(16).padStart(2, '0');
  return `#${toHex(match[1])}${toHex(match[2])}${toHex(match[3])}`;
}

/**
 * Bass pulls toward gold/red, treble toward cyan/violet, time walks the wheel.
 */
export function pickGlowHue(input: AmbientGlowInput): number {
  const { bass, mid, treble, timeSec, beatBoostDeg, playing } = input;
  const drift = timeSec * (playing ? GLOW_HUE_DEG_PER_SEC : 6);
  const bandBias = bass * 38 - treble * 52 + mid * 14;
  return ((drift + bandBias + beatBoostDeg) % 360 + 360) % 360;
}

/** Follow the short way around the wheel, including the 360→0 seam. */
export function followGlowHue(current: number, target: number, elapsed: number): number {
  const delta = ((target - current + 180) % 360 + 360) % 360 - 180;
  const next = current + delta * -Math.expm1(-Math.max(0, elapsed) / 0.08);
  return (next % 360 + 360) % 360;
}

export function resolveAmbientGlowFrame(input: AmbientGlowInput, hue = pickGlowHue(input)): AmbientGlowFrame {
  const { bass, energy, treble, beat, playing } = input;
  const sat = 0.7 + treble * 0.22;
  const light = 0.52 + energy * 0.1;
  const hex = hslToHex(hue, sat, light);
  const color = hslToRgba(hue, sat, light, playing ? 0.5 + energy * 0.22 : 0.28);

  return {
    color,
    hex,
    opacity: playing ? 0.38 + energy * 0.48 : 0.2,
    scale: playing ? 1 + bass * 0.2 + (beat ? 0.07 : 0) : 1,
  };
}
