import type { ReactNode, RefObject } from 'react';
import { clampNumber } from '../core/numberOps.js';
import { surfaceColor } from './glassOps.js';
import type { FloorTransform, StageEffectProps } from './stagingOps.js';

export interface CausticsProps extends StageEffectProps, FloorTransform {
  /** Closed, non-overlapping ordinary meshes. Their geometry and rigid transforms drive the pattern. */
  children?: ReactNode;
  size?: [number, number];
  /** World-space position of a directional beam aimed at the wrapped geometry. */
  lightSource?: [number, number, number];
  /** Share this value with GlassMaterial. Material properties are not inferred. */
  ior?: number;
  intensity?: number;
  color?: string;
  /** Opaque built-in floor by default. null adds light over an existing floor. */
  floorColor?: string | null;
  /** Photon grid side, 32–256 (squared to obtain the photon count). */
  samples?: number;
  /** Receiving texture side in physical pixels, 128–1024. */
  resolution?: number;
  /** Photon footprint in texture pixels, 1–8. */
  softness?: number;
}
export interface CausticsRuntimeProps extends CausticsProps { casterRef: RefObject<any> }
const tuple = (value: number[] | undefined, fallback: [number, number, number]): [number, number, number] =>
  fallback.map((item, index) => clampNumber(value?.[index], -10000, 10000, item)) as [number, number, number];

export function resolveCausticsConfig(props: CausticsProps = {}) {
  return {
    enabled: props.enabled !== false,
    position: tuple(props.position, [0, -1, 0]), rotation: tuple(props.rotation, [-Math.PI / 2, 0, 0]),
    size: [clampNumber(props.size?.[0], .1, 100, 10), clampNumber(props.size?.[1], .1, 100, 10)] as [number, number],
    lightSource: tuple(props.lightSource, [3, 6, 2]), ior: clampNumber(props.ior, 1, 2.5, 1.5),
    intensity: clampNumber(props.intensity, 0, 10, 2), color: surfaceColor(props.color, '#fff4dc'),
    floorColor: props.floorColor === null ? null : surfaceColor(props.floorColor, '#303945'),
    samples: Math.round(clampNumber(props.samples, 32, 256, 128)),
    resolution: Math.round(clampNumber(props.resolution, 128, 1024, 512)),
    softness: clampNumber(props.softness, 1, 8, 3),
  };
}
export type CausticsConfig = ReturnType<typeof resolveCausticsConfig>;

/** Centered stratified samples: the GPU reads the light-space surface at each UV. */
export function causticPhotonGrid(side: number): Float32Array {
  const count = Math.round(clampNumber(side, 32, 256, 128)), result = new Float32Array(count * count * 3);
  for (let y = 0; y < count; y++) for (let x = 0; x < count; x++) {
    const offset = (y * count + x) * 3;
    result[offset] = (x + .5) / count; result[offset + 1] = (y + .5) / count;
  }
  return result;
}

/** Normalize splat energy against beam area, receiver area, grid density and footprint. */
export function causticPhotonPower(beamArea: number, receiverArea: number, config: CausticsConfig): number {
  const kernelArea = Math.PI * config.softness * config.softness / 16;
  const power = beamArea / Math.max(receiverArea, .000001) * (config.resolution / config.samples) ** 2 / kernelArea;
  // Even if every photon hits one texel, accumulation must fit the half-float target.
  return Math.min(power, 60000 / config.samples ** 2);
}
