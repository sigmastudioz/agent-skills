import { extractPoints, warpLuminance } from './geometricField.js';
import type { FieldPoint, GeometricScene, MotionProgram, ResolvedGeometricConfig, ShapeKind } from './types.js';

const SHAPE_CYCLE: Array<Exclude<ShapeKind, 'mixed'>> = ['circle', 'square', 'diamond', 'cross', 'bracket'];

interface Circle { x: number; y: number; r: number }

/** Unique Delaunay edges for a point set in any 2D space. Fewer than 3 points yield none. */
export function delaunayEdges(points: Array<{ x: number; y: number }>): Array<[number, number]> {
  const unique: Array<{ x: number; y: number; index: number }> = [];
  for (let i = 0; i < points.length; i++) {
    const point = points[i];
    if (unique.some(other => Math.hypot(other.x - point.x, other.y - point.y) < 1e-6)) continue;
    unique.push({ x: point.x, y: point.y, index: i });
  }
  const n = unique.length;
  if (n < 3) return [];
  const all = unique.map(point => ({ x: point.x, y: point.y }));
  all.push({ x: -8, y: -8 }, { x: 8, y: -8 }, { x: 0, y: 12 });
  let tris: Array<[number, number, number]> = [[n, n + 1, n + 2]];
  const circum = (a: number, b: number, c: number) => {
    const A = all[a];
    const B = all[b];
    const C = all[c];
    const d = 2 * (A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y - B.y));
    if (Math.abs(d) < 1e-12) return null;
    const a2 = A.x * A.x + A.y * A.y;
    const b2 = B.x * B.x + B.y * B.y;
    const c2 = C.x * C.x + C.y * C.y;
    const x = (a2 * (B.y - C.y) + b2 * (C.y - A.y) + c2 * (A.y - B.y)) / d;
    const y = (a2 * (C.x - B.x) + b2 * (A.x - C.x) + c2 * (B.x - A.x)) / d;
    return { x, y, r2: (x - A.x) ** 2 + (y - A.y) ** 2 };
  };
  for (let i = 0; i < n; i++) {
    const bad: Array<[number, number, number]> = [];
    for (const tri of tris) {
      const circle = circum(tri[0], tri[1], tri[2]);
      if (!circle) continue;
      const dx = all[i].x - circle.x;
      const dy = all[i].y - circle.y;
      if (dx * dx + dy * dy <= circle.r2 * (1 + 1e-9) + 1e-12) bad.push(tri);
    }
    const boundary = new Map<string, { edge: [number, number]; count: number }>();
    for (const tri of bad) {
      const edges: Array<[number, number]> = [[tri[0], tri[1]], [tri[1], tri[2]], [tri[2], tri[0]]];
      for (const edge of edges) {
        const key = edge[0] < edge[1] ? `${edge[0]}:${edge[1]}` : `${edge[1]}:${edge[0]}`;
        const found = boundary.get(key);
        if (found) found.count += 1;
        else boundary.set(key, { edge, count: 1 });
      }
    }
    const badSet = new Set(bad);
    tris = tris.filter(tri => !badSet.has(tri));
    for (const { edge, count } of boundary.values()) {
      if (count === 1) tris.push([edge[0], edge[1], i]);
    }
  }
  const edges = new Map<string, [number, number]>();
  for (const tri of tris) {
    if (tri.some(index => index >= n)) continue;
    const pairs: Array<[number, number]> = [[tri[0], tri[1]], [tri[1], tri[2]], [tri[2], tri[0]]];
    for (const [a, b] of pairs) {
      const ia = unique[a].index;
      const ib = unique[b].index;
      const key = ia < ib ? `${ia}:${ib}` : `${ib}:${ia}`;
      edges.set(key, ia < ib ? [ia, ib] : [ib, ia]);
    }
  }
  return [...edges.values()];
}

function edgeKey(a: number, b: number): string {
  return a < b ? `${a}:${b}` : `${b}:${a}`;
}

export function linkPoints(
  points: FieldPoint[], mode: ResolvedGeometricConfig['link'], maxDistance: number,
): Array<{ a: number; b: number; confidence: number }> {
  if (points.length < 2 || maxDistance <= 0) return [];
  if (mode === 'delaunay' || mode === 'hybrid') {
    const mesh = delaunayEdges(points)
      .map(([a, b]) => {
        const dist = Math.hypot(points[a].x - points[b].x, points[a].y - points[b].y);
        return { a, b, confidence: 1 - dist / maxDistance, dist };
      })
      .filter(edge => edge.dist <= maxDistance && edge.dist > 1e-6)
      .map(({ a, b, confidence }) => ({ a, b, confidence }));
    if (mode === 'delaunay') return mesh;
    const degree = new Array(points.length).fill(0);
    mesh.forEach(edge => { degree[edge.a] += 1; degree[edge.b] += 1; });
    return mesh.concat(radialLinks(points, maxDistance * 1.4).filter(edge => degree[edge.a] === 0 || degree[edge.b] === 0));
  }
  if (mode === 'radial') return radialLinks(points, maxDistance * 1.6);
  if (mode === 'orthogonal') return orthogonalLinks(points, maxDistance);
  if (mode === 'edgeChain') return chainLinks(points, maxDistance);
  return proximityLinks(points, maxDistance);
}

function radialLinks(points: FieldPoint[], maxDistance: number) {
  let cx = 0;
  let cy = 0;
  points.forEach(point => { cx += point.x; cy += point.y; });
  cx /= points.length;
  cy /= points.length;
  let hub = 0;
  let best = Infinity;
  points.forEach((point, index) => {
    const dist = Math.hypot(point.x - cx, point.y - cy);
    if (dist < best) { best = dist; hub = index; }
  });
  const links = [];
  for (let i = 0; i < points.length; i++) {
    if (i === hub) continue;
    const dist = Math.hypot(points[i].x - points[hub].x, points[i].y - points[hub].y);
    if (dist <= maxDistance) links.push({ a: hub, b: i, confidence: 1 - dist / maxDistance });
  }
  return links;
}

function proximityLinks(points: FieldPoint[], maxDistance: number) {
  const links = new Map<string, { a: number; b: number; confidence: number }>();
  for (let i = 0; i < points.length; i++) {
    const near: Array<{ index: number; dist: number }> = [];
    for (let j = 0; j < points.length; j++) {
      if (i === j) continue;
      const dist = Math.hypot(points[i].x - points[j].x, points[i].y - points[j].y);
      if (dist <= maxDistance) near.push({ index: j, dist });
    }
    near.sort((a, b) => a.dist - b.dist);
    near.slice(0, 2).forEach(({ index, dist }) => {
      links.set(edgeKey(i, index), { a: i, b: index, confidence: 1 - dist / maxDistance });
    });
  }
  return [...links.values()];
}

function orthogonalLinks(points: FieldPoint[], maxDistance: number) {
  const links = new Map<string, { a: number; b: number; confidence: number }>();
  for (let i = 0; i < points.length; i++) {
    let horizontal = -1;
    let vertical = -1;
    let bestH = Infinity;
    let bestV = Infinity;
    for (let j = 0; j < points.length; j++) {
      if (i === j) continue;
      const dx = Math.abs(points[i].x - points[j].x);
      const dy = Math.abs(points[i].y - points[j].y);
      const dist = Math.hypot(dx, dy);
      if (dist > maxDistance) continue;
      if (dx >= dy && dist < bestH) { bestH = dist; horizontal = j; }
      if (dy > dx && dist < bestV) { bestV = dist; vertical = j; }
    }
    if (horizontal >= 0) links.set(edgeKey(i, horizontal), { a: i, b: horizontal, confidence: 1 - bestH / maxDistance });
    if (vertical >= 0) links.set(edgeKey(i, vertical), { a: i, b: vertical, confidence: 1 - bestV / maxDistance });
  }
  return [...links.values()];
}

function chainLinks(points: FieldPoint[], maxDistance: number) {
  const used = new Set<number>([0]);
  const links = [];
  let current = 0;
  let heading = points[0].angle + Math.PI / 2;
  for (let step = 0; step < points.length - 1; step++) {
    let best = -1;
    let bestScore = Infinity;
    const origin = points[current];
    for (let i = 0; i < points.length; i++) {
      if (used.has(i)) continue;
      const dx = points[i].x - origin.x;
      const dy = points[i].y - origin.y;
      const dist = Math.hypot(dx, dy);
      if (dist > maxDistance || dist < 1e-6) continue;
      const turn = Math.atan2(Math.sin(Math.atan2(dy, dx) - heading), Math.cos(Math.atan2(dy, dx) - heading));
      const score = dist * (1 + Math.abs(turn));
      if (score < bestScore) { bestScore = score; best = i; }
    }
    if (best < 0) break;
    links.push({ a: current, b: best, confidence: Math.min(origin.strength, points[best].strength) });
    heading = Math.atan2(points[best].y - origin.y, points[best].x - origin.x);
    used.add(best);
    current = best;
  }
  return links;
}

/** Two-circle crossings. Empty when the circles miss or one contains the other. */
export function circleIntersections(a: Circle, b: Circle): Array<{ x: number; y: number }> {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const dist = Math.hypot(dx, dy);
  if (dist < 1e-8 || dist > a.r + b.r || dist < Math.abs(a.r - b.r)) return [];
  const along = (a.r * a.r - b.r * b.r + dist * dist) / (2 * dist);
  const height = Math.sqrt(Math.max(0, a.r * a.r - along * along));
  const mx = a.x + (along * dx) / dist;
  const my = a.y + (along * dy) / dist;
  if (height < 1e-8) return [{ x: mx, y: my }];
  const rx = (-dy * height) / dist;
  const ry = (dx * height) / dist;
  return [{ x: mx + rx, y: my + ry }, { x: mx - rx, y: my - ry }];
}

/** Keep `angle`, or flip it, so the ray points into the emptier half-plane. */
export function openDirection(points: FieldPoint[], origin: FieldPoint, angle: number): number {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  let forward = 0;
  let back = 0;
  for (const point of points) {
    const ahead = c * (point.x - origin.x) + s * (point.y - origin.y);
    if (ahead >= 0) forward += 1;
    else back += 1;
  }
  return forward <= back ? angle : angle + Math.PI;
}

export function circleChain(points: FieldPoint[], count: number, baseRadius: number, ratio: number): { circles: Circle[]; crossings: Array<{ x: number; y: number }> } {
  if (!points.length || count < 2) return { circles: [], crossings: [] };
  const origin = points[0];
  const angle = openDirection(points, origin, origin.angle + Math.PI / 2);
  const circles: Circle[] = [];
  let x = origin.x;
  let y = origin.y;
  let radius = baseRadius;
  for (let i = 0; i < count; i++) {
    circles.push({ x, y, r: radius });
    const next = radius * ratio;
    const step = (radius + next) * 0.72;
    x += Math.cos(angle) * step;
    y += Math.sin(angle) * step;
    radius = next;
  }
  const crossings = [];
  for (let i = 0; i < circles.length - 1; i++) crossings.push(...circleIntersections(circles[i], circles[i + 1]));
  return { circles, crossings };
}

export function motionPoint(point: FieldPoint, index: number, time: number, program: MotionProgram): FieldPoint & { scale: number; reveal: number } {
  let dx = 0;
  let dy = 0;
  let scale = 1;
  let reveal = 1;
  const tangent = point.angle + Math.PI / 2;
  if (program === 'contourFlow') {
    const travel = Math.sin(time * 0.85 + point.strength * 9) * 0.02;
    dx = Math.cos(tangent) * travel;
    dy = Math.sin(tangent) * travel;
  } else if (program === 'signalPulse') {
    scale = 1 + Math.sin(time * 2.2 + index) * 0.18 * (0.4 + point.strength);
  } else if (program === 'scanSweep') {
    reveal = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(time * 1.4 - point.x * 8));
  } else if (program === 'assemble') {
    const wave = (time * 0.2) % 1;
    reveal = Math.min(1, Math.max(0, (wave * 1.25 - (1 - point.strength)) * 4));
  } else if (program === 'orbit') {
    dx = Math.cos(time + index) * 0.012;
    dy = Math.sin(time * 1.3 + index) * 0.012;
  } else if (program === 'edgeWave') {
    const travel = Math.sin(time * 1.6 + index * 0.45) * 0.02 * point.strength;
    dx = Math.cos(point.angle) * travel;
    dy = Math.sin(point.angle) * travel;
  }
  return { ...point, x: clamp01(point.x + dx), y: clamp01(point.y + dy), scale, reveal };
}

function clamp01(value: number): number {
  if (value < 0) return 0;
  if (value > 1) return 1;
  return value;
}

export function buildGeometricScene(
  lum: Float32Array,
  width: number,
  height: number,
  config: Pick<ResolvedGeometricConfig, 'density' | 'threshold' | 'link' | 'shapes' | 'motion' | 'seed' | 'maxDistance' | 'showLinks' | 'showShapes' | 'showChain'>,
  time: number,
  pointer: { x: number; y: number; strength: number },
): GeometricScene {
  const warped = warpLuminance(lum, width, height, pointer.x, pointer.y, pointer.strength);
  const sampled = extractPoints(warped, width, height, config.threshold, config.density);
  const points = sampled.map((point, index) => motionPoint(point, index, time, config.motion));
  const rawLinks = config.showLinks ? linkPoints(points, config.link, config.maxDistance) : [];
  const links = rawLinks.map(link => {
    const a = points[link.a];
    const b = points[link.b];
    return {
      x0: a.x, y0: a.y, x1: b.x, y1: b.y, confidence: link.confidence,
      reveal: Math.min(a.reveal, b.reveal),
    };
  });
  const shapes = config.showShapes ? points.map((point, index) => ({
    x: point.x,
    y: point.y,
    size: (0.012 + point.strength ** 1.45 * 0.05) * point.scale,
    rotation: point.angle + Math.PI / 2,
    kind: config.shapes === 'mixed' ? SHAPE_CYCLE[(index + config.seed) % SHAPE_CYCLE.length] : config.shapes,
    reveal: point.reveal,
  })) : [];
  const chain = config.showChain ? circleChain(points, 7, 0.034, 1.22) : { circles: [], crossings: [] };
  return { points, links, shapes, circles: chain.circles, crossings: chain.crossings };
}
