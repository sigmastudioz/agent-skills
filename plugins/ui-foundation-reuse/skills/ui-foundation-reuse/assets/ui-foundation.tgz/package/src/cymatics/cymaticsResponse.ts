import { clampNumber } from '../core/numberOps.js';
import { CYMATICS_GRID, modeFrequency, type CymaticsMode } from './cymaticsModes.js';
import type { CymaticsAudioFrame, CymaticsConfig } from './types.js';

const unit = (v: number) => Number.isFinite(v) ? Math.max(0, Math.min(1, v)) : 0;
export function resonanceAt(frequency: number, natural: number, q: number): number {
  const detune = (frequency - natural) / Math.max(1, natural);
  return 1 / (1 + 4 * q * q * detune * detune);
}

/** FFT → resonant mode envelopes, no allocation. A supplied silent/invalid frame stays silent. */
export function updateCymaticsResponse(modes: CymaticsMode[], weights: Float32Array, config: CymaticsConfig, frame: CymaticsAudioFrame | undefined, delta: number): number {
  const level = unit((frame ? unit(frame.amplitude) : config.amplitude) * config.sensitivity);
  const valid = frame && Number.isFinite(frame.sampleRate) && frame.sampleRate > 0 && Number.isFinite(frame.fftSize) && frame.fftSize >= 2;
  const binHz = valid ? frame.sampleRate / frame.fftSize : 1;
  const blend = 1 - Math.exp(-clampNumber(delta, 0, .1, 1 / 60) * 14);
  for (let i = 0; i < modes.length; i++) {
    const frequency = modeFrequency(modes[i], config);
    let target = 0;
    if (!frame) target = resonanceAt(config.frequency, frequency, config.resonance);
    else if (valid && level > .0001) {
      const center = frequency / binHz, radius = Math.max(2, center / config.resonance * 2);
      const start = Math.max(1, Math.floor(center - radius)), end = Math.min(frame.spectrum.length - 1, Math.ceil(center + radius));
      for (let j = start; j <= end; j++) target = Math.max(target, unit(frame.spectrum[j]) * resonanceAt(j * binHz, frequency, config.resonance));
    }
    target *= level;
    weights[i] += (target - weights[i]) * blend;
    if (weights[i] < 1e-7) weights[i] = 0;
  }
  return level;
}

/** Four strongest modes bound the simulation cost, independent of FFT size. */
export function writeCymaticsField(modes: CymaticsMode[], weights: Float32Array, field: Float32Array, gradient: Float32Array): number {
  const top = [-1, -1, -1, -1];
  for (let i = 0; i < weights.length; i++) for (let slot = 0; slot < 4; slot++) {
    if (top[slot] < 0 || weights[i] > weights[top[slot]]) { for (let j = 3; j > slot; j--) top[j] = top[j - 1]; top[slot] = i; break; }
  }
  let total = 0;
  for (const i of top) if (i >= 0) total += weights[i];
  field.fill(0);
  if (total > 1e-12) for (const i of top) if (i >= 0) {
    const weight = weights[i] / total, values = modes[i].values;
    for (let j = 0; j < field.length; j++) field[j] += weight * values[j];
  }
  // A coherent modal blend retains nodal curves instead of collapsing grains
  // to intersections of unrelated squared modes. FFT phase is not reconstructed.
  for (let i = 0; i < field.length; i++) field[i] *= field[i];
  const size = CYMATICS_GRID;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const i = y * size + x;
    gradient[i * 2] = (field[y * size + Math.min(size - 1, x + 1)] - field[y * size + Math.max(0, x - 1)]) * size / 4;
    gradient[i * 2 + 1] = (field[Math.min(size - 1, y + 1) * size + x] - field[Math.max(0, y - 1) * size + x]) * size / 4;
  }
  return top[0];
}
