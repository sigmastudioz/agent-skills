import { createFullscreenPass, createTexture } from '../core/fullscreenPass.js';
import { coverScale } from '../core/imageFit.js';
import { createHeatmapPixels } from '../heatmap/heatmapOps.js';
import { HEATMAP_RAMPS } from '../heatmap/ramps.js';
import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import { createGlyphPixels, filterColor, filterModeIndex, imageFilterKind } from './filterOps.js';
import { IMAGE_FILTER_FRAGMENT } from './filterShader.js';
import type { ResolvedImageFilterConfig } from './types.js';

export interface ImageFilterRenderer extends WebGLRendererLike {
  load(src: string, ready: (error?: string) => void): () => void;
  /** Optional lifecycle time excludes pauses; omitted time redraws the frozen frame. */
  render(config: ResolvedImageFilterConfig, timeSeconds?: number): void;
}

export function createImageFilterRenderer(canvas: HTMLCanvasElement): ImageFilterRenderer | null {
  const gl = canvas.getContext('webgl', { alpha: true, premultipliedAlpha: false, antialias: false, depth: false });
  if (!gl) return null;
  const cleanup: (() => void)[] = [];
  let disposed = false, loaded = false, cssWidth = 1, cssHeight = 1;
  let imageWidth = 1, imageHeight = 1;
  let phase = 0, previousTime: number | undefined;
  let cancelLoad = () => {};
  const dispose = () => {
    if (disposed) return;
    disposed = true; cancelLoad(); cleanup.splice(0).reverse().forEach(fn => fn());
  };
  try {
    const pass = createFullscreenPass(gl, IMAGE_FILTER_FRAGMENT, [
      'uImage', 'uGlyphs', 'uColorRamp', 'uResolution', 'uCover', 'uOffset', 'uColor', 'uBackground',
      'uKind', 'uCell', 'uIntensity', 'uMonochrome', 'uInvert',
      'uLevels', 'uContrast', 'uAccent', 'uGrain', 'uGlow', 'uScanlines', 'uCurvature', 'uTime',
      'uDistortion', 'uTrail', 'uThreshold',
      'uCenter', 'uRadius', 'uSlices', 'uDirection', 'uMatrix', 'uMode', 'uSeed', 'uInterval',
    ]);
    cleanup.push(pass.dispose);
    const imageTexture = createTexture(gl); cleanup.push(() => gl.deleteTexture(imageTexture));
    const glyphTexture = createTexture(gl); cleanup.push(() => gl.deleteTexture(glyphTexture));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.ALPHA, 60, 8, 0, gl.ALPHA, gl.UNSIGNED_BYTE, createGlyphPixels());
    const rampTexture = createTexture(gl); cleanup.push(() => gl.deleteTexture(rampTexture));
    let rampKey = '';
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 256, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, createHeatmapPixels(HEATMAP_RAMPS.thermal));
    return {
      resize(width, height, dpr) {
        cssWidth = Math.max(1, width); cssHeight = Math.max(1, height);
        canvas.width = Math.max(1, Math.round(cssWidth * dpr));
        canvas.height = Math.max(1, Math.round(cssHeight * dpr));
        gl.viewport(0, 0, canvas.width, canvas.height);
      },
      load(src, ready) {
        cancelLoad(); loaded = false;
        let cancelled = false;
        const image = new Image();
        const fail = (message: string) => { if (!cancelled && !disposed) ready(message); };
        cancelLoad = () => { cancelled = true; image.onload = null; image.onerror = null; };
        image.crossOrigin = 'anonymous';
        image.onload = () => {
          if (cancelled || disposed) return;
          try {
            gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, imageTexture);
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
            if (gl.getError() !== gl.NO_ERROR) throw new Error('Upload failed');
            imageWidth = image.naturalWidth; imageHeight = image.naturalHeight;
            loaded = true; ready();
          } catch { fail('Image upload failed. Use same-origin images or images with CORS enabled.'); }
        };
        image.onerror = () => fail('Image loading failed. Use a reachable URL with CORS enabled.');
        image.src = src;
        return cancelLoad;
      },
      render(config, timeSeconds) {
        if (timeSeconds !== undefined && Number.isFinite(timeSeconds)) {
          if (previousTime !== undefined && config.animated) phase += Math.max(0, timeSeconds - previousTime) * config.speed;
          previousTime = timeSeconds;
        }
        if (!loaded || disposed) return;
        pass.use(); gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        const u = pass.uniforms, angle = config.angle * Math.PI / 180;
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, imageTexture);
        gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, glyphTexture);
        gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, rampTexture);
        if (config.kind === 'heatmap' || config.kind === 'dither') {
          const nextKey = config.colorRamp.join(',');
          if (nextKey !== rampKey) {
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 256, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, createHeatmapPixels(config.colorRamp));
            rampKey = nextKey;
          }
        }
        gl.uniform1i(u.uImage, 0); gl.uniform1i(u.uGlyphs, 1); gl.uniform1i(u.uColorRamp, 2);
        gl.uniform2f(u.uResolution, cssWidth, cssHeight);
        gl.uniform2f(u.uCover, ...coverScale(imageWidth, imageHeight, cssWidth, cssHeight));
        gl.uniform2f(u.uOffset, Math.cos(angle) * config.offset / cssWidth, Math.sin(angle) * config.offset / cssHeight);
        gl.uniform3f(u.uColor, ...filterColor(config.color));
        gl.uniform3f(u.uBackground, ...filterColor(config.backgroundColor));
        gl.uniform1f(u.uKind, imageFilterKind(config.kind)); gl.uniform1f(u.uCell, config.cellSize);
        gl.uniform1f(u.uIntensity, config.intensity); gl.uniform1f(u.uMonochrome, config.monochrome ? 1 : 0);
        gl.uniform1f(u.uInvert, config.invert ? 1 : 0);
        gl.uniform1f(u.uLevels, config.levels); gl.uniform1f(u.uContrast, config.contrast);
        gl.uniform3f(u.uAccent, ...filterColor(config.accentColor));
        gl.uniform1f(u.uGrain, config.grain); gl.uniform1f(u.uGlow, config.glow);
        gl.uniform1f(u.uScanlines, config.scanlines); gl.uniform1f(u.uCurvature, config.curvature);
        gl.uniform1f(u.uDistortion, config.distortion); gl.uniform1f(u.uTrail, config.trail);
        gl.uniform2f(u.uCenter, config.center[0], 1 - config.center[1]);
        gl.uniform1f(u.uRadius, config.radius); gl.uniform1f(u.uSlices, config.slices);
        gl.uniform2f(u.uDirection, Math.cos(angle), -Math.sin(angle));
        gl.uniform1f(u.uThreshold, config.threshold);
        gl.uniform1f(u.uMatrix, config.ditherMatrix); gl.uniform1f(u.uMode, filterModeIndex(config));
        gl.uniform1f(u.uSeed, config.seed); gl.uniform1f(u.uInterval, config.interval);
        gl.uniform1f(u.uTime, phase); pass.draw();
      },
      dispose,
    };
  } catch { dispose(); return null; }
}
