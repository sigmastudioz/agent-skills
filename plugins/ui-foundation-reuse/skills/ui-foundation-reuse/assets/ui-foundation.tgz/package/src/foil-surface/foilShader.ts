/** Original WebGL 1 shaders. UV artwork follows the simulated sheet; foil follows its normals. */
export const FOIL_VERTEX = `
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec2 aUv;
uniform vec2 uView;
uniform float uTurn;
uniform float uShadow;
varying vec2 vUv;
varying vec3 vNormal;
varying vec3 vPosition;
void main() {
  float c = cos(uTurn), s = sin(uTurn);
  mat3 rotation = mat3(c,0.,-s, 0.,1.,0., s,0.,c);
  vec3 p = rotation * aPosition;
  vNormal = rotation * aNormal;
  vPosition = p;
  vUv = aUv;
  float perspective = 1. / (1. - p.z * .12);
  vec2 projected = p.xy * perspective;
  projected += step(.5,uShadow) * vec2(.045 + p.z*.07 + (uShadow-1.)*.009, -.06 - (uShadow-1.)*.012);
  gl_Position = vec4(projected / (uView * .5), -p.z * .12, 1.);
}
`;
export const FOIL_FRAGMENT = `
precision highp float;
uniform sampler2D uFront;
uniform sampler2D uBack;
uniform sampler2D uMask;
uniform sampler2D uBackMask;
uniform float uIntensity;
uniform float uHue;
uniform vec3 uFoilTint;
uniform float uTearFromRight;
uniform float uTearAt;
uniform float uProgress;
uniform float uTearable;
uniform float uDebug;
uniform float uShadow;
varying vec2 vUv;
varying vec3 vNormal;
varying vec3 vPosition;
void main() {
  vec2 uv = gl_FrontFacing ? vUv : vec2(1. - vUv.x, vUv.y);
  vec4 printColor = gl_FrontFacing ? texture2D(uFront, uv) : texture2D(uBack, uv);
  float across = mix(vUv.x, 1.-vUv.x, uTearFromRight);
  float fiber = min(24.,floor(across * 25.));
  float seam = abs(vUv.y - uTearAt);
  if (uTearable > .5) {
    if (fiber < uProgress * 25.) {
      float tooth = .5 + .5*cos(vUv.x*25.*6.2831853);
      float ragged = .0025 + tooth*.0045 + (sin(vUv.x*733.)*.5+.5)*.0015;
      if (seam < ragged) discard;
    } else {
      vec2 hole = vec2((fract(vUv.x * 25.) - .5) * .04, (vUv.y - uTearAt) * 1.8);
      if (length(hole) < .0065) discard;
    }
  }
  if (printColor.a < .02) discard;
  if (uShadow > .5) { gl_FragColor = vec4(.12,.13,.1,printColor.a * .048); return; }
  vec3 n = normalize(vNormal) * (gl_FrontFacing ? 1. : -1.);
  vec3 view = normalize(vec3(0.,0.,5.)-vPosition);
  vec3 light = normalize(vec3(-.55,.75,1.5));
  float facing = max(dot(n,view),0.);
  float diffuse = .77 + .23*max(dot(n,light),0.);
  vec3 halfway = normalize(light+view);
  float softbox = pow(max(dot(n,halfway),0.),9.);
  float glint = pow(max(dot(n,halfway),0.),95.);
  // Fine attached print grain and multi-order diffraction respond to local sheet normals.
  vec2 paperCell = floor(uv*vec2(1800.,3120.));
  float grain = fract(sin(dot(paperCell,vec2(127.1,311.7)))*43758.5453)-.5;
  vec2 emblem = (uv-vec2(.5,.272))*vec2(1.,1.7333);
  float radial = length(emblem);
  float engrave = sin(atan(emblem.y,emblem.x)*24.+radial*125.)*.12;
  float phase = uv.x*2.75+uv.y*.55+n.x*1.8-n.y*1.35+(1.-facing)*2.2+uHue;
  phase += engrave * (1.-smoothstep(.12,.27,radial));
  vec3 spectral = .5+.5*cos(6.2831853*(phase+vec3(0.,.33,.67)));
  spectral = mix(spectral,vec3(.9),(1.-min(uFoilTint.r,min(uFoilTint.g,uFoilTint.b)))*.72);
  float mask = gl_FrontFacing ? texture2D(uMask,uv).r : texture2D(uBackMask,uv).r;
  vec3 color = printColor.rgb*diffuse + grain*.012;
  vec3 metal = mix(vec3(.66),spectral,.82)*(.68+softbox*.32)*uFoilTint;
  metal += mix(uFoilTint,vec3(1.),.7)*(glint*.4+softbox*.12);
  float center = 1.-smoothstep(.075,.1,radial);
  metal = mix(metal,printColor.rgb*uFoilTint,center*.55);
  color = mix(color,metal,mask*uIntensity);
  // The unprinted stock keeps a restrained laminate sheen instead of rainbow emission.
  color += (1.-mask)*softbox*.018;
  float edge = min(min(uv.x,1.-uv.x),min(uv.y,1.-uv.y));
  color += (1.-smoothstep(.002,.007,edge))*.08;
  if (uDebug > .5) {
    float row = vUv.y < uTearAt ? vUv.y / uTearAt * floor(32. * uTearAt + .5) : (vUv.y-uTearAt)/(1.-uTearAt)*(32.-floor(32.*uTearAt+.5));
    vec2 grid = abs(fract(vec2(vUv.x * 24.,row))-.5);
    float edge = smoothstep(.455,.49,max(grid.x,grid.y));
    color = mix(color, vec3(.05,.85,.56),edge*.8);
  }
  gl_FragColor = vec4(color, printColor.a);
}
`;
