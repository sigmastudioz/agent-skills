import { REACTIVE_COMMON } from './reactiveCommon.js';

export const BAR_SKSL = `${REACTIVE_COMMON}
float3 tone(float i){
 if(i<.5) return float3(.16,.98,.42);
 if(i<1.5) return float3(.18,.86,1.0);
 if(i<2.5) return float3(.32,.36,1.0);
 if(i<3.5) return float3(.72,.22,1.0);
 if(i<4.5) return float3(1.0,.9,.18);
 if(i<5.5) return float3(1.0,.28,.74);
 return float3(.28,.9,1.0);
}
float3 neon(float x){
 float t=clamp(x,0.0,1.0)*6.0;
 float i=floor(t);
 return mix(tone(i),tone(i+1.0),fract(t));
}
float energy(float n){
 float x=clamp(n,0.0,1.0);
 return clamp(smoothstep(.05,.4,x)*.62+smoothstep(0.0,1.0,x)*.5,0.0,1.0);
}
half4 main(float2 fragCoord){
 float2 uv=fragCoord/uResolution;
 float horizon=.64;
 float y=horizon-uv.y;
 float x=clamp(uv.x,0.0,.999);
 float level=spectrum(x);
 float lift=energy(level);
 float columns=48.0;
 float cell=floor(x*columns);
 float local=fract(x*columns);
 float mask=smoothstep(.16,.28,local)*(1.0-smoothstep(.6,.74,local));
 float jag=.84+.32*hash(float2(cell,4.0));
 float barH=(.016+lift*(.1+.48*uAmplitude))*jag;
 float3 ink=neon((cell+.5)/columns);
 float3 col=float3(.003,.004,.01);
 float sky=step(0.0,y);
 float thread=abs(fract(x*170.0)-.5);
 float filament=exp(-thread*42.0);
 col+=ink*filament*exp(-max(y,0.0)*1.45)*.06*sky;
 col+=ink*filament*exp(-max(y,0.0)*mix(6.2,.26,lift))*lift*1.85*sky;
 col+=ink*exp(-abs(local-.46)*3.2)*exp(-max(y,0.0)*mix(5.2,.4,lift))*lift*sky*.95;
 float body=mask*sky*smoothstep(0.0,.003,y)*(1.0-smoothstep(barH,barH+.012,y));
 col+=ink*body*(1.15+lift*(1.2+uAmplitude));
 col+=float3(1.0,.98,.94)*body*exp(-y*10.0)*(.15+.5*lift);
 col+=float3(1.0,.97,.9)*exp(-abs(y-barH)*48.0)*mask*sky*lift;
 float held=(.016+energy(peak(int(min(floor(x*15.0),15.0))))*(.1+.48*uAmplitude))*jag;
 col+=ink*exp(-abs(y-held)*90.0)*mask*sky*(.15+.4*lift);
 float blaze=exp(-abs(y)*22.0);
 col+=ink*blaze*(.12+.9*lift);
 col+=float3(1.0,.97,.9)*blaze*lift*.28;
 float floorMask=1.0-sky;
 float my=max(-y,0.0);
 col+=ink*(filament*.65+.35)*exp(-my*3.4)*exp(-max(my-barH,0.0)*4.0)*floorMask*(.08+.85*lift);
 col+=ink*exp(-my*2.4)*floorMask*lift*.28;
 return half4(finish(col,uv),1.0);
}
`;
