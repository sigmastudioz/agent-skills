import { RETRO_FILTER_FUNCTIONS } from './retroShader.js';
import { SIGNAL_FILTER_FUNCTIONS } from './signalShader.js';
import { HEATMAP_FILTER_FUNCTION } from '../heatmap/heatmapShader.js';
import { DISTORTION_FILTER_FUNCTIONS } from './distortionShader.js';
import { DITHER_FILTER_FUNCTIONS } from './ditherShader.js';
import { GLITCH_FILTER_FUNCTIONS } from './glitchShader.js';
import { ZOOM_BLUR_FILTER_FUNCTIONS } from './zoomBlurShader.js';

/** One shared texture pass for image treatments; all geometry is in CSS pixels. */
export const IMAGE_FILTER_FRAGMENT = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUv;
uniform sampler2D uImage;
uniform sampler2D uGlyphs;
uniform sampler2D uColorRamp;
uniform vec2 uResolution;
uniform vec2 uCover;
uniform vec2 uOffset;
uniform vec3 uColor;
uniform vec3 uBackground;
uniform float uKind;
uniform float uCell;
uniform float uIntensity;
uniform float uMonochrome;
uniform float uInvert;
uniform float uLevels;
uniform float uContrast;
uniform vec3 uAccent;
uniform float uGrain;
uniform float uGlow;
uniform float uScanlines;
uniform float uCurvature;
uniform float uTime;
uniform float uDistortion;
uniform float uTrail;
uniform float uThreshold;
uniform vec2 uCenter;
uniform float uRadius;
uniform float uSlices;
uniform vec2 uDirection;
uniform float uMatrix;
uniform float uMode;
uniform float uSeed;
uniform float uInterval;

vec4 sampleImage(vec2 uv) {
  return texture2D(uImage, clamp((uv - .5) * uCover + .5, vec2(.001), vec2(.999)));
}
float luminance(vec3 color) { return dot(color, vec3(.2126, .7152, .0722)); }
${HEATMAP_FILTER_FUNCTION}
${RETRO_FILTER_FUNCTIONS}
${SIGNAL_FILTER_FUNCTIONS}
${DISTORTION_FILTER_FUNCTIONS}
${DITHER_FILTER_FUNCTIONS}
${GLITCH_FILTER_FUNCTIONS}
${ZOOM_BLUR_FILTER_FUNCTIONS}
void main() {
  vec4 original = sampleImage(vUv);
  vec4 filtered = original;
  vec2 cell = vec2(uCell, uCell * (uKind < .5 ? 1.5 : 1.));
  vec2 point = vUv * uResolution;
  vec2 center = (floor(point / cell) + .5) * cell / uResolution;
  vec4 source = sampleImage(center);
  float light = mix(luminance(source.rgb), 1. - luminance(source.rgb), uInvert);
  vec2 local = fract(point / cell);
  if (uKind < .5) {
    float glyph = min(9., floor(light * 10.));
    float ink = texture2D(uGlyphs, vec2((glyph + local.x) / 10., 1. - local.y)).a;
    vec3 color = mix(source.rgb, uColor, uMonochrome);
    filtered = vec4(mix(uBackground, color, ink), source.a);
  } else if (uKind < 1.5) {
    // Radius follows sqrt(luminance): dot area, rather than radius, represents brightness.
    float radius = sqrt(light) * .71;
    float edge = min(.15, 1. / uCell);
    float ink = 1. - smoothstep(radius - edge, radius + edge, length(local - .5));
    vec3 color = mix(source.rgb, uColor, uMonochrome);
    filtered = vec4(mix(uBackground, color, ink), source.a);
  } else if (uKind < 2.5) {
    filtered = source;
  } else if (uKind < 3.5) {
    filtered = vec4(sampleImage(vUv + uOffset).r, original.g, sampleImage(vUv - uOffset).b, original.a);
  } else if (uKind < 7.5) {
    filtered = retroFilter(original, point);
  } else if (uKind < 12.5) {
    filtered = signalFilter(original, point);
  } else if (uKind < 13.5) {
    filtered = heatmapFilter(original);
  } else if (uKind < 18.5) {
    filtered = distortionFilter(original);
  } else if (uKind < 19.5) {
    filtered = ditherFilter(original, point);
  } else if (uKind < 20.5) {
    filtered = flashFilter(original, point);
  } else if (uKind < 21.5) {
    filtered = glitchFilter(original, point);
  } else {
    filtered = zoomBlurFilter(original, point);
  }
  gl_FragColor = mix(original, filtered, uIntensity);
}`;
