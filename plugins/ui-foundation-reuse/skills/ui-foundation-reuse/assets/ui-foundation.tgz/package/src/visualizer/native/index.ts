export { Visualizer } from './Visualizer.js';
export type { NativeVisualizerProps, NativeVisualizerProps as VisualizerProps } from './types.js';
export type { VisualizerOptions, VisualizerKind, ResolvedVisualizerConfig } from '../types.js';
export type { VisualizerAudioSource, VisualizerAudioFrame } from '../audioOps.js';
export { createAudioFrame } from '../audioOps.js';
export { resolveVisualizerConfig, VISUALIZER_KIND_NAMES } from '../presets.js';
export { VISUALIZER_KINDS } from '../types.js';
export { EffectsProvider } from '../../core/EffectsProvider.js';

export * from '../ambientGlowFrame.js';
export { createSmoothedAudioSource } from '../smoothedAudioSource.js';
export type { AudioEnvelopeOptions } from '../smoothedAudioSource.js';
