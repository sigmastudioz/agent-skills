import type { MediaDisclosureValue } from './types.js';
export function nextDisclosure(value: MediaDisclosureValue, id: string): MediaDisclosureValue {
  return { activeId: id, expanded: value.activeId !== id || !value.expanded };
}
