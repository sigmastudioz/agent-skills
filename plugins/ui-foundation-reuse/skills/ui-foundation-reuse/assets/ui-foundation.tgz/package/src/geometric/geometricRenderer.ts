import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import { GEOMETRIC_FRAGMENT, GEOMETRIC_VERTEX } from './geometricShader.js';
import type { ResolvedGeometricConfig } from './types.js';

export interface GeometricSource {
  image: HTMLCanvasElement | null;
  pixels: Uint8Array | null;
  width: number;
  height: number;
}

export interface GeometricRenderer extends WebGLRendererLike {
  render(
    config: ResolvedGeometricConfig,
    time: number,
    pointer: [number, number],
    pull: number,
    source: GeometricSource,
  ): void;
}

function rgb(hex: string): [number, number, number] {
  const text = hex.length === 4 ? hex.slice(1).split('').map(channel => channel + channel).join('') : hex.slice(1);
  const value = parseInt(text, 16);
  return [(value >> 16 & 255) / 255, (value >> 8 & 255) / 255, (value & 255) / 255];
}

export function createGeometricRenderer(canvas: HTMLCanvasElement): GeometricRenderer | null {
  const gl = canvas.getContext('webgl', { alpha: false, antialias: false, preserveDrawingBuffer: true });
  if (!gl) return null;
  const shaders: WebGLShader[] = [];
  let program: WebGLProgram | null = null;
  let buffer: WebGLBuffer | null = null;
  let texture: WebGLTexture | null = null;
  const dispose = () => {
    if (texture) gl.deleteTexture(texture);
    if (buffer) gl.deleteBuffer(buffer);
    if (program) gl.deleteProgram(program);
    shaders.forEach(shader => gl.deleteShader(shader));
  };
  try {
    for (const [type, source] of [[gl.VERTEX_SHADER, GEOMETRIC_VERTEX], [gl.FRAGMENT_SHADER, GEOMETRIC_FRAGMENT]] as const) {
      const shader = gl.createShader(type);
      if (!shader) throw new Error('Shader allocation failed');
      shaders.push(shader);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || 'Shader compilation failed');
    }
    program = gl.createProgram();
    if (!program) throw new Error('Program allocation failed');
    shaders.forEach(shader => gl.attachShader(program!, shader));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program) || 'Program linking failed');
    buffer = gl.createBuffer();
    texture = gl.createTexture();
    if (!buffer || !texture) throw new Error('Buffer allocation failed');
    gl.useProgram(program);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const position = gl.getAttribLocation(program, 'aPosition');
    gl.enableVertexAttribArray(position);
    gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 1);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([7, 20, 28, 255]));
    const names = [
      'uResolution', 'uPointer', 'uTexel', 'uPull', 'uTime', 'uLevels', 'uContour', 'uFlow',
      'uCurtain', 'uDither', 'uMemory', 'uGrain', 'uSource', 'uInkOpacity', 'uBackground', 'uInk', 'uAccent', 'uSourceTex',
    ];
    const uniforms = Object.fromEntries(names.map(name => [name, gl.getUniformLocation(program!, name)]));
    gl.uniform1i(uniforms.uSourceTex, 0);
    let imageToken: HTMLCanvasElement | null = null;
    return {
      resize(width, height, dpr) {
        canvas.width = Math.max(1, Math.round(width * dpr));
        canvas.height = Math.max(1, Math.round(height * dpr));
        gl.viewport(0, 0, canvas.width, canvas.height);
      },
      render(config, time, pointer, pull, source) {
        gl.useProgram(program);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        if (source.image && source.image !== imageToken) {
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source.image);
          imageToken = source.image;
        } else if (!source.image && source.pixels) {
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, source.width, source.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, source.pixels);
          imageToken = null;
        }
        gl.uniform2f(uniforms.uResolution, canvas.width, canvas.height);
        gl.uniform2f(uniforms.uPointer, pointer[0], pointer[1]);
        gl.uniform2f(uniforms.uTexel, 1 / Math.max(1, source.width), 1 / Math.max(1, source.height));
        gl.uniform1f(uniforms.uPull, pull);
        gl.uniform1f(uniforms.uTime, time);
        gl.uniform1f(uniforms.uLevels, config.levels);
        gl.uniform1f(uniforms.uContour, config.contour);
        gl.uniform1f(uniforms.uFlow, config.flow);
        gl.uniform1f(uniforms.uCurtain, config.curtain);
        gl.uniform1f(uniforms.uDither, config.dither);
        gl.uniform1f(uniforms.uMemory, config.memory);
        gl.uniform1f(uniforms.uGrain, config.grain);
        gl.uniform1f(uniforms.uSource, config.sourceOpacity);
        gl.uniform1f(uniforms.uInkOpacity, config.inkOpacity);
        gl.uniform3f(uniforms.uBackground, ...rgb(config.background));
        gl.uniform3f(uniforms.uInk, ...rgb(config.ink));
        gl.uniform3f(uniforms.uAccent, ...rgb(config.accent));
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      },
      dispose,
    };
  } catch {
    dispose();
    return null;
  }
}
