// Original procedural material: warped satin folds, spectral bands and softbox light.
// WebGL 1 / GLSL ES 1.00, no textures or renderer dependencies.
export const IRIDESCENCE_VERTEX = `
attribute vec2 aPosition;
void main() { gl_Position = vec4(aPosition, 0.0, 1.0); }
`;

export const IRIDESCENCE_FRAGMENT = `
precision highp float;
uniform vec2 uResolution;
uniform vec2 uPointer;
uniform float uTime;
uniform float uScale;
uniform float uRotation;
uniform float uIntensity;
uniform float uRoughness;
uniform vec3 uBase;
uniform vec3 uAccent;

float surface(vec2 p, float t) {
  float bend = sin(p.y * 0.9 + t * 0.31) * 0.75;
  float broad = sin(p.x * 1.65 + bend + t * 0.24);
  float fold = sin(p.x * 3.1 - p.y * 0.8 + broad * 1.2 - t * 0.3);
  float ripple = sin(p.y * 2.1 + p.x * 0.6 + t * 0.18);
  return broad * 0.72 + fold * 0.22 + ripple * 0.15;
}

void main() {
  vec2 uv = gl_FragCoord.xy / uResolution;
  vec2 p = (gl_FragCoord.xy - 0.5 * uResolution) / min(uResolution.x, uResolution.y);
  float c = cos(uRotation), s = sin(uRotation);
  p = mat2(c, -s, s, c) * p * 3.0 * uScale;
  float h = surface(p, uTime);
  float e = 0.012;
  vec2 slope = vec2(surface(p + vec2(e,0.0), uTime) - h,
                    surface(p + vec2(0.0,e), uTime) - h) / e;
  vec3 n = normalize(vec3(-slope * 1.25, 1.0));
  vec3 light = normalize(vec3(uPointer * 0.8 + vec2(-0.5, 0.7), 1.3));
  vec3 halfway = normalize(light + vec3(0.0, 0.0, 1.0));
  float diffuse = max(dot(n, light), 0.0);
  float fresnel = pow(1.0 - n.z, 1.6);
  float specular = pow(max(dot(n, halfway), 0.0), mix(100.0, 5.0, uRoughness));
  float phase = h * 0.65 + (1.0 - n.z) * 1.7 + n.x * 0.45;
  vec3 spectral = 0.5 + 0.5 * cos(6.2831853 * (phase + vec3(0.0, 0.33, 0.67)));
  vec3 color = uBase * (0.2 + diffuse * 0.65);
  color += mix(uAccent * 0.45, spectral, uIntensity) * (0.16 + fresnel * 0.7 + diffuse * 0.22);
  color += uAccent * specular * 0.65;
  float edge = 1.0 - smoothstep(0.05, 0.8, length(uv - 0.5));
  color *= 0.78 + 0.22 * edge;
  color = color / (1.0 + color * 0.25);
  gl_FragColor = vec4(pow(max(color, vec3(0.0)), vec3(0.85)), 1.0);
}
`;
