/** Rounded cylindrical ribs, directional diffusion and dispersive edge light. */
export const FLUTED_GLASS_FRAGMENT = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUv;
uniform sampler2D uImage;
uniform vec2 uResolution;
uniform vec2 uCover;
uniform float uRibWidth;
uniform float uRefraction;
uniform float uBlur;
uniform float uChromaticSeparation;
uniform float uHighlight;

vec4 source(vec2 uv) {
  vec4 pixel = texture2D(uImage, clamp((uv - .5) * uCover + .5, 0., 1.));
  return vec4(pixel.rgb * pixel.a, pixel.a);
}
vec4 diffuse(vec2 uv) {
  vec2 stepUv = vec2(uBlur / uResolution.x, 0.);
  vec4 pixel = source(uv) * .375;
  pixel += (source(uv - stepUv * .5) + source(uv + stepUv * .5)) * .25;
  pixel += (source(uv - stepUv) + source(uv + stepUv)) * .0625;
  return vec4(pixel.a > .00001 ? pixel.rgb / pixel.a : vec3(0.), pixel.a);
}
void main() {
  float phase = vUv.x * uResolution.x / uRibWidth * 6.28318530718;
  float slope = sin(phase);
  vec2 refracted = vUv + vec2(slope * uRibWidth * .42 * uRefraction / uResolution.x, 0.);
  vec2 dispersion = vec2(slope * uChromaticSeparation / uResolution.x, 0.);
  vec4 center = diffuse(refracted);
  vec3 color = vec3(diffuse(refracted + dispersion).r, center.g, diffuse(refracted - dispersion).b);
  float glint = pow(.5 + .5 * cos(phase + .8), 24.);
  color *= 1. + uHighlight * (.13 * cos(phase) - .18 * slope);
  color = mix(color, vec3(1.), glint * uHighlight * .35);
  gl_FragColor = vec4(clamp(color, 0., 1.), center.a);
}
`;
