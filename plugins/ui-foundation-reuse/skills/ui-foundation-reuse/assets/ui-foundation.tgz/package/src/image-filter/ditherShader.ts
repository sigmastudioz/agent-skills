/** Ordered dither and on-camera flash. Reuse the shared sampler, tone and hash helpers. */
export const DITHER_FILTER_FUNCTIONS = `
float ditherBayer2(vec2 a) {
  // Reduce first: large squared coordinates would lose mediump precision.
  a = mod(floor(a), 2.);
  return fract(a.x * .5 + a.y * a.y * .75);
}
float ditherBayer4(vec2 a) { return ditherBayer2(.5 * a) * .25 + ditherBayer2(a); }
float ditherBayer(vec2 a) {
  return uMatrix < 6. ? ditherBayer4(a) : ditherBayer4(.5 * a) * .25 + ditherBayer2(a);
}
vec4 ditherFilter(vec4 original, vec2 point) {
  vec2 cell = floor(point / uCell);
  vec4 source = sampleImage((cell + .5) * uCell / uResolution);
  float steps = uLevels - 1.;
  // Uniform thresholds preserve mean tone: floor(light * steps + t) averages light * steps.
  float tone = clamp(floor(retroLight(source.rgb) * steps + ditherBayer(cell)) / steps, 0., 1.);
  return vec4(texture2D(uColorRamp, vec2((tone * 255. + .5) / 256., .5)).rgb, source.a);
}
vec4 flashFilter(vec4 original, vec2 point) {
  vec2 p = distortionPoint(vUv);
  float falloff = 1. - smoothstep(0., uRadius, length(p));
  vec3 color = original.rgb * (1. + uDistortion * 1.6 * falloff);
  vec3 bloom = vec3(0.);
  for (int i = 0; i < 8; i++) {
    float turn = float(i) * .78539816;
    vec2 tap = vec2(cos(turn), sin(turn)) * uCell * 1.5 / uResolution;
    bloom += max(sampleImage(vUv + tap).rgb * (1. + uDistortion * falloff) - uThreshold, 0.);
  }
  color += bloom * .25 * uGlow;
  color = (color - .5) * uContrast + .5;
  color *= 1. - (1. - falloff) * .45 * uDistortion;
  color += (retroHash(floor(point)) - .5) * uGrain * .15;
  return vec4(clamp(color, 0., 1.), original.a);
}
`;
