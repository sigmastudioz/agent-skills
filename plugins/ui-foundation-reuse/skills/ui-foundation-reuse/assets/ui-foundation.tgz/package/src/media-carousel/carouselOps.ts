import { clampNumber } from '../core/numberOps.js';
export function resolveCarouselWindow(length: number, index: number, visibleCount = 1) {
  const count = Math.max(1, Math.min(length || 1, Math.floor(clampNumber(visibleCount, 1, 6, 1))));
  const maximum = Math.max(0, length - count);
  const start = Math.floor(clampNumber(index, 0, maximum, 0));
  return { count, maximum, start, end: Math.min(length, start + count) };
}
