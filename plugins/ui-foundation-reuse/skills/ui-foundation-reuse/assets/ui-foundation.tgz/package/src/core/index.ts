export { finiteNumberOr, clampNumber } from './numberOps.js';
export { useRafLoop } from './useRafLoop.js';
export type { RafCallback } from './useRafLoop.js';
export { useReducedMotion } from './useReducedMotion.js';
export { useInView } from './useInView.js';
export type { UseInViewOptions } from './useInView.js';
export { useScrollProgress } from './useScrollProgress.js';
export type { UseScrollProgressOptions } from './useScrollProgress.js';
export { useWebGLEffect } from './useWebGLEffect.js';
export type {
  WebGLRendererLike,
  UseWebGLEffectParams,
  WebGLEffectHandle,
} from './useWebGLEffect.js';
export { EffectsProvider, useEffectsSettings } from './EffectsProvider.js';
export type { EffectsProviderProps, EffectsSettings } from './EffectsProvider.js';
export { usePageVisible } from './usePageVisible.js';

export { createInteractionSignal, normalizePointer, useInteraction } from './interaction.js';
export type { InteractionSignal, InteractionState } from './interaction.js';
export { useAdaptiveQuality } from './adaptiveQuality.js';
