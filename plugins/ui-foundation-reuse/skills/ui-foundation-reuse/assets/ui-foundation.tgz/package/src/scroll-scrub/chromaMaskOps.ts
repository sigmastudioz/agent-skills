import { clampNumber } from '../core/numberOps.js';

/** Retain dominant blue/green background pixels; neutral/foreground pixels become transparent. */
export function maskChromaPixels(pixels: Uint8ClampedArray, channel: 'blue' | 'green', threshold = 20, softness = 60): void {
  const cutoff = clampNumber(threshold, 0, 255, 20);
  const feather = clampNumber(softness, 1, 255, 60);
  const key = channel === 'green' ? 1 : 2;
  const other = channel === 'green' ? 2 : 1;
  for (let index = 0; index + 3 < pixels.length; index += 4) {
    const dominance = pixels[index + key] - Math.max(pixels[index], pixels[index + other]);
    const alpha = clampNumber((dominance - cutoff) / feather, 0, 1, 0);
    pixels[index + 3] = Math.round(pixels[index + 3] * alpha);
  }
}
