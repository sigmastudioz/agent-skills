import { clampNumber } from '../core/numberOps.js';

export function cursorProgress(position: number, origin: number, length: number, reverse = false): number {
  if (![position, origin, length].every(Number.isFinite) || length <= 0) return .5;
  const progress = clampNumber((position - origin) / length, 0, 1, .5);
  return reverse ? 1 - progress : progress;
}

export function videoRangeProgress(progress: number, start = 0, end = 1): number {
  const from = clampNumber(start, 0, 1, 0), to = clampNumber(end, from, 1, 1);
  return from + clampNumber(progress, 0, 1, .5) * (to - from);
}
