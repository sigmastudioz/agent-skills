import type { FieldPoint } from './types.js';

export const FIELD_SIZE = 128;

export function clamp01(value: number): number {
  if (value < 0) return 0;
  if (value > 1) return 1;
  return value;
}

/** Pull a sample toward the pointer. Strength 0 is the identity. Matches the shader. */
export function warpUv(x: number, y: number, px: number, py: number, strength: number): [number, number] {
  if (strength <= 0) return [x, y];
  const dx = px - x;
  const dy = py - y;
  const dist = Math.hypot(dx, dy) + 0.001;
  const pull = Math.exp(-dist * 3.2) * 0.18 * strength;
  return [clamp01(x + (dx / dist) * pull), clamp01(y + (dy / dist) * pull)];
}

function smoother(edge0: number, edge1: number, value: number): number {
  const span = edge1 - edge0;
  const t = span === 0 ? 0 : clamp01((value - edge0) / span);
  return t * t * (3 - 2 * t);
}

/** Procedural portrait field. `v` is 0 at the bottom, 1 at the top. */
export function proceduralColor(u: number, v: number, seed: number, time: number): { r: number; g: number; b: number; l: number } {
  const drift = Math.sin(time * 0.35) * 0.012;
  const head = Math.hypot((u - 0.5) / 0.15, (v - 0.64) / 0.19);
  const torso = Math.hypot((u - 0.5 + drift) / 0.3, (v - 0.34) / 0.3);
  const figure = Math.max(smoother(1.05, 0.78, head), smoother(1.08, 0.82, torso) * 0.92);
  const eyeL = Math.exp(-Math.hypot(u - 0.445, v - 0.655) * 52);
  const eyeR = Math.exp(-Math.hypot(u - 0.555, v - 0.655) * 52);
  const mouth = Math.exp(-(((u - 0.5) ** 2) / 0.0016 + ((v - 0.59) ** 2) / 0.00015));
  const hair = smoother(0.7, 0.88, v) * Math.exp(-((u - 0.5) ** 2) / 0.03);
  const neck = Math.exp(-((u - 0.5) ** 2) / 0.012) * smoother(0.5, 0.36, v) * smoother(0.28, 0.4, v);
  const ridges = Math.sin((u * 22 + seed * 0.17) + time * 0.5) * Math.sin(v * 16 - time * 0.4);
  const ring = Math.sin(Math.hypot(u - 0.5, v - 0.5) * 46 - time * 0.9);
  const horizon = smoother(0.18, 0.62, v);
  const l = clamp01(0.08 + horizon * 0.2 + figure * 0.7 + hair * 0.22 + neck * 0.28
    - eyeL * 0.55 - eyeR * 0.55 - mouth * 0.35
    + ridges * 0.05 * (0.25 + figure) + ring * 0.035);
  return {
    r: clamp01(0.04 + l * 0.48 + figure * 0.22),
    g: clamp01(0.08 + l * 0.55 + figure * 0.06),
    b: clamp01(0.16 + l * 0.62 + (1 - figure) * 0.08),
    l,
  };
}

/** Row 0 is the top of the frame. */
export function writeProceduralField(pixels: Uint8Array, lum: Float32Array, seed: number, time: number): void {
  const h = Math.round(Math.sqrt(lum.length));
  const w = h;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const sample = proceduralColor((x + 0.5) / w, 1 - (y + 0.5) / h, seed, time);
      const i = y * w + x;
      const p = i * 4;
      pixels[p] = Math.round(sample.r * 255);
      pixels[p + 1] = Math.round(sample.g * 255);
      pixels[p + 2] = Math.round(sample.b * 255);
      pixels[p + 3] = 255;
      lum[i] = sample.l;
    }
  }
}

export function sampleLum(lum: Float32Array, w: number, h: number, u: number, v: number): number {
  const x = clamp01(u) * (w - 1);
  const y = clamp01(1 - v) * (h - 1);
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const x1 = Math.min(w - 1, x0 + 1);
  const y1 = Math.min(h - 1, y0 + 1);
  const tx = x - x0;
  const ty = y - y0;
  const at = (yy: number, xx: number) => lum[yy * w + xx];
  return at(y0, x0) * (1 - tx) * (1 - ty) + at(y0, x1) * tx * (1 - ty)
    + at(y1, x0) * (1 - tx) * ty + at(y1, x1) * tx * ty;
}

/** Source window for a cover crop into a destination aspect. */
export function coverSourceRect(
  srcW: number, srcH: number, dstW: number, dstH: number,
): { sx: number; sy: number; sw: number; sh: number } {
  if (srcW <= 0 || srcH <= 0 || dstW <= 0 || dstH <= 0) return { sx: 0, sy: 0, sw: Math.max(srcW, 0), sh: Math.max(srcH, 0) };
  const srcAspect = srcW / srcH;
  const dstAspect = dstW / dstH;
  if (srcAspect > dstAspect) {
    const sw = srcH * dstAspect;
    return { sx: (srcW - sw) / 2, sy: 0, sw, sh: srcH };
  }
  const sh = srcW / dstAspect;
  return { sx: 0, sy: (srcH - sh) / 2, sw: srcW, sh };
}

export function warpLuminance(
  lum: Float32Array, w: number, h: number, px: number, py: number, strength: number,
): Float32Array {
  if (strength <= 0) return lum;
  const out = new Float32Array(lum.length);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const [u, v] = warpUv((x + 0.5) / w, 1 - (y + 0.5) / h, px, py, strength);
      out[y * w + x] = sampleLum(lum, w, h, u, v);
    }
  }
  return out;
}

function magAt(mag: Float32Array, w: number, h: number, x: number, y: number): number {
  const xx = Math.max(0, Math.min(w - 1, Math.round(x)));
  const yy = Math.max(0, Math.min(h - 1, Math.round(y)));
  return mag[yy * w + xx];
}

/** Sobel magnitude plus non-maximum suppression. Points are in y-up 0–1 space. */
export function extractPoints(lum: Float32Array, w: number, h: number, threshold: number, limit: number): FieldPoint[] {
  const mag = new Float32Array(lum.length);
  const gxA = new Float32Array(lum.length);
  const gyA = new Float32Array(lum.length);
  const at = (x: number, y: number) => lum[Math.max(0, Math.min(h - 1, y)) * w + Math.max(0, Math.min(w - 1, x))];
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const tl = at(x - 1, y - 1);
      const tc = at(x, y - 1);
      const tr = at(x + 1, y - 1);
      const ml = at(x - 1, y);
      const mr = at(x + 1, y);
      const bl = at(x - 1, y + 1);
      const bc = at(x, y + 1);
      const br = at(x + 1, y + 1);
      const gx = -tl - 2 * ml - bl + tr + 2 * mr + br;
      const gy = -tl - 2 * tc - tr + bl + 2 * bc + br;
      const i = y * w + x;
      mag[i] = Math.hypot(gx, gy);
      gxA[i] = gx;
      gyA[i] = gy;
    }
  }
  let peak = 0;
  for (let i = 0; i < mag.length; i++) if (mag[i] > peak) peak = mag[i];
  const strictness = threshold <= 0 ? 0 : threshold >= 4 ? 1 : threshold / 4;
  const cutoff = peak * (0.2 + strictness * 0.65);
  const candidates: FieldPoint[] = [];
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const m = mag[i];
      if (m <= cutoff) continue;
      const pixelAngle = Math.atan2(gyA[i], gxA[i]);
      const sx = Math.cos(pixelAngle);
      const sy = Math.sin(pixelAngle);
      if (m < magAt(mag, w, h, x + sx, y + sy) || m < magAt(mag, w, h, x - sx, y - sy)) continue;
      candidates.push({
        x: (x + 0.5) / w,
        y: 1 - (y + 0.5) / h,
        strength: Math.min(1, m / 4),
        angle: Math.atan2(-gyA[i], gxA[i]),
      });
    }
  }
  candidates.sort((a, b) => b.strength - a.strength);
  const spacing = 0.05 * Math.sqrt(64 / Math.max(8, limit));
  const spacing2 = spacing * spacing;
  const chosen: FieldPoint[] = [];
  for (const point of candidates) {
    if (chosen.length >= limit) break;
    if (chosen.some(other => (other.x - point.x) ** 2 + (other.y - point.y) ** 2 < spacing2)) continue;
    chosen.push(point);
  }
  return chosen;
}

export interface ImagePlane {
  canvas: HTMLCanvasElement;
  lum: Float32Array;
}

/** Cover-crop `image` into a GPU texture and a matching luminance grid. Browser only. */
export function readImagePlane(
  image: CanvasImageSource & { width: number; height: number },
  dstW: number,
  dstH: number,
): ImagePlane | null {
  if (typeof document === 'undefined' || image.width <= 0 || image.height <= 0) return null;
  const edge = Math.max(dstW, dstH);
  const maxEdge = Math.min(1024, Math.max(image.width, image.height, edge));
  const aspect = dstW / Math.max(1, dstH);
  const canvas = document.createElement('canvas');
  canvas.width = aspect >= 1 ? maxEdge : Math.max(1, Math.round(maxEdge * aspect));
  canvas.height = aspect >= 1 ? Math.max(1, Math.round(maxEdge / aspect)) : maxEdge;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return null;
  const crop = coverSourceRect(image.width, image.height, canvas.width, canvas.height);
  ctx.drawImage(image, crop.sx, crop.sy, crop.sw, crop.sh, 0, 0, canvas.width, canvas.height);
  const field = document.createElement('canvas');
  field.width = FIELD_SIZE;
  field.height = FIELD_SIZE;
  const fieldCtx = field.getContext('2d', { willReadFrequently: true });
  if (!fieldCtx) return null;
  fieldCtx.drawImage(canvas, 0, 0, FIELD_SIZE, FIELD_SIZE);
  let data: Uint8ClampedArray;
  try {
    data = fieldCtx.getImageData(0, 0, FIELD_SIZE, FIELD_SIZE).data;
  } catch {
    return null;
  }
  const lum = new Float32Array(FIELD_SIZE * FIELD_SIZE);
  for (let i = 0, p = 0; i < lum.length; i++, p += 4) {
    lum[i] = (data[p] * 0.2126 + data[p + 1] * 0.7152 + data[p + 2] * 0.0722) / 255;
  }
  return { canvas, lum };
}
