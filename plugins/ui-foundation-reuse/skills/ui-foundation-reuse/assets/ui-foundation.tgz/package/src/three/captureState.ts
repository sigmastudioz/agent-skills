const auxiliaryCaptures = new WeakSet<object>();
export const isAuxiliaryCapture = (renderer: object): boolean => auxiliaryCaptures.has(renderer);

/** Per-pass scratch state; callers guard re-entry. Restore even after a failed GPU draw. */
export function createRenderState(three: any) {
  const viewport = new three.Vector4(), color = new three.Color();
  return function preserve<T>(renderer: any, draw: () => T): T {
    const target = renderer.getRenderTarget(), face = renderer.getActiveCubeFace(), mip = renderer.getActiveMipmapLevel();
    renderer.getCurrentViewport(viewport); renderer.getClearColor(color);
    const alpha = renderer.getClearAlpha(), xr = renderer.xr.enabled;
    const autoClear = renderer.autoClear, toneMapping = renderer.toneMapping, shadowUpdate = renderer.shadowMap.autoUpdate;
    try { return draw(); }
    finally {
      renderer.xr.enabled = xr; renderer.autoClear = autoClear; renderer.toneMapping = toneMapping;
      renderer.shadowMap.autoUpdate = shadowUpdate; renderer.setClearColor(color, alpha);
      renderer.setRenderTarget(target, face, mip); renderer.state.viewport(viewport);
    }
  };
}
/** Reflections and shadow captures draw cached surfaces rather than recursively recapturing them. */
export function captureAuxiliary<T>(renderer: object, draw: () => T): T | undefined {
  if (isAuxiliaryCapture(renderer)) return;
  auxiliaryCaptures.add(renderer);
  try { return draw(); } finally { auxiliaryCaptures.delete(renderer); }
}
