/** Small owned WebGL pass. Locations and geometry are allocated once, never per frame. */
export const FULLSCREEN_VERTEX = 'attribute vec2 aPosition; varying vec2 vUv; void main(){vUv=aPosition*.5+.5;gl_Position=vec4(aPosition,0.,1.);}';

/** KHR_parallel_shader_compile: the driver compiles on another thread and reports when it is done. */
const COMPLETION_STATUS = 0x91B1;

export interface PassStatus { ready: boolean; error?: Error }
interface Pending { settle(): boolean }
interface Watch { pending: Set<Pending>; listeners: Set<(status: PassStatus) => void>; frame: number }
const watches = new WeakMap<object, Watch>();
const watchOf = (gl: object): Watch => {
  let watch = watches.get(gl);
  if (!watch) { watch = { pending: new Set(), listeners: new Set(), frame: 0 }; watches.set(gl, watch); }
  return watch;
};
const frames = (callback: () => void): number => (typeof requestAnimationFrame === 'function' ? requestAnimationFrame(callback) : (setTimeout(callback, 16) as unknown as number));
const cancel = (id: number) => { if (typeof cancelAnimationFrame === 'function') cancelAnimationFrame(id); else clearTimeout(id as unknown as ReturnType<typeof setTimeout>); };

function poll(gl: object): void {
  const watch = watchOf(gl);
  if (watch.frame || !watch.pending.size) return;
  watch.frame = frames(() => {
    watch.frame = 0;
    let error: Error | undefined, settled = false;
    for (const pass of [...watch.pending]) {
      try { if (pass.settle()) { watch.pending.delete(pass); settled = true; } }
      catch (reason) { watch.pending.delete(pass); settled = true; error = reason instanceof Error ? reason : new Error(String(reason)); }
    }
    if (error) watch.listeners.forEach(listener => listener({ ready: false, error }));
    else if (settled && !watch.pending.size) watch.listeners.forEach(listener => listener({ ready: true }));
    poll(gl);
  });
}

/**
 * Hear when the passes of a context finish compiling in the background, or fail. Passes draw
 * nothing until then, so a still (paused or reduced-motion) effect needs this to draw its
 * frame. Returns an unsubscribe function. Nothing is reported for a context that compiled
 * synchronously.
 */
export function watchPasses(gl: object | null | undefined, listener: (status: PassStatus) => void): () => void {
  if (!gl) return () => {};
  const watch = watchOf(gl);
  watch.listeners.add(listener);
  return () => { watch.listeners.delete(listener); if (!watch.listeners.size && !watch.pending.size && watch.frame) { cancel(watch.frame); watch.frame = 0; } };
}

/** True while any pass of this context is still compiling. */
export function passesPending(gl: object | null | undefined): boolean {
  return !!gl && (watches.get(gl)?.pending.size ?? 0) > 0;
}

/**
 * Compile and link a fullscreen pass. Where the browser can compile in the background
 * (KHR_parallel_shader_compile), this returns at once: asking for the compile status straight
 * away is what blocks the main thread for hundreds of milliseconds. Until the program is ready
 * `use()` and `draw()` do nothing and `uniforms` is empty (setting a missing uniform is a
 * no-op in WebGL); `watchPasses` reports readiness or a late compile error. Without the
 * extension it compiles synchronously and throws on error, as before.
 */
export function createFullscreenPass(gl: WebGLRenderingContext, fragment: string, names: string[]) {
  const shaders: WebGLShader[] = [];
  let program: WebGLProgram | null = null;
  let buffer: WebGLBuffer | null = null;
  let disposed = false, ready = false, position = -1;
  const uniforms: Record<string, WebGLUniformLocation | null> = {};
  const watch = watchOf(gl);
  const pending: Pending = { settle: () => settle() };
  const dispose = () => {
    if (disposed) return; disposed = true; watch.pending.delete(pending);
    shaders.forEach(s => gl.deleteShader(s)); if (program) gl.deleteProgram(program); if (buffer) gl.deleteBuffer(buffer);
  };
  const finish = () => {
    for (const shader of shaders) {
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || 'Shader compile failed');
    }
    if (!gl.getProgramParameter(program!, gl.LINK_STATUS)) throw new Error('Program link failed');
    position = gl.getAttribLocation(program!, 'aPosition');
    for (const name of names) uniforms[name] = gl.getUniformLocation(program!, name);
    ready = true;
  };
  /** True once usable; throws when the background compile failed. */
  function settle(): boolean {
    if (ready || disposed) return true;
    if (!gl.getProgramParameter(program!, COMPLETION_STATUS)) return false;
    finish();
    return true;
  }
  try {
    const parallel = !!gl.getExtension?.('KHR_parallel_shader_compile');
    for (const [type, source] of [[gl.VERTEX_SHADER, FULLSCREEN_VERTEX], [gl.FRAGMENT_SHADER, fragment]] as const) {
      const shader = gl.createShader(type); if (!shader) throw new Error('Shader allocation failed');
      shaders.push(shader); gl.shaderSource(shader, source); gl.compileShader(shader);
      if (!parallel && !gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || 'Shader compile failed');
    }
    program = gl.createProgram(); if (!program) throw new Error('Program allocation failed');
    shaders.forEach(shader => gl.attachShader(program!, shader)); gl.linkProgram(program);
    buffer = gl.createBuffer(); if (!buffer) throw new Error('Buffer allocation failed');
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,3,-1,-1,3]), gl.STATIC_DRAW);
    if (parallel) { watch.pending.add(pending); poll(gl); } else finish();
    return { uniforms, dispose,
      /** False while the program is still compiling in the background. */
      get ready() { return ready; },
      draw() {
        if (ready) gl.drawArrays(gl.TRIANGLES, 0, 3);
      }, use() {
        if (!ready) return;
        gl.useProgram(program); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
        gl.enableVertexAttribArray(position); gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
      } };
  } catch (error) { dispose(); throw error; }
}
export function createTexture(gl: WebGLRenderingContext): WebGLTexture {
  const texture = gl.createTexture(); if (!texture) throw new Error('Texture allocation failed');
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return texture;
}
