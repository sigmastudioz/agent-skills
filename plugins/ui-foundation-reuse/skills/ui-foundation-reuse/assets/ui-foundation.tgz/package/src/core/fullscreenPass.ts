/** Small owned WebGL pass. Locations and geometry are allocated once, never per frame. */
export const FULLSCREEN_VERTEX = 'attribute vec2 aPosition; varying vec2 vUv; void main(){vUv=aPosition*.5+.5;gl_Position=vec4(aPosition,0.,1.);}';
export function createFullscreenPass(gl: WebGLRenderingContext, fragment: string, names: string[]) {
  const shaders: WebGLShader[] = [];
  let program: WebGLProgram | null = null;
  let buffer: WebGLBuffer | null = null;
  const dispose = () => { shaders.forEach(s => gl.deleteShader(s)); if (program) gl.deleteProgram(program); if (buffer) gl.deleteBuffer(buffer); };
  try {
    for (const [type, source] of [[gl.VERTEX_SHADER, FULLSCREEN_VERTEX], [gl.FRAGMENT_SHADER, fragment]] as const) {
      const shader = gl.createShader(type); if (!shader) throw new Error('Shader allocation failed');
      shaders.push(shader); gl.shaderSource(shader, source); gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || 'Shader compile failed');
    }
    program = gl.createProgram(); if (!program) throw new Error('Program allocation failed');
    shaders.forEach(shader => gl.attachShader(program!, shader)); gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error('Program link failed');
    buffer = gl.createBuffer(); if (!buffer) throw new Error('Buffer allocation failed');
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,3,-1,-1,3]), gl.STATIC_DRAW);
    const position = gl.getAttribLocation(program, 'aPosition');
    const uniforms = Object.fromEntries(names.map(name => [name, gl.getUniformLocation(program!, name)]));
    return { uniforms, dispose, draw() {
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    }, use() {
      gl.useProgram(program); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.enableVertexAttribArray(position); gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
    } };
  } catch (error) { dispose(); throw error; }
}
export function createTexture(gl: WebGLRenderingContext): WebGLTexture {
  const texture = gl.createTexture(); if (!texture) throw new Error('Texture allocation failed');
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return texture;
}
