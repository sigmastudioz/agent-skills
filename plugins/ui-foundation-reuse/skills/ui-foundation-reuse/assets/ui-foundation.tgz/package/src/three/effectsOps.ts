import { clampNumber } from '../core/numberOps.js';
import type { StageEffectProps } from './stagingOps.js';

export interface AmbientOcclusionOptions {
  /** How far, in scene units, a surface looks for nearby geometry, 0.02–5. Default 0.4. */
  radius?: number;
  /** Strength of the darkening, 0–2. Default 1. */
  intensity?: number;
}
export interface DepthOfFieldOptions {
  /** Distance from the camera that is sharp, in scene units, 0.01–1000. Default 5. */
  focus?: number;
  /** Blur gained per scene unit away from `focus`, as a fraction of the frame, 0–0.1. Default 0.004. */
  aperture?: number;
  /** Largest blur, as a fraction of the frame, 0–0.05. Default 0.012. */
  maxBlur?: number;
}
export interface BloomOptions {
  strength?: number;
  radius?: number;
  /** Linear HDR luminance threshold; values above 1 isolate emissive objects. */
  threshold?: number;
}

/** Camera and lens finishing drawn after the scene. See `PostEffects`. */
export interface PostEffectsProps extends StageEffectProps {
  /** Soft darkening where surfaces meet (creases, contact). `true` for defaults. */
  ambientOcclusion?: boolean | AmbientOcclusionOptions;
  /** Blur away from a focus distance. `true` for defaults. */
  depthOfField?: boolean | DepthOfFieldOptions;
  /** Glow around bright light. `true` for defaults. Use this instead of a separate `Bloom`. */
  bloom?: boolean | BloomOptions;
  /** Maximum render-target side in physical pixels, 64–4096. Default 2048, so a typical canvas is not softened. */
  resolution?: number;
}

export interface PostEffectsConfig {
  enabled: boolean;
  resolution: number;
  ambientOcclusion: { radius: number; intensity: number } | null;
  depthOfField: { focus: number; aperture: number; maxBlur: number } | null;
  bloom: { strength: number; radius: number; threshold: number } | null;
}

const options = <T extends object>(value: boolean | T | undefined): T | null =>
  value === true ? ({} as T) : value && typeof value === 'object' ? value : null;

export function resolvePostEffectsConfig(props: PostEffectsProps = {}): PostEffectsConfig {
  const ao = options<AmbientOcclusionOptions>(props.ambientOcclusion);
  const dof = options<DepthOfFieldOptions>(props.depthOfField);
  const bloom = options<BloomOptions>(props.bloom);
  return {
    enabled: props.enabled !== false,
    resolution: Math.round(clampNumber(props.resolution, 64, 4096, 2048)),
    ambientOcclusion: ao && { radius: clampNumber(ao.radius, 0.02, 5, 0.4), intensity: clampNumber(ao.intensity, 0, 2, 1) },
    depthOfField: dof && { focus: clampNumber(dof.focus, 0.01, 1000, 5), aperture: clampNumber(dof.aperture, 0, 0.1, 0.004), maxBlur: clampNumber(dof.maxBlur, 0, 0.05, 0.012) },
    bloom: bloom && { strength: clampNumber(bloom.strength, 0, 5, 0.8), radius: clampNumber(bloom.radius, 0, 1, 0.4), threshold: clampNumber(bloom.threshold, 0, 10, 1) },
  };
}

/** Which passes exist. A change here rebuilds the chain; anything else only updates values. */
export function postEffectsShape(config: PostEffectsConfig): string {
  return `${config.ambientOcclusion ? 'a' : '-'}${config.depthOfField ? 'd' : '-'}${config.bloom ? 'b' : '-'}`;
}

/** True when the chain would draw the scene unchanged. */
export function postEffectsIdle(config: PostEffectsConfig): boolean {
  return !config.enabled || (!config.ambientOcclusion && !config.depthOfField && !config.bloom);
}
