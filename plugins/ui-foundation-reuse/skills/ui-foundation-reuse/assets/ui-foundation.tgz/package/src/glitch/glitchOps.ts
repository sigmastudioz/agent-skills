import { clampNumber } from '../core/numberOps.js';
import type { GlitchSignal, GlitchTrigger } from './types.js';

/** Viewport progress (0 entering → 1 exited) to glitch weight: full while entering,
 * easing to clean by the center so the settled image is readable. */
export function scrollGlitchEnvelope(progress: number): number {
  const p = clampNumber(progress, 0, 1, 0);
  const t = Math.min(1, Math.max(0, (p - .2) / .3));
  return 1 - t * t * (3 - 2 * t);
}

/** Pure trigger → shader amount. Interval bursts are gated in the shader from phase. */
export function glitchAmount(trigger: GlitchTrigger, intensity: number, signal: GlitchSignal): number {
  const peak = clampNumber(intensity, 0, 1, .6);
  switch (trigger) {
    case 'hover': return signal.hovered ? peak : 0;
    case 'scroll': return peak * scrollGlitchEnvelope(signal.scrollProgress);
    case 'progress': return peak * clampNumber(signal.progress, 0, 1, 0);
    default: return peak;
  }
}
