import { clampNumber } from '../core/numberOps.js';
import { createHeatmapPixels, isHeatmapRamp, resolveHeatmapRamp } from '../heatmap/heatmapOps.js';
import { DITHER_PRESETS } from './presets.js';
import type { DitherAlgorithm, DitherProps, ResolvedDitherConfig } from './types.js';

const ALGORITHMS: DitherAlgorithm[] = ['bayer4', 'bayer8', 'floyd', 'atkinson'];
/** Error-diffusion work is bounded; larger frames use proportionally larger cells. */
export const MAX_DIFFUSION_CELLS = 640 * 640;
const HEX = /^#(?:[\da-f]{3}|[\da-f]{6})$/i;

export function resolveDitherConfig(props: Partial<DitherProps> = {}): ResolvedDitherConfig {
  const preset = DITHER_PRESETS[props.preset ?? 'newsprint'] ?? DITHER_PRESETS.newsprint;
  const algorithm = props.algorithm ?? preset.algorithm;
  const fallback = [props.ink && HEX.test(props.ink) ? props.ink : '#1b1a17', props.paper && HEX.test(props.paper) ? props.paper : '#efe9dc'];
  // Explicit ink/paper replace the preset palette unless a valid palette is supplied.
  const palette = isHeatmapRamp(props.palette) ? props.palette
    : props.ink !== undefined || props.paper !== undefined ? fallback : preset.palette ?? fallback;
  return {
    algorithm: ALGORITHMS.includes(algorithm as DitherAlgorithm) ? algorithm! : 'bayer8',
    levels: Math.round(clampNumber(props.levels ?? preset.levels, 2, 16, 2)),
    palette: resolveHeatmapRamp(palette),
    cellSize: Math.round(clampNumber(props.cellSize ?? preset.cellSize, 1, 16, 2)),
    contrast: clampNumber(props.contrast ?? preset.contrast, .1, 3, 1),
    invert: props.invert ?? false,
    intensity: clampNumber(props.intensity, 0, 1, 1),
  };
}

export function isDiffusion(algorithm: DitherAlgorithm): boolean {
  return algorithm === 'floyd' || algorithm === 'atkinson';
}

/** Square cells covering the frame; cell size grows only when the work bound requires it. */
export function ditherGrid(width: number, height: number, cellSize: number): { columns: number; rows: number; cell: number } {
  if (![width, height].every(n => Number.isFinite(n) && n > 0)) return { columns: 0, rows: 0, cell: cellSize };
  let cell = Math.max(1, cellSize);
  while (Math.ceil(width / cell) * Math.ceil(height / cell) > MAX_DIFFUSION_CELLS) cell += 1;
  return { columns: Math.ceil(width / cell), rows: Math.ceil(height / cell), cell };
}

/** Contrast-adjusted Rec. 709 luminance in [0,1]; transparent pixels read as paper. */
export function ditherLuminance(pixels: ArrayLike<number>, count: number, contrast: number, invert: boolean): Float32Array {
  const light = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    const o = i * 4;
    const value = (pixels[o] * .2126 + pixels[o + 1] * .7152 + pixels[o + 2] * .0722) / 255;
    const tone = Math.min(1, Math.max(0, (value - .5) * contrast + .5));
    light[i] = invert ? 1 - tone : tone;
  }
  return light;
}

// Neighbour offsets [dx, dy, weight]. Atkinson intentionally diffuses only 6/8.
const KERNELS: Record<'floyd' | 'atkinson', readonly (readonly [number, number, number])[]> = {
  floyd: [[1, 0, 7 / 16], [-1, 1, 3 / 16], [0, 1, 5 / 16], [1, 1, 1 / 16]],
  atkinson: [[1, 0, 1 / 8], [2, 0, 1 / 8], [-1, 1, 1 / 8], [0, 1, 1 / 8], [1, 1, 1 / 8], [0, 2, 1 / 8]],
};

/** Deterministic left-to-right error diffusion to `levels` tones in [0,1]. */
export function errorDiffuse(light: Float32Array, columns: number, rows: number,
  algorithm: 'floyd' | 'atkinson', levels: number): Float32Array {
  const work = Float32Array.from(light), out = new Float32Array(light.length);
  const steps = Math.max(1, Math.round(levels) - 1), kernel = KERNELS[algorithm];
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < columns; x++) {
      const i = y * columns + x;
      const tone = Math.min(1, Math.max(0, Math.round(work[i] * steps) / steps));
      const error = work[i] - tone;
      out[i] = tone;
      for (const [dx, dy, weight] of kernel) {
        const nx = x + dx, ny = y + dy;
        if (nx >= 0 && nx < columns && ny < rows) work[ny * columns + nx] += error * weight;
      }
    }
  }
  return out;
}

/** Map tones through the same 256-texel ramp the GPU path samples. Alpha follows the source. */
export function ditherPixels(tones: Float32Array, palette: readonly string[], source: ArrayLike<number>): Uint8ClampedArray {
  const lut = createHeatmapPixels(palette), out = new Uint8ClampedArray(tones.length * 4);
  for (let i = 0; i < tones.length; i++) {
    const t = Math.round(tones[i] * 255) * 4;
    out[i * 4] = lut[t]; out[i * 4 + 1] = lut[t + 1]; out[i * 4 + 2] = lut[t + 2];
    out[i * 4 + 3] = source[i * 4 + 3];
  }
  return out;
}
