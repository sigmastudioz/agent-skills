import type { ReactNode } from 'react';
import { clampNumber } from '../core/numberOps.js';
export type AssemblyVector = readonly [number, number, number];
export interface AssemblyPart {
  id: string;
  position?: AssemblyVector;
  /** Displacement from its assembled position at amount=1, in scene units. */
  offset?: AssemblyVector;
  rotation?: AssemblyVector;
  /** Extra XYZ rotation in radians at amount=1. */
  spin?: AssemblyVector;
  children?: ReactNode;
}
export interface ExplodedAssemblyProps {
  parts: readonly AssemblyPart[];
  /** Controlled assembled(0) → separated(1) pose. No implicit hover or global input. */
  amount: number;
  position?: AssemblyVector;
  rotation?: AssemblyVector;
  scale?: number;
}
export function sampleAssemblyPose(part: AssemblyPart, amount: number) {
  const t = clampNumber(amount, 0, 1, 0);
  const sample = (origin: AssemblyVector | undefined, delta: AssemblyVector | undefined, limit: number): [number, number, number] => [0, 1, 2].map(i =>
    clampNumber(origin?.[i], -limit, limit, 0) + clampNumber(delta?.[i], -limit, limit, 0) * t) as [number, number, number];
  return { position: sample(part.position, part.offset, 1000), rotation: sample(part.rotation, part.spin, Math.PI * 20) };
}
