import { clampNumber } from '../core/numberOps.js';
import type { PendulumState } from './types.js';

/** Transform for the rotating inner layer. */
export function flipTransform(flipped: boolean, axis: 'x' | 'y'): string {
  return `rotate${axis === 'x' ? 'X' : 'Y'}(${flipped ? 180 : 0}deg)`;
}

/** Damped pendulum, semi-implicit Euler, angles in radians. `length` in CSS pixels sets the
 * period (longer strap = slower swing); time is scaled so a 200 px strap swings at ~1 Hz. */
export function stepPendulum(state: PendulumState, deltaMs: number, length: number, damping: number): PendulumState {
  const dt = clampNumber(deltaMs, 0, 50, 16.7) / 1000;
  const omega2 = 39.5 * 200 / clampNumber(length, 40, 600, 200);
  const velocity = (state.velocity - omega2 * Math.sin(state.angle) * dt) *
    Math.pow(clampNumber(damping, .9, .999, .985), dt * 60);
  return { angle: clampNumber(state.angle + velocity * dt, -1.4, 1.4, 0), velocity };
}

export function pendulumAtRest(state: PendulumState): boolean {
  return Math.abs(state.angle) < .001 && Math.abs(state.velocity) < .002;
}

/** CSS rotation (clockwise positive) of the strap when the card is dragged to (dx, dy)
 * from the pivot, y down: dragging right swings the card right, a negative angle. */
export function dragAngle(dx: number, dy: number): number {
  return clampNumber(-Math.atan2(dx, Math.max(1, dy)), -1.4, 1.4, 0);
}

/** A press that moved less than this is a click (flip), not a drag. */
export const CLICK_SLOP = 5;
