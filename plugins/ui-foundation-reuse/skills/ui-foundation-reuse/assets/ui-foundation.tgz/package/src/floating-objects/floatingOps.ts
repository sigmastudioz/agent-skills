import { clampNumber } from '../core/numberOps.js';
import type { FloatingObject } from './types.js';

export function floatingTransform(item: FloatingObject, index: number, seconds: number, pointer = { x: 0, y: 0 }) {
  const drift = clampNumber(item.drift, 0, 100, 18), depth = clampNumber(item.depth, -3, 3, 1);
  const phase = index * 1.7;
  const t = Number.isFinite(seconds) ? seconds : 0;
  // Subtract the initial sample so SSR, reduced motion and the first frame agree.
  const x = (Math.sin(t * .7 + phase) - Math.sin(phase)) * drift + pointer.x * depth;
  const y = (Math.cos(t * .9 + phase) - Math.cos(phase)) * drift + pointer.y * depth;
  const rotate = clampNumber(item.rotate, -360, 360, 0) + (Math.sin(t * .5 + phase) - Math.sin(phase)) * drift * .3;
  return `translate3d(${x}px, ${y}px, 0) rotate(${rotate}deg)`;
}
