/** Center-crop UV scale matching object-fit: cover. */
export function coverScale(imageWidth: number, imageHeight: number, width: number, height: number): [number, number] {
  if (![imageWidth, imageHeight, width, height].every(value => Number.isFinite(value) && value > 0)) return [1, 1];
  const image = imageWidth / imageHeight, frame = width / height;
  return image > frame ? [frame / image, 1] : [1, image / frame];
}
