import { clampNumber } from '../core/numberOps.js';
import type { FluidConfig, FluidFieldProps, FluidPreset } from './types.js';
export const FLUID_PRESETS: Record<FluidPreset, { color: string; accentColor: string }> = {
  lagoon: { color: '#087f96', accentColor: '#b7ffb4' },
  ember: { color: '#bf2858', accentColor: '#ffd083' },
  ultraviolet: { color: '#5621b8', accentColor: '#f492ef' },
};
export function resolveFluidConfig(props: FluidFieldProps = {}): FluidConfig {
  const preset = FLUID_PRESETS[props.preset ?? 'lagoon'] ?? FLUID_PRESETS.lagoon;
  const color = (value: string | undefined, fallback: string) => value && /^#(?:[\da-f]{3}|[\da-f]{6})$/i.test(value) ? value : fallback;
  return { color: color(props.color, preset.color), accentColor: color(props.accentColor, preset.accentColor),
    speed: clampNumber(props.speed, 0, 3, .7), persistence: clampNumber(props.persistence, .8, .995, .97),
    resolution: Math.round(clampNumber(props.resolution, 128, 768, 512)) };
}
export function fluidRgb(hex: string): [number, number, number] {
  const expanded = hex.length === 4 ? hex.slice(1).split('').map(c => c+c).join('') : hex.slice(1);
  const n = parseInt(expanded, 16); return [(n>>16&255)/255,(n>>8&255)/255,(n&255)/255];
}
export function simulationSize(width: number, height: number, limit: number): [number, number] {
  const w = Math.max(1, Number.isFinite(width) ? width : 1), h = Math.max(1, Number.isFinite(height) ? height : 1);
  const ratio = Math.min(1, clampNumber(limit, 128, 768, 512) / Math.max(w,h));
  return [Math.max(1,Math.round(w*ratio)),Math.max(1,Math.round(h*ratio))];
}
