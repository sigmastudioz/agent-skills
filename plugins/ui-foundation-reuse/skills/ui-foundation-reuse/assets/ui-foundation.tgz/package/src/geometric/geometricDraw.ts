import type { GeometricScene, ResolvedGeometricConfig, ShapeKind } from './types.js';

function rgba(hex: string, alpha: number): string {
  const text = hex.length === 4 ? hex.slice(1).split('').map(channel => channel + channel).join('') : hex.slice(1);
  const value = parseInt(text, 16);
  return `rgba(${(value >> 16) & 255},${(value >> 8) & 255},${value & 255},${alpha})`;
}

function traceShape(ctx: CanvasRenderingContext2D, kind: Exclude<ShapeKind, 'mixed'>, size: number): void {
  const arm = size * 0.5;
  if (kind === 'circle') {
    ctx.arc(0, 0, arm, 0, Math.PI * 2);
    return;
  }
  if (kind === 'cross') {
    ctx.moveTo(-arm, 0); ctx.lineTo(arm, 0); ctx.moveTo(0, -arm); ctx.lineTo(0, arm);
    return;
  }
  if (kind === 'bracket') {
    const tip = size * 0.22;
    ctx.moveTo(-arm, -arm + tip); ctx.lineTo(-arm, -arm); ctx.lineTo(-arm + tip, -arm);
    ctx.moveTo(arm - tip, -arm); ctx.lineTo(arm, -arm); ctx.lineTo(arm, -arm + tip);
    ctx.moveTo(arm, arm - tip); ctx.lineTo(arm, arm); ctx.lineTo(arm - tip, arm);
    ctx.moveTo(-arm + tip, arm); ctx.lineTo(-arm, arm); ctx.lineTo(-arm, arm - tip);
    return;
  }
  ctx.rect(-arm, -arm, size, size);
}

/** Stroke the sampled graph in y-up coordinates over a CSS-sized canvas. */
export function paintGeometric(
  canvas: HTMLCanvasElement,
  scene: GeometricScene,
  config: Pick<ResolvedGeometricConfig, 'ink' | 'accent' | 'inkOpacity' | 'showNodes' | 'showChain'>,
  dpr: number,
): void {
  const ctx = canvas.getContext('2d');
  const cssWidth = canvas.clientWidth;
  const cssHeight = canvas.clientHeight;
  if (!ctx || cssWidth <= 0 || cssHeight <= 0) return;
  const width = Math.max(1, Math.round(cssWidth * dpr));
  const height = Math.max(1, Math.round(cssHeight * dpr));
  if (canvas.width !== width) canvas.width = width;
  if (canvas.height !== height) canvas.height = height;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssWidth, cssHeight);
  const px = (x: number) => x * cssWidth;
  const py = (y: number) => (1 - y) * cssHeight;
  const unit = Math.min(cssWidth, cssHeight);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.shadowColor = rgba(config.accent, 0.9);
  ctx.shadowBlur = Math.max(6, unit * 0.012);
  ctx.strokeStyle = rgba(config.accent, 0.28 * config.inkOpacity);
  ctx.lineWidth = 2.4;
  for (const link of scene.links) {
    if (link.reveal < 0.04) continue;
    ctx.globalAlpha = link.reveal * (0.2 + link.confidence * 0.55);
    ctx.beginPath();
    ctx.moveTo(px(link.x0), py(link.y0));
    ctx.lineTo(px(link.x1), py(link.y1));
    ctx.stroke();
  }
  ctx.shadowBlur = 0;
  ctx.strokeStyle = rgba(config.ink, 0.82 * config.inkOpacity);
  ctx.lineWidth = 0.85;
  for (const link of scene.links) {
    if (link.reveal < 0.04) continue;
    ctx.globalAlpha = link.reveal * (0.35 + link.confidence * 0.65);
    ctx.beginPath();
    ctx.moveTo(px(link.x0), py(link.y0));
    ctx.lineTo(px(link.x1), py(link.y1));
    ctx.stroke();
  }
  if (config.showChain) {
    ctx.globalAlpha = 0.9;
    ctx.strokeStyle = rgba(config.accent, config.inkOpacity);
    ctx.lineWidth = 1.25;
    for (const circle of scene.circles) {
      ctx.beginPath();
      ctx.arc(px(circle.x), py(circle.y), circle.r * unit, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.fillStyle = rgba(config.accent, config.inkOpacity);
    for (const crossing of scene.crossings) {
      ctx.beginPath();
      ctx.arc(px(crossing.x), py(crossing.y), 2.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.lineWidth = 1.15;
  for (const shape of scene.shapes) {
    if (shape.reveal < 0.04) continue;
    ctx.save();
    ctx.globalAlpha = shape.reveal * config.inkOpacity;
    ctx.translate(px(shape.x), py(shape.y));
    ctx.rotate(-shape.rotation);
    if (shape.kind === 'diamond') ctx.rotate(Math.PI / 4);
    ctx.beginPath();
    ctx.strokeStyle = rgba(shape.kind === 'bracket' || shape.kind === 'diamond' ? config.accent : config.ink, 1);
    traceShape(ctx, shape.kind === 'diamond' ? 'square' : shape.kind, shape.size * unit);
    ctx.stroke();
    ctx.restore();
  }
  if (config.showNodes) {
    for (const point of scene.points) {
      if (point.reveal < 0.04) continue;
      const radius = (1.1 + point.strength * 2.4) * point.scale;
      ctx.globalAlpha = point.reveal * 0.55;
      ctx.fillStyle = rgba(config.accent, 0.9);
      ctx.shadowColor = rgba(config.accent, 0.85);
      ctx.shadowBlur = radius * 3.5;
      ctx.beginPath();
      ctx.arc(px(point.x), py(point.y), radius * 1.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.globalAlpha = point.reveal;
      ctx.fillStyle = rgba(config.ink, 0.95);
      ctx.beginPath();
      ctx.arc(px(point.x), py(point.y), Math.max(0.8, radius * 0.45), 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;
}
