export { DEFAULT_FORCE_SIM_CONFIG } from './types.js';
export type {
  ForceBody2D,
  ForceObstacle,
  ForcePointer,
  ForceSimConfig,
  ForceSimStepInput,
} from './types.js';
export { stepForceSim, forceIdPhase } from './stepForceSim.js';
export { applyForceHomes, syncForceBodies } from './syncForceBodies.js';
export { useForceSim } from './useForceSim.js';
export type { UseForceSimOptions } from './useForceSim.js';
