import type { CurtainField } from './curtainOps.js';

/** Glyphs rasterize once per text/font/size change; animation only blits the atlas. */
export function createCurtainRenderer(canvas: HTMLCanvasElement, text: string,
  width: number, height: number, dpr: number, fontSize: number, fontFamily: string,
  color: string, direction: 'ltr' | 'rtl'): ((field: CurtainField) => void) | null {
  const context = canvas.getContext('2d'); if (!context) return null;
  const characters = Array.from(text.replace(/\s+/gu, ' ').trim() || '·');
  // Bound atlas memory for arbitrary caller text; full text remains available to AT.
  const unique = [...new Set([...characters, '·'])].slice(0, 256);
  const cell = Math.ceil(fontSize * 1.7 * dpr), atlas = document.createElement('canvas');
  atlas.width = cell * 16; atlas.height = cell * Math.ceil(unique.length / 16);
  const ink = atlas.getContext('2d'); if (!ink) return null;
  ink.font = `${fontSize * dpr}px ${fontFamily}`; ink.fillStyle = color;
  ink.textAlign = 'center'; ink.textBaseline = 'middle';
  const positions = new Map(unique.map((glyph, i) => [glyph, i]));
  unique.forEach((glyph, i) => ink.fillText(glyph, (i % 16 + .5) * cell, (Math.floor(i / 16) + .5) * cell));
  const glyphs = characters.map(glyph => positions.get(glyph) ?? positions.get('·') ?? 0);
  canvas.width = Math.max(1, Math.round(width * dpr)); canvas.height = Math.max(1, Math.round(height * dpr));
  return field => {
    context.setTransform(1, 0, 0, 1, 0, 0); context.clearRect(0, 0, canvas.width, canvas.height);
    const size = cell / dpr;
    for (let col = 0; col < field.columns; col++) for (let row = 0; row < field.rows; row++) {
      const index = col * field.rows + row, previous = row ? index - 1 : index;
      const angle = row ? Math.atan2(field.y[index] - field.y[previous], field.x[index] - field.x[previous]) - Math.PI / 2 : 0;
      const cosine = Math.cos(angle) * dpr, sine = Math.sin(angle) * dpr;
      const order = (direction === 'rtl' ? field.columns - col - 1 : col) * field.rows + row;
      const glyph = glyphs[order % glyphs.length];
      context.setTransform(cosine, sine, -sine, cosine, field.x[index] * dpr, field.y[index] * dpr);
      context.drawImage(atlas, glyph % 16 * cell, Math.floor(glyph / 16) * cell, cell, cell, -size / 2, -size / 2, size, size);
    }
  };
}
