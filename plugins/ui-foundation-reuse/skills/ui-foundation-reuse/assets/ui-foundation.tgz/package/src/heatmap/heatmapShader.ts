/** Full-resolution photographic luminance mapped through a 256-texel color ramp. */
export const HEATMAP_FILTER_FUNCTION = `
vec4 heatmapFilter(vec4 source) {
  float tone = clamp((luminance(source.rgb) - .5) * uContrast + .5, 0., 1.);
  tone = mix(tone, 1. - tone, uInvert);
  vec3 color = texture2D(uColorRamp, vec2((tone * 255. + .5) / 256., .5)).rgb;
  return vec4(color, source.a);
}`;
