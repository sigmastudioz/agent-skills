import { createFullscreenPass, createTexture } from '../core/fullscreenPass.js';
import { coverScale } from '../core/imageFit.js';
import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import { FLUTED_GLASS_FRAGMENT } from './flutedGlassShader.js';
import type { ResolvedFlutedGlassConfig } from './types.js';

export interface FlutedGlassRenderer extends WebGLRendererLike {
  load(src: string, ready: (error?: string) => void): () => void;
  render(config: ResolvedFlutedGlassConfig): void;
}

export function createFlutedGlassRenderer(canvas: HTMLCanvasElement): FlutedGlassRenderer | null {
  const gl = canvas.getContext('webgl', { alpha: true, premultipliedAlpha: false, antialias: false, depth: false });
  if (!gl) return null;
  const cleanup: (() => void)[] = [];
  let disposed = false, loaded = false, width = 1, height = 1;
  let imageWidth = 1, imageHeight = 1;
  let cancelLoad = () => {};
  const dispose = () => {
    if (disposed) return;
    disposed = true;
    cancelLoad();
    cleanup.splice(0).reverse().forEach(fn => fn());
  };
  try {
    const pass = createFullscreenPass(gl, FLUTED_GLASS_FRAGMENT, [
      'uImage', 'uResolution', 'uCover', 'uRibWidth', 'uRefraction', 'uBlur', 'uChromaticSeparation', 'uHighlight',
    ]);
    cleanup.push(pass.dispose);
    const texture = createTexture(gl);
    cleanup.push(() => gl.deleteTexture(texture));
    return {
      resize(cssWidth, cssHeight, dpr) {
        width = Math.max(1, cssWidth); height = Math.max(1, cssHeight);
        canvas.width = Math.max(1, Math.round(width * dpr));
        canvas.height = Math.max(1, Math.round(height * dpr));
        gl.viewport(0, 0, canvas.width, canvas.height);
      },
      load(src, ready) {
        cancelLoad(); loaded = false;
        if (disposed) return () => {};
        let cancelled = false;
        const image = new Image();
        cancelLoad = () => { cancelled = true; image.onload = null; image.onerror = null; };
        const fail = (message: string) => { if (!cancelled && !disposed) ready(message); };
        image.crossOrigin = 'anonymous';
        image.onload = () => {
          if (cancelled || disposed) return;
          try {
            if (!image.naturalWidth || !image.naturalHeight) throw new Error('Empty image');
            gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, texture);
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
            if (gl.getError() !== gl.NO_ERROR) throw new Error('Upload failed');
            imageWidth = image.naturalWidth; imageHeight = image.naturalHeight;
            loaded = true;
          } catch {
            fail('FlutedGlass image upload failed. Use same-origin images or images with CORS enabled.');
            return;
          }
          ready();
        };
        image.onerror = () => fail('FlutedGlass image loading failed. Use a reachable URL with CORS enabled.');
        image.src = src;
        return cancelLoad;
      },
      render(config) {
        if (!loaded || disposed) return;
        pass.use(); gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, texture);
        const u = pass.uniforms;
        gl.uniform1i(u.uImage, 0);
        gl.uniform2f(u.uResolution, width, height);
        gl.uniform2f(u.uCover, ...coverScale(imageWidth, imageHeight, width, height));
        gl.uniform1f(u.uRibWidth, config.ribWidth);
        gl.uniform1f(u.uRefraction, config.refraction);
        gl.uniform1f(u.uBlur, config.blur);
        gl.uniform1f(u.uChromaticSeparation, config.chromaticSeparation);
        gl.uniform1f(u.uHighlight, config.highlight);
        pass.draw();
      },
      dispose,
    };
  } catch { dispose(); return null; }
}
