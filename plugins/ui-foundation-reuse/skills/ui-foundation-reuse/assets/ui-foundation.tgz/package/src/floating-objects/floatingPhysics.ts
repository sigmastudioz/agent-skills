import { clampNumber } from '../core/numberOps.js';
import { stepForceSim, forceIdPhase } from '../force-2d/stepForceSim.js';
import type { ForceBody2D, ForceSimConfig } from '../force-2d/types.js';
import type { FloatingObject } from './types.js';

export interface FloatingBody extends ForceBody2D { angle: number; spin: number }
const FREE_FLIGHT: ForceSimConfig = { spring: 0, damping: 1, collide: 1, bounce: .8, idle: 0, pointerStrength: 0, pointerRadius: 0, maxSpeed: 1000, padding: 0 };

export function createFloatingBody(item: FloatingObject, width: number, height: number): FloatingBody {
  const phase = forceIdPhase(item.id), angle = phase * Math.PI * 2, velocity = Math.min(width, height) * .065;
  const x = clampNumber(item.x, 0, 1, .5) * width, y = clampNumber(item.y, 0, 1, .5) * height;
  return { id: item.id, x, y, homeX: x, homeY: y,
    vx: Math.cos(angle) * velocity, vy: Math.sin(angle) * velocity,
    angle: clampNumber(item.rotate, -360, 360, 0), spin: (phase > .5 ? 1 : -1) * (8 + phase * 19),
    r: Math.min(Math.min(width, height) * .18, clampNumber(item.width, .01, 2, .2) * width / 2 * Math.min(1, 1 / clampNumber(item.aspectRatio, .2, 5, 1))) };
}
/** Reuses the shared collision solver; this adapter owns free-flight walls and spin. */
export function stepFloatingBodies(bodies: FloatingBody[], width: number, height: number, seconds: number): void {
  const dt = clampNumber(seconds, 0, .1, 0);
  if (!(width > 0 && height > 0) || !dt) return;
  const steps = Math.ceil(dt / .016), step = dt / steps;
  for (let n = 0; n < steps; n++) {
    stepForceSim(bodies, step * 1000, 0, { config: FREE_FLIGHT });
    for (const b of bodies) {
      b.angle += b.spin * step;
      const r = Math.min(b.r, width / 2, height / 2);
      if (b.x < r) { b.x = r; b.vx = Math.abs(b.vx); } if (b.x > width - r) { b.x = width - r; b.vx = -Math.abs(b.vx); }
      if (b.y < r) { b.y = r; b.vy = Math.abs(b.vy); } if (b.y > height - r) { b.y = height - r; b.vy = -Math.abs(b.vy); }
    }
  }
}
