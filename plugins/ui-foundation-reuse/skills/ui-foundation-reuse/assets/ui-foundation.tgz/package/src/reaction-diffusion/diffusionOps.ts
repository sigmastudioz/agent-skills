import { clampNumber } from '../core/numberOps.js';
import type { GrayScottPreset, GrayScottState, PhysarumState } from './types.js';

export const GRAY_SCOTT_PRESETS: Readonly<Record<GrayScottPreset, readonly [number, number]>> = Object.freeze({
  coral: [.0545, .062], mitosis: [.0367, .0649], maze: [.029, .057], spots: [.03, .062], worms: [.078, .061],
});

/** Small deterministic PRNG (mulberry32), so the same seed grows the same first frames. */
export function seededRandom(seed: number): () => number {
  let a = (Math.round(seed) >>> 0) || 1;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** u = 1 everywhere, v seeded in a few square patches. */
export function createGrayScott(size: number, seed: number): GrayScottState {
  const n = Math.round(clampNumber(size, 16, 256, 128)), u = new Float32Array(n * n).fill(1), v = new Float32Array(n * n);
  const random = seededRandom(seed), patches = 4 + Math.floor(random() * 5), half = Math.max(3, Math.round(n / 16));
  for (let p = 0; p < patches; p++) seedGrayScott({ size: n, u, v }, random() * n, random() * n, half);
  return { size: n, u, v };
}

/** Drop a square of v (pointer seeding). Coordinates wrap. */
export function seedGrayScott(state: GrayScottState, x: number, y: number, half: number): void {
  const n = state.size;
  for (let dy = -half; dy <= half; dy++) for (let dx = -half; dx <= half; dx++) {
    const i = (((Math.round(y) + dy) % n + n) % n) * n + (((Math.round(x) + dx) % n + n) % n);
    state.u[i] = .5; state.v[i] = 1;
  }
}

/** Gray–Scott on a torus: Du = 1, Dv = .5, dt = 1, 3×3 Laplacian (.2 edges, .05 corners). */
export function stepGrayScott(state: GrayScottState, feed: number, kill: number, iterations = 1): GrayScottState {
  const n = state.size;
  // Never write into the caller's arrays: ping-pong between two private buffer pairs.
  let u = state.u, v = state.v, nu = new Float32Array(n * n), nv = new Float32Array(n * n);
  let spareU: Float32Array | null = null, spareV: Float32Array | null = null;
  for (let k = 0; k < iterations; k++) {
    for (let y = 0; y < n; y++) {
      const up = ((y - 1 + n) % n) * n, row = y * n, down = ((y + 1) % n) * n;
      for (let x = 0; x < n; x++) {
        const l = (x - 1 + n) % n, r = (x + 1) % n, i = row + x;
        const lapU = .2 * (u[up + x] + u[down + x] + u[row + l] + u[row + r]) +
          .05 * (u[up + l] + u[up + r] + u[down + l] + u[down + r]) - u[i];
        const lapV = .2 * (v[up + x] + v[down + x] + v[row + l] + v[row + r]) +
          .05 * (v[up + l] + v[up + r] + v[down + l] + v[down + r]) - v[i];
        const uvv = u[i] * v[i] * v[i];
        nu[i] = clamp01(u[i] + lapU - uvv + feed * (1 - u[i]));
        nv[i] = clamp01(v[i] + .5 * lapV + uvv - (kill + feed) * v[i]);
      }
    }
    const oldU = u, oldV = v; u = nu; v = nv;
    if (!spareU || !spareV) { spareU = new Float32Array(n * n); spareV = new Float32Array(n * n); }
    nu = oldU === state.u ? spareU : oldU; nv = oldV === state.v ? spareV : oldV;
  }
  return { size: n, u, v };
}

const clamp01 = (x: number) => x < 0 ? 0 : x > 1 ? 1 : x;

export interface PhysarumParams { sensorAngle: number; sensorDistance: number; turn: number; step: number; deposit: number; decay: number }
export const PHYSARUM_DEFAULTS: PhysarumParams = Object.freeze({ sensorAngle: .6, sensorDistance: 9, turn: .45, step: 1, deposit: .35, decay: .92 });

export function createPhysarum(size: number, count: number, seed: number): PhysarumState {
  const n = Math.round(clampNumber(size, 16, 256, 128)), m = Math.round(clampNumber(count, 1, 20000, 6000));
  const random = seededRandom(seed), agents = new Float32Array(m * 3);
  for (let i = 0; i < m; i++) {
    // Start on a ring facing inward-ish so the first frames already form a network.
    const a = random() * Math.PI * 2, r = n * (.15 + random() * .2);
    agents[i * 3] = n / 2 + Math.cos(a) * r; agents[i * 3 + 1] = n / 2 + Math.sin(a) * r;
    agents[i * 3 + 2] = a + Math.PI + (random() - .5);
  }
  return { size: n, trail: new Float32Array(n * n), agents, random };
}

/** Sense → turn toward the strongest trail → move → deposit; then 3×3 blur and decay. */
export function stepPhysarum(state: PhysarumState, params: PhysarumParams = PHYSARUM_DEFAULTS): PhysarumState {
  const { size: n, agents, random } = state;
  let trail = state.trail;
  const wrap = (value: number) => ((value % n) + n) % n;
  const sense = (x: number, y: number, heading: number) =>
    trail[Math.floor(wrap(y + Math.sin(heading) * params.sensorDistance)) * n + Math.floor(wrap(x + Math.cos(heading) * params.sensorDistance))];
  for (let i = 0; i < agents.length; i += 3) {
    const x = agents[i], y = agents[i + 1];
    let h = agents[i + 2];
    const f = sense(x, y, h), l = sense(x, y, h - params.sensorAngle), r = sense(x, y, h + params.sensorAngle);
    if (f < l && f < r) h += (random() < .5 ? -1 : 1) * params.turn;
    else if (l > r) h -= params.turn;
    else if (r > l) h += params.turn;
    const nx = wrap(x + Math.cos(h) * params.step), ny = wrap(y + Math.sin(h) * params.step);
    agents[i] = nx; agents[i + 1] = ny; agents[i + 2] = h;
    const cell = Math.floor(ny) * n + Math.floor(nx);
    trail[cell] = Math.min(1, trail[cell] + params.deposit);
  }
  const next = new Float32Array(n * n);
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
    let sum = 0;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) sum += trail[wrap(y + dy) * n + wrap(x + dx)];
    next[y * n + x] = sum / 9 * params.decay;
  }
  trail = next;
  return { ...state, trail };
}

/** Field in [0,1] → RGBA between two hex colors, written into `out`. */
export function shadeField(field: Float32Array, from: string, to: string, out: Uint8ClampedArray, gain = 1): void {
  const a = hex(from), b = hex(to);
  for (let i = 0; i < field.length; i++) {
    const t = clamp01(field[i] * gain), o = i * 4;
    out[o] = a[0] + (b[0] - a[0]) * t; out[o + 1] = a[1] + (b[1] - a[1]) * t; out[o + 2] = a[2] + (b[2] - a[2]) * t; out[o + 3] = 255;
  }
}

function hex(value: string): [number, number, number] {
  const v = /^#([\da-f]{3}|[\da-f]{6})$/i.test(value) ? value.slice(1) : '000000';
  const full = v.length === 3 ? [...v].map(c => c + c).join('') : v;
  return [0, 2, 4].map(i => parseInt(full.slice(i, i + 2), 16)) as [number, number, number];
}
