import { coverScale } from './imageFit.js';

/** Load a still image for pixel sampling. Cancelling also detaches handlers, so an
 * obsolete source can never report into a newer one. */
export function loadSampledImage(src: string, crossOrigin: 'anonymous' | 'use-credentials',
  ready: (image: HTMLImageElement) => void, failed: (error: Error) => void): () => void {
  const image = new Image();
  let cancelled = false;
  image.crossOrigin = crossOrigin;
  image.onload = () => {
    if (cancelled) return;
    if (!image.naturalWidth || !image.naturalHeight) failed(new Error('Image has no decoded pixels.'));
    else ready(image);
  };
  image.onerror = () => { if (!cancelled) failed(new Error('Unable to load image. Check the source and CORS permission.')); };
  image.src = src;
  return () => { cancelled = true; image.onload = null; image.onerror = null; image.removeAttribute('src'); };
}

/** Center-cropped cover sample of a frame at columns × rows. A CORS-tainted image
 * throws SecurityError from getImageData; callers keep their semantic fallback. */
export function sampleCoverPixels(image: HTMLImageElement, columns: number, rows: number,
  frameWidth: number, frameHeight: number): Uint8ClampedArray {
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, columns); canvas.height = Math.max(1, rows);
  const context = canvas.getContext('2d', { willReadFrequently: true });
  if (!context) throw new Error('Canvas2D pixel sampling is unavailable.');
  try {
    const iw = image.naturalWidth, ih = image.naturalHeight;
    const [cx, cy] = coverScale(iw, ih, Math.max(1, frameWidth), Math.max(1, frameHeight));
    const sw = iw * cx, sh = ih * cy;
    context.drawImage(image, (iw - sw) / 2, (ih - sh) / 2, sw, sh, 0, 0, canvas.width, canvas.height);
    return context.getImageData(0, 0, canvas.width, canvas.height).data;
  } finally {
    canvas.width = canvas.height = 0;
  }
}
