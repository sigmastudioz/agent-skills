import { HEATMAP_RAMPS } from './ramps.js';

/** 2–16 evenly spaced #RGB/#RRGGBB colors. Invalid ramps use the thermal palette. */
export function resolveHeatmapRamp(ramp?: readonly string[]): string[] {
  const valid = Array.isArray(ramp) && ramp.length >= 2 && ramp.length <= 16 &&
    Array.from(ramp).every(color => typeof color === 'string' && /^#(?:[\da-f]{3}|[\da-f]{6})$/i.test(color));
  return (valid ? ramp! : HEATMAP_RAMPS.thermal).map(color =>
    (color.length === 4 ? '#' + [...color.slice(1)].map(char => char + char).join('') : color).toLowerCase(),
  );
}

/** A small linear RGB lookup texture; endpoints are exact and all texels are opaque. */
export function createHeatmapPixels(ramp: readonly string[]): Uint8Array {
  const colors = resolveHeatmapRamp(ramp).map(color =>
    [1, 3, 5].map(index => parseInt(color.slice(index, index + 2), 16)),
  );
  const pixels = new Uint8Array(256 * 4);
  for (let index = 0; index < 256; index++) {
    const position = index / 255 * (colors.length - 1);
    const left = Math.min(colors.length - 2, Math.floor(position));
    const blend = position - left;
    for (let channel = 0; channel < 3; channel++) {
      pixels[index * 4 + channel] = Math.round(colors[left][channel] * (1 - blend) + colors[left + 1][channel] * blend);
    }
    pixels[index * 4 + 3] = 255;
  }
  return pixels;
}
