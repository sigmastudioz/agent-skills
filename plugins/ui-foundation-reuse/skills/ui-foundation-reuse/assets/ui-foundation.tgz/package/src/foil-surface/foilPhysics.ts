import { clampNumber } from '../core/numberOps.js';
import { projectFoilPoint } from './foilOps.js';
import type { ResolvedFoilConfig } from './types.js';

interface Link { a: number; b: number; length: number; bend: boolean }
export interface FoilGrab { index: number; x: number; y: number; z: number; startX: number; startY: number }
export interface FoilMesh {
  positions: Float32Array;
  previous: Float32Array;
  rest: Float32Array;
  uv: Float32Array;
  indices: Uint16Array;
  links: Link[];
  seam: [number, number][];
  progress: number;
  autoTear: boolean;
  tearTime: number;
  tearFromRight: boolean;
  peel: number;
  turn: number;
  targetTurn: number;
  grab: FoilGrab | null;
  time: number;
  accumulator: number;
}
const COLUMNS = 24, ROWS = 32, HEIGHT = 2.8;

/** Two connected grids with duplicate seam vertices: no triangles bridge a broken seam. */
export function createFoilMesh(config: ResolvedFoilConfig): FoilMesh {
  const positions: number[] = [], uv: number[] = [], indices: number[] = [], links: Link[] = [];
  const seam: [number, number][] = [];
  const topRows = Math.round(ROWS * config.tearAt), bottomRows = ROWS - topRows;
  function panel(from: number, to: number, rows: number): number {
    const start = positions.length / 3;
    for (let row = 0; row <= rows; row++) {
      const v = from + (to - from) * row / rows;
      for (let col = 0; col <= COLUMNS; col++) {
        const u = col / COLUMNS;
        positions.push((u - .5) * HEIGHT * config.aspectRatio, (.5 - v) * HEIGHT, 0);
        uv.push(u, v);
      }
    }
    const link = (a: number, b: number, bend = false) => {
      const length = Math.hypot(positions[a*3]-positions[b*3], positions[a*3+1]-positions[b*3+1]);
      links.push({ a, b, length, bend });
    };
    for (let row = 0; row <= rows; row++) for (let col = 0; col <= COLUMNS; col++) {
      const a = start + row * (COLUMNS + 1) + col;
      if (col < COLUMNS) link(a, a + 1);
      if (row < rows) link(a, a + COLUMNS + 1);
      if (col < COLUMNS && row < rows) {
        link(a, a + COLUMNS + 2); link(a + 1, a + COLUMNS + 1);
        // CCW when seen from the printed front.
        indices.push(a, a + COLUMNS + 1, a + 1, a + 1, a + COLUMNS + 1, a + COLUMNS + 2);
      }
      if (col < COLUMNS - 1) link(a, a + 2, true);
      if (row < rows - 1) link(a, a + 2 * (COLUMNS + 1), true);
    }
    return start;
  }
  panel(0, config.tearAt, topRows);
  const bottom = panel(config.tearAt, 1, bottomRows);
  for (let col = 0; col <= COLUMNS; col++) seam.push([topRows * (COLUMNS + 1) + col, bottom + col]);
  const rest = new Float32Array(positions);
  return { positions: rest.slice(), previous: rest.slice(), rest, uv: new Float32Array(uv),
    indices: new Uint16Array(indices), links, seam, progress: 0, autoTear: false,
    tearTime: 0, tearFromRight: true, peel: 0,
    turn: -.06, targetTurn: -.06, grab: null, time: 0, accumulator: 0 };
}

export function resetFoilMesh(mesh: FoilMesh): void {
  mesh.positions.set(mesh.rest); mesh.previous.set(mesh.rest);
  mesh.progress = 0; mesh.autoTear = false; mesh.grab = null;
  mesh.tearTime = 0; mesh.peel = 0; mesh.tearFromRight = true;
  mesh.turn = mesh.targetTurn = -.06; mesh.time = 0; mesh.accumulator = 0;
}

/** Progress is monotonic until reset, and snaps to physical seam connections. */
export function tearFoilMesh(mesh: FoilMesh, progress: number): void {
  const next = clampNumber(progress, 0, 1, mesh.progress);
  const previousProgress = mesh.progress;
  mesh.progress = Math.max(mesh.progress, Math.floor(next * mesh.seam.length + 1e-6) / mesh.seam.length);
  if (previousProgress < 1 && mesh.progress === 1) {
    mesh.autoTear = false;
    // Release with downward momentum and a twist, retaining the peeled shape.
    const direction = mesh.tearFromRight ? -1 : 1;
    for (let i=mesh.seam[0][1];i<mesh.positions.length/3;i++) {
      const j=i*3;
      mesh.previous[j] = mesh.positions[j] - direction * .018;
      mesh.previous[j+1] = mesh.positions[j+1] + .025;
      mesh.previous[j+2] = mesh.positions[j+2] - mesh.rest[j] * .035;
    }
  }
}

export function pickFoilVertex(mesh: FoilMesh, x: number, y: number, radius = .24): number {
  let nearest = -1, distance = radius * radius;
  for (let i = 0; i < mesh.positions.length / 3; i++) {
    const [px, py] = projectFoilPoint(mesh.positions[i*3], mesh.positions[i*3+1], mesh.positions[i*3+2], mesh.turn);
    const d = (x-px)**2 + (y-py)**2;
    if (d < distance) { distance = d; nearest = i; }
  }
  return nearest;
}

function simulate(mesh: FoilMesh, config: ResolvedFoilConfig): void {
  const p = mesh.positions, previous = mesh.previous, rest = mesh.rest;
  const count = p.length / 3, bottomStart = mesh.seam[0][1];
  const grab = mesh.grab;
  if (mesh.autoTear && config.tearable) {
    mesh.tearTime += 1/60;
    // Preload the stub, then peel the seam across it over about 600 ms.
    tearFoilMesh(mesh, Math.max(mesh.progress, (mesh.tearTime - .12) / .6));
  }
  const detached = mesh.progress === 1;
  const peeling = config.tearable && (mesh.progress > 0 || mesh.autoTear);
  const peelTarget = peeling ? Math.min(1, .2 + mesh.progress * .8 + mesh.tearTime * .35) : 0;
  mesh.peel += (peelTarget - mesh.peel) * .16;
  const grabIndex = grab ? grab.index*3 : 0;
  const dragX = grab ? grab.x-rest[grabIndex] : 0;
  const dragY = grab ? grab.y-rest[grabIndex+1] : 0;
  const dragZ = grab ? grab.z-rest[grabIndex+2] : 0;
  for (let i = 0; i < count; i++) {
    const j=i*3, stub=i>=bottomStart, loose=detached && stub;
    const u=mesh.uv[i*2], v=mesh.uv[i*2+1];
    const localV=stub ? (v-config.tearAt)/(1-config.tearAt) : 0;
    const distance = grab ? ((rest[j]-rest[grabIndex])**2+(rest[j+1]-rest[grabIndex+1])**2) : 0;
    const influence = grab && (mesh.progress===0 || stub === (grab.index>=bottomStart)) ? Math.exp(-distance/1.1) : 0;
    const side = mesh.tearFromRight ? u : 1-u;
    const freedom = Math.min(1, Math.max(0, (side - (1-mesh.progress)) * 3 + localV * .65 + .15));
    for (let axis = 0; axis < 3; axis++) {
      const k=j+axis, value=p[k];
      const wave = axis===2 ? Math.sin(mesh.time*.85+rest[j+1]*1.7)*config.idleMotion*.09 : 0;
      // Broad compliant displacement under a grab; a weaker rest spring lets the sheet fold as a whole.
      let target=rest[k]+wave;
      if (grab) target += (axis===0?dragX:axis===1?dragY:dragZ) * influence * .7;
      if (stub && !loose && peeling) {
        const peel = mesh.peel * freedom;
        if (axis===0) target += (mesh.tearFromRight?-1:1)*peel*.18*localV;
        if (axis===1) target -= peel*(.12+.35*localV);
        if (axis===2) target += peel*(.3+.65*Math.sin(localV*1.8));
      }
      const spring = loose ? 0 : grab ? .003+config.stiffness*.004 : .006+config.stiffness*.009;
      const peelForce = stub && !loose && peeling ? .035 : 0;
      p[k] += (value-previous[k])*(loose?.992:grab?.94:.925) + (target-value)*(spring+peelForce) + (loose && axis===1?-.0035:0);
      if (loose && p[j+1]<-7) p[k]=value;
      previous[k]=value;
    }
  }
  for (let iteration=0;iteration<7;iteration++) {
    for (const link of mesh.links) {
      const a=link.a*3,b=link.b*3;
      const dx=p[b]-p[a],dy=p[b+1]-p[a+1],dz=p[b+2]-p[a+2];
      const distance=Math.hypot(dx,dy,dz)||1;
      const strength=link.bend?.045+config.stiffness*.26:.94;
      const correction=(distance-link.length)/distance*.5*strength;
      p[a]+=dx*correction;p[a+1]+=dy*correction;p[a+2]+=dz*correction;
      p[b]-=dx*correction;p[b+1]-=dy*correction;p[b+2]-=dz*correction;
    }
    const broken=Math.round(mesh.progress*mesh.seam.length);
    for (let fiber=broken;fiber<mesh.seam.length;fiber++) {
      const index=mesh.tearFromRight?mesh.seam.length-1-fiber:fiber;
      const [a,b]=mesh.seam[index];
      for (let axis=0;axis<3;axis++) {
        const mean=(p[a*3+axis]+p[b*3+axis])*.5;
        p[a*3+axis]=mean;p[b*3+axis]=mean;
      }
    }
    if (grab) {
      const a=grab.index*3;
      // A small contact patch removes the sharp single-vertex pinch.
      for (let i=0;i<count;i++) {
        if (mesh.progress>0 && (i>=bottomStart)!==(grab.index>=bottomStart)) continue;
        const j=i*3,distance=(rest[j]-rest[a])**2+(rest[j+1]-rest[a+1])**2;
        if (distance>.045) continue;
        const weight=Math.exp(-distance/.015)*.7;
        p[j]+=(grab.x+rest[j]-rest[a]-p[j])*weight;
        p[j+1]+=(grab.y+rest[j+1]-rest[a+1]-p[j+1])*weight;
        p[j+2]+=(grab.z-p[j+2])*weight;
      }
      p[a]=grab.x;p[a+1]=grab.y;p[a+2]=grab.z;
    }
  }
}

/** Fixed steps make stiffness and tear speed independent of the display refresh rate. */
export function stepFoilMesh(mesh: FoilMesh, config: ResolvedFoilConfig, seconds: number): void {
  const delta = clampNumber(seconds, 0, .064, 0);
  mesh.time += delta;
  mesh.turn += (mesh.targetTurn - mesh.turn) * (1 - Math.exp(-delta * 9));
  mesh.accumulator += delta;
  while (mesh.accumulator >= 1/60) { simulate(mesh, config); mesh.accumulator -= 1/60; }
}

/** A readable, motionless pose; a detached stub is outside the stage. */
export function settleFoilMesh(mesh: FoilMesh): void {
  mesh.grab = null; mesh.turn = mesh.targetTurn;
  mesh.positions.set(mesh.rest);
  if (mesh.progress === 1) {
    for (let i=mesh.seam[0][1]; i<mesh.positions.length/3; i++) mesh.positions[i*3+1] -= 9;
  }
  mesh.previous.set(mesh.positions);
}
