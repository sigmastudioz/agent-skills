export { Geometric } from './Geometric.js';
export { GEOMETRIC_PRESETS, geometricFallback, resolveGeometricConfig } from './presets.js';
export { buildGeometricScene, circleIntersections, delaunayEdges } from './geometricMesh.js';
export type {
  FieldPoint,
  GeometricPalette,
  GeometricPreset,
  GeometricProps,
  GeometricScene,
  LinkMode,
  MotionProgram,
  ResolvedGeometricConfig,
  ShapeKind,
} from './types.js';
