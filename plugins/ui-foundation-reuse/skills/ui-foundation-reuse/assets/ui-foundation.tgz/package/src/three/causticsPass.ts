import { captureAuxiliary, createRenderState, isAuxiliaryCapture } from './captureState.js';
import { causticPhotonGrid, causticPhotonPower, type CausticsConfig } from './causticsOps.js';
import { CAUSTIC_CAPTURE_VERTEX, CAUSTIC_CAPTURE_FRAGMENT, CAUSTIC_PHOTON_VERTEX, CAUSTIC_PHOTON_FRAGMENT,
  CAUSTIC_RECEIVER_VERTEX, CAUSTIC_RECEIVER_FRAGMENT } from './causticsShader.js';

/** Owns GPU resources, borrows caster geometry, and never changes the host scene's materials. */
export function createCausticsPass(three: any, initial: CausticsConfig, casterRef: { current: any }) {
  const preserve = createRenderState(three), captures = new three.Scene(), photons = new three.Scene();
  const camera = new three.OrthographicCamera(), bounds = new three.Box3(), sphere = new three.Sphere();
  const center = new three.Vector3(), direction = new three.Vector3(), light = new three.Vector3();
  const plane = new three.Plane(), normal = new three.Vector3(), origin = new three.Vector3();
  const normalMatrix = new three.Matrix3(), axisX = new three.Vector3(), axisY = new three.Vector3();
  const proxies = new Map<any, any>(), resources: any[] = [];
  const own = <T,>(resource: T): T => { resources.push(resource); return resource; };
  let config = initial, disposed = false, checkedRenderer: any, points: any, photonGeometry: any;
  const dispose = () => {
    if (disposed) return; disposed = true;
    proxies.clear(); captures.clear(); photons.clear();
    photonGeometry?.dispose(); resources.forEach(resource => resource.dispose());
  };
  try {
    const target = (depthBuffer: boolean) => own(new three.WebGLRenderTarget(1, 1, {
      type: three.HalfFloatType, minFilter: three.NearestFilter, magFilter: three.NearestFilter,
      generateMipmaps: false, depthBuffer,
    }));
    const front = target(true), back = target(true), frontNormal = target(true), backNormal = target(true);
    const focused = target(false), baseline = target(false);
    // Linear filtering is only for the finished light field, never the captured geometry.
    for (const map of [focused, baseline]) map.texture.minFilter = map.texture.magFilter = three.LinearFilter;
    const capture = own(new three.ShaderMaterial({ side: three.DoubleSide, toneMapped: false,
      uniforms: { uBack: { value: false }, uNormals: { value: false }, uLightWorld: { value: camera.matrixWorld } },
      vertexShader: CAUSTIC_CAPTURE_VERTEX, fragmentShader: CAUSTIC_CAPTURE_FRAGMENT,
    }));
    const photon = own(new three.ShaderMaterial({ transparent: true, blending: three.AdditiveBlending,
      depthTest: false, depthWrite: false, toneMapped: false,
      uniforms: {
        uFront: { value: front.texture }, uBack: { value: back.texture },
        uFrontNormal: { value: frontNormal.texture }, uBackNormal: { value: backNormal.texture },
        uLightProjection: { value: new three.Matrix4() }, uReceiverInverse: { value: new three.Matrix4() },
        uPlane: { value: new three.Vector4() }, uDirection: { value: direction },
        uIor: { value: initial.ior }, uPower: { value: 1 }, uFootprint: { value: initial.softness }, uRefract: { value: true },
      }, vertexShader: CAUSTIC_PHOTON_VERTEX, fragmentShader: CAUSTIC_PHOTON_FRAGMENT,
    }));
    const material = own(new three.ShaderMaterial({
      uniforms: { uFocused: { value: focused.texture }, uBaseline: { value: baseline.texture },
        uColor: { value: new three.Color() }, uFloor: { value: new three.Color() }, uIntensity: { value: initial.intensity } },
      vertexShader: CAUSTIC_RECEIVER_VERTEX, fragmentShader: CAUSTIC_RECEIVER_FRAGMENT,
    }));
    const surface = new three.Mesh(own(new three.PlaneGeometry(1, 1)), material);
    const configure = (next: CausticsConfig) => {
      if (disposed) return;
      if (!photonGeometry || next.samples !== config.samples) {
        const replacement = new three.BufferGeometry();
        try { replacement.setAttribute('position', new three.BufferAttribute(causticPhotonGrid(next.samples), 3)); }
        catch (error) { replacement.dispose(); throw error; }
        photonGeometry?.dispose(); photonGeometry = replacement;
        if (points) points.geometry = replacement;
        else { points = new three.Points(replacement, photon); points.frustumCulled = false; photons.add(points); }
      }
      config = next;
      for (const map of [focused, baseline]) if (map.width !== next.resolution) map.setSize(next.resolution, next.resolution);
      const captureSize = Math.min(512, next.samples * 2);
      for (const map of [front, back, frontNormal, backNormal]) if (map.width !== captureSize) map.setSize(captureSize, captureSize);
      surface.position.fromArray(next.position); surface.rotation.set(...next.rotation); surface.scale.set(...next.size, 1);
      material.uniforms.uColor.value.set(next.color); material.uniforms.uFloor.value.set(next.floorColor ?? '#000000');
      material.uniforms.uIntensity.value = next.enabled ? next.intensity : 0;
      const overlay = next.floorColor === null;
      if (material.transparent !== overlay) { material.transparent = overlay; material.needsUpdate = true; }
      material.blending = overlay ? three.AdditiveBlending : three.NormalBlending; material.depthWrite = !overlay;
      photon.uniforms.uIor.value = next.ior; photon.uniforms.uFootprint.value = next.softness;
    };
    const syncCasters = () => {
      const seen = new Set<any>();
      casterRef.current?.updateWorldMatrix(true, true);
      casterRef.current?.traverseVisible((source: any) => {
        if (!source.isMesh) return;
        if (source.isSkinnedMesh || source.isInstancedMesh || Object.keys(source.geometry?.morphAttributes ?? {}).length ||
          !source.geometry?.attributes.position || !source.geometry?.attributes.normal) {
          throw new Error('Caustics requires ordinary closed meshes with position/normal attributes; bake skinning, instances and morphs first.');
        }
        seen.add(source);
        let proxy = proxies.get(source);
        if (!proxy) { proxy = new three.Mesh(source.geometry, capture); proxy.matrixAutoUpdate = false; proxies.set(source, proxy); captures.add(proxy); }
        proxy.geometry = source.geometry; proxy.matrix.copy(source.matrixWorld);
      });
      proxies.forEach((proxy, source) => { if (!seen.has(source)) { captures.remove(proxy); proxies.delete(source); } });
      captures.updateMatrixWorld(true); bounds.setFromObject(captures); return !bounds.isEmpty();
    };
    surface.onBeforeRender = (renderer: any) => {
      if (disposed || !config.enabled || config.intensity === 0 || isAuxiliaryCapture(renderer)) return;
      if (checkedRenderer !== renderer) {
        if (!renderer.capabilities.isWebGL2 || renderer.capabilities.maxVertexTextures < 4 || !renderer.extensions.has('EXT_color_buffer_float')) {
          throw new Error('Caustics requires WebGL 2, floating-point color targets and four vertex texture units.');
        }
        checkedRenderer = renderer;
      }
      const hasCasters = syncCasters();
      if (hasCasters) {
        bounds.getBoundingSphere(sphere); center.copy(sphere.center); light.fromArray(config.lightSource);
        const distance = light.distanceTo(center), radius = Math.max(.01, sphere.radius) * 1.1;
        if (distance <= radius) throw new Error('Caustics lightSource must be outside the wrapped geometry.');
        camera.position.copy(light); direction.subVectors(center, light).normalize();
        camera.up.set(0, Math.abs(direction.y) > .99 ? 0 : 1, Math.abs(direction.y) > .99 ? 1 : 0);
        camera.lookAt(center); camera.left = camera.bottom = -radius; camera.right = camera.top = radius;
        camera.near = Math.max(.001, distance - radius); camera.far = distance + radius; camera.updateProjectionMatrix(); camera.updateMatrixWorld(true);
        surface.updateWorldMatrix(true, false);
        normalMatrix.getNormalMatrix(surface.matrixWorld); normal.set(0, 0, 1).applyMatrix3(normalMatrix).normalize();
        origin.setFromMatrixPosition(surface.matrixWorld); plane.setFromNormalAndCoplanarPoint(normal, origin);
        photon.uniforms.uPlane.value.set(normal.x, normal.y, normal.z, plane.constant);
        photon.uniforms.uReceiverInverse.value.copy(surface.matrixWorld).invert();
        photon.uniforms.uLightProjection.value.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
        axisX.setFromMatrixColumn(surface.matrixWorld, 0); axisY.setFromMatrixColumn(surface.matrixWorld, 1);
        photon.uniforms.uPower.value = causticPhotonPower(4 * radius * radius, axisX.cross(axisY).length(), config);
      }
      captureAuxiliary(renderer, () => preserve(renderer, () => {
        renderer.xr.enabled = false; renderer.autoClear = true; renderer.shadowMap.autoUpdate = false;
        renderer.toneMapping = three.NoToneMapping; renderer.setClearColor(0, 0);
        if (hasCasters) {
          for (const [map, isBack, isNormal] of [[front, false, false], [back, true, false], [frontNormal, false, true], [backNormal, true, true]]) {
            capture.uniforms.uBack.value = isBack; capture.uniforms.uNormals.value = isNormal;
            renderer.setRenderTarget(map); renderer.render(captures, camera);
          }
        }
        for (const [map, refract] of [[focused, true], [baseline, false]]) {
          renderer.setRenderTarget(map);
          if (hasCasters) { photon.uniforms.uRefract.value = refract; renderer.render(photons, camera); }
          else renderer.clear();
        }
      }));
    };
    configure(initial);
    return { surface, configure, dispose };
  } catch (error) { dispose(); throw error; }
}
