import { clampNumber } from '../core/numberOps.js';

export type GlassPreset = 'clear' | 'frosted' | 'smoked' | 'amber';
export interface GlassConfig {
  color: string;
  attenuationColor: string;
  attenuationDistance: number;
  transmission: number;
  roughness: number;
  thickness: number;
  ior: number;
  clearcoat: number;
  envMapIntensity: number;
}
export interface GlassMaterialProps extends Partial<GlassConfig> { preset?: GlassPreset }

const CLEAR: GlassConfig = {
  color: '#ffffff', attenuationColor: '#ffffff', attenuationDistance: 5,
  transmission: 1, roughness: .04, thickness: .8, ior: 1.5, clearcoat: 1, envMapIntensity: 1,
};
export const GLASS_PRESETS: Readonly<Record<GlassPreset, Readonly<GlassConfig>>> = {
  clear: CLEAR,
  frosted: { ...CLEAR, roughness: .4, thickness: 1.2 },
  smoked: { ...CLEAR, attenuationColor: '#667582', attenuationDistance: .65, roughness: .1 },
  amber: { ...CLEAR, attenuationColor: '#edaf50', attenuationDistance: .7, roughness: .08 },
};

/** Deliberately constrained colors keep invalid CSS out of Three's Color parser. */
export function surfaceColor(value: unknown, fallback: string): string {
  return typeof value === 'string' && /^#(?:[\da-f]{3}|[\da-f]{6})$/i.test(value) ? value : fallback;
}
export function resolveGlassConfig(props: GlassMaterialProps = {}): GlassConfig {
  const base = GLASS_PRESETS[props.preset ?? 'clear'] ?? CLEAR;
  return {
    color: surfaceColor(props.color, base.color),
    attenuationColor: surfaceColor(props.attenuationColor, base.attenuationColor),
    attenuationDistance: clampNumber(props.attenuationDistance, .01, 1000, base.attenuationDistance),
    transmission: clampNumber(props.transmission, 0, 1, base.transmission),
    roughness: clampNumber(props.roughness, 0, 1, base.roughness),
    thickness: clampNumber(props.thickness, 0, 10, base.thickness),
    ior: clampNumber(props.ior, 1, 2.333, base.ior),
    clearcoat: clampNumber(props.clearcoat, 0, 1, base.clearcoat),
    envMapIntensity: clampNumber(props.envMapIntensity, 0, 10, base.envMapIntensity),
  };
}
