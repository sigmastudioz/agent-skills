import { clampNumber } from '../core/numberOps.js';
import type { BlobTrackSignal, TrackedBlob } from './types.js';

export type Region = Omit<TrackedBlob, 'id'>;

/** RGBA pixels → per-cell signal in [0,1]: luminance, or its inverse for darkness. */
export function signalField(pixels: Uint8ClampedArray, signal: Exclude<BlobTrackSignal, 'motion'>): Float32Array {
  const field = new Float32Array(pixels.length / 4);
  for (let i = 0; i < field.length; i++) {
    const o = i * 4;
    const light = (pixels[o] * .2126 + pixels[o + 1] * .7152 + pixels[o + 2] * .0722) / 255;
    field[i] = signal === 'darkness' ? 1 - light : light;
  }
  return field;
}

/** Absolute per-cell change between two luminance fields of equal size. */
export function motionField(previous: Float32Array, current: Float32Array): Float32Array {
  const field = new Float32Array(current.length);
  for (let i = 0; i < current.length; i++) field[i] = Math.abs(current[i] - (previous[i] ?? current[i]));
  return field;
}

/** 3×3 box blur (edges clamp). Joins speckled cells into regions before thresholding. */
export function smoothField(field: Float32Array, columns: number, rows: number): Float32Array {
  const out = new Float32Array(field.length);
  for (let y = 0; y < rows; y++) for (let x = 0; x < columns; x++) {
    let sum = 0, count = 0;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const sx = x + dx, sy = y + dy;
      if (sx >= 0 && sy >= 0 && sx < columns && sy < rows) { sum += field[sy * columns + sx]; count++; }
    }
    out[y * columns + x] = sum / count;
  }
  return out;
}

/** Motion energy that decays instead of vanishing between changes: max(change, previous × decay). */
export function accumulateMotion(energy: Float32Array | null, change: Float32Array, decay = .7): Float32Array {
  if (!energy || energy.length !== change.length) return Float32Array.from(change);
  const out = new Float32Array(change.length);
  for (let i = 0; i < change.length; i++) out[i] = Math.max(change[i], energy[i] * decay);
  return out;
}

/** 4-connected regions where field ≥ threshold, largest first, normalized to the grid. */
export function findBlobs(field: Float32Array, columns: number, rows: number, threshold: number,
  minArea: number, maxBlobs: number): Region[] {
  const total = columns * rows;
  if (!columns || !rows || field.length < total) return [];
  const seen = new Uint8Array(total), stack = new Int32Array(total);
  const minCells = Math.max(1, Math.ceil(clampNumber(minArea, 0, 1, .004) * total));
  const regions: Region[] = [];
  for (let start = 0; start < total; start++) {
    if (seen[start] || field[start] < threshold) continue;
    let top = 0, count = 0, sx = 0, sy = 0;
    let minX = columns, minY = rows, maxX = 0, maxY = 0;
    stack[top++] = start; seen[start] = 1;
    while (top) {
      const cell = stack[--top], x = cell % columns, y = (cell - x) / columns;
      count++; sx += x; sy += y;
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      const push = (next: number) => { if (!seen[next] && field[next] >= threshold) { seen[next] = 1; stack[top++] = next; } };
      if (x > 0) push(cell - 1);
      if (x < columns - 1) push(cell + 1);
      if (y > 0) push(cell - columns);
      if (y < rows - 1) push(cell + columns);
    }
    if (count < minCells) continue;
    regions.push({
      x: minX / columns, y: minY / rows, width: (maxX - minX + 1) / columns, height: (maxY - minY + 1) / rows,
      cx: (sx / count + .5) / columns, cy: (sy / count + .5) / rows, area: count / total,
    });
  }
  return regions.sort((a, b) => b.area - a.area).slice(0, Math.round(clampNumber(maxBlobs, 1, 24, 8)));
}

/** Greedy nearest-center matching keeps IDs stable; unmatched regions get fresh IDs. */
export function matchBlobs(previous: readonly TrackedBlob[], regions: readonly Region[], nextId: number,
  maxDistance = .15): { blobs: TrackedBlob[]; nextId: number } {
  const free = new Set(previous.map((_, index) => index));
  let id = nextId;
  const blobs = regions.map(region => {
    let best = -1, bestDistance = maxDistance;
    free.forEach(index => {
      const d = Math.hypot(previous[index].cx - region.cx, previous[index].cy - region.cy);
      if (d < bestDistance) { bestDistance = d; best = index; }
    });
    if (best >= 0) { free.delete(best); return { ...region, id: previous[best].id }; }
    return { ...region, id: id++ };
  });
  return { blobs, nextId: id };
}

/** Same IDs and boxes (to grid precision) → no callback or redraw needed. */
export function sameBlobs(a: readonly TrackedBlob[], b: readonly TrackedBlob[]): boolean {
  return a.length === b.length && a.every((blob, i) => blob.id === b[i].id &&
    Math.abs(blob.x - b[i].x) < 1e-6 && Math.abs(blob.y - b[i].y) < 1e-6 &&
    Math.abs(blob.width - b[i].width) < 1e-6 && Math.abs(blob.height - b[i].height) < 1e-6);
}
