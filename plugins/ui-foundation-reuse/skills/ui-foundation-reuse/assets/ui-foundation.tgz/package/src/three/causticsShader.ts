// Original light-space photon splatting. No scene-wide shader patches or material replacement.
export const CAUSTIC_CAPTURE_VERTEX = `
uniform mat4 uLightWorld;
varying vec3 vWorld; varying vec3 vNormal;
void main(){
  vWorld=(modelMatrix*vec4(position,1.)).xyz;
  vNormal=normalize(mat3(uLightWorld)*normalMatrix*normal);
  gl_Position=projectionMatrix*viewMatrix*vec4(vWorld,1.);
}`;
export const CAUSTIC_CAPTURE_FRAGMENT = `
uniform bool uBack; uniform bool uNormals;
varying vec3 vWorld; varying vec3 vNormal;
void main(){
  if(gl_FrontFacing==uBack) discard;
  gl_FragColor=vec4(uNormals ? normalize(vNormal) : vWorld,1.);
}`;

export const CAUSTIC_PHOTON_VERTEX = `
uniform sampler2D uFront; uniform sampler2D uBack; uniform sampler2D uFrontNormal; uniform sampler2D uBackNormal;
uniform mat4 uLightProjection; uniform mat4 uReceiverInverse;
uniform vec4 uPlane; uniform vec3 uDirection;
uniform float uIor; uniform float uPower; uniform float uFootprint; uniform bool uRefract;
varying float vEnergy;
vec2 projectLight(vec3 p){vec4 q=uLightProjection*vec4(p,1.);return q.xy/q.w*.5+.5;}
bool inside(vec2 p){return all(greaterThanEqual(p,vec2(0.)))&&all(lessThanEqual(p,vec2(1.)));}
void main(){
  vEnergy=0.; gl_Position=vec4(2.,2.,2.,1.); gl_PointSize=uFootprint;
  vec2 uv=position.xy; vec4 entry=texture2D(uFront,uv), back=texture2D(uBack,uv);
  if(entry.a<.5||back.a<.5)return;
  vec3 origin=entry.xyz, ray=uDirection;
  if(uRefract){
    vec3 normal=normalize(texture2D(uFrontNormal,uv).xyz);
    ray=refract(uDirection,normal,1./uIor);
    vec3 exitNormal=normalize(texture2D(uBackNormal,uv).xyz);
    // Refine the exit intersection against the back surface in light space.
    for(int i=0;i<3;i++){
      float denominator=dot(ray,exitNormal);
      if(abs(denominator)<.0001)return;
      float distance=dot(back.xyz-entry.xyz,exitNormal)/denominator;
      if(distance<=0.)return;
      origin=entry.xyz+ray*distance;
      vec2 nextUv=projectLight(origin);
      if(!inside(nextUv))return;
      back=texture2D(uBack,nextUv);
      if(back.a<.5)return;
      exitNormal=normalize(texture2D(uBackNormal,nextUv).xyz);
    }
    ray=refract(ray,-exitNormal,uIor);
    if(dot(ray,ray)<.5)return; // Total internal reflection does not reach the floor.
  }
  float denominator=dot(uPlane.xyz,ray);
  if(abs(denominator)<.0001)return;
  float distance=-(dot(uPlane.xyz,origin)+uPlane.w)/denominator;
  if(distance<=0.)return;
  vec3 hit=(uReceiverInverse*vec4(origin+ray*distance,1.)).xyz;
  if(any(greaterThan(abs(hit.xy),vec2(.5))))return;
  gl_Position=vec4(hit.xy*2.,0.,1.); vEnergy=uPower;
}`;
export const CAUSTIC_PHOTON_FRAGMENT = `
varying float vEnergy;
void main(){vec2 p=gl_PointCoord*2.-1.;float kernel=exp(-4.*dot(p,p));
  gl_FragColor=vec4(vec3(vEnergy*kernel),1.);}
`;
export const CAUSTIC_RECEIVER_VERTEX = `
varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}
`;
export const CAUSTIC_RECEIVER_FRAGMENT = `
uniform sampler2D uFocused; uniform sampler2D uBaseline;
uniform vec3 uColor; uniform vec3 uFloor; uniform float uIntensity;
varying vec2 vUv;
void main(){
  float light=max(texture2D(uFocused,vUv).r-texture2D(uBaseline,vUv).r,0.);
  gl_FragColor=vec4(uFloor+uColor*light*uIntensity,1.);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;
