export { BallPit } from './BallPit.js';
export type { BallPitProps } from './BallPit.js';
// Re-export the rapier primitives so consumers can compose custom physics
// through this package (used inside <Scene>/<World>).
export {
  Physics,
  RigidBody,
  CuboidCollider,
  BallCollider,
  CapsuleCollider,
} from '@react-three/rapier';
