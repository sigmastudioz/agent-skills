import { createFullscreenPass, createTexture } from '../core/fullscreenPass.js';
import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import type { InteractionState } from '../core/interaction.js';
import type { FluidConfig } from './types.js';
import { FLUID_DISPLAY, FLUID_SIMULATION } from './fluidShader.js';
import { fluidRgb, simulationSize } from './fluidOps.js';
export interface FluidRenderer extends WebGLRendererLike { render(config: FluidConfig, time: number, input: InteractionState, interactive: boolean): void }
export function createFluidRenderer(canvas: HTMLCanvasElement, limit: number): FluidRenderer | null {
  const gl = canvas.getContext('webgl', { alpha: false, antialias: false, depth: false }); if (!gl) return null;
  const cleanups: (() => void)[] = [];
  const dispose = () => cleanups.splice(0).reverse().forEach(fn => fn());
  try {
    const sim = createFullscreenPass(gl, FLUID_SIMULATION, ['uPrevious','uPointer','uLastPointer','uSize','uTime','uDelta','uActive','uPersistence']); cleanups.push(sim.dispose);
    const display = createFullscreenPass(gl, FLUID_DISPLAY, ['uDye','uSize','uColor','uAccent','uTime']); cleanups.push(display.dispose);
    const targets = [0,1].map(() => {
      const texture = createTexture(gl); cleanups.push(() => gl.deleteTexture(texture));
      const framebuffer = gl.createFramebuffer(); if (!framebuffer) throw new Error('Framebuffer allocation failed');
      cleanups.push(() => gl.deleteFramebuffer(framebuffer)); return { texture, framebuffer };
    });
    let w=1,h=1,read=0,lastTime=-1,phase=0,lastX=.5,lastY=.5,wasActive=false;
    let palette=''; let color: [number,number,number]=[0,0,0],accent: [number,number,number]=[1,1,1];
    return {
      resize(width,height,dpr) {
        canvas.width=Math.max(1,Math.round(width*dpr));canvas.height=Math.max(1,Math.round(height*dpr));
        const size=simulationSize(canvas.width,canvas.height,limit);w=size[0];h=size[1];
        targets.forEach(target=>{
          gl.bindTexture(gl.TEXTURE_2D,target.texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,w,h,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
          gl.bindFramebuffer(gl.FRAMEBUFFER,target.framebuffer);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,target.texture,0);
          if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Incomplete fluid target');
          gl.clearColor(0,0,0,1);gl.clear(gl.COLOR_BUFFER_BIT);
        }); gl.bindFramebuffer(gl.FRAMEBUFFER,null);
      },
      render(config,time,input,interactive) {
        const dt=lastTime<0?1/60:Math.min(.05,Math.max(0,time-lastTime));lastTime=time;phase+=dt*config.speed;
        const x=input.x*.5+.5,y=input.y*.5+.5,active=interactive&&input.active;
        if(!wasActive){lastX=x;lastY=y;}wasActive=active;
        sim.use();gl.bindFramebuffer(gl.FRAMEBUFFER,targets[1-read].framebuffer);gl.viewport(0,0,w,h);
        gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,targets[read].texture);
        const u=sim.uniforms;gl.uniform1i(u.uPrevious,0);gl.uniform2f(u.uSize,w,h);gl.uniform1f(u.uTime,phase);
        gl.uniform1f(u.uDelta,dt*config.speed);gl.uniform1f(u.uPersistence,config.persistence);gl.uniform1f(u.uActive,active?1:0);
        gl.uniform2f(u.uPointer,x,y);gl.uniform2f(u.uLastPointer,lastX,lastY);sim.draw();read=1-read;lastX=x;lastY=y;
        display.use();gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);
        gl.bindTexture(gl.TEXTURE_2D,targets[read].texture);
        const key=config.color+config.accentColor;if(key!==palette){palette=key;color=fluidRgb(config.color);accent=fluidRgb(config.accentColor);}
        const v=display.uniforms;gl.uniform1i(v.uDye,0);gl.uniform2f(v.uSize,canvas.width,canvas.height);gl.uniform1f(v.uTime,phase);
        gl.uniform3f(v.uColor,...color);gl.uniform3f(v.uAccent,...accent);display.draw();
      }, dispose,
    };
  } catch { dispose();return null; }
}
