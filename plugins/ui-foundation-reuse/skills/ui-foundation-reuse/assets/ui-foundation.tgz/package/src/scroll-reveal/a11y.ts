import type { CSSProperties } from 'react';

/** Screen-reader-only text. aria-label is prohibited on generic and paragraph roles. */
export const VISUALLY_HIDDEN: CSSProperties = {
  position: 'absolute', width: 1, height: 1, padding: 0, margin: -1, overflow: 'hidden',
  clip: 'rect(0 0 0 0)', clipPath: 'inset(50%)', whiteSpace: 'nowrap', border: 0,
};
