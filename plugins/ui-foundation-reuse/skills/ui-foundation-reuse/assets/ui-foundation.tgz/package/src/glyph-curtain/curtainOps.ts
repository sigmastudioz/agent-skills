import { clampNumber } from '../core/numberOps.js';
import type { CurtainConfig, GlyphCurtainProps } from './types.js';

export function resolveCurtainConfig(props: GlyphCurtainProps): CurtainConfig {
  return {
    columns: Math.round(clampNumber(props.columns, 4, 64, 32)),
    rows: Math.round(clampNumber(props.rows, 4, 48, 24)),
    damping: clampNumber(props.damping, .8, .995, .97),
    stiffness: clampNumber(props.stiffness, .2, 1, .9),
    gravity: clampNumber(props.gravity, 0, 800, 180),
    radius: clampNumber(props.radius, 10, 240, 85),
    force: clampNumber(props.force, 0, 12, 3.5),
    fontSize: clampNumber(props.fontSize, 3, 48, 17),
  };
}

export interface CurtainField {
  x: Float32Array; y: Float32Array; previousX: Float32Array; previousY: Float32Array;
  width: number; height: number; segment: number; columns: number; rows: number; top: number;
}

export function curtainAnchor(field: CurtainField, column: number): number {
  return field.width * (.06 + .88 * column / Math.max(1, field.columns - 1));
}

export function createCurtainField(width: number, height: number, config: CurtainConfig): CurtainField {
  width = Math.max(1, Number.isFinite(width) ? width : 1);
  height = Math.max(1, Number.isFinite(height) ? height : 1);
  const length = config.columns * config.rows, top = Math.min(config.fontSize, height / 10);
  const field: CurtainField = { x: new Float32Array(length), y: new Float32Array(length),
    previousX: new Float32Array(length), previousY: new Float32Array(length),
    width, height, top, segment: Math.max(.1, (height - top * 2) / (config.rows - 1)), columns: config.columns, rows: config.rows };
  resetCurtainField(field);
  return field;
}

export function resetCurtainField(field: CurtainField): void {
  for (let col = 0; col < field.columns; col++) for (let row = 0; row < field.rows; row++) {
    const index = col * field.rows + row;
    field.x[index] = field.previousX[index] = curtainAnchor(field, col);
    field.y[index] = field.previousY[index] = field.top + row * field.segment;
  }
}

/** Fixed timestep, pinned independent strands. Returns average squared velocity. */
export function stepCurtainField(field: CurtainField, config: CurtainConfig,
  pointer: { x: number; y: number } | null = null): number {
  const { x, y, previousX, previousY, rows } = field;
  for (let i = 0; i < x.length; i++) {
    if (i % rows === 0) continue;
    const oldX = x[i], oldY = y[i];
    x[i] += (x[i] - previousX[i]) * config.damping;
    y[i] += (y[i] - previousY[i]) * config.damping + config.gravity / 3600;
    previousX[i] = oldX; previousY[i] = oldY;
    // Weak centering gives displaced strands a bounded resting state.
    x[i] += (curtainAnchor(field, Math.floor(i / rows)) - x[i]) * .0008;
    if (pointer && Number.isFinite(pointer.x) && Number.isFinite(pointer.y)) {
      let dx = x[i] - pointer.x; const dy = y[i] - pointer.y;
      if (Math.abs(dx) < .01) dx = Math.floor(i / rows) % 2 ? .5 : -.5;
      const distance = Math.hypot(dx, dy);
      if (distance < config.radius) {
        const pressure = (1 - distance / config.radius) * config.force;
        x[i] += dx / Math.max(1, distance) * pressure;
        y[i] += dy / Math.max(1, distance) * pressure;
      }
    }
    x[i] = Math.max(-field.width * .25, Math.min(field.width * 1.25, x[i]));
    y[i] = Math.max(-field.height * .25, Math.min(field.height * 1.25, y[i]));
  }
  for (let iteration = 0; iteration < 6; iteration++) {
    for (let col = 0; col < field.columns; col++) {
      const first = col * rows;
      x[first] = previousX[first] = curtainAnchor(field, col);
      y[first] = previousY[first] = field.top;
      for (let row = 1; row < rows; row++) {
        const b = first + row, a = b - 1;
        const dx = x[b] - x[a], dy = y[b] - y[a], length = Math.hypot(dx, dy) || .001;
        const ratio = (length - field.segment) / length * config.stiffness;
        const weight = row === 1 ? 1 : .5;
        x[b] -= dx * ratio * weight; y[b] -= dy * ratio * weight;
        if (row !== 1) { x[a] += dx * ratio * .5; y[a] += dy * ratio * .5; }
      }
    }
  }
  let energy = 0;
  for (let i = 0; i < x.length; i++) energy += (x[i] - previousX[i]) ** 2 + (y[i] - previousY[i]) ** 2;
  return energy / x.length;
}
