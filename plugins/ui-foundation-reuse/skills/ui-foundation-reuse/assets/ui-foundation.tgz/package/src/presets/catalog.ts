import type { CuratedPreset, PresetFilter } from './types.js';

const recipes: CuratedPreset[] = [
  {
    id: 'atlantic', name: 'Atlantic', effect: 'gradient', mood: 'calm', tone: 'dark',
    description: 'A slow tide of ink, slate and sea green.', tags: ['water', 'editorial', 'background'],
    guidance: 'Use as a broad backdrop. Keep body text on a solid surface or add a scrim.',
    palette: ['#081f30', '#296879', '#86cfbb'],
    props: { colors: ['#081f30', '#296879', '#86cfbb'], shape: 'waterPlane', speed: 0.18, amplitude: 0.8, frequency: 1.2 },
  },
  {
    id: 'paper-haze', name: 'Paper haze', effect: 'gradient', mood: 'calm', tone: 'light',
    description: 'Soft mineral colour with a low, rolling field.', tags: ['minimal', 'pastel', 'background'],
    guidance: 'Pair with dark typography. Check contrast at the brightest and darkest frame.',
    palette: ['#d5e2df', '#b4bfcf', '#f0ece5'],
    props: { colors: ['#d5e2df', '#b4bfcf', '#f0ece5'], shape: 'plane', speed: 0.1, amplitude: 0.45, frequency: 1.5 },
  },
  {
    id: 'ember-silk', name: 'Ember silk', effect: 'gradient', mood: 'dramatic', tone: 'dark',
    description: 'Burnt orange folds against a deep red field.', tags: ['warm', 'launch', 'background'],
    guidance: 'A strong opening accent. Keep nearby sections quieter to preserve its impact.',
    palette: ['#280e1a', '#b93d25', '#ffb15d'],
    props: { colors: ['#280e1a', '#b93d25', '#ffb15d'], shape: 'sphere', speed: 0.25, amplitude: 1.2, frequency: 0.9 },
  },
  {
    id: 'brushed-silver', name: 'Brushed silver', effect: 'liquid-metal', mood: 'calm', tone: 'dark',
    description: 'Cool silver relief with a restrained blue rim.', tags: ['chrome', 'wordmark', 'identity'],
    guidance: 'Try a short wordmark. Empty the text field for a full material surface.',
    palette: ['#161d27', '#e3e9ed', '#7d9cae'],
    props: { metalLow: '#161d27', metalHigh: '#e3e9ed', tint: '#7d9cae', speed: 0.25, amplitude: 0.65 },
  },
  {
    id: 'champagne-foil', name: 'Champagne foil', effect: 'liquid-metal', mood: 'luminous', tone: 'dark',
    description: 'Pale gold highlights over warm metal shadows.', tags: ['gold', 'wordmark', 'identity'],
    guidance: 'Best as an accent mark; keep essential copy as ordinary accessible text.',
    palette: ['#302514', '#f3e4bf', '#bda070'],
    props: { metalLow: '#302514', metalHigh: '#f3e4bf', tint: '#bda070', speed: 0.3, amplitude: 0.85 },
  },
  {
    id: 'midnight-chrome', name: 'Midnight chrome', effect: 'liquid-metal', mood: 'dramatic', tone: 'dark',
    description: 'High-relief graphite with electric blue edges.', tags: ['graphite', 'tech', 'identity'],
    guidance: 'Use for a large decorative mark. Provide a semantic label separately.',
    palette: ['#05070e', '#9baecb', '#3f79eb'],
    props: { metalLow: '#05070e', metalHigh: '#9baecb', tint: '#3f79eb', speed: 0.55, amplitude: 1.5 },
  },
  {
    id: 'opal-fold', name: 'Opal fold', effect: 'iridescence', mood: 'calm', tone: 'light',
    description: 'Broad pearlescent folds with a soft mint highlight.', tags: ['pearl', 'material', 'minimal'],
    guidance: 'Keep the folds large for smaller surfaces; test pointer-free use on touch devices.',
    palette: ['#b9bdcb', '#e3f6e9'],
    props: { baseColor: '#b9bdcb', accentColor: '#e3f6e9', intensity: 0.32, roughness: 0.5, scale: 0.8, speed: 0.18, rotation: -20, interactive: true },
  },
  {
    id: 'petrol-film', name: 'Petrol film', effect: 'iridescence', mood: 'dramatic', tone: 'dark',
    description: 'A dark spectral film with tightly folded highlights.', tags: ['oil', 'spectral', 'material'],
    guidance: 'Treat as a focal material rather than a body-text surface.',
    palette: ['#101b26', '#7bdac9'],
    props: { baseColor: '#101b26', accentColor: '#7bdac9', intensity: 0.9, roughness: 0.2, scale: 1.8, speed: 0.3, rotation: 32, interactive: true },
  },
  {
    id: 'rose-satin', name: 'Rose satin', effect: 'iridescence', mood: 'luminous', tone: 'light',
    description: 'Warm satin with gently shifting peach reflections.', tags: ['rose', 'soft', 'material'],
    guidance: 'Use a solid backing for controls placed over the material.',
    palette: ['#a17488', '#ffe1c8'],
    props: { baseColor: '#a17488', accentColor: '#ffe1c8', intensity: 0.4, roughness: 0.42, scale: 1, speed: 0.2, rotation: -12, interactive: true },
  },
  {
    id: 'firefly-dusk', name: 'Firefly dusk', effect: 'particles', mood: 'calm', tone: 'dark',
    description: 'Sparse golden points drifting through the dark.', tags: ['gold', 'ambient', 'points'],
    guidance: 'Sparse counts leave breathing room. Pointer repulsion is optional, never required.',
    palette: ['#05060a', '#edcd76'],
    props: { color: '#edcd76', count: 1200, size: 3, speed: 0.35, mouseRadius: 0.16 },
  },
  {
    id: 'arctic-dust', name: 'Arctic dust', effect: 'particles', mood: 'luminous', tone: 'dark',
    description: 'Fine, cool-white particles with a slow current.', tags: ['snow', 'ambient', 'points'],
    guidance: 'Keep point size small for a distant field. No WebGL leaves the dark backing.',
    palette: ['#05060a', '#d7e9ff'],
    props: { color: '#d7e9ff', count: 2200, size: 1.8, speed: 0.4, mouseRadius: 0.12 },
  },
  {
    id: 'biolume', name: 'Biolume', effect: 'particles', mood: 'luminous', tone: 'dark',
    description: 'A lively field of sea-green light.', tags: ['green', 'interactive', 'points'],
    guidance: 'Try fewer points on small screens. Count changes rebuild the particle buffer.',
    palette: ['#05060a', '#60e2bc'],
    props: { color: '#60e2bc', count: 2800, size: 2.5, speed: 0.65, mouseRadius: 0.22 },
  },
  {
    id: 'ion-tunnel', name: 'Ion tunnel', effect: 'warp', mood: 'dramatic', tone: 'dark',
    description: 'Cool light streaks converging into a navy field.', tags: ['blue', 'speed', 'radial'],
    guidance: 'Use as a brief focal moment. Offer pause and respect reduced-motion settings.',
    palette: ['#d6ecff', '#142d65'],
    props: { core: '#d6ecff', edge: '#142d65', speed: 0.75, density: 22 },
  },
  {
    id: 'copper-flight', name: 'Copper flight', effect: 'warp', mood: 'dramatic', tone: 'dark',
    description: 'Warm copper streaks and a pale amber core.', tags: ['orange', 'speed', 'radial'],
    guidance: 'Avoid placing a primary action on the bright focal point.',
    palette: ['#ffe4b9', '#4c210f'],
    props: { core: '#ffe4b9', edge: '#4c210f', speed: 1.1, density: 32 },
  },
  {
    id: 'after-hours', name: 'After hours', effect: 'warp', mood: 'calm', tone: 'dark',
    description: 'Sparse silver trails against a deep neutral edge.', tags: ['mono', 'space', 'radial'],
    guidance: 'A quieter tunnel; paused mode keeps a static shader frame.',
    palette: ['#bfc8d4', '#11151e'],
    props: { core: '#bfc8d4', edge: '#11151e', speed: 0.3, density: 16 },
  },
  {
    id: 'tidal-ink', name: 'Tidal ink', effect: 'fluid-field', mood: 'calm', tone: 'dark',
    description: 'Blue ink with long, seafoam-coloured trails.', tags: ['water', 'interactive', 'fluid'],
    guidance: 'Works without a pointer. Resolution changes recreate the simulation.',
    palette: ['#126879', '#a4e5cd'],
    props: { color: '#126879', accentColor: '#a4e5cd', speed: 0.4, persistence: 0.975, resolution: 384, interactive: true },
  },
  {
    id: 'solar-bloom', name: 'Solar bloom', effect: 'fluid-field', mood: 'luminous', tone: 'dark',
    description: 'Coral currents carrying a warm yellow glow.', tags: ['warm', 'interactive', 'fluid'],
    guidance: 'Let the material be the focus. Essential information needs its own readable surface.',
    palette: ['#bc3549', '#ffcf84'],
    props: { color: '#bc3549', accentColor: '#ffcf84', speed: 0.65, persistence: 0.96, resolution: 384, interactive: true },
  },
  {
    id: 'violet-current', name: 'Violet current', effect: 'fluid-field', mood: 'dramatic', tone: 'dark',
    description: 'Violet eddies with bright lilac afterimages.', tags: ['violet', 'interactive', 'fluid'],
    guidance: 'Check a static frame before shipping. Touch interaction must remain optional.',
    palette: ['#4f2993', '#e4afe9'],
    props: { color: '#4f2993', accentColor: '#e4afe9', speed: 0.8, persistence: 0.98, resolution: 384, interactive: true },
  },
];

// Shared recipes are immutable at runtime as well as in the public type contract.
for (const recipe of recipes) {
  for (const value of Object.values(recipe.props)) if (Array.isArray(value)) Object.freeze(value);
  Object.freeze(recipe.props); Object.freeze(recipe.palette); Object.freeze(recipe.tags); Object.freeze(recipe);
}
export const CURATED_PRESETS: readonly CuratedPreset[] = Object.freeze(recipes);

export function getCuratedPreset(id: string): CuratedPreset | undefined {
  return CURATED_PRESETS.find(recipe => recipe.id === id);
}

/** Every query word must match; independent facets are combined with AND. */
export function findCuratedPresets(filter: PresetFilter = {}): readonly CuratedPreset[] {
  const words = (filter.query ?? '').trim().toLowerCase().split(/\s+/).filter(Boolean);
  return CURATED_PRESETS.filter(recipe => {
    const text = [recipe.name, recipe.effect, recipe.description, recipe.mood, recipe.tone, ...recipe.tags].join(' ').toLowerCase();
    return (!filter.effect || recipe.effect === filter.effect) && (!filter.mood || recipe.mood === filter.mood) &&
      (!filter.tone || recipe.tone === filter.tone) && words.every(word => text.includes(word));
  });
}
