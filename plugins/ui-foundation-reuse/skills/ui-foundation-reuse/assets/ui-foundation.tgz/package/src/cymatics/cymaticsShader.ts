export const CYMATICS_SURFACE = `
precision highp float;
varying vec2 vUv;
uniform vec2 uResolution;
uniform float uCircle,uLiquid,uTime,uLevel;
uniform vec3 uColor;
uniform sampler2D uField;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
void main(){
  vec2 p=(vUv-.5)*2.0*uResolution/min(uResolution.x,uResolution.y)/.92;
  float edge=mix(max(abs(p.x),abs(p.y)),length(p),uCircle);
  if(edge>1.045){gl_FragColor=vec4(0.0);return;}
  float grain=hash(gl_FragCoord.xy);
  vec3 color=vec3(.032,.031,.026)+grain*.008;
  if(uLiquid>.5 && edge<.995){
    vec2 uv=p*.5+.5,texel=vec2(1.0/112.0);
    float h=texture2D(uField,uv).r;
    float dx=texture2D(uField,uv+vec2(texel.x,0)).r-texture2D(uField,uv-vec2(texel.x,0)).r;
    float dy=texture2D(uField,uv+vec2(0,texel.y)).r-texture2D(uField,uv-vec2(0,texel.y)).r;
    vec3 normal=normalize(vec3(-dx*18.0,-dy*18.0,1.0));
    float spec=pow(max(0.0,dot(normal,normalize(vec3(-.5,.7,1.0)))),28.0);
    float reflection=pow(max(0.0,normal.y*.6+normal.x*.3+.4),3.0);
    float contour=pow(.5+.5*cos(h*30.0-uTime*1.5),8.0)*uLevel;
    color=vec3(.025,.032,.035)+uColor*(reflection*.65+contour*.12)+vec3(.95,.92,.81)*spec*.9;
  }
  float rim=exp(-pow((edge-1.018)*170.0,2.0));
  float inner=exp(-pow((edge-.998)*260.0,2.0));
  color=mix(color,vec3(.28,.26,.22),rim*.8);
  color+=vec3(.7,.65,.54)*inner*.5;
  float alpha=1.0-smoothstep(1.035,1.045,edge);
  gl_FragColor=vec4(color,alpha);
}`;

export const CYMATICS_GRAIN_VERTEX = `
precision highp float;
attribute vec2 aPosition;
attribute float aGrain;
uniform vec2 uResolution;
uniform float uDpr,uSize;
varying float vGrain;
void main(){
  vec2 p=aPosition*.92*min(uResolution.x,uResolution.y)/uResolution;
  gl_Position=vec4(p,0.0,1.0);
  gl_PointSize=clamp(uSize*uDpr*(.62+aGrain*.72),1.0,8.0);
  vGrain=aGrain;
}`;
export const CYMATICS_GRAIN_FRAGMENT = `
precision highp float;
uniform vec3 uColor;
varying float vGrain;
void main(){
  vec2 p=gl_PointCoord-.5;
  float coverage=1.0-smoothstep(.2,.52,length(p));
  vec3 color=uColor*(.5+vGrain*.8);
  gl_FragColor=vec4(color,coverage*(.55+vGrain*.4));
}`;
