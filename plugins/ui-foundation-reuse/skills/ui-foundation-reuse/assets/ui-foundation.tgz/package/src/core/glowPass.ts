/** Owned buffer/program lifecycle for the particle-form and luminous-trails passes. */
export function createGlowPass(
  canvas: HTMLCanvasElement,
  vertex: string,
  fragment: string,
  data: Float32Array | (() => Float32Array),
  attributes: readonly (readonly [name: string, size: number])[],
  names: readonly string[],
) {
  const gl = canvas.getContext('webgl', { alpha: true, antialias: false, depth: false, premultipliedAlpha: true });
  if (!gl) return null;
  const shaders: WebGLShader[] = [];
  let program: WebGLProgram | null = null;
  let buffer: WebGLBuffer | null = null;
  const dispose = () => {
    if (buffer) gl.deleteBuffer(buffer);
    if (program) gl.deleteProgram(program);
    shaders.forEach(shader => gl.deleteShader(shader));
  };
  try {
    for (const [kind, source] of [[gl.VERTEX_SHADER, vertex], [gl.FRAGMENT_SHADER, fragment]] as const) {
      const shader = gl.createShader(kind);
      if (!shader) throw new Error('Shader allocation failed');
      shaders.push(shader);
      gl.shaderSource(shader, source); gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error('Shader compilation failed');
    }
    program = gl.createProgram();
    if (!program) throw new Error('Program allocation failed');
    shaders.forEach(shader => gl.attachShader(program!, shader));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error('Program linking failed');
    buffer = gl.createBuffer();
    if (!buffer) throw new Error('Buffer allocation failed');
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, typeof data === 'function' ? data() : data, gl.STATIC_DRAW);
    const stride = attributes.reduce((sum, [, size]) => sum + size, 0);
    let offset = 0;
    const slots = attributes.map(([name, size]) => {
      const slot = { location: gl.getAttribLocation(program!, name), size, offset };
      offset += size; return slot;
    });
    const uniforms = Object.fromEntries(names.map(name => [name, gl.getUniformLocation(program!, name)]));
    // RGB is premultiplied by blending; accumulate light, union coverage. Using
    // SRC_ALPHA for the alpha channel too would square it and dim transparent art.
    gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE, gl.ONE, gl.ONE_MINUS_SRC_ALPHA); gl.disable(gl.DEPTH_TEST);
    return {
      gl, uniforms, dispose,
      resize(width: number, height: number, dpr: number) {
        canvas.width = Math.max(1, Math.round(width * dpr));
        canvas.height = Math.max(1, Math.round(height * dpr));
        gl.viewport(0, 0, canvas.width, canvas.height);
      },
      use() {
        gl.useProgram(program); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
        slots.forEach(slot => {
          if (slot.location < 0) return;
          gl.enableVertexAttribArray(slot.location);
          gl.vertexAttribPointer(slot.location, slot.size, gl.FLOAT, false, stride * 4, slot.offset * 4);
        });
        gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
      },
    };
  } catch { dispose(); return null; }
}

/** Integrate speed instead of multiplying absolute time: changing speed never rewinds. */
export function createGlowClock() {
  let previous: number | undefined, phase = 0;
  return (time: number, speed: number) => {
    if (previous !== undefined) phase += Math.max(0, time - previous) * speed;
    previous = time;
    return phase;
  };
}

/** Validated hex colors shared by both luminous effects. */
export function glowColor(value: unknown, fallback: string): string {
  return typeof value === 'string' && /^#(?:[\da-f]{3}|[\da-f]{6})$/i.test(value) ? value : fallback;
}
export function glowRgb(hex: string): [number, number, number] {
  const text = hex.length === 4 ? hex.slice(1).split('').map(c => c + c).join('') : hex.slice(1);
  const value = parseInt(text, 16);
  return [(value >> 16 & 255) / 255, (value >> 8 & 255) / 255, (value & 255) / 255];
}
