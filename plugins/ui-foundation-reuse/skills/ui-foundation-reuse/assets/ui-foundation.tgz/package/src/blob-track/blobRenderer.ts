import { coverScale } from '../core/imageFit.js';
import type { TrackedBlob } from './types.js';

type Drawable = HTMLImageElement | HTMLVideoElement;
const sizeOf = (media: Drawable): [number, number] => media instanceof HTMLVideoElement
  ? [media.videoWidth, media.videoHeight] : [media.naturalWidth, media.naturalHeight];

/** Cover-crop the current frame into a columns × rows grid. Throws SecurityError on tainted media. */
export function sampleFrame(context: CanvasRenderingContext2D, media: Drawable, columns: number, rows: number,
  frameWidth: number, frameHeight: number): Uint8ClampedArray | null {
  const [iw, ih] = sizeOf(media);
  if (!iw || !ih) return null;
  const [sx, sy] = coverScale(iw, ih, frameWidth, frameHeight), sw = iw * sx, sh = ih * sy;
  context.drawImage(media, (iw - sw) / 2, (ih - sh) / 2, sw, sh, 0, 0, columns, rows);
  return context.getImageData(0, 0, columns, rows).data;
}

export interface HudStyle { color: string; labels: boolean; crosshair: boolean; links: boolean }

/** Bracketed boxes, crosshairs, labels and links, in CSS pixels. */
export function drawHud(context: CanvasRenderingContext2D, blobs: readonly TrackedBlob[], width: number,
  height: number, style: HudStyle): void {
  context.clearRect(0, 0, width, height);
  if (!blobs.length) return;
  context.strokeStyle = context.fillStyle = style.color;
  context.lineWidth = 1;
  context.font = '10px ui-monospace, SFMono-Regular, Menlo, monospace';
  if (style.links && blobs.length > 1) {
    context.globalAlpha = .45; context.setLineDash([3, 4]); context.beginPath();
    blobs.forEach((blob, i) => (i ? context.lineTo : context.moveTo).call(context, blob.cx * width, blob.cy * height));
    context.stroke(); context.setLineDash([]); context.globalAlpha = 1;
  }
  blobs.forEach(blob => {
    const x = blob.x * width, y = blob.y * height, w = blob.width * width, h = blob.height * height;
    const arm = Math.max(4, Math.min(w, h) * .25);
    context.beginPath();
    for (const [cx, cy, dx, dy] of [[x, y, 1, 1], [x + w, y, -1, 1], [x, y + h, 1, -1], [x + w, y + h, -1, -1]]) {
      context.moveTo(cx + dx * arm, cy); context.lineTo(cx, cy); context.lineTo(cx, cy + dy * arm);
    }
    context.stroke();
    if (style.crosshair) {
      const px = blob.cx * width, py = blob.cy * height;
      context.beginPath(); context.moveTo(px - 5, py); context.lineTo(px + 5, py);
      context.moveTo(px, py - 5); context.lineTo(px, py + 5); context.stroke();
    }
    if (style.labels) {
      const label = `ID ${String(blob.id).padStart(2, '0')} · ${(blob.area * 100).toFixed(1)}%`;
      context.fillText(label, x, Math.max(10, y - 4));
    }
  });
}
