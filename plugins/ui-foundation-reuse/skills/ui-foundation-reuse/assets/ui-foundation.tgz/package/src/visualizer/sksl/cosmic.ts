import { REACTIVE_COMMON } from './reactiveCommon.js';

export const COSMIC_SKSL = `${REACTIVE_COMMON}

half4 main(float2 fragCoord){

 float2 uv=fragCoord/uResolution,p=(fragCoord-uResolution*.5)/uResolution.y*2.0;
 float r=length(p),core=.24+uBass*.105;
 float warpedY=p.y*(1.0-.42*exp(-p.x*p.x*6.0));
 float2 disk=float2(p.x,warpedY*3.5);float radius=length(disk),angle=atan(disk.y,disk.x);
 float turbulence=fbm(disk*8.0+float2(uTime*.15,0.0));
 float rings=pow(.5+.5*sin(radius*75.0-angle*2.0+turbulence*9.0-uTime*(.8+uMid)),8.0);
 float falloff=exp(-max(0.0,radius-core)*2.2)*smoothstep(core*.9,core*1.5,radius);
 float3 col=float3(.004,.006,.02);
 float3 diskColor=mix(float3(1.0,.68,.3),palette(turbulence),.5);
 col+=diskColor*falloff*(.22+rings*.8+turbulence*.7)*(1.0+uMid*1.5);
 float lensed=glow(r-core,.014)+glow(r-core,.045)*.3;
 col+=float3(1.0,.78,.45)*lensed*(1.1+uBass+uBeat*.5);
 col+=palette(.3)*glow(r-core-.045,.009)*(.3+uTreble*.3);
 for(int i=0;i<3;i++){
  float layer=float(i)+1.0;float2 q=p*(18.0+layer*10.0)+float2(uTime*.025*layer,0.0);
  float seed=hash(floor(q));float2 star=fract(q)-.5;
  float light=glow(length(star),.025)*step(.978,seed);
  col+=mix(float3(.45,.7,1.0),float3(1.0,.8,.6),seed)*light*(.45+uTreble*2.0)/layer;
 }
 col*=smoothstep(core-.012,core+.012,r);
 col+=palette(.4)*glow(p.y,.018)*exp(-abs(p.x)*.85)*smoothstep(core,core+.2,r)*(.16+uMid*.35);
 return half4(finish(col,uv),1.0);
}
`;
