import { clampNumber } from '../core/numberOps.js';
import { resolveHeatmapRamp } from '../heatmap/heatmapOps.js';
import type { ImageFilterKind, ImageFilterProps, ResolvedImageFilterConfig } from './types.js';

const KINDS: ImageFilterKind[] = [
  'ascii', 'halftone', 'pixelate', 'chromatic', 'posterize', 'stipple', 'thermal', 'phosphor',
  'liquid', 'xerox', 'raster', 'solarized', 'teletext', 'heatmap',
  'lens-distortion', 'moving-blobs', 'slice-shift', 'pixel-stretch', 'image-warp',
];
function hexColor(value: string | undefined, fallback: string): string {
  if (!value || !/^#(?:[\da-f]{3}|[\da-f]{6})$/i.test(value)) return fallback;
  return value.length === 4 ? '#' + [...value.slice(1)].map(char => char + char).join('') : value;
}
export function resolveImageFilterConfig(props: Partial<ImageFilterProps> = {}): ResolvedImageFilterConfig {
  const kind = KINDS.includes(props.kind as ImageFilterKind) ? props.kind! : 'ascii';
  return {
    kind,
    cellSize: clampNumber(props.cellSize, 4, 64, 10),
    intensity: clampNumber(props.intensity, 0, 1, 1),
    color: hexColor(props.color, '#e8ecf2'),
    backgroundColor: hexColor(props.backgroundColor, '#10131a'),
    monochrome: props.monochrome ?? true,
    invert: props.invert ?? false,
    offset: clampNumber(props.offset, 0, 64, 6),
    angle: clampNumber(props.angle, -360, 360, 0),
    levels: Math.round(clampNumber(props.levels, 2, 16, 4)),
    contrast: clampNumber(props.contrast, .1, 3, 1),
    colorRamp: resolveHeatmapRamp(props.colorRamp),
    accentColor: hexColor(props.accentColor, '#eaff9a'),
    grain: clampNumber(props.grain, 0, 1, .08),
    glow: clampNumber(props.glow, 0, 1, .5),
    scanlines: clampNumber(props.scanlines, 0, 1, .3),
    curvature: clampNumber(props.curvature, 0, .5, .12),
    distortion: clampNumber(props.distortion, 0, 1, .5),
    center: [clampNumber(props.center?.[0], 0, 1, .5), clampNumber(props.center?.[1], 0, 1, .5)],
    radius: clampNumber(props.radius, .05, 2, .6),
    slices: Math.round(clampNumber(props.slices, 2, 128, 16)),
    trail: clampNumber(props.trail, 0, 1, .6),
    threshold: clampNumber(props.threshold, 0, 1, .5),
    animated: (['thermal', 'phosphor', 'liquid', 'raster', 'moving-blobs'].includes(kind) && (props.animated ?? true)) ||
      (['lens-distortion', 'slice-shift', 'pixel-stretch', 'image-warp'].includes(kind) && props.animated === true),
    speed: clampNumber(props.speed, 0, 3, .6),
  };
}
export function imageFilterKind(kind: ImageFilterKind): number { return KINDS.indexOf(kind); }
export function filterColor(color: string): [number, number, number] {
  return [1, 3, 5].map(index => parseInt(color.slice(index, index + 2), 16) / 255) as [number, number, number];
}

// Original fixed 5×7 glyphs, from sparse to dense. A one-pixel border separates cells.
// A byte atlas avoids font loading, canvas text, and platform-dependent metrics.
const GLYPHS = [
  [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 4, 0],
  [0, 4, 0, 0, 4, 0, 0], [0, 0, 0, 31, 0, 0, 0],
  [0, 4, 4, 31, 4, 4, 0], [0, 0, 31, 0, 31, 0, 0],
  [25, 26, 4, 4, 11, 19, 0], [0, 21, 14, 31, 14, 21, 0],
  [10, 31, 10, 10, 31, 10, 0], [14, 17, 23, 21, 23, 16, 14],
];
export function createGlyphPixels(): Uint8Array {
  const pixels = new Uint8Array(60 * 8);
  GLYPHS.forEach((rows, glyph) => rows.forEach((bits, y) => {
    for (let x = 0; x < 5; x++) pixels[y * 60 + glyph * 6 + x] = (bits & (1 << (4 - x))) ? 255 : 0;
  }));
  return pixels;
}
