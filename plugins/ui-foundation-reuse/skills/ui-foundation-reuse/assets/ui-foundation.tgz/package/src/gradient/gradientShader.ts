// WebGL1 (GLSL ES 1.00) shader pair for the animated gradient.
// A single full-screen triangle is rasterized; all motion lives in the
// fragment shader, driven by 2D simplex noise (Ashima / Gustavson, public domain).

export const VERTEX_SRC = `
attribute vec2 aPosition;
void main() {
  gl_Position = vec4(aPosition, 0.0, 1.0);
}
`;

export const FRAGMENT_SRC = `
precision highp float;

uniform vec2  uResolution;
uniform float uTime;
uniform float uAmplitude;
uniform float uFrequency;   // 1 = original scale; higher = finer / mistier
uniform int   uShape;       // 0 plane, 1 sphere, 2 waterPlane
uniform int   uColorCount;  // 2 or 3
uniform vec3  uColor0;
uniform vec3  uColor1;
uniform vec3  uColor2;

vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec2 mod289(vec2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec3 permute(vec3 x) { return mod289(((x * 34.0) + 1.0) * x); }

float snoise(vec2 v) {
  const vec4 C = vec4(0.211324865405187, 0.366025403784439,
                     -0.577350269189626, 0.024390243902439);
  vec2 i  = floor(v + dot(v, C.yy));
  vec2 x0 = v - i + dot(i, C.xx);
  vec2 i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec4 x12 = x0.xyxy + C.xxzz;
  x12.xy -= i1;
  i = mod289(i);
  vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0)) + i.x + vec3(0.0, i1.x, 1.0));
  vec3 m = max(0.5 - vec3(dot(x0, x0), dot(x12.xy, x12.xy), dot(x12.zw, x12.zw)), 0.0);
  m = m * m; m = m * m;
  vec3 x = 2.0 * fract(p * C.www) - 1.0;
  vec3 h = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.79284291400159 - 0.85373472095314 * (a0 * a0 + h * h);
  vec3 g;
  g.x  = a0.x * x0.x + h.x * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}

void main() {
  vec2 uv = gl_FragCoord.xy / uResolution.xy;
  vec2 p = uv - 0.5;
  p.x *= uResolution.x / uResolution.y;   // aspect-correct
  float t = uTime;
  float f = max(uFrequency, 0.05);

  // Broad, continuous domain folds add depth without another noise octave.
  p += vec2(sin(p.y * 2.8 + t * 0.24), cos(p.x * 2.4 - t * 0.18)) * 0.16;
  float field;
  if (uShape == 1) {                      // sphere: seamless radial swirl
    float r = length(p);
    // Sample along the continuous direction vector (p/r) instead of atan(),
    // whose +pi/-pi branch cut drew a hard seam through the center. The circle
    // radius grows with r, so angle sweeps trace a closed loop — no seam.
    vec2 dir = r > 1e-4 ? p / r : vec2(0.0);
    field = snoise(dir * (1.0 + r * 2.0 * f) + vec2(t * 0.25, -t * 0.2));
  } else if (uShape == 2) {               // waterPlane: layered waves
    field = snoise(vec2(p.x * 2.0 * f + t * 0.5, p.y * 2.0 * f)) * 0.5
          + snoise(vec2(p.x * 4.0 * f - t, p.y * 4.0 * f + t)) * 0.5;
  } else {                                // plane: diagonal flow
    field = snoise(p * 2.0 * f + vec2(t * 0.3, t * 0.2));
  }

  float m = clamp(field * uAmplitude * 0.5 + 0.5, 0.0, 1.0);

  vec3 col;
  if (uColorCount == 3) {
    col = m < 0.5
      ? mix(uColor0, uColor1, smoothstep(0.0, 0.5, m))
      : mix(uColor1, uColor2, smoothstep(0.5, 1.0, m));
  } else {
    col = mix(uColor0, uColor1, m);
  }

  float fold = 0.5 + 0.5 * sin(field * 3.8 + p.x * 1.2 - p.y * 0.7);
  float silk = pow(fold, 10.0) * 0.2 * min(uAmplitude, 1.5);
  float vignette = 1.0 - 0.28 * dot(uv - 0.5, uv - 0.5);
  col = (col * (0.78 + 0.24 * fold) + silk * mix(col, vec3(1.0), 0.55)) * vignette;
  // Sub-LSB static dithering prevents banding without a noise texture.
  col += (fract(dot(gl_FragCoord.xy, vec2(0.75487766, 0.56984029))) - 0.5) / 255.0;
  gl_FragColor = vec4(col, 1.0);
}
`;

/** Full-screen triangle (covers clip space with 3 verts, no index buffer). */
export const FULLSCREEN_TRIANGLE = new Float32Array([
  -1, -1,
  3, -1,
  -1, 3,
]);

/** Parse `#rgb` / `#rrggbb` to normalized [r,g,b] floats. Falls back to black. */
export function hexToRgb01(hex: string): [number, number, number] {
  let h = hex.trim().replace(/^#/, '');
  if (h.length === 3) {
    h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  }
  if (h.length !== 6 || /[^0-9a-fA-F]/.test(h)) return [0, 0, 0];
  const n = parseInt(h, 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}
