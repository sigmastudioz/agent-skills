/**
 * BlurView material for the current theme.
 * iOS `chromeMaterial` (no Light suffix) reads charcoal even when the app is
 * in light mode — that is the dark-slab Settings / tab-bar bug.
 */
export function resolveFrostedBlurType(
  platform: string,
  scheme: 'light' | 'dark',
): 'dark' | 'light' | 'chromeMaterialLight' {
  if (scheme === 'light') {
    return platform === 'ios' ? 'chromeMaterialLight' : 'light';
  }
  return 'dark';
}
