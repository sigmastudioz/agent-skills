/** Transparent laminate over the caller's artwork. No texture download or continuous clock. */
export const NATIVE_FOIL_SKSL = `
uniform float2 resolution;
uniform float2 tilt;
uniform float intensity;
uniform float iridescence;
uniform float hue;
half4 main(float2 p) {
  float2 uv = p / resolution;
  float phase = uv.x * 2.75 + uv.y * .55 + tilt.x * .9 - tilt.y * .65 + hue;
  float3 spectral = .5 + .5 * cos(6.2831853 * (phase + float3(0., .33, .67)));
  spectral = mix(float3(.88), spectral, iridescence);
  float band = exp(-pow((uv.x + uv.y * .55 - .7 - tilt.x * .45 + tilt.y * .25) * 4., 2.));
  float glint = pow(band, 5.);
  float edge = min(min(uv.x, 1.-uv.x), min(uv.y, 1.-uv.y));
  float rim = 1. - smoothstep(0., .012, edge);
  float grain = fract(sin(dot(floor(p * 1.5), float2(127.1,311.7))) * 43758.5453);
  float alpha = clamp((.065 + band * .24 + glint * .12 + rim * .13) * intensity, 0., .45);
  float3 color = mix(spectral, float3(1.), glint * .6) + (grain-.5)*.04;
  return half4(color * alpha, alpha);
}
`;
