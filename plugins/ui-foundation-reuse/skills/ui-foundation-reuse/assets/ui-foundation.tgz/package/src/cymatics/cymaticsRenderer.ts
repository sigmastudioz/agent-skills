import { createFullscreenPass, createTexture } from '../core/fullscreenPass.js';
import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import { buildCymaticsModes, CYMATICS_GRID } from './cymaticsModes.js';
import { createCymaticsParticles, stepCymaticsParticles } from './cymaticsParticles.js';
import { updateCymaticsResponse, writeCymaticsField } from './cymaticsResponse.js';
import { CYMATICS_GRAIN_FRAGMENT, CYMATICS_GRAIN_VERTEX, CYMATICS_SURFACE } from './cymaticsShader.js';
import type { CymaticsAudioFrame, CymaticsConfig } from './types.js';

export interface CymaticsRenderer extends WebGLRendererLike {
  render(config: CymaticsConfig, frame: CymaticsAudioFrame | undefined, time: number, animate: boolean): void;
}

export function createCymaticsRenderer(canvas: HTMLCanvasElement, count: number, seed: number): CymaticsRenderer | null {
  const gl = canvas.getContext('webgl', { alpha: true, antialias: false, depth: false, premultipliedAlpha: false });
  if (!gl) return null;
  const shaders: WebGLShader[] = [], buffers: WebGLBuffer[] = [];
  let program: WebGLProgram | null = null, texture: WebGLTexture | null = null;
  let surface: ReturnType<typeof createFullscreenPass> | null = null;
  const dispose = () => { surface?.dispose(); buffers.forEach(buffer => gl.deleteBuffer(buffer)); shaders.forEach(shader => gl.deleteShader(shader)); if (texture) gl.deleteTexture(texture); if (program) gl.deleteProgram(program); };
  try {
    surface = createFullscreenPass(gl, CYMATICS_SURFACE, ['uResolution','uCircle','uLiquid','uColor','uTime','uLevel','uField']);
    for (const [type, text] of [[gl.VERTEX_SHADER, CYMATICS_GRAIN_VERTEX], [gl.FRAGMENT_SHADER, CYMATICS_GRAIN_FRAGMENT]] as const) {
      const shader = gl.createShader(type); if (!shader) throw new Error('Shader allocation failed');
      shaders.push(shader); gl.shaderSource(shader, text); gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || 'Grain shader failed');
    }
    program = gl.createProgram(); if (!program) throw new Error('Program allocation failed');
    shaders.forEach(shader => gl.attachShader(program!, shader)); gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error('Grain program linking failed');
    const positionBuffer = gl.createBuffer(), grainBuffer = gl.createBuffer();
    if (positionBuffer) buffers.push(positionBuffer); if (grainBuffer) buffers.push(grainBuffer);
    if (!positionBuffer || !grainBuffer) throw new Error('Buffer allocation failed');
    texture = createTexture(gl);
    const pixels = new Uint8Array(CYMATICS_GRID * CYMATICS_GRID * 4);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, CYMATICS_GRID, CYMATICS_GRID, 0, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    const position = gl.getAttribLocation(program, 'aPosition'), grain = gl.getAttribLocation(program, 'aGrain');
    const uniforms = Object.fromEntries(['uResolution','uDpr','uSize','uColor'].map(name => [name, gl.getUniformLocation(program!, name)]));
    const field = new Float32Array(CYMATICS_GRID * CYMATICS_GRID), gradient = new Float32Array(field.length * 2);
    const banks = new Map<string, ReturnType<typeof buildCymaticsModes>>();
    let modes = buildCymaticsModes('circle'); banks.set('circle', modes);
    let weights = new Float32Array(modes.length), particles = createCymaticsParticles(count, seed, true);
    let shape = 'circle', initialized = false, lastTime: number | null = null, staticKey = '', ratio = 1, previousMaterial = 'sand';
    const upload = () => {
      gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer); gl.bufferData(gl.ARRAY_BUFFER, particles.positions, gl.DYNAMIC_DRAW);
      gl.bindBuffer(gl.ARRAY_BUFFER, grainBuffer); gl.bufferData(gl.ARRAY_BUFFER, particles.grain, gl.STATIC_DRAW);
    };
    upload();
    return {
      resize(width, height, dpr) { ratio = dpr; canvas.width = Math.max(1, Math.round(width * dpr)); canvas.height = Math.max(1, Math.round(height * dpr)); },
      render(config, frame, time, animate) {
        if (shape !== config.shape) {
          shape = config.shape;
          if (!banks.has(shape)) banks.set(shape, buildCymaticsModes(config.shape));
          modes = banks.get(shape)!; weights = new Float32Array(modes.length);
          particles = createCymaticsParticles(count, seed, shape === 'circle'); upload(); initialized = false;
        }
        const delta = lastTime === null ? 1 / 60 : Math.max(0, Math.min(.05, time - lastTime)); lastTime = time;
        const level = updateCymaticsResponse(modes, weights, config, frame, initialized && animate ? delta : .1);
        writeCymaticsField(modes, weights, field, gradient);
        const key = [config.frequency, config.fundamental, config.tension, config.size, config.stiffness, config.resonance].join(':');
        // A static preview settles only when its excitation changes, never on ordinary parent renders.
        if (!initialized || !animate && (key !== staticKey || previousMaterial !== config.material)) {
          if (config.material === 'sand') for (let i = 0; i < 65; i++) stepCymaticsParticles(particles, field, gradient, config, level, 1 / 30);
          initialized = true;
        } else if (animate && config.material === 'sand') stepCymaticsParticles(particles, field, gradient, config, level, delta);
        staticKey = key; previousMaterial = config.material;
        gl.viewport(0, 0, canvas.width, canvas.height); gl.disable(gl.BLEND);
        gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
        const hex = parseInt(config.color.slice(1), 16), color: [number, number, number] = [(hex >> 16 & 255) / 255, (hex >> 8 & 255) / 255, (hex & 255) / 255];
        surface!.use(); const u = surface!.uniforms;
        gl.uniform2f(u.uResolution, canvas.width, canvas.height); gl.uniform1f(u.uCircle, shape === 'circle' ? 1 : 0);
        gl.uniform1f(u.uLiquid, config.material === 'liquid' ? 1 : 0); gl.uniform3f(u.uColor, ...color); gl.uniform1f(u.uTime, time); gl.uniform1f(u.uLevel, level);
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, texture); gl.uniform1i(u.uField, 0);
        if (config.material === 'liquid') {
          for (let i = 0; i < field.length; i++) { const value = Math.round(Math.sqrt(field[i]) * 255); pixels[i * 4] = value; pixels[i * 4 + 1] = value; pixels[i * 4 + 2] = value; pixels[i * 4 + 3] = 255; }
          gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, CYMATICS_GRID, CYMATICS_GRID, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
        }
        surface!.draw();
        if (config.material === 'sand') {
          gl.useProgram(program); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
          gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer); gl.bufferSubData(gl.ARRAY_BUFFER, 0, particles.positions);
          gl.enableVertexAttribArray(position); gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
          gl.bindBuffer(gl.ARRAY_BUFFER, grainBuffer); gl.enableVertexAttribArray(grain); gl.vertexAttribPointer(grain, 1, gl.FLOAT, false, 0, 0);
          gl.uniform2f(uniforms.uResolution, canvas.width, canvas.height); gl.uniform1f(uniforms.uDpr, ratio); gl.uniform1f(uniforms.uSize, config.grainSize); gl.uniform3f(uniforms.uColor, ...color);
          gl.drawArrays(gl.POINTS, 0, count); gl.disableVertexAttribArray(grain);
        }
      }, dispose,
    };
  } catch { dispose(); return null; }
}
