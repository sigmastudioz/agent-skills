import {analyzeAudio,createAudioFrame,frequencyBands,type VisualizerAudioSource} from './audioOps.js';
/** Wrap an existing analyser. Its context, connections and audio playback remain caller-owned. */
export function createAudioAnalyser(analyser:AnalyserNode):VisualizerAudioSource {
  let fft=0,frequency=new Uint8Array(0),wave=new Uint8Array(0),bands:ReturnType<typeof frequencyBands>=[];
  const frame=createAudioFrame(),history={baseline:0,cooldown:0};let previous=-1;
  return {sample(){
    if(fft!==analyser.fftSize){fft=analyser.fftSize;frequency=new Uint8Array(analyser.frequencyBinCount);wave=new Uint8Array(fft);bands=frequencyBands(analyser.context.sampleRate,fft);}
    analyser.getByteFrequencyData(frequency);analyser.getByteTimeDomainData(wave);
    const now=analyser.context.currentTime,dt=previous<0?1/60:now-previous;previous=now;
    analyzeAudio(frequency,wave,bands,frame,history,dt);
    return frame;
  }};
}
