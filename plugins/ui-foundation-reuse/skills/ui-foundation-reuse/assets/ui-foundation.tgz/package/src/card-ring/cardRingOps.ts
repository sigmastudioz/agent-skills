import { clampNumber } from '../core/numberOps.js';

/** Angle between neighbouring cards, degrees. */
export function ringStep(count: number): number {
  return 360 / Math.max(1, count);
}

/** Cylinder radius that seats `count` cards of `cardWidth` with `gap` between their edges. */
export function ringRadius(count: number, cardWidth: number, gap: number): number {
  const n = Math.max(3, count);
  return (Math.max(1, cardWidth) + Math.max(0, gap)) / (2 * Math.tan(Math.PI / n));
}

function wrap(index: number, count: number): number {
  return ((index % count) + count) % count;
}

/** Card facing the viewer for ring rotation `angle` (degrees, card i sits at i × step). */
export function frontIndex(angle: number, count: number): number {
  if (count <= 0) return 0;
  return wrap(Math.round(-angle / ringStep(count)), count);
}

/** How directly card `index` faces the viewer: 1 front, 0 side-on, -1 behind. */
export function cardFacing(index: number, angle: number, count: number): number {
  return Math.cos(((angle + index * ringStep(count)) * Math.PI) / 180);
}

/** Rotation that brings card `index` to the front with the shortest turn from `from`. */
export function angleForIndex(index: number, count: number, from: number): number {
  const base = -wrap(index, count) * ringStep(count);
  return base + Math.round((from - base) / 360) * 360;
}

/** Rest angle after a drag, biased by release velocity in degrees per second. */
export function snapAngle(angle: number, velocity: number, count: number): number {
  const step = ringStep(count);
  const biased = angle + clampNumber(velocity, -1440, 1440, 0) * 0.22;
  return Math.round(biased / step) * step;
}

/** Brightness and opacity for a card by facing; back cards stay legible as a silhouette. */
export function cardShade(facing: number): { brightness: number; opacity: number } {
  const f = clampNumber(facing, -1, 1, 1);
  return { brightness: 0.45 + 0.55 * Math.max(0, f), opacity: f < -0.2 ? 0.35 : 0.55 + 0.45 * Math.max(0, f) };
}
