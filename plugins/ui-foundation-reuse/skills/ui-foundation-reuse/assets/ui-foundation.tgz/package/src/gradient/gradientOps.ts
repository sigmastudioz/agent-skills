export { finiteNumberOr } from '../core/numberOps.js';

/** Spatial scale of 1 matches the original hardcoded noise field. */
export const DEFAULT_GRADIENT_FREQUENCY = 1;

/** Keep the field from collapsing (0) or exploding into noise. */
export function clampGradientFrequency(value: number): number {
  if (value < 0.05) return 0.05;
  if (value > 8) return 8;
  return value;
}

/** Live, per-frame input on top of the resolved config. */
export interface GradientInput {
  /** Pointer warp centre in the shader's aspect-corrected space (0,0 is the centre). */
  offset: [number, number];
  /** Multiplies `amplitude` (audio). 1 = unchanged. */
  amplitudeScale: number;
}

/** Audio frame (from `/visualizer` sources) → amplitude multiplier, 1 … 1 + 1.5 × reactivity. */
export function audioAmplitudeScale(frame: { amplitude?: number; bass?: number } | null | undefined, reactivity: number): number {
  const r = Math.min(2, Math.max(0, Number.isFinite(reactivity) ? reactivity : 1));
  const level = Math.min(1, Math.max(0, (frame?.amplitude ?? 0) * .6 + (frame?.bass ?? 0) * .8));
  return 1 + level * 1.5 * r;
}

/**
 * Eases the warp centre toward the pointer target. `target` is the pointer in 0–1 page/element
 * coordinates (y down) or null when the pointer is away, which relaxes the warp to the centre.
 */
export function easePointerOffset(current: [number, number], target: [number, number] | null, aspect: number, strength: number, seconds: number): [number, number] {
  const s = Math.min(1, Math.max(0, strength));
  const goal: [number, number] = target ? [(target[0] - .5) * Math.max(.01, aspect) * s, (.5 - target[1]) * s] : [0, 0];
  const k = 1 - Math.exp(-Math.min(.1, Math.max(0, seconds)) * 6);
  return [current[0] + (goal[0] - current[0]) * k, current[1] + (goal[1] - current[1]) * k];
}
