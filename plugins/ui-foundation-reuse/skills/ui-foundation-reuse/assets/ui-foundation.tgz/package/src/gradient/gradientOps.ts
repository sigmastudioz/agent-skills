export { finiteNumberOr } from '../core/numberOps.js';

/** Spatial scale of 1 matches the original hardcoded noise field. */
export const DEFAULT_GRADIENT_FREQUENCY = 1;

/** Keep the field from collapsing (0) or exploding into noise. */
export function clampGradientFrequency(value: number): number {
  if (value < 0.05) return 0.05;
  if (value > 8) return 8;
  return value;
}
