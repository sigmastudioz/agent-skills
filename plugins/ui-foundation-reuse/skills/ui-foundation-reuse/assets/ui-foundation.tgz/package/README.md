# @sigmastudioz/ui-foundation

Web-first React library of the visual design effects that used to live scattered
across GitHub repos — animated shader gradients, liquid-metal & liquid-glass
shaders, three.js scene helpers, and scroll/mouse illusion effects. Each effect
is a tree-shakeable subpath export; heavy renderers (`three`) are lazy optional
peers, so importing `/gradient` never pulls in three.js.

Packaging discipline is modeled on `@renative-core/foundation` (dual CJS/ESM,
per-module subpath exports, `sideEffects: false`, CI-only publish).

## Agent skill: reuse existing effects

The self-contained [ui-foundation-reuse skill](skills/ui-foundation-reuse/SKILL.md)
helps Codex and Claude Code reuse effects and scene helpers alongside Taste,
Impeccable and img2threejs. It includes a local runtime archive with built modules,
types, original source, license and attribution notices. Users can install that
archive without downloading the library or accessing its source repository.

Follow the [setup guide](skills/ui-foundation-reuse/references/setup.md) for
project or personal agent setup, local runtime installation, verification and updates.
Distribute the complete skill folder; each agent needs its own discovery installation.
React, optional rendering peers and companion design skills are installed separately.

### Automatic skill distribution for maintainers

`npm run build` compiles CJS and ESM, rebuilds the bundled runtime/source, license
and checksums, and writes the complete shareable `dist/ui-foundation-reuse.zip`.
When a Visualizer source is registered, the same build also generates
`dist/sigmastudioz-visualizer-kit.zip` containing both current skills, the fresh runtime,
licenses, rendered setup instructions and per-file SHA-256 checksums.
`npm run dev` runs this full build initially and after changes to effects, helpers,
exports, build inputs or authored skill files, including the registered external
Visualizer folder (directory symlinks are followed at its root). Builds run serially; a failed compile
leaves the previous ZIP and agent installations available until the next successful build.
Update the skill's capability guidance when adding or changing public APIs.

To synchronize personal installations during each successful build, create
`.reuse-skill.local.json` in this repository (ignored by Git):

```json
{
  "skillDirectories": [
    "~/.agents/skills/ui-foundation-reuse",
    "~/.claude/skills/ui-foundation-reuse"
  ],
  "archiveCopies": [],
  "visualizerDirectory": "~/.agents/skills/visualization-videos",
  "kitArchiveCopies": []
}
```

Use the actual discovery directories for your agents; `~/.codex/skills/ui-foundation-reuse`
is also supported. Paths may be absolute, relative to this repository, or start with `~/`.
Optional `archiveCopies` entries name additional `.zip` files to keep current.
`visualizerDirectory` points to the maintained Visualizer skill on this host; it
is read directly, without creating another maintained copy in this repository.
`kitArchiveCopies` names additional combined `.zip` files, including previously shared
download locations, to replace atomically after successful builds. The consumer setup
template is `docs/visualizer-kit-setup.md`; edit it here rather than inside a generated ZIP.
Registered skill directories are managed mirrors: stale files are removed, and local edits
are replaced from `skills/ui-foundation-reuse/`. Symlinks remain intact and shared physical
destinations are synchronized once. Only register dedicated copies of this skill.
Without a Visualizer source, a clean build generates only the standalone reuse ZIP.
Once configured, a missing/invalid source fails rather than silently preserving a stale kit.
`npm run build:kit` requires a combined kit and compiles both formats first;
`npm run check:kit` requires its read-only freshness check. Normal build/verify and
`npm run check:skill` cover both ZIPs whenever the kit is configured.
CI skips personal destinations/configuration. To build the combined kit there, supply the
Visualizer skill as an external build input and set `UI_FOUNDATION_VISUALIZER_DIR` to its
directory in every build/release step that refreshes artifacts. No user-home fallback is
assumed. `npm run check:skill` checks runtime, ZIPs and registered mirrors without modifying
them; failures identify stale outputs. A pre-existing kit also requires a source to refresh it.
Consumers' vendored app runtimes stay pinned until they deliberately upgrade.

## Editable paper samurai film

Run `npm run dev --prefix playground` and open
[The weight of paper](http://localhost:5173/paper-samurai.html). An original folded
3D samurai, camera pullback/orbit, brush-covered cuts, ink impression, and torn-paper
title share one seekable timeline. Edit copy, palette, textures, camera distance,
duration, and seed; save/load project JSON, switch format, and save a still.
The [example source and MP4 export instructions](playground/src/paper-samurai/README.md)
cover geometry, timing, local rendering, and the reference/reconstruction boundary.

```tsx
import { PaperReveal, BrushWipe } from '@sigmastudioz/ui-foundation/paper-motion';

<PaperReveal kind="ink" progress={progress} seed={71} roughness={0.7}>
  <YourContent />
</PaperReveal>;
<BrushWipe progress={cutProgress} color="#17283d" direction="right" />;
```

`PaperReveal` supports `brush`, `ink`, and `torn`; `direction` is the travel direction
for brush/torn edges (`right`, `left`, `down`, `up`). Ink grows radially.
Progress clamps to 0–1. Masks retain their seeded shape through forward/backward
scrubbing and resize. Incomplete content is inert and hidden from assistive technology;
full content is accessible. Reduced motion reveals it fully. The brush curtain is
empty at 0/1 and fully covers the viewport at .5, where the host switches scenes.
It is decorative: hosts own scene visibility and focus. Both components freeze
progress offscreen or under `EffectsProvider paused`, without allocating an RAF loop.

`createPaperMask(progress, options)` and `createBrushWipeMask(progress, options)`
return normalized SVG/Canvas `Path2D` data and exact `empty`/`full` endpoint flags.
The geometry operations do not call React or a renderer and drive the example's compositor too.
`createInkSplashLayers(progress, options)` returns a finite impression of wet pools,
filaments and droplets, retaining negative space at 1. `createBrushWipeLayers`
adds translucent bristles around the opaque curtain. Both return ordered
`{ path, opacity }` layers: fill each normalized path with the same ink color in
SVG or Canvas. The React `BrushWipe` uses these layers directly. Seeds, roughness
and travel direction work in both helpers; they allocate no clock or DOM resources.
The subpath stays free of Three; the original samurai artwork is example-only.
[Browser mask checks](examples/paper-motion-demo.html) cover Canvas and SVG routes.

## Marina scene demo pages

Open [Scene studies](http://localhost:5173/marina.html) after starting the playground.
Each experiment is a standalone page with original scene artwork, three curated
presets, live controls and a complete **Copy React** example:

- [One Fold](http://localhost:5173/folding-portrait.html): a textured folding portrait,
  manual openness control and explicitly enabled on-device hand tracking.
- [Create Daily](http://localhost:5173/koi-type.html): a Blender-authored rigged koi
  over giant white type, with spine, heading, tilt, swim speed and fin controls.
- [Chimes](http://localhost:5173/chimes.html): architectural roofs, three destination
  scripts, physical glyph strands and optional synthesized chimes.
- [Unhinged](http://localhost:5173/creature-gaze.html): a furry meadow creature with
  source-registered, pointer-directed eyes.
- [Inner Journey](http://localhost:5173/inner-journey.html): a scalloped blue passage
  with moving ornamental light and a protected foreground figure.
- [Hidden in Plain Sight](http://localhost:5173/scratch-gallery.html): persistent
  cloud-to-portrait scratching inside an untouched gilded frame.
- [Armored Wanderers](http://localhost:5173/floral-crab.html): one floral specimen
  choreographed through three reversible editorial chapters, with a Blender model,
  independent pincers, eight articulated legs and shell tilt controls.
- [Threshold](http://localhost:5173/temple-portal.html): a feathered spotlight inside
  an architectural aperture, with source-space crop registration.
- [Height](http://localhost:5173/pagoda-moods.html): coordinated grading, sky tint,
  stars, fog and rain over one pavilion scene.
- [Helper RV2](http://localhost:5173/rover-story.html): three modeled product views,
  chapter copy and counters directed by one reversible scroll/manual timeline.

The seven newer scenes follow the supplied video’s layouts with independently
authored artwork. Image-mesh deformation reconstructs the portrait. Real volumetric
Blender models now replace the fish and crab image meshes, reusing `Scene`, `Model`
and `useSceneMotion` from `/three`. Both pages include editable `.blend` documents,
portable `.glb` assets and authored Python modeling sources in their downloads;
the original films/models were not recovered. Camera tracking is optional and
downloads a pinned MediaPipe model only on enable. Copy recipes identify any
demo-owned helper; the full source ZIP includes all ten pages, helpers and assets.
Each demo includes a lazy filmed-frame comparison and opacity overlay below its
tuning controls. These reveal remaining media, typography and motion differences;
the pages are reconstructions, not 1:1 recovered originals.

```tsx
import { ApertureReveal } from '@sigmastudioz/ui-foundation/aperture-reveal';
import { SceneEnvironment } from '@sigmastudioz/ui-foundation/weather';
import { ChapterStage } from '@sigmastudioz/ui-foundation/scroll-scrub';

<ApertureReveal src="architecture.webp" alt="Temple entrance" imageAspect={16 / 9}
  aperture={[[.42, .36], [.56, .36], [.56, .74], [.42, .74]]}
  radius={.24} feather={.55} smoothingMs={90}>
  <DecorativeWorld />
</ApertureReveal>;

<SceneEnvironment src="landscape.webp" alt="An open landscape"
  grade={{ brightness: .35, hue: 145, tint: '#172a60', tintOpacity: .35, stars: true }}
  weather={{ kind: 'fog', intensity: .3 }}>
  <YourSemanticContent />
</SceneEnvironment>;

<ChapterStage progress={progress} chapters={chapters}>
  {(chapter, presented) => <YourStory chapter={chapter} progress={presented} />}
</ChapterStage>;
```

`ApertureReveal` takes at least three normalized source-image vertices and a
positive `imageAspect`. It uses the same centered `cover` crop for the plate and
aperture. `contentFit="image"` registers the reveal content to that same source
plane; the default `viewport` fills the host. Reveal content is decorative and inert; put controls and meaningful copy
outside it. Pointer/touch drag and arrow keys move the spotlight; Enter/Space
toggles the full opening, Escape closes it. `open`/`onOpenChange` support a visible
equivalent control. Reduced motion exposes the whole aperture. Pointer smoothing
sleeps at rest and suspends offscreen, in hidden tabs and under provider pause.

`SceneEnvironment` extends `/weather` without adding a renderer dependency.
`grade` accepts brightness, saturation, contrast, hue, tint/tintOpacity, skyTint
and static stars. `objectPosition` controls responsive framing. Foreground
children remain outside grading. Weather uses its existing bounded particle
engine; grading transitions are immediate under reduced motion or provider pause.

`ChapterStage` extends `/scroll-scrub` and consumes the existing weighted
`ScrollChapter` contract (`id`, positive `weight`, `frames`, `transition`). Its
render function receives chapter state and the same presented 0–1 progress.
It settles then sleeps, freezes offscreen/hidden/paused, and presents the first
pose under reduced motion. Supply readable chapter content separately, as the
demo does. An asynchronous media caller owns readiness and should gate requested
progress until its artwork is available. These three original product plates
crossfade; this demo does not simulate a live exploded mesh.

Demo artwork and generation prompts: [asset provenance](playground/public/marina/README.md).

## Material interaction studies

Run `npm run dev --prefix playground`, then open
[Material studies](http://localhost:5173/material-studies.html): three effects,
eight curated looks, editable controls, and complete preview → tune → copy examples.

```tsx
import { GlyphCurtain } from '@sigmastudioz/ui-foundation/glyph-curtain';
import { ScratchReveal } from '@sigmastudioz/ui-foundation/scratch-reveal';
import { CursorVideo } from '@sigmastudioz/ui-foundation/cursor-video';

<GlyphCurtain text="MAKE ROOM FOR SOMETHING UNEXPECTED · "
  columns={32} rows={24} damping={0.97} stiffness={0.9}
  radius={85} force={3.5} style={{ height: 420 }} />;

<ScratchReveal coverSrc="/clouds.svg" revealSrc="/garden.svg"
  alt="A botanical illustration" radius={44} softness={0.4} />;

<CursorVideo src="/short-film.mp4" poster="/still.webp"
  label="Explore the film" axis="x" smoothingMs={100} />;
```

`GlyphCurtain` draws cached glyphs along independently simulated pinned strands.
Pointer/touch input parts the text; Left/Right/Space disturbs it and Escape settles
it. `gravity`, `fontSize`, `fontFamily`, `color`, and `direction` tune the material.
The canvas inherits host color by default; accessible text remains outside it.
Bounds cap particle/atlas allocation. Idle physics sleeps after settling.
A `ref<GlyphCurtainHandle>` exposes `disturb(x, y, once?)`, `release()` and
`reset()` for input arriving through a decorative mask or foreground. Coordinates
are normalized to the curtain (0–1); out-of-bounds input releases the pointer.
`radius` remains a pixel distance. The bridge follows the same motion/pause guards.

`ScratchReveal` retains a fixed-resolution normalized mask through resize and
brush changes, with `interaction="drag"` by default or `"hover"` for mouse hover.
`onProgress` reports approximate geometric coverage without pixel readback or
cross-origin canvas export. A `ref<ScratchRevealHandle>` exposes `reset()` and
`revealAll()`; Enter reveals all and Escape resets. Changing either image source
starts fresh. Use image pairs with the same framing/aspect ratio. Touch dragging
paints within the surface; page scrolling remains available outside it.

`CursorVideo` uses one native seek at a time and retains the newest pending target.
It never autoplays or emits audio. `start`/`end` select fractions of the film;
`reverse` changes pointer direction, `restProgress` sets the initial/return pose,
and `resetOnLeave={false}` retains the last pose. `progress` plus
`onProgressChange` enables controlled input; keys are arrows, Home and End.
`onFrameChange` reports completed seek time, while `onStatusChange` reports
loading/ready/error. Use a short, silent film encoded with frequent keyframes.
The shared transport also coalesces existing `ScrollScrubVideo` seeks.

All three honor `EffectsProvider`, hidden/offscreen suspension and system reduced
motion. Reduced motion shows a static curtain, the revealed image or the video
poster. No Three.js, camera access, sound engine or external renderer is required.
Playground artwork is original and excluded from the published package; copied
media examples point to the running playground until you host the assets yourself.

## Atmosphere effects

Run `npm run dev --prefix playground` and open the [After hours demo](http://localhost:5173/atmosphere.html).
The town includes original masonry and roof textures, layered shopfronts and balconies,
café terraces, canal details, 22 independently walking residents and traffic in both
directions. Warm/cool occupied windows, soft shadows, headlights and rain-responsive
road materials follow the existing time and weather controls. Depth-tested rain
lands on roofs, streets and the canal; pavement splashes and water rings share
the same impacts. Wet patches reflect the actual scene. Storms add occasional
lightning and broad light pulses; pause and reduced motion suppress the flashes. Sound starts muted. The scene toggle and the soundscape mixer share one master mute;
Master, Rain, Thunder and Street life volumes are independent and persist when
visual presets/reset are used. Rain follows weather intensity, thunder rolls
shortly after a lightning strike, and recorded birds, traffic, market voices and
footsteps fill the street bed. Reduced-motion and static-fallback storms retain an audio-only thunder cadence.
Actual CC0 stereo field recordings load from bundled local MP3 files only after
an explicit sound toggle. Rain and street beds use crossfaded loops; thunder keeps
its natural pitch and decay. [Sources, licenses and processing details](playground/public/atmosphere-audio/README.md)
ship with the demo. Failed loads expose a retry through the sound toggle.
The owned context, scheduled voices and timer suspend while the town is paused,
out of view or the page is hidden, and dispose on unmount. Repeated architecture
and pedestrian parts are instanced; surface textures are generated locally.
It combines an original 3D neighborhood with independently adjustable weather,
lamp halos, tilt-shift focus, time of day, and the existing `LiquidGlass` panels.
Choose Night rain, Golden hour, Morning mist, or Storm watch; fine-tune wind,
speed and rain ripples; zoom into shopfronts, rooftops, the fountain and canal;
or enable the focus guide. Lighting interpolates continuously through the day.

The town is modeled geometry, with instanced buildings/windows/vegetation, shadows,
world-space lamp halos, bloom, canal reflections and animated fountain/traffic.
Drag to orbit; right-drag or Shift-drag to pan; scroll to zoom. Touch supports
one-finger orbit and two-finger pan/pinch. Focus the scene and use arrow keys to
pan or Home to reset; Reset view restores both angle and target. Camera input
remains available while ambient animation is paused or reduced motion is enabled.
The 3D scene is loaded lazily and uses the optional peers already installed by the
playground. Missing WebGL or a renderer-load failure shows the original vector
artwork and an availability notice. The town stays demo-owned; the effects below
remain independently usable without Three.js.

```tsx
import { EffectsProvider } from '@sigmastudioz/ui-foundation/core';
import { TiltShift } from '@sigmastudioz/ui-foundation/tilt-shift';
import { LightGlow } from '@sigmastudioz/ui-foundation/light-glow';
import { Weather } from '@sigmastudioz/ui-foundation/weather';
import { LiquidGlass } from '@sigmastudioz/ui-foundation/liquid-glass';

<EffectsProvider paused={false} maxDpr={1.5} maxFps={40}>
  <div style={{ position: 'relative', aspectRatio: '14 / 9' }}>
    <TiltShift blur={12} focus={0.55} band={0.25} style={{ height: '100%' }}>
      {/* Your image, SVG, video, DOM content or canvas goes here. */}
      <LightGlow points={[{ x: 0.3, y: 0.6, radius: 32, color: '#ffcc88' }]} />
    </TiltShift>
    <Weather kind="rain" intensity={0.6} wind={0.2} splashes={0.65} />
    <LiquidGlass quality="economy" finish="smoked"
      style={{ position: 'absolute', top: 20, right: 20, padding: 20 }}>
      Your controls
    </LiquidGlass>
  </div>
</EffectsProvider>
```

- `/tilt-shift`: masked backdrop blur over one live content tree. `focus`, `band`,
  and `falloff` use normalized units; `blur` uses CSS pixels; `angle` rotates the
  focus band. This approximates miniature depth of field in screen space. Browsers
  without backdrop filtering show the original content clearly.
- `/light-glow`: static CSS halos with normalized `x`/`y`, pixel `radius`, per-light
  `color`/`opacity`, and global `intensity`. At most 128 lights render. These are
  positioned overlays; use the existing `/three` `Bloom` for actual scene bloom.
- `/weather`: transparent Canvas2D `clear`, `overcast`, `fog`, `drizzle`, `rain`,
  and `storm`. Accepts `intensity`, `wind`, `speed`, `seed`, `count`, `color`, and
  `paused`. Optional `splashes` (0–1, default 0) adds at most 48 seeded rain rings
  in the lower third. These approximate wet ground in screen space; they do not
  intersect consumer geometry. Work is capped at 650 drops; storm uses dense wind-driven rain without
  lightning flashes. Missing Canvas2D retains a static SVG/haze fallback and calls
  `onError`. Rain and fog stop offscreen, in hidden tabs, when paused, or at zero
  speed; reduced motion shows a static frame. Provider DPR and FPS limits apply.

Place overlays inside a positioned parent with explicit dimensions. Both decorative
overlays ignore pointer input and are hidden from assistive technology. Keep controls
outside `TiltShift` to keep them sharp. No new dependencies or 3D peers are required.

## Native visualizers

The `/visualizer/native` entry provides a Skia renderer for React Native iOS and
Android, with shared presets/audio inputs, lazy optional Skia loading, and native
lifecycle/performance controls. Other effect entry points remain web-first.
See [Native visualizer setup and validation](NATIVE_VISUALIZER.md).

## Install

```bash
npm i @sigmastudioz/ui-foundation
# react + react-dom are peers you already have
```

## Holographic foil surface

`/foil-surface` renders caller-supplied artwork on a flexible, double-sided sheet.
It combines masked spectral foil, pointer-driven bending, and a perforated tear-off
section without Three/Fiber or any additional dependency. The
[Atelier Kinetic browser demo](http://localhost:5173/foil-surface.html) recreates the
reference ticket: three editions, seat selection, reverse printing, progressive
tearing, validation, reset, mesh inspection, optional sound, and dark room.
Run `npm run dev --prefix playground` to open it.

```tsx
import { useRef } from 'react';
import { FoilSurface, type FoilSurfaceHandle } from '@sigmastudioz/ui-foundation/foil-surface';

function PrintedPass() {
  const sheet = useRef<FoilSurfaceHandle>(null);
  return <>
    <FoilSurface
      ref={sheet}
      front="/pass-front.svg"
      back="/pass-back.svg"
      mask="/front-foil-mask.svg"
      backMask="/back-foil-mask.svg"
      alt="Holographic event pass"
      aspectRatio={600 / 1040}
      tearAt={0.76}
      stiffness={0.55}
      intensity={0.8}
      onTear={() => console.log('Stub detached')}
      style={{ width: '100%', height: 640 }}
    />
    <button onClick={() => sheet.current?.flip()}>Flip pass</button>
    <button onClick={() => sheet.current?.tear()}>Tear stub</button>
    <button onClick={() => sheet.current?.reset()}>Issue fresh pass</button>
  </>;
}
```

Artwork uses the entire image, stretched to `aspectRatio` (width / height).
Use identical dimensions for the front, reverse, and masks. White mask pixels
receive foil; black pixels retain the printing. Without a mask the whole sheet
receives foil; `back` defaults to `front`, and `backMask` defaults to `mask`.
Image URLs must be same-origin, data URLs, or CORS enabled.

`tearAt` measures the seam from the top; `tearable={false}` removes it.
The grab uses a compliant contact patch for broad folds. Tearing builds tension,
peels from the grabbed edge, and releases the curled stub with downward momentum.
A partially torn stub keeps its peel when released. On a fresh front-facing sheet,
the tear button starts from the right edge; pointer tearing selects the grabbed edge.

`onTearProgress` reports monotonic progress from 0 to 1 in 25 fiber steps, and
`onTear` fires once per completion. `reset()` or a changed `resetKey` restores an
intact front-facing sheet and reports progress 0 if needed. `onFlip` reports the
selected face. Material and artwork changes preserve the tear; structural
`aspectRatio`/`tearAt`/`tearable` changes create a fresh mesh. `stiffness`, `intensity`, `hue`,
and `idleMotion` are bounded to 0–1. `foilTint` is an RGB tuple (each channel 0–1),
defaulting to neutral `[1, 1, 1]`; warm gold can use `[1, .82, .38]`. `debug` displays
the mesh.

Focus the surface and press **F** to flip, **T** to tear, or **R** to reset.
`interactive={false}` disables pointer/keyboard input while ref commands remain
available. `paused`, the EffectsProvider pause setting, and reduced motion stop
continuous animation; explicit flip/tear commands resolve immediately when
paused or reduced. Reduced motion uses a flat static pose. Off-screen/hidden
surfaces stop their RAF loop. WebGL failure, context loss, or pending artwork
shows the selected source image; artwork failures call `onError`. Context
restoration reloads textures while retaining the sheet's tear state. The lightweight
positional solver does not model self-collision or permanent creases.

## Text portrait

The [text portrait study](http://localhost:5173/text-portrait.html) recreates the
supplied video's scattered letters, ivory portrait, coral serif overlay and
technical frame. Run `npm run dev --prefix playground`. Replay, pause, scrub,
compare the original, change the text or upload a local still image.

```tsx
import { TextPortrait } from '@sigmastudioz/ui-foundation/text-portrait';

<TextPortrait
  src="/portrait.jpg"
  alt="A portrait assembled from letters"
  text="every letter holds a little light / "
  columns={154}
  color="#e9e2d1"
  backgroundColor="#090a09"
  imageOpacity={0.2}
  duration={3200}
  style={{ width: '100%', aspectRatio: '16 / 9' }}
/>
```

Canvas2D samples image luminance into a bounded character grid. A retained glyph
atlas animates deterministic scattered positions into the image; the completed
portrait stops its animation loop. `text` flows in reading order, `columns`
controls density, and `contrast`, `brightness` and `threshold` control light.
`imageOpacity={0}` produces text only. `colorMode="source"` uses a quantized image
palette; `fit="contain"` preserves the full image rather than center-cropping it.

`progress={0…1}` overrides autoplay and supports reversible scrubbing. `duration`
and `delay` use milliseconds; `scatter` and `seed` configure assembly.
Remount with a new React `key` to replay. `paused`, offscreen visibility, hidden
tabs and `EffectsProvider` suspend playback without advancing its clock. OS
reduced motion always displays the completed static portrait, including when
controlled progress is zero. `onComplete` fires once per autoplay/source, never
for controlled scrubbing. Provide a sized host (height or aspect ratio).

The semantic original stays visible while loading or if Canvas2D/pixel sampling
fails. Remote images need CORS permission (`crossOrigin` defaults to `anonymous`);
`onError` reports load and sampling failures. No renderer peers are required.
The reference image is demo-only; attribution is in
[the asset notes](playground/public/text-portrait/README.md).
The [browser checks](examples/text-portrait-demo.html) exercise real pixel output
after building and serving the repository root.

## Particle forms and luminous trails

The [light studies collection](http://localhost:5173/motion-atlas.html) presents
eight original live compositions inspired by the supplied website-gallery video.
Open [particle forms](http://localhost:5173/particle-forms.html) or
[luminous trails](http://localhost:5173/luminous-trails.html) for full-size scenes,
live controls, pause, and copyable React examples. Run `npm run dev --prefix playground`.

Existing `/particles` provides free-drifting ambient points; `/neural-field`
provides tree/brain fibers and a head envelope. These new subpaths cover independent,
morphable point surfaces and glowing parametric ribbons, without Three or new peers.

```tsx
import { ParticleForm } from '@sigmastudioz/ui-foundation/particle-form';
import { LuminousTrails } from '@sigmastudioz/ui-foundation/luminous-trails';

<ParticleForm
  shape="head" morphTo="brain" morph={0.35}
  count={40000} seed={42} color="#195bff" accentColor="#75bbff"
  pointSize={1.15} glow={1.5} dispersion={0.08} speed={0.6}
  style={{ height: 600, background: '#030711' }}
/>

<LuminousTrails
  path="orbit" trails={4} width={1.3} glow={1.2}
  color="#d8aa66" accentColor="#fff1cf" tailLength={0.65}
  tilt={0.45} speed={0.7}
  style={{ height: 600, background: '#090807' }}
/>
```

`ParticleForm` supports `head`, `brain`, `sphere`, `torus`, and `wave`; `morph`
is controlled from 0 (source) to 1 (`morphTo`). `seed` keeps point identity stable.
Head and brain particles now sample licensed reference meshes, with shared angular
coordinates that keep neighboring points together during morphs. These are visual
effects, not diagnostic anatomical datasets. Shape, destination, seed, and count changes rebuild buffers;
color, morph, glow, brightness, dispersion, camera, and speed update retained resources.
The default is 28000 cobalt-blue points, with normal-based lighting and a separate
colored halo (`glow`, 0–3; zero skips that pass). Sparse halo samples keep the glow
pass from drawing a large sprite for every point. The head retains scanned facial
features and ears, with shoulders cropped away; the brain retains its modeled
hemispheres, folds, cerebellum and brainstem. Use `rotation`, `tilt`, and `zoom` to
compose the form. `autoRotate` gently orbits head/brain to keep their features
visible; other shapes rotate continuously.

The particle demo pins the head while you scroll through a damped morph into the
brain. Scrolling backward reverses it. It composes `useScrollProgress({ range:
'sticky' })` from `/core` and `useScrubProgress(progress, { smoothingMs: 160,
active: visible })` from `/scroll-scrub`, feeding the result to `morph`. The demo's
copy button includes the complete component and sticky track styles. Manual mode
and the morph slider remain available. Reduced motion uses a single still viewport;
provider pause freezes both scroll progress and smoothing, and smoothing sleeps
offscreen and after settling.

Reference asset credits (also retained in the generated geometry modules):

- Head: **Infinite, 3D Head Scan**, Lee Perry-Smith / Infinite-Realities,
  [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/),
  [distributed source and original notice](https://threejs.org/examples/models/gltf/LeePerrySmith/LeePerrySmith_License.txt).
  Based on work at triplegangers.com. Changes: shoulders cropped, centered, scaled,
  ray-sampled, quantized, and rendered as particles; textures omitted.
- Brain: **BodyParts3D, © The Database Center for Life Science licensed under
  CC Attribution 4.0 International**. [Official license](https://dbarchive.biosciencedbc.jp/en/bodyparts3d/lic.html),
  [dataset](https://dbarchive.biosciencedbc.jp/en/bodyparts3d/download.html).
  Uses the 59 FMA50801 brain elements in the 4.0 PART-OF release plus the
  six additional FMA55676 cortical elements from IS-A (orbital and superior
  temporal gyri). Changes: brain
  structures combined, axes converted to Y-up, centered, scaled, ray-sampled,
  quantized; textures omitted. The atlas geometry remains CC BY 4.0.

`python3 scripts/bake-particle-anatomy.py head.glb partof_BP3D_4.0_obj_99.zip isa_BP3D_4.0_obj_99.zip` reproduces the compact
reference atlases (offline tooling requires NumPy). Source geometry hashes and URLs are
embedded in the generated files (the brain hash covers the sorted element IDs
and original OBJ bytes, so one combined archive containing only those 65
elements also works, omitting the final argument). The library loads no external models, textures,
Three, or network resources; decoding is deferred until geometry is requested.
The two geometry modules add about 500 KB before compression to `/particle-form`.
Consumers of unrelated effect subpaths do not import them.

`LuminousTrails` supports `orbit`, `helix`, `wave`, and `knot`. `trails` (1–12)
and `segments` (32–512) set geometry; `width` is the bright core's CSS-pixel width.
Open paths fade at their endpoints. Glow, tail length, colors, brightness, camera,
and speed are live controls. Colors accept `#rgb` or `#rrggbb`.

Both effects have transparent canvases and preserve `children` for overlays.
Give the container an explicit height; `label` exposes the canvas as an image,
otherwise it is decorative. They render a static frame for reduced motion, pause
off-screen/in background tabs/through `EffectsProvider`, and freeze their current
phase at `speed={0}`. Missing/lost WebGL shows a CSS still and retains content;
restoration retries the renderer. See `examples/light-studies-demo.html` for
built-package WebGL compilation and pixel checks.

## Spectral ribbon

`/spectral-ribbon` reconstructs the supplied spectral-flow reference as an original
procedural ribbon: a tight left fold, a sheared lower-right curl, fine blue/violet/
cyan/pink contours, warm highlights and a soft blue plume on black. Broad flowing
bands swell and shear at different rates, with six uneven contours by default and
a saturated pink/orange inner curl. Autoplay includes shape deformation and advected
color flow; the independent study opens playing. It uses a small
WebGL mesh and shaders, with no video texture, external asset, or Three dependency.

```tsx
import { SpectralRibbon } from '@sigmastudioz/ui-foundation/spectral-ribbon';

<SpectralRibbon
  speed={1} glow={1} bands={6} intensity={1}
  style={{ width: '100%', aspectRatio: '3 / 2' }}
/>
```

The effect preserves the reference's 3:2 composition inside other host ratios.
Provide a height or aspect ratio for an empty host. Children render as live DOM
above the decorative canvas. Optional `colors` supplies five hex colors in the
order blue, violet, cyan, pink, warm. `scale` defaults to 1 and `rotation` is radians.
Numeric controls clamp to the documented ranges in `SpectralRibbonProps`.

`paused` and `speed={0}` freeze the current frame; changing speed does not rewind.
`time={seconds}` selects a deterministic frame and disables autoplay; omit it to
resume the autonomous clock. Local/provider pause, offscreen visibility, background
tabs, reduced motion, adaptive resolution and context recovery use the shared GPU
lifecycle. Reduced motion renders a static shader frame. Without WebGL, or during
context loss, static SVG contours remain visible and children stay usable. The SVG
is an approximation; controlled time selects frames in the GPU effect only.

Run `npm run dev --prefix playground` and open `/spectral-ribbon.html` for the React
study with time scrubbing, playback and material controls. Build the library and
serve the repository over HTTP to run `examples/spectral-ribbon-demo.html`, which
checks actual shader pixels, motion, black negative space, zero intensity and
deterministic time. The procedural motion approximates the reference rather than
replaying the five-second source clip.

## Square tile reveal and fill

The [tile studies](http://localhost:5173/square-tiles.html) reconstruct the supplied
reel's square-wave transitions as three original demo sites: neon console,
fluorescent tile room and red editorial scene. Run `npm run dev --prefix playground`.
Each scene uses the shipped React component; controls include replay, reverse,
pause, manual progress, timing, glow, fill style, wave origin and seed.

```tsx
import { SquareTileReveal } from '@sigmastudioz/ui-foundation/square-tile-reveal';

<SquareTileReveal
  revealed={open}
  duration={1800} delay={150} stagger={0.65}
  cellSize={42} cellStyle="mixed" order="center"
  color="#47ff9a" glow={18} gap={1} seed={17}
  style={{ minHeight: 500 }}
>
  <YourContent />
</SquareTileReveal>
```

`revealed` defaults to true and animates on mount; set it false to conceal.
`duration` and `delay` are milliseconds. Stagger reserves 0–0.95 of the total
wave duration for cell start offsets. Reversing starts from the current frame.
`progress={0..1}` overrides autoplay for deterministic scrubbing in either direction.
Use `cellStyle="filled"`, `"outlined"` or `"mixed"`; wave origins are `center`,
`left`, `right`, `top`, `bottom` and `random`. Glow and gap use CSS pixels.
Replay a finished entrance by remounting with a new React `key`, or conceal then reveal.

`mode="fill"` keeps decorative cells behind the children instead of clipping them:
`<SquareTileReveal mode="fill" progress={1} cellStyle="filled" style={{ height: 400 }} />`.
It also works as an absolute background with the caller's layout/CSS transforms.
Provide height for empty fill surfaces; ordinary reveal hosts can size to their children.

The effect reveals one live DOM copy using an SVG square mask; Canvas2D draws
only decoration. It needs no WebGL/Three peers or CSS import. Content imports and
server-renders without DOM access, remaining readable before hydration. During a
partial reveal, clipped content is inert and hidden from assistive technology;
completion removes clipping and restores normal interaction. Fill children remain
interactive. Without Canvas2D, masking still works and decoration is omitted.

Autoplay honors local/provider pause, page visibility and offscreen pause with
no elapsed-time jump. `onComplete(revealed)` fires once per autoplay completion;
controlled scrubbing does not fire it. Reduced motion immediately selects the target
endpoint (controlled progress selects 0 below 0.5, otherwise 1), with no animation.
Sizing follows the host; grids stay square and cap at 2048 cells by increasing cell
size on large surfaces. The decorative gap never leaves seams in revealed content.

## Curated presets and preset studio

### Cymatics / audio-driven sand and liquid

The [cymatics instrument](http://localhost:5173/cymatics.html) turns incoming
sound into granular nodal patterns or a reflective liquid surface. Four original
looks, circle/square boundaries, surface controls, freeze, local files, microphone,
a test oscillator and copyable integrations are included. The input meter reports
RMS and the dominant FFT bin in Hz (bin resolution, not a pitch estimate). No input or audible
oscillator starts automatically; the initial surface is labeled manual preview.

```tsx
import { Cymatics, createCymaticsEffect }
  from '@sigmastudioz/ui-foundation/cymatics';

// With your existing AudioContext, source AudioNode and destination:
const insert = createCymaticsEffect(context);
incoming.connect(insert.input);
insert.output.connect(destination); // unity dry signal; analysis runs on a tap

<Cymatics audio={insert.audio} material="sand" style={{ height: 600 }} />

// When removing this visual insert (the context remains caller-owned):
incoming.disconnect(insert.input);
insert.dispose();
```

Create/connect the insert in a gesture or effect and retain it across renders.
It never opens a microphone, resumes/closes a caller's context, or connects speakers
automatically. `createCymaticsAnalyser(analyser)` wraps an existing analyser without
changing its settings. `useAudioVisualizer()` now also exposes its hook-owned
`analyser` while ready, so the same file/microphone lifecycle supports full-spectrum
cymatics. Do not disconnect that hook-owned analyser yourself.

Custom `audio.sample()` sources supply `{ spectrum, sampleRate, fftSize, amplitude }`:
linear FFT amplitudes indexed by `sampleRate / fftSize`, and RMS level in 0–1.
Retained typed arrays are supported; the effect pulls them on rendered frames
without per-frame React state updates. An explicit silent or failed source never
switches to demo excitation. With no `audio`, `frequency`/`amplitude` provide manual
excitation. `onError` reports sampling failures once until the source recovers.

Tune `fundamental`, `tension`, `size`, `stiffness`, `resonance`, `sensitivity`,
`settle`, `damping`, `grainSize` and `color`. Only `seed`/`count` recreate the GPU
renderer; a boundary change reuses its programs and resets the grains. Provider
DPR/FPS budgets, offscreen/page pause, reduced-motion static frames and context
recovery use the shared lifecycle. Freeze holds the visual while audio playback
remains caller-owned. The lab stops its own oscillators, microphone tracks and
local playback when switching inputs or unmounting; local object URLs are revoked.

The model uses original [circular membrane mode math](https://www.acs.psu.edu/drussell/Demos/MembraneCircle/Circle.html)
and square cosine modes, adjustable frequency dispersion, a coherent blend of the
four strongest resonant responses and overdamped grain transport. It is a visual
simulation, not a physical plate calibration or a reconstruction of Sonicrama's
proprietary engine. FFT phase is not reconstructed; the finite mode bank emphasizes
its supported resonances rather than estimating a unique pattern for every
possible frequency. Audio routing follows the [Web Audio specification](https://www.w3.org/TR/webaudio-1.0/).

### Neural field / world tree → glass cortex

The independent [neural playground](http://localhost:5173/neural-field.html)
recreates the supplied video's visual idea with original procedural geometry:
colored fiber territories morph from a rooted tree into a stylized brain inside
a translucent head. Three curated looks, synchronized axial/coronal/sagittal
views, region isolation, orbit controls, phone preview and live tuning all feed
the copied component. The 29 existing studio presets remain unchanged.

```tsx
import { NeuralField } from '@sigmastudioz/ui-foundation/neural-field';

<NeuralField
  mode="brain" // 'tree' by default; explicit morph={0..1} overrides mode
  multiView
  shellOpacity={0.65}
  style={{ height: 620 }}
/>
```

`seed` and `detail` (0.2–1) control deterministic geometry and rebuild buffers.
`morph`, five hex `colors`, `brightness`, `pointSize`, `speed`, `shellOpacity`,
`rotation`, `tilt`, `zoom`, `view` and `selectedRegion` (0–4 or null) update live.
Drag/arrow keys orbit, +/− zoom, Home/double-click reset. To keep the camera in
application state, pass `onCameraChange` and write its absolute rotation/tilt/zoom
back into those props. `onRegionChange` reports hovered regions; provide your own
labels and keyboard-accessible region controls, as the playground does.

One WebGL context and immutable buffers serve all four views. No Three.js or other
rendering dependency is needed. The shared engine handles DPR/FPS budgets,
offscreen/page-visibility pause, reduced motion, context restoration and disposal.
Paused/reduced-motion edits render a static result; unavailable WebGL shows a
readable fallback. **Check FPS** is an opt-in measurement of submitted rendering
updates, not physical display FPS or GPU completion time. The artwork and sample
dashboard values are synthetic; this is not a scientific or clinical data viewer.

### Existing material and interaction recipes

The data-only `/presets` entry contains 18 original material looks and 11 curated
interaction patterns from the ten site studies. Search by effect, mood, tone,
source study or words; recipes include composition guidance and immutable inputs.
It imports no React or GPU renderer at runtime. Recipe IDs are separate from
each component's built-in `preset` names; spread the recipe's props instead.

```tsx
import { getCuratedPreset } from '@sigmastudioz/ui-foundation/presets';
import { Gradient } from '@sigmastudioz/ui-foundation/gradient';

export function AtlanticBackdrop() {
  const look = getCuratedPreset('atlantic');
  // The discriminator narrows each recipe to its effect's supported inputs.
  return look?.effect === 'gradient'
    ? <Gradient {...look.props} style={{ height: 420 }} />
    : null;
}
```

Run `npm run dev --prefix playground` and open
[`http://localhost:5173/?studio=1`](http://localhost:5173/?studio=1), or choose
**Preset studio** from the gallery. Select a look, tune its controls and copy
React or JSON generated from the exact preview configuration. Pause/quality
settings are included; the OS reduced-motion preference still takes precedence.
**Copy look link** retains tuned settings in a versioned URL fragment. Phone
mode changes preview width, not touch capabilities or exported app layout.
Runtime animation phase, random particle seeds and fluid history are not saved.

Material presets also offer **Art direction** recipes from the supplied color
reel: **Powerful** (charcoal/forest/crimson), **Bold** (lemon/charcoal/lavender),
and **Rich** (mocha/champagne/amber). Select one to apply compatible color and
finish inputs, then toggle **Use accent color** to compare the base palette.
Motion speed and preview preferences are preserved. The six supported materials
are Gradient, LiquidMetal, Iridescence, Particles, Warp and FluidField; one-color
effects use the selected accent as their ink over the palette ground. Typography
and material guidance explain the composition, while **Copy CSS colors** exports
the app-owned roles and readable text colors. It does not replace scene artwork
or automatically recolor uploaded media. Tune may override the mapped inputs;
Reset restores the original material and clears the palette. React/JSON export
and shared look links retain the current effect inputs and palette surface.
Existing links without a palette still load normally. These palettes and layout
roles belong to the playground, not the library runtime's public design tokens.

The unified library filters materials and interaction patterns together. Pattern
preview actions (selection, chapters, panels, disclosures, video and carousels)
update the same configuration as the tuning controls. Copied React includes original
sample content, styles and controlled state; JSON contains inputs and entry metadata.
The assembly example loads optional Three only when selected. Native video uses
this playground's original film/poster URLs; download both for independent hosting.

```ts
import { CURATED_PATTERNS, findCuratedPatterns, getCuratedPattern }
  from '@sigmastudioz/ui-foundation/presets';

const panels = findCuratedPatterns({ effect: 'scene-panel' });
const reveal = getCuratedPattern('scene-reveal');
// reveal.props contains serializable effect inputs. Supply your own scene,
// content, callbacks and controlled state to the component at reveal.entry.
```

`CURATED_PRESETS` remains the existing 18-material catalog. `CURATED_PATTERNS`
contains the new deeply immutable recipes, with `study`, `source`, `component`
and `entry` metadata. Neither catalog imports React or Three at runtime.

The adaptive-surface and story demos share a six-second 960×600 film rendered with
360 temporal samples at 60 FPS. To regenerate it, install playground dependencies
and FFmpeg, run `node playground/scripts/render-interaction-media.mjs`, then open
the printed local URL and press **Render 60fps film**. The renderer reuses the
original Field geometry and quarry environment; it does not modify Field's frame
sequences. Source encoding rate is verified; displayed FPS depends on the device.

The [reference audit](docs/reference-pattern-audit.md) covers all five supplied
sites, the full capability inventory, implemented gaps and prioritized follow-ups.

### Measuring preset performance

The opt-in [preset benchmark](http://localhost:5173/performance.html) exercises all
29 real studio renderers at 720px or 375px, with full/economy budgets and optional
resize notifications. It measures active animation, idle work, shared pause and
offscreen suspension. For a production run, build the playground and serve it with
`npm run preview --prefix playground`; open `/performance.html` on the printed URL.
Keep the tab active and avoid other rendering or build work during timed samples.

The results distinguish page animation cadence, submitted canvas updates and
presented native-video frames. Finite DOM transitions and demand-rendered 3D are
expected to stop drawing when settled. Page FPS alone does not establish effect
FPS, GPU completion time or physical display presentation. The benchmark restores
its instrumentation and cancels sampling callbacks after each run. See the
[29-preset performance report](docs/preset-performance.md) for the measured scope
and before/after results.

## Interactive compositions

Nine lightweight DOM effects and a Three assembly helper grew from deeper runtime
studies of ten sites. They provide reusable behavior with original playground
content. The DOM effects require no WebGL or optional renderer; the assembly
helper composes inside the existing optional `Scene`/Canvas.

| Import | Behavior | Caller owns |
| --- | --- | --- |
| `/layout-morph` → `LayoutMorph` | Stable keyed content moves between normalized rectangles | Layout coordinates, filters, item content and selection |
| `/object-stack` → `ObjectStack` | CSS 3D browse/inspect poses with semantic selection buttons | One `selectedId`, object artwork, detail content, palette and routes |
| `/recursive-viewport` → `RecursiveViewport` | Quarter-turn chapter camera, scoped keys and optional focused wheel input | Panels, active index, navigation controls and ordinary-layout toggle |
| `/media-strip` → `MediaStrip` | Native horizontal list, threshold mouse drag, optional reflected drift | Media, stable IDs, aspect ratios, navigation destinations and filtering |
| `/scene-panel` → `ScenePanel` | Controlled scene push or centered focus panel | Open state, content, surface styling, navigation and routes |
| `/media-disclosure` → `MediaDisclosure` | Single-open text with independently retained selected media | Items and controlled `{ activeId, expanded }` value |
| `/adaptive-surface` → `AdaptiveSurface` | Surface and identity change at a content boundary | Before/after colors, identity, boundary/root refs and layout |
| `/motion-video` → `MotionVideo` | Native playback intent, actual status, poster and suspension policies | Source, poster, captions, controls and story routes |
| `/media-carousel` → `MediaCarousel` | Bounded controlled window, responsive visible count, scoped keys | Items, start index, content and responsive count |
| `/three` → `ExplodedAssembly` | Stable part groups between authored assembled/separated poses | Geometry, offsets, amount, trigger, interpolation and scene |

Open [`http://localhost:5173/?interactions=1`](http://localhost:5173/?interactions=1)
for all ten studies, including [project strips](http://localhost:5173/?interactions=1#strips),
[scene navigation](http://localhost:5173/?interactions=1#scene), and
[compact focus](http://localhost:5173/?interactions=1#focus). Tune
transition duration, layout/filter, stack spacing or recursive ratio. Configuration
JSON reflects the current props and target boxes; it does not include artwork,
React content or an animation replay. The gallery and preset studio link here.

```tsx
'use client';
import { useState } from 'react';
import { LayoutMorph } from '@sigmastudioz/ui-foundation/layout-morph';

export function RearrangingCollection() {
  const [spread, setSpread] = useState(false);
  return <>
    <button onClick={() => setSpread(!spread)}>Change arrangement</button>
    <LayoutMorph style={{ height: 360 }} items={[
      { id: 'red', rect: { x: spread ? .6 : .1, y: .15, width: .25, height: .6 },
        content: <button style={{ width: '100%', height: '100%', background: 'coral' }}>One</button> },
      { id: 'green', rect: { x: spread ? .1 : .6, y: .3, width: .25, height: .6 },
        content: <button style={{ width: '100%', height: '100%', background: '#c9d4b3' }}>Two</button> },
    ]} />
  </>;
}
```

Rectangles use host-relative fractions. Positions clamp to −4…4; sizes to
0.001…4. Supply unique, nonempty stable IDs; ambiguous IDs throw explicitly.
Hidden layout items retain their DOM identity but leave focus and accessibility.
The host owns clipping. Rearrangements animate translation, rotation and box
dimensions; this is controlled geometry, not automatic FLIP measurement.

```tsx
'use client';
import { useState } from 'react';
import { ObjectStack } from '@sigmastudioz/ui-foundation/object-stack';

export function ObjectCollection() {
  const [selectedId, select] = useState<string | null>(null);
  const editions = [
    { id: 'one', label: 'First edition', color: '#e85b38' },
    { id: 'two', label: 'Second edition', color: '#cbd798' },
  ];
  const selected = editions.find(item => item.id === selectedId);
  return <>
    <ObjectStack items={editions.map(item => ({ ...item,
      content: <span style={{ display: 'grid', placeItems: 'center', height: '100%', background: item.color }}>{item.label}</span>,
    }))} selectedId={selectedId} onSelect={select} />
    {selected && <section><h2>{selected.label}</h2><button onClick={() => select(null)}>Return</button></section>}
  </>;
}
```

Object content is decorative: the effect supplies the button, so never nest
interactive content inside it. Arrow keys/Home/End move shelf focus; Enter/Space
activate native buttons; Escape returns from inspection. External index controls
can switch IDs directly. Return restores the trigger's focus. Unknown/removed IDs
resolve to browsing without mutating caller state; consumers should derive their
detail view from the same valid identity (`resolveStackSelection` is available).

```tsx
'use client';
import { useState } from 'react';
import { RecursiveViewport } from '@sigmastudioz/ui-foundation/recursive-viewport';

export function ChapterField() {
  const [index, change] = useState(0);
  const [linear, setLinear] = useState(false);
  return <>
    <button onClick={() => setLinear(!linear)}>{linear ? 'Spatial' : 'Linear'} view</button>
    <button disabled={index === 0 || linear} onClick={() => change(index - 1)}>Previous</button>
    <button disabled={index === 1 || linear} onClick={() => change(index + 1)}>Next</button>
    <RecursiveViewport activeIndex={index} onActiveIndexChange={change}
      mode={linear ? 'linear' : 'spatial'} panels={[
        { id: 'start', label: 'Start', content: <h2>First chapter</h2> },
        { id: 'next', label: 'Next', content: <h2>Second chapter</h2> },
      ]} />
  </>;
}
```

Recursive panels have a 400×400 local coordinate space, fitted to the host.
Portrait hosts place the continuation below; landscape hosts place it to the
right. Style panel content to fit that square. In spatial mode only the active
panel is accessible/operable; inactive neighbors remain visible but inert. Keys
are scoped to the viewport, ignore editable fields and modified shortcuts, and
bound navigation to valid panels. Optional `wheelNavigation` only runs while the
viewport contains focus; page scrolling is released at the ends. Mark nested
scroll areas with `data-recursive-scroll` to keep their native input.

System reduced motion automatically uses ordinary document order; explicit
`mode="linear"` does the same. More than 16 panels also resolves to linear mode
to avoid extreme zoom. Empty collections are safe. Initial SSR output includes
readable content without DOM measurement. Hooks observe resize and disconnect
on unmount; imports touch no browser globals. `EffectsProvider paused`, offscreen
state and reduced motion settle finite CSS transitions directly to their target.
CSS transitions use no persistent RAF loop and do not obey the provider's GPU FPS cap.

See [the study and implementation decisions](docs/ten-site-reconstruction-study.md#implementation-follow-on-dmcg-stripe-and-narrow)
for observed behavior, deliberate differences and verification limits.

### Media strips, scene panels and linked disclosures

```tsx
'use client';
import { useState } from 'react';
import { MediaStrip } from '@sigmastudioz/ui-foundation/media-strip';
import { ScenePanel } from '@sigmastudioz/ui-foundation/scene-panel';
import { MediaDisclosure } from '@sigmastudioz/ui-foundation/media-disclosure';

export function StudioPieces() {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState({ activeId: 'identity' as string | null, expanded: true });
  return <>
    <MediaStrip label="Project images" height={220} items={[
      { id: 'wide', aspectRatio: 1.5, content: <img src="/project-wide.jpg" alt="Project overview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> },
      { id: 'detail', aspectRatio: .8, content: <img src="/project-detail.jpg" alt="Printed detail" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> },
    ]} />
    <ScenePanel title="Studio menu" open={open} onOpenChange={setOpen}
      variant="push" panelClassName="my-panel-surface" scene={<h2>Your scene</h2>}>
      <button onClick={() => setOpen(false)}>Return to the scene</button>
    </ScenePanel>
    <MediaDisclosure value={value} onValueChange={setValue} items={[
      { id: 'identity', label: 'Identity', content: <p>A point of view.</p>, media: <img src="/identity.jpg" alt="Identity study" /> },
      { id: 'digital', label: 'Digital', content: <p>A useful place.</p>, media: <img src="/digital.jpg" alt="Digital study" /> },
    ]} />
  </>;
}
```

`MediaStrip` renders one semantic copy. Native touch, wheel and keyboard scrolling
stay available; mouse dragging begins beyond six pixels and suppresses the ensuing
pointer click. Editable descendants and `data-strip-interactive` opt out of custom
dragging. `speed` defaults to zero; positive pixels/second enable drift that reflects
at finite ends. It pauses on hover, focus, dragging, reduced motion, offscreen,
hidden tabs and shared pause. This is an original motion option; seamless looping
and Boc's precise autoplay triggers were not established by the source study.

`ScenePanel` is a host-scoped **non-modal** dialog. `variant="push"` moves the scene
aside; `variant="focus"` blurs/dims the scene and opens a centered panel. Supply an
opaque, readable panel surface via `panelClassName`, plus your trigger/content
styles. Scene and panel children remain mounted, preserving caller state. The
hidden side becomes inert; nested library effects pause. Close/Escape return focus;
keyboard users can still reach the surrounding document. There is no global body
scroll lock or focus trap. Navigation and URL updates belong to the caller.

`MediaDisclosure` keeps `activeId` after collapse; `expanded` only controls its text.
Selecting another ID changes both. Hidden text retains local state; only selected
media mounts, avoiding several hidden renderers. Unique IDs are required; unknown
selection renders no media. The layout switches to a single column below 620px host
width. Media entry uses a cancellable finite animation, with a static fallback.
All three import and server-render without browser globals or optional renderers.

### Adaptive surfaces, native films, bounded carousels and assemblies

The final four studies are [atmosphere in parts](http://localhost:5173/?interactions=1#assembly),
[adaptive identity](http://localhost:5173/?interactions=1#surface),
[story discovery](http://localhost:5173/?interactions=1#stories) and
[considered objects](http://localhost:5173/?interactions=1#carousel).

```tsx
'use client';
import { useRef, useState } from 'react';
import { AdaptiveSurface } from '@sigmastudioz/ui-foundation/adaptive-surface';
import { MotionVideo } from '@sigmastudioz/ui-foundation/motion-video';
import { MediaCarousel } from '@sigmastudioz/ui-foundation/media-carousel';

export function EditorialPieces() {
  const boundary = useRef<HTMLElement>(null);
  const [playing, setPlaying] = useState(false);
  const [index, setIndex] = useState(0);
  return <>
    <AdaptiveSurface boundaryRef={boundary} offset={72}
      before={{ background: 'transparent', color: 'white' }}
      after={{ background: '#f1eee5', color: '#37392e' }}
      style={{ position: 'sticky', top: 0, zIndex: 1 }}>
      {past => <nav><a href="#home">{past ? 'F /' : 'Frame'}</a></nav>}
    </AdaptiveSurface>
    <button onClick={() => setPlaying(!playing)}>{playing ? 'Pause' : 'Play'}</button>
    <MotionVideo src="/original-film.mp4" poster="/original-still.webp"
      label="Original landscape film" playing={playing} onPlayingChange={setPlaying}>
      <track kind="captions" src="/captions.vtt" srcLang="en" label="English" />
    </MotionVideo>
    <section ref={boundary}><h2>A different point of view</h2></section>
    <MediaCarousel index={index} onIndexChange={setIndex} visibleCount={1}
      label="Selected projects" items={[
        { id: 'one', content: <a href="/one">First project</a> },
        { id: 'two', content: <a href="/two">Second project</a> },
      ]} />
  </>;
}
```

`AdaptiveSurface` switches when `boundaryRef`'s top passes the viewport top plus
`offset`. Supply `scrollRootRef` for a contained scrolling region. Both refs must
point to mounted elements in the same commit. Passive scroll and resize observers
coalesce measurements into one RAF per burst and publish only boolean changes.
The caller owns positioning and identity markup; stable matching child types keep
native navigation identity. Pause/reduced motion disables the color transition,
while the boundary still updates so content stays readable.

`MotionVideo` requires a poster. `playing` is intent, and `onStatusChange` reports
`idle`, `loading`, `playing`, `paused`, `blocked` or `error`. Native controls report
user play/pause/end via `onPlayingChange`. Offscreen, hidden-page and shared pause
suspend playback without erasing intent; re-entry resumes it. Reduced motion shows
a semantic still and prevents playback. Rejected play promises show truthful retry
feedback; toggle intent off/on to retry. A replaced source gets a fresh video
identity, so stale promises cannot replace its status. Error retains the labelled
poster and `fallback`. Ordinary content/caption requirements remain caller-owned.

`MediaCarousel` clamps the start `index` to `items.length - visibleCount`, with no
wrap/autoplay. Counts clamp to one through six; apps choose responsive counts.
One mounted copy per ID retains local input state. Off-window slides become inert,
hidden to accessibility, and pause nested effects. Previous/Next stay visible but
disabled at bounds; root-focused arrows/Home/End work without stealing input keys.
Focus returns to the host if its active content disappears or an endpoint button
becomes disabled by activation. Narrow touch dragging is not implemented; controls
are the supported input, while `MediaStrip` supplies native horizontal scrolling.

```tsx
import { Scene, ExplodedAssembly } from '@sigmastudioz/ui-foundation/three';

export function PartStudy({ amount }: { amount: number }) {
  return <Scene style={{ height: 400 }} fallback={<p>Static assembly illustration</p>}>
    <ambientLight intensity={2} />
    <ExplodedAssembly amount={amount} parts={[
      { id: 'shell', position: [0, 0, 0], offset: [1, .5, 0], spin: [0, .2, 0],
        children: <mesh><boxGeometry /><meshStandardMaterial color="#d4e1dc" /></mesh> },
    ]} />
  </Scene>;
}
```

`ExplodedAssembly` maps bounded `amount` (0–1) into authored position offsets and
XYZ spin (radians), keeping stable keyed part groups. `sampleAssemblyPose` is the
pure math export. It creates no RAF, renderer or hidden input handler; caller
interpolation can reuse `useScrubProgress`, or use direct poses for reduced motion.
The existing Scene/Float own visibility, optional-peer and ambient-motion policy.
Geometry, annotations, atmosphere and trigger policy belong to the app. Source
Igloo hover versus click and later scroll-story progression remain unverified.

All four demos export their current configuration and use original content.
The shared six-second silent MP4 is encoded from the existing Field study's
code-rendered arrival frames (including its original generated backplate); every
story card intentionally uses this same sample clip. No source-site media is shipped.
See [the deeper findings](docs/ten-site-reconstruction-study.md#implementation-follow-on-the-remaining-four-sites).

## `/geometric` — contour field

A photograph, or a field the material grows itself, traced into living geometry.
Isolines, flow engraving, spectral curtains, dither, and pixel memory run in one
WebGL pass. The same luminance builds the vector layer: nodes, Delaunay / radial /
orthogonal / chained links, a shape hierarchy, and a circle chain whose crossings
are solved analytically. The pointer bends both layers. Presets: `contourAtlas`,
`flowEngraving`, `spectralCurtain`, `ditherPrint`, `pixelMemory`, `circleChain`,
`ghostConstellation`, `delaunayPortrait`.

```tsx
import { Geometric } from '@sigmastudioz/ui-foundation/geometric';

<Geometric preset="contourAtlas" style={{ height: 640 }} />

<Geometric preset="delaunayPortrait" src="/portrait.jpg" alt="Traced portrait" palette="solarTrace" />
```

`src` is optional. Without it, the component samples a procedural portrait field.
`speed={0}` freezes time. `interactive={false}` disables pointer gravity.
Reduced motion and `paused` hold a single frame. The canvas is decorative; pass
`children` for readable content. A CSS contour paint covers SSR and missing WebGL.

[`examples/geometric-demo.html`](examples/geometric-demo.html) compiles the shader
and checks that time and pointer gravity change pixels. Build first, then open it
over HTTP.

## `/image-filter` — image treatments

Four original image treatments inspired by the [pmndrs examples gallery](https://pmndrs.github.io/examples/):
`ascii`, `halftone`, `pixelate`, and `chromatic`. This module processes a still
image in one WebGL pass and has no Three dependency. These four kinds render only
when an image, size, or control changes. The same renderer also powers the ten
retro components below (`posterize`, `stipple`, `ascii`, `thermal`, `phosphor`,
`liquid`, `xerox`, `raster`, `solarized`, `teletext`).

```tsx
import { ImageFilter } from '@sigmastudioz/ui-foundation/image-filter';

<ImageFilter src="/portrait.jpg" alt="Portrait of the artist" kind="ascii"
  cellSize={8} style={{ height: 480 }} />

<ImageFilter src="/coast.jpg" alt="A volcanic coast" kind="chromatic"
  offset={12} angle={30} intensity={0.7} style={{ height: 400 }} />
```

`cellSize` (4–64) and chromatic `offset` (0–64) use CSS pixels, so device pixel
ratio does not change the look. `intensity` blends the original (0) with the
effect (1). ASCII and halftone support `color`, `backgroundColor` (3- or 6-digit
hex), `monochrome={false}` for source colors, and `invert` for reversed luminance.
ASCII uses a built-in bitmap alphabet with no font or texture downloads.

Images center-crop like `object-fit: cover`. The actual `<img>` retains its
description and intrinsic size; a fixed container height is optional. It also
paints SSR, missing-WebGL, context-loss, and loading/error states. Transparent
pixels retain their alpha. Remote images need CORS permission for texture upload;
`onError(message)` reports loading/upload failures. Replacing `src` cancels stale
callbacks, and restored contexts reload the image.

The playground includes live controls. [`examples/image-filter-demo.html`](examples/image-filter-demo.html)
verifies all four shaders with pixel readback, inversion/color controls, DPR
scaling, exact zero-separation output, alpha, and source replacement.

## Seven image effects from the supplied shader video

Each effect has its own React component and typed subpath. They reuse `/image-filter`'s
single-pass WebGL renderer, image loader, cover crop and lifecycle; no Three peers are needed.

| Import from `@sigmastudioz/ui-foundation` | Component | Controls specific to the treatment |
| --- | --- | --- |
| `/lens-distortion` | `LensDistortion` | `distortion`, `center`, `radius`, RGB `offset` in CSS pixels |
| `/moving-blobs` | `MovingBlobs` | `distortion`, `center`, `radius`; animated by default |
| `/slice-shift` | `SliceShift` | `distortion`, `slices` (2–128), `angle` |
| `/pixel-stretch` | `PixelStretch` | `distortion`, `center`, `radius`, `angle`; defaults downward from `[.5,.25]` |
| `/halftone` | `Halftone` | `cellSize` (4–64 CSS px), `monochrome`, `invert`, ink `color`, `backgroundColor` |
| `/image-warp` | `ImageWarp` | `distortion`, `center`, `radius`, `angle`; separate from the `/warp` starfield |
| `/pixelate` | `Pixelate` | `cellSize` (4–64 CSS px) |

```tsx
import { LensDistortion } from '@sigmastudioz/ui-foundation/lens-distortion';
import { MovingBlobs } from '@sigmastudioz/ui-foundation/moving-blobs';
import { PixelStretch } from '@sigmastudioz/ui-foundation/pixel-stretch';

<LensDistortion src="/portrait.jpg" alt="Portrait" distortion={.7} offset={16}
  center={[.5, .4]} style={{ height: 420 }} />
<MovingBlobs src="/flowers.jpg" alt="Flowers" radius={.7} speed={.5}
  style={{ height: 420 }} />
<PixelStretch src="/portrait.jpg" alt="Stretched portrait" angle={90}
  center={[.5, .3]} distortion={1} style={{ height: 420 }} />
```

All accept required `src`/`alt`, `intensity` (0–1 blend), `paused`, `className`, `style`,
and `onError(message)`. Empty `alt` marks decorative images. Distortion strength is 0–1;
`center` is normalized `[x,y]` from the top-left; `radius` is .05–2 times the shorter
container dimension. Angles are degrees, clockwise: 0 points right and 90 down.
Slice Shift at angle 0 divides into vertical strips displaced horizontally; 90 uses
horizontal strips. Outside-image samples clamp to the edge. No temporal feedback is stored.

The five distortions accept `animated` and `speed` (0–3); only Moving Blobs animates
by default. Other distortions opt in with `animated`. Halftone and Pixelate render
on demand. `paused`, zero speed, reduced motion, offscreen state and hidden tabs
freeze animation; control changes still redraw a static treatment. All retain the
semantic original image for SSR/loading/WebGL failure/context loss. Remote URLs need
CORS for GPU upload. Use a reachable ordinary image as the fallback.

The same treatments are available as `ImageFilter` kinds `lens-distortion`,
`moving-blobs`, `slice-shift`, `pixel-stretch`, `halftone`, `image-warp` and `pixelate`.
Facades choose treatment-specific defaults; the generic `ImageFilter` keeps its
existing defaults for compatibility. These are independent visual recreations,
not the original Figma shaders or source artwork.

For the **interactive comparison**, run `npm --prefix playground run dev`, then open
`http://localhost:5173/image-effects.html` (or the port printed by Vite). It renders
all seven public components, an original panel, per-effect controls, original toggles,
image upload and a local reference-video picker. Files stay in the browser.
[`examples/image-effects-demo.html`](examples/image-effects-demo.html) is the compiled
GPU check page: after `npm run build`, serve the repository with
`python3 -m http.server 5186`, then open `/examples/image-effects-demo.html`.
It checks changed pixels, identity settings, motion/static redraw, centers, strip
controls, DPR scaling, wide resizing and source alpha for all seven treatments.

## `/heatmap` — photographic false color

Map image luminance through a configurable shadow-to-highlight color ramp,
inspired by the supplied poster-style video. This is a visual treatment, not a
temperature measurement. It shares the image-filter renderer and fallback above;
no Three dependency or animation loop is required.

```tsx
import { Heatmap, HEATMAP_RAMPS } from '@sigmastudioz/ui-foundation/heatmap';

<Heatmap src="/portrait.jpg" alt="Artist portrait" preset="thermal"
  contrast={1.3} style={{ height: 480 }} />;

<Heatmap src="/coast.jpg" alt="Volcanic coast"
  colorRamp={['#10106b', '#1262ef', '#00d6b2', '#d5f522', '#ff851b', '#e51b35']}
  intensity={0.85} invert={false} />;
```

`preset` selects `thermal` (default), `infrared`, or `ember`; their immutable
arrays are available as `HEATMAP_RAMPS`. `colorRamp` overrides the preset with
2–16 evenly spaced colors in `#RGB` or `#RRGGBB` format. Invalid arrays fall back
to the thermal palette. Colors interpolate through a 256-texel RGB lookup
texture. `contrast` (0.1–3, default 1) adjusts luminance around mid-gray;
`invert` reverses the mapping; `intensity` (0–1, default 1) blends with the
original. Source alpha is retained. Loading, missing WebGL, context loss, CORS
errors, and SSR show the semantic original image. The treatment stays static
under reduced motion and offscreen; source, size, and control changes redraw it.
The shared `ImageFilter` also accepts `kind="heatmap"` and `colorRamp`.

In the main playground, open [Heatmap](http://localhost:5173/#heatmap) for live
named palettes, editable color stops, contrast, blend, reversal, and a **Copy React**
example that follows the current controls. Run `npm run dev --prefix playground`.

Build with `npm run build`, then run `python3 -m http.server 8000` from the
repository root and open
[`examples/heatmap-demo.html`](http://localhost:8000/examples/heatmap-demo.html).
The [demo source](examples/heatmap-demo.html) includes named/custom palettes,
contrast, inversion, blend, local image upload, React usage, and automatic GPU
checks for ramp endpoints, blending, transparency, DPR, and existing filters.

## Retro image effects and presets

Ten independently importable React components share `ImageFilter`'s texture
loader, glyph atlas, image fitting, and WebGL lifecycle. Each provides three
immutable named presets. Explicit props override preset values.

```tsx
import { Posterize } from '@sigmastudioz/ui-foundation/posterize';
import { StippleDuotone } from '@sigmastudioz/ui-foundation/stipple-duotone';
import { GlyphGrid } from '@sigmastudioz/ui-foundation/glyph-grid';
import { ThermalNoise } from '@sigmastudioz/ui-foundation/thermal-noise';
import { PhosphorGhost } from '@sigmastudioz/ui-foundation/phosphor-ghost';
import { LiquidScreen } from '@sigmastudioz/ui-foundation/liquid-screen';
import { XeroxCollage } from '@sigmastudioz/ui-foundation/xerox-collage';
import { RasterLines } from '@sigmastudioz/ui-foundation/raster-lines';
import { SolarizedStreak } from '@sigmastudioz/ui-foundation/solarized-streak';
import { TeletextPattern } from '@sigmastudioz/ui-foundation/teletext-pattern';

<Posterize src="/portrait.jpg" alt="Artist portrait" preset="pop" levels={4} />
<StippleDuotone src="/portrait.jpg" alt="Artist portrait" preset="newsprint" cellSize={5} />
<GlyphGrid src="/portrait.jpg" alt="Artist portrait" preset="cobalt" cellSize={8} />
<ThermalNoise src="/portrait.jpg" alt="Artist portrait" preset="acid" grain={0.2} />
<PhosphorGhost src="/portrait.jpg" alt="Artist portrait" preset="cyan" glow={0.8}
  style={{ height: 480 }} />
<LiquidScreen src="/portrait.jpg" alt="Artist portrait" preset="electric" trail={0.7} />
<XeroxCollage src="/portrait.jpg" alt="Artist portrait" preset="copier" threshold={0.5} />
<RasterLines src="/portrait.jpg" alt="Artist portrait" preset="cyan" distortion={0.7} />
<SolarizedStreak src="/portrait.jpg" alt="Artist portrait" preset="silver" angle={0} />
<TeletextPattern src="/portrait.jpg" alt="Artist portrait" preset="broadcast" cellSize={12} />
```

| Component | Presets | Main controls |
| --- | --- | --- |
| `Posterize` | `graphic`, `pop`, `noir` | `levels` (integer 2–16), `contrast` (.1–3), `monochrome`, `invert` |
| `StippleDuotone` | `newsprint`, `blueprint`, `saffron` | `cellSize` (4–64 CSS pixels), ink `color`, paper `backgroundColor`, `contrast`, `grain`, `invert` |
| `GlyphGrid` | `terminal`, `cobalt`, `paper` | `cellSize`, `color`, `backgroundColor`, `monochrome`, `invert` |
| `ThermalNoise` | `acid`, `ember`, `arctic` | `backgroundColor` → `color` → `accentColor` palette, `contrast`, `grain`, `glow`, `speed` |
| `PhosphorGhost` | `cyan`, `green`, `amber` | `color`, `backgroundColor`, `contrast`, `grain`, `glow`, `scanlines`, `curvature`, `speed` |
| `LiquidScreen` | `electric`, `ultraviolet`, `mint` | `color`, `backgroundColor`, `distortion`, `trail`, `cellSize`, `glow`, `scanlines`, `grain`, `contrast`, `speed` |
| `XeroxCollage` | `copier`, `zine`, `archive` | ink `color`, paper `backgroundColor`, `threshold`, `distortion`, `cellSize`, `grain`, `contrast`, `invert` |
| `RasterLines` | `cyan`, `terrain`, `copper` | `color`, `backgroundColor`, `cellSize`, `distortion`, `glow`, `contrast`, `grain`, `speed` |
| `SolarizedStreak` | `silver`, `oxide`, `diagonal` | `color`, `backgroundColor`, `threshold`, `trail`, `offset`, `angle`, `cellSize`, `contrast`, `grain`, `monochrome` |
| `TeletextPattern` | `broadcast`, `ceefax`, `magenta` | `color`, `backgroundColor`, `accentColor`, `cellSize`, `levels`, `contrast`, `scanlines`, `grain`, `monochrome`, `invert` |

Grain, glow, scanlines, distortion, trail, and threshold use 0–1; curvature uses
0–.5; speed uses 0–3. All ten support `src`, required `alt`, `intensity`, `className`, `style`, and
`onError`. Hex colors support three or six digits. Posterize's `noir` preset uses
a quantized ink/paper ramp; its other presets quantize RGB channels. Stipple uses
irregular dot positions and sizes rather than a regular halftone screen. Glyph
Grid reuses the font-independent bitmap alphabet.

Thermal, phosphor, liquid, and raster animate by default. Set `paused`, `animated={false}`,
or `speed={0}` to freeze the current frame; controls still redraw. Shared
`EffectsProvider` pause, page visibility, offscreen detection, and
`prefers-reduced-motion` stop their animation. The other six remain static
even when `animated` is supplied. No Three.js or generation API is used.

These effects process still images. Phosphor adds luminous monochrome emission,
scanlines, interference, and barrel distortion; it does not provide a television
bezel or temporal video persistence. Its warped corners become transparent.
The existing `CRTSurface` remains available for a DOM overlay around arbitrary
children. All ten retain the semantic original image during SSR, loading,
missing WebGL, upload failure, and context loss; restored contexts reload textures.

Liquid Screen uses a bounded set of upstream image samples for vertical trails,
edge emission, and time-driven distortion. Raster Lines displaces horizontal
lines using image luminance; its `distortion={0}` produces straight scanlines.
Both freeze their flow under reduced motion. These are image-space treatments;
neither constructs a 3D surface or stores temporal video history.

Xerox Collage thresholds ink and offsets image tiles with ragged paper seams;
`distortion={0}` removes the tile offsets/seams, while `cellSize` sets one quarter
of the tile width. Solarized Streak folds luminance around `threshold` and smears
along `angle` (degrees), with `offset` in CSS pixels and `trail` controlling the
strength. Zero offset or zero trail removes the smear. `cellSize` controls row
variation. These print effects keep their grain deterministic.

Teletext Pattern uses a 2×3 mosaic of sampled blocks inside each `cellSize` tile.
Its three-stop palette runs from `backgroundColor` through `accentColor` to
`color`, quantized to `levels`. `monochrome={false}` switches to the eight binary
RGB colors. `scanlines` controls mosaic gaps. This is an image treatment, not a
Teletext broadcast decoder.

Build and serve the repository to run the browser demos:

```sh
npm run build
python3 -m http.server 8765 --bind 127.0.0.1
# Open http://localhost:8765/examples/retro-filters-demo.html
```

- [`Interactive gallery`](examples/retro-filters-demo.html): five comparisons,
  fifteen presets, local image upload, controls, and pause/resume.
- [`Signal and print gallery`](examples/signal-filters-demo.html): the remaining
  five effects and fifteen presets, using the same controls and lifecycle. Each
  gallery allocates at most five image-effect contexts.
- [`GPU verification`](examples/retro-filters-gpu-demo.html): all ten effects and
  thirty presets; actual compilation,
  preset/control differences, quantization, static determinism, motion/freeze,
  DPR scaling, source replacement, and alpha readback.

## `/rain-on-glass` — refractive wet-window rain

Irregular beads cling to the pane, merge on contact and become heavier drops
that release and accelerate down the glass. They collect smaller beads and
leave stationary wet tracks that gradually dry over a blurred still image. Rounded
water lenses distort/invert the city locally and reflect its colors along their
rims, inspired by the supplied Rain Atlas video. Children stay sharp above
the glass; the library does not include a focus timer or page layout.

```tsx
import { RainOnGlass } from '@sigmastudioz/ui-foundation/rain-on-glass';

<RainOnGlass
  src="/city.jpg" alt=""
  backgroundBlur={5} dropletDensity={0.8}
  dropletSize={1} refraction={0.65} speed={0.7}
  style={{ height: '100svh' }}
>
  <YourSharpContent />
</RainOnGlass>
```

Web React >=18.2, WebGL 1 and Canvas2D, no optional Three peers. Supply a height and a
same-origin/data/blob or CORS-enabled image. The image uses center-cropped
cover fitting. `backgroundBlur` is a Gaussian radius of 0–40 CSS pixels
(default 5); `dropletDensity` is 0–1 (default .8). Zero density removes all
drops/trails and stops animation while retaining the configured blur.
`dropletSize` (.5–2, default 1) stays consistent across canvas DPRs;
`refraction` (0–1, default .65) adjusts lens distortion. `speed` (0–3,
default .7) integrates changes without jumping; zero freezes. `seed`
(-10000–10000, default 7) chooses a deterministic drop field.

`paused`, provider pause, reduced motion, offscreen and hidden-page state stop
RAF. Changed controls still redraw a still frame. Background Gaussian passes
are cached until image, blur or size changes. Blur targets are capped at 1536
pixels on their long side; provider `maxDpr` and `maxFps` limit animated work.
The semantic image remains visible during SSR/loading, WebGL initialization
failure or context loss, using CSS blur as an approximation. `onError` reports
WebGL, image/CORS and rendering failures; restoration reloads the image.
The private CPU water model conserves volume and momentum during coalescence,
uses swept contacts and a spatial grid, and caps the population at 2,200 drops.
Fixed 120 Hz steps plus interpolated presentation keep motion stable across
display rates; catch-up is capped at .25 simulation seconds per render. A bounded
Canvas2D height/track texture feeds the WebGL lens shader. Merging bodies ease
together over .22 seconds, heavier drops overcome contact pinning, and trails
dry over five simulation seconds. This is a lightweight droplet model, without
arbitrary DOM refraction or video input. Density, seed, droplet size and host
dimensions restart the seeded model; blur/refraction and source-image changes
preserve it. Context restoration resets to a fresh layout. There is no public
time-seeking API, and paused/hidden/offscreen time does not advance the water.

Run `npm run dev --prefix playground` and open
[Rain Atlas](http://localhost:5173/rain-on-glass.html) for Tokyo/Neon/Dusk scenes,
live controls, pause, local image upload, Copy React and a functioning focus
timer. City backdrops are original AI-generated demo assets. After building,
serve the repository and open [GPU checks](examples/rain-on-glass-demo.html)
for actual shader, blur, density, motion, deterministic-frame and GL-error checks.

## `/fluted-glass` — ribbed image refraction

Static, vertically fluted glass inspired by editorial photography. Rounded ribs
refract the image horizontally, with directional diffusion, RGB dispersion and
subtle reflections. No Three dependency or animation loop; reduced motion keeps
the same static treatment.

```tsx
import { FlutedGlass } from '@sigmastudioz/ui-foundation/fluted-glass';

<FlutedGlass src="/portrait.jpg" alt="Portrait of the artist"
  ribWidth={9} refraction={0.65} blur={1.5} chromaticSeparation={1}
  style={{ height: 480 }}>
  <h2>Through glass</h2>
</FlutedGlass>
```

| Prop | Default | Range / meaning |
| --- | --- | --- |
| `ribWidth` | `9` | 2–128 CSS pixels between vertical ribs; smaller means more ribs |
| `refraction` | `0.65` | 0–1 lens strength |
| `blur` | `1.5` | 0–16 CSS pixels of horizontal diffusion |
| `chromaticSeparation` | `1` | 0–12 CSS pixels of RGB separation at rib slopes |
| `highlight` | `0.25` | 0–1 rib reflections and shading |

Values are clamped; nonfinite values use defaults. Set `refraction`, `blur`,
`chromaticSeparation` and `highlight` to zero for an unchanged image. Distances
stay consistent across device pixel ratios. Images center-crop like
`object-fit: cover`; give the container a height or retain intrinsic image sizing.
Optional `children` sit above the canvas and stay sharp. Position and style them
in the consuming app.

An ordinary accessible `<img>` remains visible during SSR, loading, failed
uploads, unavailable WebGL and context loss. Transparent images retain alpha;
diffusion avoids dark transparency fringes. Cross-origin sources require CORS
permission for WebGL; `onError(message)` reports image loading/upload errors.
Changing `src` cancels stale callbacks; context restoration reloads the image.

Build first, then serve the repository over HTTP and open
[`examples/fluted-glass-demo.html`](examples/fluted-glass-demo.html). It includes
an original/effect comparison, live controls, local image uploads, and real GPU
checks for independent controls, deterministic frames, zero optics, DPR and alpha.

## `/iridescent-ribbon` — flowing thin-film ribbon

An original procedural recreation of the supplied wallet welcome-screen video:
a pale rainbow ribbon curves around a clear opening, gathering into narrow,
reflective folds toward the lower edge. No video texture or Three dependency.

```tsx
import { IridescentRibbon } from '@sigmastudioz/ui-foundation/iridescent-ribbon';

<IridescentRibbon
  speed={1} width={1} bands={3} distortion={0.55}
  style={{ width: 300, height: 650, borderRadius: 30 }}
>
  <YourWelcomeContent />
</IridescentRibbon>
```

Web React >=18.2. `width` (.5–2) controls ribbon thickness, `distortion` (0–1)
controls folds, `bands` (1–8) controls interference density, `hue` (0–360 degrees)
shifts colors, `intensity` (0–1) fades the material to `backgroundColor` (hex,
default white). `scale` (.5–2) and clockwise `rotation` (-360–360 degrees) transform
the artwork. Set a host size; a 300/650 portrait ratio matches the reference.
Other aspect ratios stretch the composition. All controls are optional.

`speed` (0–3) integrates without rewinding when changed; zero freezes. Optional
`time` (0–3600 seconds) selects an exact static material frame independently of
speed. Removing `time` resumes the retained autoplay phase. Animation pauses for
`paused`, provider pause, reduced motion, hidden tabs and offscreen state; changed
controls redraw a still frame. Adaptive DPR is enabled by default (`adaptive={false}`
opts out). SSR and WebGL failure/context loss retain approximate static SVG art
and live children. The decorative canvas never intercepts input. This web effect
is separate from the existing dark luminous `SpectralRibbon` and satin `Iridescence`.

Run `npm run dev --prefix playground -- --port 5174` and open
`/iridescent-ribbon.html` for the matching phone demo, motion controls, time scrub,
reset and Copy React. Wallet actions are explicitly demo-only. After building,
serve the repository over HTTP and open `examples/iridescent-ribbon-demo.html`
for pixel checks of spectral variation, motion, clear opening, deterministic time,
hue changes, zero intensity and WebGL errors. The demo's logo, screen copy and
phone layout are outside the library API.

## `/iridescence` — interactive spectral materials

Flowing satin folds, soft highlights, and iridescent color, rendered in one WebGL
pass without textures or Three. Presets: `pearl`, `aurora`, `oil`, `rose`.

```tsx
import { Iridescence } from '@sigmastudioz/ui-foundation/iridescence';

<Iridescence preset="pearl" style={{ height: 460, borderRadius: 24 }} />

<Iridescence preset="oil" intensity={0.8} roughness={0.25} speed={0.4}
  style={{ minHeight: 400 }}>
  <h2>Your content stays accessible above the material.</h2>
</Iridescence>
```

`baseColor` / `accentColor` accept 3- or 6-digit hex. Tune `intensity` (0–1),
`roughness` (0.08–1), `scale` (0.2–4), `speed` (0–3), and `rotation` (degrees).
Explicit props override presets; invalid numeric inputs fall back safely.
`interactive={false}` disables pointer lighting; `paused` freezes animation.
Give the container a height, minimum height, or content that establishes its size.
The decorative canvas is hidden from assistive technology; CSS paints the first
server frame and remains available when WebGL cannot initialize.

The playground has a material tuner with preset, pause, quality, and intensity
controls. [`examples/iridescence-demo.html`](examples/iridescence-demo.html) tests
the compiled shader with real pixel readback. Run `npm run build`, serve the
repository (for example `python3 -m http.server 8000`), and open the demo over HTTP.

## Shared rendering controls

```tsx
import { EffectsProvider } from '@sigmastudioz/ui-foundation/core';

<EffectsProvider paused={false} maxDpr={1.5} maxFps={30}>
  <Iridescence preset="aurora" style={{ height: 400 }} />
  <Gradient preset="ocean" style={{ height: 240 }} />
</EffectsProvider>
```

- `paused` freezes library animations and scroll tracking in the subtree.
  Nested providers cannot undo a parent's pause.
- `maxDpr` limits shader canvas pixel density; the default is 2. Lower values
  reduce pixel work. Scene uses it as its default DPR cap; explicit `canvasProps.dpr`
  remains a consumer override.
- `maxFps` caps animations using the shared RAF hook; the default is 60.
  Three retains its own render loop, so this setting does not cap Three's frame rate.
- OS reduced-motion preferences always take precedence. Shader and RAF effects
  pause when the document is hidden. GPU effects, Grain, and mouse parallax also
  pause offscreen. Scene suspends its render loop offscreen and propagates motion
  state to Model, World, and BallPit.

Changing a shader's visibility, pause state, or DPR does not recreate its GPU
resources. Animation time excludes pauses, so resuming does not rewind or jump.
Context restoration rebuilds the renderer and reloads liquid-metal masks.
`useRafLoop` uses active elapsed time and caps unusually large frame deltas;
consumers should not use it as a wall clock.

## `/gradient` — animated WebGL gradient

```tsx
import { Gradient } from '@sigmastudioz/ui-foundation/gradient';

// Preset, zero config:
<Gradient preset="aurora" style={{ height: 400 }} />

// Preset + overrides (explicit props win):
<Gradient preset="sunset" shape="waterPlane" speed={0.6} style={{ height: 400 }} />

// Fully custom:
<Gradient colors={['#5b2c83', '#2f80ed', '#43e97b']} shape="sphere" amplitude={1.2} />
```

Presets: `aurora` (default), `sunset`, `ocean`, `mono`, `mist`. Props:
`preset`, `colors` (2–3 hex stops), `shape` (`plane`/`sphere`/`waterPlane`),
`speed` (0 freezes), `amplitude`, `frequency` (`1` = original scale; higher is
finer / mistier), `opacity` (only when passed), `paused`, `className`, `style`.
Omitted / non-finite numbers fall back to the preset.

Behavior: **SSR-safe** (CSS-gradient paint until mounted), **accessible**
(freezes under `prefers-reduced-motion`), **efficient** (RAF loop pauses when
scrolled off-screen), **resilient** (CSS fallback if WebGL is unavailable).

See a live grid of the core presets in [`examples/gradient-demo.html`](examples/gradient-demo.html).

## Modules

| Subpath | Exports | Notes |
|---|---|---|
| `/image-filter` | `<ImageFilter>`, `resolveImageFilterConfig` | shared static and retro image shader renderer; no Three dependency |
| `/posterize` | `<Posterize>`, `POSTERIZE_PRESETS` | RGB or monochrome quantization; three presets |
| `/stipple-duotone` | `<StippleDuotone>`, `STIPPLE_DUOTONE_PRESETS` | irregular ink dots on paper; three presets |
| `/glyph-grid` | `<GlyphGrid>`, `GLYPH_GRID_PRESETS` | bitmap character reconstruction; three presets |
| `/thermal-noise` | `<ThermalNoise>`, `THERMAL_NOISE_PRESETS` | animated false-color grain and halo; three presets |
| `/heatmap` | `<Heatmap>`, `HEATMAP_RAMPS` | static photographic false color; named or custom color ramps |
| `/phosphor-ghost` | `<PhosphorGhost>`, `PHOSPHOR_GHOST_PRESETS` | animated CRT image treatment; three presets |
| `/liquid-screen` | `<LiquidScreen>`, `LIQUID_SCREEN_PRESETS` | animated neon refraction and vertical image trails; three presets |
| `/xerox-collage` | `<XeroxCollage>`, `XEROX_COLLAGE_PRESETS` | thresholded photocopy tiles and paper seams; three presets |
| `/raster-lines` | `<RasterLines>`, `RASTER_LINES_PRESETS` | luminous image-displaced contour lines; three presets |
| `/solarized-streak` | `<SolarizedStreak>`, `SOLARIZED_STREAK_PRESETS` | solarized tones and directional smear; three presets |
| `/teletext-pattern` | `<TeletextPattern>`, `TELETEXT_PATTERN_PRESETS` | quantized six-block mosaics; three presets |
| `/fluted-glass` | `<FlutedGlass>`, `resolveFlutedGlassConfig` | static ribbed image refraction, horizontal blur, RGB dispersion and sharp overlays |
| `/rain-on-glass` | `<RainOnGlass>`, `resolveRainOnGlassConfig` | refractive beads, sliding drops and trails; configurable background blur/density with sharp overlays |
| `/fluid-field` | `<FluidField>` | interactive dye feedback and three flowing palettes |
| `/image-transition` | `<ImageTransition>` | controlled crossfade, ripple, dissolve, melt, wipe, and halftone between URLs or decoded frames |
| `/magnetic` | `<Magnetic>` | spring movement around native interactive children |
| `/kinetic-text` | `<KineticText>` | accessible wave and stretch typography |
| `/geometric` | `<Geometric>`, `GEOMETRIC_PRESETS`, `resolveGeometricConfig`, `buildGeometricScene` | contour field from a photo or a procedural source |
| `/core` | `<EffectsProvider>`, `useEffectsSettings`, `useRafLoop`, `useReducedMotion`, `useInView`, `useScrollProgress`, `usePageVisible` | shared rendering controls and hooks |
| `/iridescence` | `<Iridescence>`, `IRIDESCENCE_PRESETS`, `resolveIridescenceConfig` | interactive spectral materials (4 presets) |
| `/gradient` | `<Gradient>`, `resolveGradientConfig` | animated WebGL shader gradient (5 presets) |
| `/liquid-metal` | `<LiquidMetal>` | flowing chrome shader; `text`/`src` masks it into a logo |
| `/liquid-glass` | `<LiquidGlass>` | Apple-style glass (CSS + SVG filter, no WebGL) |
| `/mouse-parallax` | `<Parallax>`, `useMouseParallax` | damped cursor-tracking parallax |
| `/scroll-3d` | `<ScrollParallax>`, `<ScrollLayer>` | scroll-driven transforms and coordinated layers on a shared timeline |
| `/scroll-scrub` | `<ScrollScrubVideo>`, `<ScrollScrubFrames>`, `<SceneCover>` | pinned media, frame loading, chapter timing, chroma-key overlays and foreground transitions |
| `/three` | `<World>`, `<Scene>`, `<Model>`, `<Float>`, `<GlassMaterial>`, `<Caustics>`, `<Portal>`, `<ReflectiveFloor>`, `<SoftShadows>`, `<Bloom>`, `loadThree` | 3D worlds, glass caustics, portals, reflective floors, soft contact shadows, and HDR bloom (needs the `three` peers) |
| `/particles` | `<Particles>` | GPU point field, flow-field motion + pointer repulsion |
| `/warp` | `<Warp>` | hyperspeed light-speed streaks |
| `/scroll-reveal` | `<StickyReveal>` | pinned heading, words reveal on scroll |
| `/grain` | `<Grain>` | animated film-grain / noise overlay |
| `/physics` | `<BallPit>` | rigid-body physics; rapier loads on mount (optional peer) |
| `/physics/rapier` | `<Physics>`, `<RigidBody>`, colliders | direct rapier primitives; importing this subpath evaluates the peer |
| `/force-2d` | `useForceSim`, `stepForceSim` | spring and collision simulation with reduced-motion support |
| `/visualizer` | `<Visualizer>` | Skia-parity now-playing looks (`bars` default). Zero props still animates. |

```tsx
import { LiquidMetal }      from '@sigmastudioz/ui-foundation/liquid-metal';
import { LiquidGlass }      from '@sigmastudioz/ui-foundation/liquid-glass';
import { Parallax }         from '@sigmastudioz/ui-foundation/mouse-parallax';
import { ScrollParallax }   from '@sigmastudioz/ui-foundation/scroll-3d';
import { ScrollScrubVideo } from '@sigmastudioz/ui-foundation/scroll-scrub';
import { Scene }            from '@sigmastudioz/ui-foundation/three'; // needs: npm i three @react-three/fiber
```

### `/three` — react-three-fiber scenes & glTF models

```tsx
import { World, Scene, Model } from '@sigmastudioz/ui-foundation/three';

// One-liner "live world": image-based lighting + fog + shadows + auto-orbit.
// preset: coastal | studio | night | sunset
<World src="/model.glb" preset="coastal" style={{ height: 460 }} />

// Physics: colorful balls raining and bouncing (needs @react-three/rapier).
import { BallPit } from '@sigmastudioz/ui-foundation/physics';
<Scene canvasProps={{ shadows: true }}><BallPit count={46} /></Scene>

// Or compose your own scene with <Scene> + <Model>:
<Scene canvasProps={{ camera: { position: [0, 0, 4] } }} style={{ height: 420 }}>
  <ambientLight intensity={0.7} />
  <directionalLight position={[3, 3, 3]} intensity={1.4} />
  <Model src="/model.glb" autoRotate animation orbit fit />
</Scene>
```

**Physics:** add [`@react-three/rapier`](https://github.com/pmndrs/react-three-rapier).
`<BallPit>` loads that peer on mount. Compose `<Physics>` / `<RigidBody>` from
`@sigmastudioz/ui-foundation/physics/rapier` inside `<Scene>` or `<World>`
(see the playground's `ThreePhysics.tsx`). A missing peer calls `onError` and
renders nothing instead of throwing while the module is imported.

`Float` adds a bounded hover and gentle XYZ rotation to any mesh or model, inspired
by the gallery's floating objects and [Drei's Float contract](https://drei.docs.pmnd.rs/staging/float).
It is independently implemented and needs no Drei dependency.

```tsx
import { Float, Scene, Model } from '@sigmastudioz/ui-foundation/three';

<Scene style={{ height: 420 }} canvasProps={{ frameloop: 'demand' }}>
  <ambientLight intensity={1} />
  <Float position={[0, 0, 0]} floatingRange={[-0.3, 0.3]} phase={2}>
    <Model src="/sculpture.glb" fit />
  </Float>
</Scene>
```

`speed` defaults to 1 (0 freezes the current phase); `floatIntensity` and
`rotationIntensity` default to 1. `floatingRange` defaults to `[-0.1, 0.1]` in
scene units. `phase` is a deterministic starting phase in radians; vary it between
instances. `position`, `rotation`, and `scale` apply to an outer group, preserving
the child's own transforms. Children stay mounted while the runtime loads.
`paused`, provider pause, reduced motion, hidden pages, and the containing Scene's
visibility stop updates. Demand scenes invalidate only while motion is enabled.
It also works in a consumer Canvas; that host owns its offscreen render policy.

`GlassMaterial` attaches physical transmission to a consumer-owned mesh. Presets:
`clear`, `frosted`, `smoked`, and `amber`. It uses Three's physical material engine
and has no shader loop or additional peer dependency.

```tsx
import { World, GlassMaterial } from '@sigmastudioz/ui-foundation/three';

<World preset="studio" ground={false} style={{ height: 500 }}>
  <mesh>
    <sphereGeometry args={[1, 64, 48]} />
    <GlassMaterial preset="frosted" ior={1.5} thickness={1.2} />
  </mesh>
  {/* Place opaque geometry behind the glass to reveal its refraction. */}
</World>
```

Control `transmission` (0–1), `roughness` (0–1), `ior` (1–2.333), `thickness`
(0–10 mesh units), `color`, `attenuationColor` (3- or 6-digit hex),
`attenuationDistance` (0.01–1000 world units), `clearcoat`, and `envMapIntensity`.
Explicit props override the preset. A ref exposes the host's physical material.
Use closed geometry for a solid volume and an environment map for reflections;
World supplies a procedural environment. Physical transmission samples opaque
scene content; overlapping transmissive objects have Three's usual limitations.
The supported API works with the existing Three 0.160 peer minimum.

`Portal` is a shaped window onto an isolated scene. Its offscreen camera follows
the host camera through the portal's world transform, preserving perspective
when the viewer moves. An oblique near plane clips content in front of the opening.

```tsx
import { Scene, Portal, Float } from '@sigmastudioz/ui-foundation/three';

<Scene style={{ height: 500 }} canvasProps={{ camera: { position: [0, 0, 5] } }}>
  <Portal interactive shape="arch" width={2} height={3} background="#9fb6bd" resolution={512}>
    <ambientLight intensity={1.5} />
    <Float position={[0, 0, -2]}>
      <mesh>
        <torusKnotGeometry args={[0.5, 0.15, 96, 20]} />
        <meshStandardMaterial color="#e2c6a2" />
      </mesh>
    </Float>
  </Portal>
</Scene>
```

Portal children use local coordinates; place visible content at negative Z.
They need their own lights because the scene is isolated. Add `inheritEnvironment`
to borrow the containing scene's current environment texture for glass and metal;
it follows changes on requested frames and never disposes the host's texture.
Without it, provide an environment inside the portal as needed.
Supported shapes: `arch`, `rounded` (with `radius`), and `circle` (diameter =
`width`, height follows width). `position`, `rotation`, and `scale` transform the
opening and its coordinate system together. Perspective and orthographic cameras
are supported. `resolution` caps the longest render-target side in physical pixels
(64–2048); target size also follows the host drawing-buffer aspect ratio.

`paused` freezes motion-aware children, including Float/Model, and inherits the
containing Scene/provider/reduced-motion state. The view updates when the host
requests a frame, including camera moves or newly loaded content. Portal does not
start an idle render loop, and a culled window does not capture its scene. Demand hosts
can use Float to request frames while moving. `fallback` accepts R3F content while
loading or after failure; `onError(Error)` reports runtime failures. Geometry
changes preserve the child scene, and unmount frees owned GPU resources.

Add `hdr` when portal content needs to retain light intensities above 1 for root
bloom. This uses a linear half-float target and requires WebGL 2 with floating-point
color targets; unsupported renderers report `onError` and show `fallback`. The
default remains an unsigned-byte target. Changing `hdr` retains the child scene.

Add `interactive` to click an opening and blend its world across the canvas.
Click the entered view or press Escape to exit; dragging remains a camera gesture.
`transitionDuration` is in seconds (default `.65`, range 0–5). Paused scenes and
reduced motion switch immediately. Entry reuses the child scene and leaves the host
camera unchanged; existing camera controls continue to work. The full view removes
the aperture's near-plane clipping. Window-only behavior remains the default.

For DOM buttons, keyboard access, or routing, control `entered` and
`onEnteredChange`. Keep one selected portal ID per Canvas:

```tsx
const [selected, setSelected] = useState<string | null>(null);
// DOM controls outside the Canvas:
<button onClick={() => setSelected('ocean')}>Enter ocean</button>
<button onClick={() => setSelected(null)}>Exit scene</button>
// Inside the Canvas:
<Portal interactive entered={selected === 'ocean'}
  onEnteredChange={next => setSelected(current => next ? 'ocean' : current === 'ocean' ? null : current)}>
  {/* Your isolated scene */}
</Portal>
```

Portal does not add DOM controls or routes. Its scene contents remain visual;
picking individual objects through the texture is not provided.

Glass can cast a geometry-driven caustic light field onto its own receiving plane:

```tsx
import { World, Caustics, GlassMaterial } from '@sigmastudioz/ui-foundation/three';

const ior = 1.5;
<World ground={false}>
  <Caustics ior={ior} lightSource={[-2, 6, 2.5]} intensity={1.5}
    position={[0, -1, 0]} size={[10, 10]} floorColor="#303945"
    samples={128} resolution={512} softness={3}>
    <mesh position={[0, 0.15, 0]}>
      <sphereGeometry args={[0.75, 64, 48]} />
      <GlassMaterial ior={ior} thickness={1.4} />
    </mesh>
  </Caustics>
</World>
```

`Caustics` captures the wrapped geometry's front/back positions and normals from
the light, refracts photons through both interfaces, and accumulates their light
on the plane. A straight-through baseline removes unfocused light. The result is
an approximation for closed, rigid, ordinary meshes; use separate wrappers for
separate glass volumes. Overlapping volumes, internal reflections, skinning,
instances, morphs, normal maps, and spectral dispersion are not modeled. Geometry
and world transforms drive the capture; material properties are not inferred.
Share `ior` (1–2.5) with `GlassMaterial`. IOR 1 leaves the base floor unchanged.

`lightSource` is a world-space position outside the caster bounds; the beam aims
at their center and uses parallel incident rays. `position`, `rotation`, and
`size` affect only the receiver, leaving children in their original coordinates.
`intensity` (0–10) and `color` tint the focused light; `softness` (1–8) sets its
footprint in texture pixels. `samples` is the photon grid side (32–256, squared
for the photon count); `resolution` bounds the receiving texture (128–1024).
Four geometry captures are separately capped at 512 px. Increase samples to
reduce gaps in strongly defocused regions.
Energy saturates conservatively at extreme beam/receiver ratios to keep the
floating-point accumulation finite.

The default opaque `floorColor` makes the light field visible through Three's
physical transmission material. To add light above an existing reflective floor,
use `floorColor={null}` and place the receiver slightly above it; Three's standard
transmission buffer excludes transparent overlays, so that mode is visible around
the glass. `enabled={false}` retains the glass and plain floor. Loading or failure
retains children and shows the supplied R3F `fallback`; `onError` reports missing
peers, unsupported geometry or hardware. WebGL 2 with floating-point color targets
and four vertex texture units is required. Owned captures restore renderer state
and release on unmount. No private animation loop is added; Scene/World supply
pause, reduced-motion and offscreen policies.

The playground's **Glass caustics** study exposes shape, refraction, glass height,
light position/height, intensity, softness, photon count, texture detail, motion
pause and an on/off comparison. [`examples/caustics-demo.html`](examples/caustics-demo.html)
verifies actual floor pixels independently of the glass image, including IOR 1,
geometry/light movement, quality controls, disabling, stale-map clearing, DPR,
shader compilation and resource cleanup.

Scene staging uses the same optional Three peers:

```tsx
import { World, ReflectiveFloor, SoftShadows, Bloom } from '@sigmastudioz/ui-foundation/three';

<World ground={false}>
  <YourObjects />
  <ReflectiveFloor position={[0, -1, 0]} size={[12, 12]}
    color="#202532" strength={0.65} blur={2} resolution={512} />
  <SoftShadows position={[0, -0.99, 0]} size={[10, 10]}
    opacity={0.65} blur={4} far={5} resolution={512} />
  <Bloom strength={0.8} radius={0.4} threshold={1} resolution={1024} />
</World>
```

`ReflectiveFloor` provides a single-bounce planar reflection with an approximate
nine-tap blur. `strength` mixes reflection with the base `color`; `blur` is in
texture pixels (0–12). It requires a perspective camera. `size` gives the local
plane dimensions; `position` and `rotation` transform the plane. The default
rotation faces upwards. Resolution caps the target's longest physical side
(64–2048) while preserving the host aspect ratio. Disabling the effect leaves
the base-color floor visible.
Reflections prepare before the scene's transmission pass so physical glass keeps
its own camera's refraction buffer. Existing scene callbacks are chained and the
preparation hook is removed when the last reflective floor unmounts.

For wet ground, place a receiver slightly above your street or pavement:

```tsx
<ReflectiveFloor position={[0, 0.01, 0]} size={[20, 3]}
  pattern="puddles" coverage={0.65} distortion={0.4}
  color="#20333d" strength={0.7} blur={1.5} resolution={384} />
```

`pattern="puddles"` leaves transparent gaps between irregular reflective patches.
`coverage` (0–1, default .5) controls their extent; zero removes all patches and
skips the reflection capture. `distortion` (0–1, default 0) adds static surface
irregularity. Both patterns reuse one bounded planar capture per receiver.
The default `pattern="solid"` preserves the original floor behavior.

`SoftShadows` is a soft **contact-shadow receiver**. It captures depth silhouettes
above its plane and blurs them in two directions; it does not modify global
shadow shaders or approximate light-source penumbrae. All meshes above the plane
participate, including meshes without `castShadow`. `far` controls capture height
and height fading; `opacity`, `color`, and `blur` control the appearance. Keep
the receiver slightly above the floor to prevent z-fighting, and use
`World ground={false}` when replacing its existing shadow-catching ground.
Transparent/cutout materials are treated as opaque silhouettes.

`Bloom` processes the entire root Canvas with Three's HDR bloom and output
passes. Mount one Bloom per Canvas, outside Portal children and other composers.
Root bloom includes the visible portal view when entering/exiting. `threshold`
uses linear luminance (0–10); use emissive intensity above 1 to isolate bright
objects. `strength` is 0–5, and `radius` is 0–1. Disabling bloom restores direct
scene rendering. Its resolution cap controls internal processing, while final
output fills the Canvas. It retains the host tone mapping and output color space.

All three accept `enabled`, R3F `fallback`, and `onError(Error)`. They allocate
after mount, retain resources across control changes, restore nested renderer
state even after a failed capture, and dispose owned resources on failure or
unmount. They add no animation loop: captures happen only on requested host
frames. Scene/World provide offscreen, hidden-page, pause, and reduced-motion
behavior; custom Canvas hosts provide their own frame policy.

The playground's **All effects studio** (`#staging`) puts glass, caustics,
reflective floors and soft shadows inside an interactive HDR portal, with bloom
at the World root. Click the doorway or use **Enter studio** to enter; click the
entered view, press Escape, or use either Exit button to return. Exit restores
focus to the entry control. Material and quality settings persist across entry
and exit. The portal borrows World's environment and supplies its own lighting.
It has individual toggles,
shared glass IOR and light controls, orb/knot selection, material/floor/shadow/glow
sliders, photon and texture quality, pause, and a complete before/after comparison.
Switching glass off also disables its caustics; the other layers stay independent.
The additive light receiver sits above the reflective floor and below the contact
shadow receiver, keeping the three planes from occluding or shadowing each other.
Standalone caustics, glass and portal studies remain available.
[`examples/portal-studio-demo.html`](examples/portal-studio-demo.html) verifies
all five effects inside an enterable portal, HDR bloom preservation, unchanged
host camera, exit restoration, nested DPR handling and resource ownership.
[`examples/caustics-demo.html`](examples/caustics-demo.html) also verifies all five
layers together, absence of a floor-sized contact shadow, and full comparison
toggle restoration. [`examples/staging-demo.html`](examples/staging-demo.html)
checks reflection/blur, shadow alignment and movement, bloom threshold/disable,
portal composition, DPR resizing, renderer restoration, and GPU cleanup.
[`examples/glass-portal-demo.html`](examples/glass-portal-demo.html) verifies
physical refraction, frosting/absorption, portal isolation, clipping, parallax,
entry/exit blending, resizing, render-target restoration, and GPU texture cleanup
with actual pixels.

`three` and `@react-three/fiber` are **optional package peers**. Install compatible
versions when using `/three` (`npm i three @react-three/fiber`). Canvas, model
loaders, orbit controls, and world lighting dependencies are dynamically imported
after mount. Importing `/three` does not require the peers to be installed; Scene
shows its `fallback` if Fiber cannot load. Other subpaths do not load Three.

`Scene` and `World` accept `paused`. Model animation and orbiting honor reduced
motion; models clone cached scenes so multiple instances can coexist. BallPit
pauses physics with its containing Scene and uses the same render loop.
The `/physics` subpath explicitly re-exports Rapier primitives and requires
`@react-three/rapier` to be installed when imported.

## Examples

Static, self-contained demos (open in a browser):

- [`examples/gradient-demo.html`](examples/gradient-demo.html) — 4 gradient presets
- [`examples/liquid-metal-demo.html`](examples/liquid-metal-demo.html) — 4 metal tints
- [`examples/liquid-metal-logo-demo.html`](examples/liquid-metal-logo-demo.html) — chrome wordmark (text mask)
- [`examples/liquid-glass-demo.html`](examples/liquid-glass-demo.html) — glass over color

## Develop

```bash
npm install
npm run verify   # CJS+ESM build, isolated tarball checks, tests with coverage
npm run lint
```

See [AGENTS.md](AGENTS.md) for the hard rules (peer deps, SSR-safety,
reduced-motion, ≤600-line modules, subpath-per-effect).

Browser checks and visual critique for new or visibly changed effects:

```bash
npm --prefix playground ci && npx playwright install chromium   # once
npm run test:browser       # Playwright checks: layout, scroll, observers, WebGL
npm run critique:capture   # frames for the critique loop → critique-frames/round-1/
```

`critique:capture` saves rest, mid-animation, reduced-motion, light and dark frames
plus a `manifest.json`. Choose targets with `CRITIQUE_TARGETS` (JSON list of
`{ name, url, selector }` on the playground) and the round with `CRITIQUE_ROUND`.
Give the frames and a short brief to an independent critic, fix the ranked defects,
re-capture and repeat with a fresh critic, for at most 3 rounds by default (AGENTS.md
rule 11). Critique adds to the tests; it never replaces them.

### Playground

A live demo app (`playground/`) imports the library straight from source and
exercises every effect, including real 3D via the `three` peers:

```bash
cd playground && npm install && npm run dev   # http://localhost:5173
```

## `/visualizer` — Skia-parity now-playing looks

Same kinds as Galaxy Radio's native Skia visualizers. Nothing passed → `bars`
with an idle sine spectrum (still moves). Feed `bins` + `amplitude` from an
analyzer when you have one.

```tsx
import { Visualizer } from '@sigmastudioz/ui-foundation/visualizer';

<Visualizer />
<Visualizer kind="nebula" bins={spectrum16} amplitude={0.6} />
<Visualizer kind="liquid-metal" metalPreset="gold" />
```

Kinds: `liquid`, `liquid-metal`, `cosmic`, `nebula`, `wave`, `bars` (default),
`ribbon`, `radial`. Unknown / omitted `kind` falls back to `bars`. Non-finite
numbers fall back to the kind defaults. The seven audio-reactive looks compile
SKSL-style material shaders to WebGL. `liquid-metal` is the chrome
shader (`metalPreset`: `gold` default, `chrome`, `rose`, `obsidian`).

[`examples/visualizer-gpu-demo.html`](examples/visualizer-gpu-demo.html) compiles
every visualizer shader and verifies pixel variation and motion using the built
package. Serve the repository over HTTP after building, then run its GPU checks.

## Publishing (CI only)

Releases are published through CI after lint, builds, package/SSR checks and tests
pass. Do not publish from a laptop. Distributions include the built CJS/ESM library,
type declarations and the portable reuse skill. Package consumers only need the
installation and setup instructions above.

### Upgraded material collection

Existing subpath imports and props still work. The default artwork has changed;
projects with screenshot baselines should review the new visual output.

| Effect | Updated appearance | Rendering work reduced |
| --- | --- | --- |
| Gradient | Flowing folds, soft highlights, smooth palette transitions, subtle dithering | Cached color parsing; no multisample buffer |
| Liquid metal | Studio strip reflections, deep chrome bands, luminous tinted rims | Analytic normals replace six simplex evaluations per pixel; masked-out pixels exit early |
| Liquid glass | Crystal, frosted and smoked finishes with polished edges | One turbulence octave; `quality="economy"` skips SVG displacement |
| Particles | Depth variation, bright cores, soft halos and individual shimmer | Single point draw; cached colors; no multisample buffer |
| Warp | Fine radial light lanes, traveling pulses and a luminous corona | Directional lane math replaces two simplex noise evaluations per pixel |
| Visualizer | Taller beveled bars, liquid rims, star detail, nebula filaments, fuller ribbons and radial highlights | Only active uniforms uploaded; locations cached; retained idle spectrum; liquid noise reduced from five to three octaves |
| Mouse parallax | Optional perspective tilt via `tilt={12}` | Settled movement avoids React updates; sized absolute layers retain their height |
| Scroll 3D | `rotateY`, `translateZ`, and `easing="smooth"` | Transform/opacity animation; layer hints removed outside the active range |
| Scroll scrub | `reveal="cinema"` opens a rounded cinematic frame; optional `poster` | Metadata preload avoids requesting the whole video up front; redundant seeks skipped |
| Sticky reveal | Eased rise and subtle word tilt; `variant="fade"` offers a simpler reveal | Layer hints only while a word is revealing; reduced motion shows the whole heading |
| Grain | Softer film texture | Eight precomputed exposures reused during animation; one under reduced motion |
| 3D world | Preset-specific key/rim lighting and a larger centerpiece | Environment generation retained across palette changes; offscreen frames paused |
| Physics | Glossy spheres, colored fill light and a reflective stage | One instanced sphere mesh with per-instance colors, shared geometry/material and fewer triangles |

The playground provides full/economy and pause controls. `EffectsProvider`
controls shared RAF effects through `maxFps`, `maxDpr`, and `paused`; the 3D scene
uses the DPR and pause settings, while its render cadence remains controlled by
Fiber. Performance depends on screen size and hardware; the changes above are
reductions in rendering work, not a promised device-independent FPS increase.

```tsx
<LiquidGlass finish="smoked" quality="economy">…</LiquidGlass>
<Parallax tilt={12} strength={28}>…</Parallax>
<ScrollParallax rotateY={16} translateZ={80} easing="smooth">…</ScrollParallax>
<ScrollScrubVideo src="/film.mp4" poster="/still.jpg" reveal="cinema" />
<World preset="night" modelScale={1.35} src="/world.glb" />
```

After `npm run build`, serve the repository and open
`examples/material-gpu-demo.html` for gradient/metal/warp/particle compilation,
nonblank pixels, and animated-frame checks. The companion
`examples/visualizer-gpu-demo.html` covers all seven spectrum shaders, and
`examples/iridescence-demo.html` covers the four new iridescent materials.

The 3D playground's **Orbital Observatory** is a procedural composition built
from ordinary R3F children inside `World`: a shader planet, translucent orbital
rings, a machined platform, orbiting moons and a star field. Its scene content
lives in `playground/src/ObservatoryWorld.tsx`, keeping application composition
out of the library. `World` accepts a `camera` override for deliberate framing,
and `/three` exports `useSceneMotion()` so custom `useFrame` callbacks can honor
the same pause, visibility and reduced-motion settings as the host scene.

The earlier floating-town composition is retained in `playground/src/IslandWorld.tsx`.
Its 354 source meshes become 54 material batches. The default gallery scene is
now the **Coastal Island**, with the observatory available beside it.
Run `npm run check:island` from `playground/` to verify the original asset batching,
both terrain detail budgets, generated geometry, and repeatable vegetation seeds.

The coastal scene now uses a textured heightfield, slope-colored rock and ground,
instanced palms and scrub, a small coastal station, shadowed sunlight, and animated
water with shallows and surf. The observatory remains selectable. `World lighting={false}`
lets custom scenes supply their own lights. The generated rock texture and its exact
prompt are documented in `playground/public/textures/README.md`.

Terrain uses 41,472 triangles in full mode and 12,800 in economy mode; vegetation
is grouped into four instanced draws. Static shadows are cached between quality
changes rather than redrawn for water animation and camera movement. Motion follows the shared pause, visibility,
and reduced-motion controls. These are geometry budgets, not measured FPS claims.
The scene is a browser-scale realism study, not a reproduction of a commercial
AAA game's renderer or assets.

## New interaction effects

Each effect below is available from its own subpath and the root barrel. None
requires Three. Give GPU surfaces an explicit height or a sized parent.

```tsx
import { FluidField } from '@sigmastudioz/ui-foundation/fluid-field';
import { ImageTransition } from '@sigmastudioz/ui-foundation/image-transition';
import { Magnetic } from '@sigmastudioz/ui-foundation/magnetic';
import { KineticText } from '@sigmastudioz/ui-foundation/kinetic-text';

<FluidField preset="lagoon" adaptive style={{ height: 500 }} />
<ImageTransition from="/coast.jpg" to="/desert.jpg" alt="A landscape"
  kind="ripple" progress={progress} style={{ height: 420 }} />
<Magnetic strength={24}><button onClick={launch}>Explore</button></Magnetic>
<KineticText as="h2" text="ALIVE." mode="wave" />
```

- **FluidField:** `lagoon`, `ember`, and `ultraviolet` palettes; configurable
  `color`, `accentColor`, `speed` (0..3), `persistence` (.8...995), and `resolution`
  (128..768, default 512). Two bounded RGBA textures retain and advect pointer dye.
  It combines a procedural flow material with persistent dye feedback; it is not
  a pressure-solving fluid simulator. `interactive={false}` disables input.
  `paused` freezes time. `adaptive` defaults to true and adjusts display resolution.
  Resizing clears the dye buffers. WebGL failure leaves a CSS gradient.
- **ImageTransition:** controlled `progress` (0..1), `kind="ripple" | "dissolve" |
  "melt" | "wipe" | "halftone" | "crossfade"`, and `intensity` (0..2). `from`/`to` accept URLs
  or decoded `HTMLImageElement` frames. Exact source/target endpoints, centered cover
  cropping, and on-demand rendering. The component does not start its own timeline.
  Reduced motion switches directly between the source and target at the midpoint.
  Use same-origin images or CORS-enabled URLs. Loading/upload failures invoke
  `onError` and retain an ordinary image fallback. Provide a meaningful `alt`.
- **Magnetic:** a stable outer hit area with spring movement inside it. `strength`
  is bounded to 0..80 pixels. Native child buttons/links retain their handlers and
  keyboard semantics. Press feedback and keyboard focus are supported. Touch
  scrolling is preserved; cancellation resets the input. `paused` resets movement.
- **KineticText:** `wave` and pointer-driven `stretch` modes; `amplitude` (0..40),
  `speed` (0..4), `paused`, and semantic `as` (`span`, `h1`, `h2`, `h3`, `p`).
  Text is exposed once to assistive technology; decorative graphemes are hidden.
  Uses `Intl.Segmenter` when available, with a code-point fallback on older runtimes.

Fluid, Magnetic, and KineticText honor shared pause, offscreen visibility,
background tabs, and reduced motion. ImageTransition responds to explicitly
supplied progress and redraws only when its inputs, size, or loaded images change.

### Shared input and adaptive quality

```tsx
import { useInteraction } from '@sigmastudioz/ui-foundation/core';

function InteractiveSurface() {
  const { signal, handlers } = useInteraction();
  return <section {...handlers}>
    <FluidField signal={signal} style={{ height: 400 }} />
    <KineticText signal={signal} text="Connected." />
  </section>;
}
```

The mutable signal carries normalized pointer coordinates, pressure, pressed and
focus state. Passing an external signal disables the effect's local input handlers;
attach the shared handlers to a stable parent. Pointer events do not update React
state. `createInteractionSignal()` also supports imperative producers.

`useAdaptiveQuality(active)` returns a detail multiplier between .5 and 1. It
samples shared RAF intervals against the requested frame budget, lowers quality
only after two slow 45-sample windows, and restores it after six healthy windows.
This is frame-interval feedback, not GPU timing or a guaranteed FPS target.
`useWebGLEffect({ adaptive: true, ... })` applies that multiplier to its DPR budget
without reallocating the renderer. Existing effects remain opt-in.

`examples/next-wave-gpu-demo.html` verifies both new shaders using real pixel
readback, animated frames, input response, and exact image endpoints. The playground
contains all four demos and original generated imagery documented in
`playground/public/images/README.md`.

### Audio-reactive visualizers

The seven shader looks (`liquid`, `cosmic`, `nebula`, `wave`, `bars`, `ribbon`,
`radial`) now support a retained audio source. Existing `bins`, `amplitude`, and
`beat` props still work. With no source or bins, the visualizer runs its ambient
preview. A connected source with silent audio remains silent; it never substitutes
an artificial spectrum.

```tsx
import { Visualizer, useAudioVisualizer } from '@sigmastudioz/ui-foundation/visualizer';

const { source, connect, startMicrophone, stop, status, error } = useAudioVisualizer();

// Run from a user gesture. Keep this media element for the hook's lifetime.
await connect(audioElement);
await audioElement.play();

<Visualizer kind="cosmic" audio={source} sensitivity={1.4} adaptive />
```

The hook creates an AudioContext only when `connect` or `startMicrophone` is called.
It reuses each media element's source node, keeps playback connected to the
speakers, and routes microphone input only to the analyser. `stop()` disconnects
analysis and stops owned microphone tracks; it does not pause your media element.
Unmounting disconnects nodes and closes the owned context. Stop or pause playback
in your own UI as appropriate. Microphone permission errors are exposed as `error`;
pending streams granted after cancellation are stopped immediately.

Use same-origin or CORS-enabled media with the element's `crossOrigin` set before
its URL. The playground's local files never leave the browser. Keep one hook as
owner of each media element; do not recreate a source node for an element from a
second hook/context. If your player already has an audio graph, retain ownership
and use `createAudioAnalyser(existingAnalyser)` instead.

The source samples sixteen logarithmic frequency bands, RMS level, a waveform,
held peaks, bass/mid/treble energy and a transient envelope. Buffers are retained;
there are no per-frame React updates. `sensitivity` applies input gain from 0 to 4.
The onset detector is an energy heuristic, not beat tracking or BPM estimation.
Shader rendering and analyser sampling pause offscreen, in background tabs, under
reduced motion, and with shared pause. Audio playback and an explicitly started
microphone remain under your control until stopped. For custom inputs, implement
`VisualizerAudioSource.sample()` and return a `VisualizerAudioFrame`.

| Look | Sound response |
|---|---|
| Liquid | Bass reshapes raymarched liquid; mids fold the surface; treble changes reflections |
| Cosmic | Bass expands the dark core and ring; mids illuminate spiral dust; treble lights stars |
| Nebula | Bass swells layered cloud volumes; mids move filaments; treble reveals fine structure |
| Wave | Waveform and band energy shape layered luminous contours |
| Bars | Rainbow rays over a low equalizer, held peaks, and a soft floor reflection |
| Ribbon | Spectrum widens metallic ribbons; waveform bends them; treble sharpens their edges |
| Radial | Fine rainbow rays around a circular spectrum, longer where that frequency is loud |

`liquid-metal` remains the separate material backend and uses its existing manual
amplitude controls. The new audio source applies to the seven shader looks above.
`examples/visualizer-gpu-demo.html` verifies animation and isolated bass/mid/treble
responses at the same timestamp for every look.

## Native app primitives and audio envelopes

`/frosted-blur` and `/remote-image` expose native conditional entries plus explicit
`/native` subpaths. Web imports are SSR-safe without native peers. Blur accepts
scheme/surface/fallback colors; images accept a source resolver for app-owned
normalization, CDN URLs, cache policy and priority. Radio injects its existing native blur/FastImage adapters; shared native entries
import neither backend. Web rendering uses the optional react-native-web peer. No app theme or CDN is imported.

`/visualizer` (including its native entry) exports `createSmoothedAudioSource`
with time-based attack/release/beat envelopes and retained per-consumer buffers,
plus ambient-glow color/frame math. Native visualizers honor explicit maxFps
through 60; omitted values retain tier defaults and provider ceilings.

### Scroll stories: frame sequences, chapters, and foreground masks

The existing video scrubber now maps the full pinned interval: frame zero when
its track reaches the viewport top, and the final frame when the track bottom
reaches the viewport bottom. Other callers of `useScrollProgress()` retain the
original entering-to-exiting viewport range. Opt into the pinned interval with
`useScrollProgress({ range: 'sticky' })`.

```tsx
import { ScrollScrubFrames } from '@sigmastudioz/ui-foundation/scroll-scrub';

// Keep frame URLs stable, ordered from first to last.
const frames = Array.from({ length: 120 }, (_, i) =>
  `/film/frame-${String(i + 1).padStart(3, '0')}.webp`);

<ScrollScrubFrames frames={frames} poster={frames[0]} alt="An orbit taking shape"
  trackHeight="400vh" smoothingMs={140} cacheSize={24} concurrency={4}>
  <h2 style={{ position: 'absolute', left: '8%', top: '25%' }}>A different pace.</h2>
</ScrollScrubFrames>
```

For chapter-driven composition, use the same primitives independently:

```tsx
import { useScrollProgress, useInView } from '@sigmastudioz/ui-foundation/core';
import { createScrollTimeline, useScrubProgress, useFrameSequence,
  ChromaKeyOverlay } from '@sigmastudioz/ui-foundation/scroll-scrub';
import { ImageTransition } from '@sigmastudioz/ui-foundation/image-transition';

// Asset URLs are supplied by your app.
const opening = Array.from({ length: 120 }, (_, i) => `/opening/${i}.webp`);
const closing = Array.from({ length: 180 }, (_, i) => `/closing/${i}.webp`);
// Create once outside the component (or memoize dynamic chapter definitions).
const timeline = createScrollTimeline([
  { id: 'opening', weight: 1, frames: opening.length, transition: 0.2 },
  { id: 'closing', weight: 2, frames: closing.length },
]);
const sequences = [opening, closing];

function Story() {
  const [track, target] = useScrollProgress({ range: 'sticky' });
  const [viewport, inView] = useInView<HTMLDivElement>();
  const progress = useScrubProgress(target, { active: inView, smoothingMs: 140 });
  const chapter = timeline(progress);
  const from = useFrameSequence({ frames: sequences[chapter.index],
    progress: chapter.progress, active: inView });
  const to = useFrameSequence({ frames: sequences[chapter.nextIndex],
    progress: 0, active: inView && chapter.nextIndex !== chapter.index });
  const incoming = chapter.nextIndex === chapter.index ? from : to;
  return <div ref={track} style={{ height: '500vh' }}>
    <div ref={viewport} style={{ position: 'sticky', top: 0, height: '100vh' }}>
      <ImageTransition from={from.image ?? sequences[chapter.index][0]}
        to={incoming.image ?? sequences[chapter.nextIndex][0]} kind="halftone"
        progress={chapter.transition} alt="A moving landscape"
        style={{ position: 'absolute', inset: 0 }} />
      <ChromaKeyOverlay image={chapter.transition === 0 ? from.image : null}>
        <div style={{ position: 'absolute', inset: '10%', border: '1px solid white' }} />
      </ChromaKeyOverlay>
      <h2 style={{ position: 'relative' }}>{chapter.id}</h2>
    </div>
  </div>;
}
```

- `createScrollTimeline` snapshots and validates nonempty, uniquely named chapters,
  positive finite weights, positive integer frame counts, and transition fractions
  in 0..1. It returns a stateless sampler with `index`, `id`, local `progress`,
  `frame`, `nextIndex`, and `transition`. The transition occupies the final fraction
  of its chapter, targeting the next chapter's first frame. A zero fraction cuts;
  the final chapter never transitions. Reverse sampling has no playback history.
- `useScrubProgress` uses elapsed-time damping and stops RAF when settled. Reduced
  motion fixes it at zero. Pass `active: inView` to stop offscreen smoothing;
  shared pause and background-tab suspension are automatic.
- `useFrameSequence` returns a decoded `image`, displayed `index` (-1 before a
  frame arrives), and `targetIndex`. Target-first requests use a bounded decoded
  LRU cache (default 24) and concurrency (default 4), with six neighboring frames
  per side. While loading, it publishes the nearest cached frame. Failures invoke
  `onError(index, src)` once per loader lifetime and are skipped; change the source
  list or remount to retry. Empty lists issue no requests. URL arrays may be inline,
  but memoizing them avoids repeated serialization. Treat them as immutable.
- `ScrollScrubFrames` combines these hooks with a responsive center-cover 2D canvas,
  semantic image label, ordinary poster fallback, and independent HTML children.
  Reduced motion loads only frame zero. Offscreen, pause, and background state
  stop new requests; already pending work can finish. Cache capacity bounds retained
  decoded entries, with concurrent requests and the displayed image additional.
- `ImageTransition` uploads decoded frame objects without creating another URL
  request and retains unchanged texture slots. Pass immutable decoded images;
  mutable video/canvas sources are outside this API. The ordinary image fallback
  follows the selected frame if WebGL is unavailable or its context is lost.
- `ChromaKeyOverlay` masks **decorative** children to dominant blue (default) or
  green background pixels. It uses a small readback canvas (at most 512×512),
  configurable `threshold`, `softness`, and `sampleWidth`, and center-cover CSS
  framing. It is not subject segmentation: foreground colors matching the key
  also disappear. Match the media framing. A CORS/readback failure hides the
  decoration and calls `onError`. The example hides rules during shader blends.

Run `cd playground && npm run dev` and open `/scroll-story.html` for the original
three-chapter **Field** demo. One continuous camera path approaches a chrome
ribbon, passes through its opening, and reveals forms deeper in the same world.
Separate landscape/portrait renders include silhouette frames for layered type.
Shared chapter endpoints are joined once; adjacent frames blend through the
existing image-transition shader's undistorted `crossfade` mode, with no chapter
reset or incoming still. Chapter navigation and a scrubber
remain visible; transition selection, damping, depth and pause controls live in
an accessible native dialog. Reduced motion supports explicit chapter selection
as still views. The Vite production build includes this standalone entry.

The playback page loads rendered WebPs through the existing public primitives,
without a live Three scene. The original demo-only asset renderer uses the
playground's existing Three dependency. See
[`playground/public/scroll-story/README.md`](playground/public/scroll-story/README.md)
for regeneration, asset provenance, and the built-in ImageGen background prompt.

After `npm run build`, serve the repository root and open
`examples/scroll-story-demo.html` for real GPU compilation, six transition
endpoints/midpoints/reversal, decoded-source replacement, chapter boundaries,
and asynchronous frame-loader checks.

### Coordinated layers and foreground scene covers

`ScrollLayer` in `/scroll-3d` accepts a shared `progress`, `from`/`to` poses,
an optional `[start, end]` range and `linear` or `smooth` easing. Translation is
in pixels, rotation in degrees. Unspecified pose channels use zero translation/
rotation, unit scale and full opacity. Poses hold outside their interval;
`sampleScrollLayer` exposes the same deterministic interpolation without React.
Layer ranges must increase inside `[0, 1]`; poses must be finite, scale
nonnegative and opacity inside `[0, 1]`. Parent layout and stacking stay in CSS.

`SceneCover` in `/scroll-scrub` moves an opaque foreground across two mounted
scenes. It holds full coverage from progress `.45` to `.55`, switches the visible
scene at `.5`, and reverses deterministically. Inactive scenes use `display:none`
and `hidden`, preserving state while excluding their content from navigation.
Use an opaque `coverColor` (default `#101418`); `cover` accepts decorative artwork
on that backing. The cover is inert and hidden from accessibility APIs. `axis`
is `x` by default or `y`. `sampleSceneCover` exposes the cut and cover offset.

```tsx
import { ScrollLayer } from '@sigmastudioz/ui-foundation/scroll-3d';
import { SceneCover } from '@sigmastudioz/ui-foundation/scroll-scrub';

<SceneCover progress={progress} coverColor="#e9e2d4" cover={<CurtainArtwork />}
  from={<OpeningScene />} to={<ClosingScene />} />
<ScrollLayer progress={progress} range={[.1, .8]} easing="smooth"
  from={{ y: 60, z: -100, rotateY: -15 }}
  to={{ y: -80, z: 120, rotateY: 15 }}>
  <ForegroundArtwork />
</ScrollLayer>
```

Both components reuse existing lifecycle controls: pause/offscreen freezes the
presented progress, resuming samples the latest value, and reduced motion holds
the initial pose/source scene. They create no animation loop or scroll listener;
the caller owns progress (for example `useScrollProgress({range: 'sticky'})`).
SSR renders that same initial composition. No Three or WebGL dependency is needed.

Run `cd playground && npm run dev` and open `/poma.html` for **Poma**, an
independent botanical motion study: one continuous camera path approaches a
marble sculpture, passes a foreground pear and moves beneath orchard branches.
The public `/camera-journey` engine samples one distance-paced path with a steady
lens. A lazily loaded Three renderer draws volumetric fruit, curved branches,
veined leaves and a reference-posed anatomical hand sculpture, with shared PBR materials,
lighting, shadows, depth testing and atmospheric distance. Nearby geometry
passes the camera in the same world. The portrait lens widens for narrow screens.
Chapter labels and copy change along the same path without replacing the world.
The demo has its own artwork, palette and choreography; it imports no Field
media or camera code. Native scroll, chapter jumps, a keyboard-operable
scrubber and shared pause drive the composition. Reduced motion provides three
explicitly selected still views. The renderer retains its resources while paused,
offscreen or backgrounded and draws only when the visible pose or size changes.
The hand is a local, baked GLB from a CC0 MakeHuman / MPFB anatomical model,
replacing the former WebXR hand. Its native palm, weighted finger topology and
integrated nails are retained, with shallow sculpted folds and an angled forearm.
Fixed-length finger chains form the reference-facing grip: three graduated
fingers at the front-left and an opposed thumb supporting the far side.
The bake avoids voxel remeshing and palm inflation. A local mineral field supplies
subtle marble color, independent crystal relief and roughness with no clearcoat.
Its embedded grip metadata positions the pear. The asset is
loaded with cancellation before creating the renderer. A static artwork poster
covers loading or unavailable WebGL; context restoration rebuilds GPU resources. The former `/scene-layers.html` URL redirects
to Poma. Both entries are included in the Vite build. Original asset provenance
and exact built-in ImageGen prompts live in
[`playground/public/poma/README.md`](playground/public/poma/README.md).

### Reusable camera journeys

`/camera-journey` is a renderer-independent camera engine. Scene geometry and
assets stay in your app. Supply position, look target, FOV and roll waypoints;
use the same compiled path in a live renderer, a scroll experience or an offline
frame render. It imports neither Three nor Fiber.

```tsx
import { useMemo } from 'react';
import { useThree } from '@react-three/fiber'; // your optional renderer
import {
  createCameraJourney, useCameraJourney, applyCameraJourneyPose,
} from '@sigmastudioz/ui-foundation/camera-journey';

function CameraRig({ progress, inView, paused = false }: { progress: number; inView: boolean; paused?: boolean }) {
  const { camera, invalidate } = useThree();
  const journey = useMemo(() => createCameraJourney({
    waypoints: [
      { at: 0, position: [0, 3, 12], target: [0, 2, 0], fov: 36 },
      { at: .45, position: [2, 3, 4], target: [0, 2, -3], fov: 44 },
      { at: 1, position: [4, 4, -8], target: [0, 3, -16], fov: 36 },
    ],
    pacing: 'distance',
    durationMs: 16000,
  }), []);
  useCameraJourney({
    journey, progress, active: inView && !paused, depth: 1.1, smoothingMs: 120,
    onUpdate(pose) { applyCameraJourneyPose(camera, pose); invalidate(); },
    onError(error) { console.warn(error.message); },
  });
  return null;
}
// Mount CameraRig alongside your own scene children inside a demand-mode Canvas
// (or <Scene canvasProps={{ frameloop: 'demand' }}>). Feed progress from your
// scroll hook/scrubber, connect the viewport's useInView result, and pass the
// same paused flag used by Scene. The camera hook is renderer-independent.
```

- Waypoints must have strictly increasing `at` values, starting at 0 and ending
  at 1. At least two are required. Coordinates, roll and FOV must be finite;
  FOV is 1..179 degrees and defaults to 36. Targets must not cross the camera.
  Invalid interior viewing directions stop the hook and call `onError`.
- `pacing: 'authored'` (default) preserves waypoint timing with a cubic path and
  shared tangents. Adjust `at` to allocate scroll distance to each part of the
  scene. `pacing: 'distance'` compiles a 1,024-interval arc-length lookup for
  approximately constant position travel; its lookup is based on depth 1.
- For autoplay, omit `progress` and set `playing: true`. `speed` is 0..10
  (default 1); 0 freezes time. Duration defaults to 12,000 ms. Autoplay stops at
  1 and excludes paused/background time. Supplying `progress` overrides autoplay;
  controlled scroll input has its own timing, independent of `speed`.
- `depth` multiplies camera-to-target distance, clamped to .1..4 (default 1).
  It changes the actual camera pose, so check clearance against your geometry.
  Geometry depth, lights, fog, clipping planes and materials remain scene-owned.
- `useCameraJourney` returns a pose ref and calls `onUpdate` imperatively. Its
  pose/vectors are reused: copy them if retaining snapshots. There is no React
  update per animation frame; controlled input stops scheduling RAF at rest.
  `active`, shared EffectsProvider pause/maxFps, background visibility and
  reduced motion are honored. Reduced motion holds the opening pose.
- Outside React, use `journey.sample(progress, { depth })`, or reuse an output
  pose with `journey.sampleInto(progress, out, { depth })`. The compiled path
  snapshots inputs. `advanceCameraJourney` provides an elapsed-time autoplay
  clock, while `applyCameraJourneyPose` accepts a structural camera interface.

Open `/camera-journey.html` in the playground for the **Camera lab**: two original
scene graphs, two paths, constant-distance/authored pacing, speed, depth, pixel
budget, scrub/play controls and editable waypoint JSON. Changes affect live
geometry immediately. The Field film at `/scroll-story.html` remains a baked
sequence; changing its recorded camera path requires regenerating its frames.
The offline Field renderer now uses the same public camera engine.

For frame playback, `useFrameSequence({ frames, progress, interpolate: true })`
shares one decoded cache and returns `image`, `nextImage`, `index`, `nextIndex`
and `blend` in addition to `targetIndex`. Blend is zero until both exact
surrounding frames are decoded; nearest-cache fallbacks are never interpolated
against unrelated frames. Default noninterpolated behavior is unchanged. Feed
these decoded images and blend into `ImageTransition kind="crossfade"`; overlapping
GPU textures are retained when the pair advances or reverses.

`ChromaKeyOverlay channel="alpha"` accepts precomputed transparent masks and
skips CPU readback, pixel classification and PNG encoding. Field's alpha masks
are generated once, then sampled with its frame strip. Its balanced playback
caps DPR at 1; the live Camera lab also offers .75/1/1.5 pixel-density controls.
The live lab requests up to 120 updates/s at its balanced DPR 1; actual cadence
depends on the browser/device. The film's **Measure playback** control runs a repeatable six-second sweep and
reports draw-update cadence, RAF p95, uploads and CPU mask work. These are local
browser observations, not guaranteed display FPS across devices.


### Particle nebula and plasma vortex

Two procedural, asset-free effects reconstructed from motion references. Each is independently importable;
React remains a peer and neither loads Three.js. Give the host a height or aspect ratio.

```tsx
import { ParticleNebula } from '@sigmastudioz/ui-foundation/particle-nebula';
import { PlasmaVortex } from '@sigmastudioz/ui-foundation/plasma-vortex';

<ParticleNebula count={52000} seed={17} bokeh={1} turbulence={1}
  style={{ aspectRatio: '3 / 2' }} />
<PlasmaVortex color="#45dcff" accentColor="#ff791c" thickness={1} glow={1}
  style={{ aspectRatio: '3 / 2' }} />
```

Both autoplay by default. `paused` or `speed={0}` freezes the current phase; `time={seconds}`
selects a deterministic static frame (0..3600). Remove `time` to resume the autonomous clock;
controlled time does not seek that clock. Both retain a frame under reduced motion, stop RAF
when offscreen or the page is hidden, recover after context restoration, and provide static SVG
artwork for SSR or unavailable WebGL. Overlay `children` remain live DOM. `adaptive` defaults to
true and adapts canvas resolution through the shared effects settings.

Shared controls: `speed` 0..3, `intensity` 0..3 (zero hides the artwork), `turbulence` 0..2,
`scale` .4..2.5, and validated hex `color`/`accentColor`. Nebula adds `count` 2000..100000,
`seed` 0..65535, and `bokeh` 0..2. Count and seed recreate its GPU buffer; other controls
update without renderer recreation. Vortex adds `thickness` .3..2, `glow` 0..2, and `rotation`
in radians (±2π). SVG fallbacks approximate the composition; GPU-only turbulence/time and
lens detail are not reproduced there.

Run `npm run dev --prefix playground -- --port 5189` and open
`/particle-nebula.html` or `/plasma-vortex.html`. Both demos provide pause/play, time scrubbing,
reset, palette and material controls; the nebula also has a new-seed button. Their navigation
links to all three video studies. `examples/energy-effects-demo.html`, served from the repository
root after `npm run build`, exercises compiled ESM WebGL and includes pixel checks for motion,
deterministic replay, warm/cool colors, zero intensity and live controls.

## Portfolio interaction studies

[Open the six-demo gallery](http://localhost:5173/portfolio-worlds.html) after running
`npm run dev --prefix playground`. Independent spatial-collage, floating-object,
CRT-TV, disc-library, desktop, and editorial pages use original neutral artwork and shared
library effects. New subpaths: `/spatial-canvas` (`SpatialCanvas`, `Draggable`),
`/floating-objects` (`FloatingObjects`, `usePopGame`), `/crt-surface`, and `/disc-carousel`; the collage and editorial
examples also reuse `LayoutMorph`. No new dependencies or optional renderers.
See [composition examples and controls](docs/portfolio-worlds.md).

### Native interactive foil artwork

```tsx
import { FoilSurface } from '@sigmastudioz/ui-foundation/foil-surface/native';

<FoilSurface width={300} height={300} alt="Album artwork" intensity={.38} visible={focused}>
  <YourCachedImage style={{ width: '100%', height: '100%' }} />
</FoilSurface>
```

The native laminate preserves your image backend and uses optional Skia for the
spectral finish and moving drop shadow. Drag horizontally, then in either
direction; release or cancellation settles to center. Vertical swipes remain
with the parent ScrollView. `renderFoil={false}` skips Skia on unsupported devices
while keeping the perspective gesture. Focus/visibility, app background, provider
pause and Reduce Motion return to the ordinary image; there is no idle frame
loop. Set `resetKey` to the artwork identity. Native does not implement the DOM
ticket's tearing/flip APIs. Avoid a fixed wrapper shadow: the effect owns it.

The web `FoilSurface` supports square covers with `aspectRatio={1}`,
`tearable={false}`, `idleMotion={0}`, `inset`, UV `cornerRadius`, and
`shadowOpacity`. Reserve a larger centered canvas for the inset so the projected
mesh shadow and lifted edges have room; leave the outer frame unclipped.

## UX composition and recovery

Keep one clear primary action, group related controls with their content, and use
progressive disclosure only where it reduces the task's complexity. Host applications
own control sizing, visual hierarchy, contrast and form validation; aim for generous
44×44 CSS-pixel primary controls and verify actual keyboard and pointer behavior.

Inactive carousel, scene-panel and spatial-chapter content, and decorative reveal
layers, remain inert under React 18 and React 19. Native semantics, retained focus,
reduced-motion and visibility policy take priority over motion. The library does not
impose arbitrary item-count limits or promise every operation completes within 400ms.

`MotionVideo` announces blocked/error feedback through a persistent polite status
region. Pass a custom `fallback` with a named retry button or recovery link when
needed; that error content accepts pointer input. The host owns retry/source changes,
while the original poster and native playback controls remain available as applicable.


### Shape patterns and SVG workshop

The [Shape studies demo](playground/shape-patterns.html), linked from the gallery
and preset studio, reconstructs the supplied Book of Shapes walkthrough with
23 original vector generators. Each shape has its own reference controls.
The cube helix consists of discrete wireframe cubes; the hollow cube skeleton is
an independent shape. The editor preserves SVG/React/JSON copying, current
frame downloads, poster layout and share links. Poster composition stays app-owned.

```tsx
import {
  ShapePattern, createShapePatternSvg, SHAPE_PATTERN_CONTROLS,
  defaultShapeParameters,
} from '@sigmastudioz/ui-foundation/shape-pattern';

<ShapePattern pattern="helix"
  parameters={{ cubeSize: 34, helixAmplitude: 421.6, helixCount: 180,
    helixFrequency: 5.2, cubeHeight: 80 }}
  label="Cube helix" style={{ width: '100%', aspectRatio: '1' }} />

const svg = createShapePatternSvg(
  { pattern: 'rings', parameters: { ringCount: 37.5, minRadius: 134,
    maxRadius: 228, ringAmplitude: 13.5 } },
  { width: 2000, height: 2000, time: 0, label: 'Ring study' },
);
```

`SHAPE_PATTERN_CONTROLS` is the frozen, per-shape control schema used by the
editor and runtime normalization: labels, parameter keys, min/max, step and
reference defaults. `defaultShapeParameters(pattern)` returns a fresh parameter
object. `shapePatternHasMotion(pattern)` exposes whether autoplay changes it.

| Kind | Reference controls |
| --- | --- |
| `waves` | Line Count, Wave Width, Amplitude, Noise Scale X, Noise Scale Y, Y Spread, Envelope Sharpness, Vertical Fade, Softness |
| `dots` | Grid Size, Dot Spacing, Falloff Radius, Circle-Radius; Falloff-Strength is under Additional controls |
| `letters` | Grid Dimension, Seed, Word |
| `quarters` | Tiles, Seed, Density, Gap |
| `arcs` | Spacing, Rows, Cols |
| `cubes` | Rows, Cols |
| `helix` | Cube Size, Amplitude, Count, Frequency, Cube-Height |
| `rings` | Ring Count, Min Radius, Max Radius, Amplitude |
| `cube-frame` | Size, Gap |
| `flow-lines` | Domain, Separation, Stop Distance, Seed |
| `flow-poles` | Poles, Ring, Turn, Pole Core, Separation, Seed, Scatter |
| `flow-dots` | Turbulence, Wavelength, Dot Spacing, Dot Size, Strands, Format |
| `chevron` | Bands, Taper, Band Ratio, Blocks, Seed |
| `triangles` | Cols, Rows, Chaos Start, Seed |
| `nodes` | Node Size, Connection Density, Displacement, Columns, Rows, Seed |
| `interference` | Grid, Spacing, Frequency, Amplitude, Source Sep |
| `spiral` | Cols, Rows, Morph, Turns, Radius, Noise Amt, Noise Scale |
| `broken-ring` | Sides, Rings, Inner Radius, Warp Amount, Noise Scale, Fill Noise Scale, Fill Threshold |
| `truchet` | Arc Count, Columns, Rows, Seed, Arc Ratio |
| `butterfly` | Arc Count, Columns, Rows, Row Offset, Arc Ratio |
| `iso-cross` | Resolution, Gap |
| `scattered-cubes` | Grid Dimension, Gap, Layers, Noise Scale, Seed, Displacement |
| `iso-sphere` | Dimension, Gap |

The remaining gallery patterns at 1s and the Flow studies at 8s in the supplied
film are included. These 14 additions are static vector studies. Streamlines
use a spatial index with at most 450 paths and 60,000 integration steps; very
dense fields stop at that budget. Voxel surfaces cull interior faces and group
visible faces by depth, including the sphere's dimension range 3–40. Filled
motifs use their own thickness/size controls rather than an inert stroke knob.
The library list supports search, and each selection resets its own controls.


Control names/ranges were checked against the filmed controls and public
[Book of Shapes](https://bookofshapes.com/) UI on November 6, 2026, including
[Joy Division](https://bookofshapes.com/patterns/joy_division),
[Cube Helix](https://bookofshapes.com/patterns/dna_helix), and
[Concentric Noise Rings](https://bookofshapes.com/patterns/concentric_noise_rings).
The original site's source, SVG data and fonts are not bundled. The algorithms
are independently authored mathematical recreations; no pixel-exact claim is made.

React DOM >=18.2; SSR-safe SVG, no WebGL, Canvas, textures or renderer peers.
`buildShapePattern` and `createShapePatternSvg` use the component's exact marks.
Geometry uses a 1000-square viewBox; a nonsquare host/export letterboxes. Ring
radius controls use the reference's half-size coordinates (multiply by two for
artwork coordinates). Counts are rounded up at geometry generation, preserving
fractional slider readouts. Zero counts produce empty artwork. The maximum
individual cube grid is 100×100; its faces/edges are aggregated into two SVG
paths to avoid tens of thousands of DOM nodes. A frame has at most 224 edge cubes;
the helix at most 500 cubes. Letters use a seeded variable-size tile packing and
editable Georgia/serif text, not outlined glyphs; font metrics can vary by machine.

Existing generic `count`, `amplitude`, `frequency`, `size`, `innerRadius` and
`outerRadius` inputs remain accepted as aliases where applicable; explicit
`parameters` take precedence. Existing version-1 links remain readable. New
exports show canonical per-shape parameters rather than conflicting aliases.
`seed` and `text` remain top-level controls. Colors accept #RGB/#RRGGBB;
`strokeWidth` (.25–5) and `rotation` (-180–180) remain additional print controls.
Letters retain up to 12 printable characters. Radius ordering is normalized.

Static by default. `animated`, `speed` (0–3, default .5), `paused`, and explicit
`time` (0–3600 seconds) retain their contracts. Motion is available for waves,
rings, dots, arcs and helix; quarters, letters, individual cubes and cube frames
stay still. Core owns provider pause, reduced motion, offscreen and hidden-tab
suspension. Clock phase repeats smoothly every 20π seconds. Explicit `time`
disables autoplay and selects a static frame even under reduced motion. SVG
exports escape text and retain editable geometry without scripts or linked media.
Labels name accessible artwork; empty/omitted labels are decorative. Import into
other editors depends on their SVG/font support.
