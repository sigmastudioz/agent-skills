import type { ResolvedFoilConfig } from './types.js';
interface Link {
    a: number;
    b: number;
    length: number;
    bend: boolean;
}
export interface FoilGrab {
    index: number;
    x: number;
    y: number;
    z: number;
    startX: number;
    startY: number;
}
export interface FoilMesh {
    positions: Float32Array;
    previous: Float32Array;
    rest: Float32Array;
    uv: Float32Array;
    indices: Uint16Array;
    links: Link[];
    seam: [number, number][];
    progress: number;
    autoTear: boolean;
    tearTime: number;
    tearFromRight: boolean;
    peel: number;
    turn: number;
    targetTurn: number;
    grab: FoilGrab | null;
    time: number;
    accumulator: number;
}
/** Two connected grids with duplicate seam vertices: no triangles bridge a broken seam. */
export declare function createFoilMesh(config: ResolvedFoilConfig): FoilMesh;
export declare function resetFoilMesh(mesh: FoilMesh): void;
/** Progress is monotonic until reset, and snaps to physical seam connections. */
export declare function tearFoilMesh(mesh: FoilMesh, progress: number): void;
export declare function pickFoilVertex(mesh: FoilMesh, x: number, y: number, radius?: number): number;
/** Fixed steps make stiffness and tear speed independent of the display refresh rate. */
export declare function stepFoilMesh(mesh: FoilMesh, config: ResolvedFoilConfig, seconds: number): void;
/** A readable, motionless pose; a detached stub is outside the stage. */
export declare function settleFoilMesh(mesh: FoilMesh): void;
export {};
