import { type ComponentType } from 'react';
import type { BallPitProps } from './BallPit.js';
/** Rapier is loaded with this runtime so importing `<BallPit>` does not evaluate the peer. */
export declare function loadBallPitRuntime(): Promise<ComponentType<BallPitProps>>;
