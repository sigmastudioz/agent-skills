import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import type { FoilMesh } from './foilPhysics.js';
import type { FoilArtwork, ResolvedFoilConfig } from './types.js';
export interface FoilRenderer extends WebGLRendererLike {
    load(artwork: FoilArtwork, ready: (error?: string) => void): () => void;
    render(mesh: FoilMesh, config: ResolvedFoilConfig): void;
}
/** Owned mesh pass; no Three/Fiber dependency and no full-screen shader abstraction. */
export declare function createFoilRenderer(canvas: HTMLCanvasElement): FoilRenderer | null;
