export { TextPortrait } from './TextPortrait.js';
export type { TextPortraitProps } from './types.js';
