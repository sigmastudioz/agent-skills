/// <reference types="react" />
import type { ImageWarpProps } from './types.js';
/** Localized smooth twist and directional image displacement. Distinct from the /warp starfield. */
export declare function ImageWarp(props: ImageWarpProps): JSX.Element;
