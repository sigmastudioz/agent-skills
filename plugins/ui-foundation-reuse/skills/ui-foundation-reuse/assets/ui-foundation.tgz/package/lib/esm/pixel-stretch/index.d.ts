export { PixelStretch } from './PixelStretch.js';
export type { PixelStretchProps } from './types.js';
