import { type CSSProperties, type ReactNode } from 'react';
export interface ChromaKeyOverlayProps {
    image: HTMLImageElement | null;
    children?: ReactNode;
    /** Alpha uses a precomputed transparent mask with no CPU pixel processing. */
    channel?: 'blue' | 'green' | 'alpha';
    threshold?: number;
    softness?: number;
    /** Low resolution bounds CPU/readback work. Default 240. */
    sampleWidth?: number;
    className?: string;
    style?: CSSProperties;
    onError?: () => void;
}
/** Decorative lines/shapes remain over the keyed background and disappear over foreground figures.
 * Match the media layer's center-cover framing. CORS/readback failure hides the decoration.
 */
export declare function ChromaKeyOverlay({ image, children, channel, threshold, softness, sampleWidth, className, style, onError }: ChromaKeyOverlayProps): JSX.Element;
