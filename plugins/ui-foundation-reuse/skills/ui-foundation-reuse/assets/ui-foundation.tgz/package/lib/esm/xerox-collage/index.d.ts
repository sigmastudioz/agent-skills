export { XeroxCollage } from './XeroxCollage.js';
export { XEROX_COLLAGE_PRESETS } from './presets.js';
export type { XeroxCollagePreset, XeroxCollageProps } from './types.js';
