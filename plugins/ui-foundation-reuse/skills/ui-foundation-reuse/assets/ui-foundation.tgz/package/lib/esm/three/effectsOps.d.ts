import type { StageEffectProps } from './stagingOps.js';
export interface AmbientOcclusionOptions {
    /** How far, in scene units, a surface looks for nearby geometry, 0.02–5. Default 0.4. */
    radius?: number;
    /** Strength of the darkening, 0–2. Default 1. */
    intensity?: number;
}
export interface DepthOfFieldOptions {
    /** Distance from the camera that is sharp, in scene units, 0.01–1000. Default 5. */
    focus?: number;
    /** Blur gained per scene unit away from `focus`, as a fraction of the frame, 0–0.1. Default 0.004. */
    aperture?: number;
    /** Largest blur, as a fraction of the frame, 0–0.05. Default 0.012. */
    maxBlur?: number;
}
export interface BloomOptions {
    strength?: number;
    radius?: number;
    /** Linear HDR luminance threshold; values above 1 isolate emissive objects. */
    threshold?: number;
}
/** Camera and lens finishing drawn after the scene. See `PostEffects`. */
export interface PostEffectsProps extends StageEffectProps {
    /** Soft darkening where surfaces meet (creases, contact). `true` for defaults. */
    ambientOcclusion?: boolean | AmbientOcclusionOptions;
    /** Blur away from a focus distance. `true` for defaults. */
    depthOfField?: boolean | DepthOfFieldOptions;
    /** Glow around bright light. `true` for defaults. Use this instead of a separate `Bloom`. */
    bloom?: boolean | BloomOptions;
    /** Maximum render-target side in physical pixels, 64–4096. Default 2048, so a typical canvas is not softened. */
    resolution?: number;
}
export interface PostEffectsConfig {
    enabled: boolean;
    resolution: number;
    ambientOcclusion: {
        radius: number;
        intensity: number;
    } | null;
    depthOfField: {
        focus: number;
        aperture: number;
        maxBlur: number;
    } | null;
    bloom: {
        strength: number;
        radius: number;
        threshold: number;
    } | null;
}
export declare function resolvePostEffectsConfig(props?: PostEffectsProps): PostEffectsConfig;
/** Which passes exist. A change here rebuilds the chain; anything else only updates values. */
export declare function postEffectsShape(config: PostEffectsConfig): string;
/** True when the chain would draw the scene unchanged. */
export declare function postEffectsIdle(config: PostEffectsConfig): boolean;
