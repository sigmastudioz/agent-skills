import { type CausticsConfig } from './causticsOps.js';
/** Owns GPU resources, borrows caster geometry, and never changes the host scene's materials. */
export declare function createCausticsPass(three: any, initial: CausticsConfig, casterRef: {
    current: any;
}): {
    surface: any;
    configure: (next: CausticsConfig) => void;
    dispose: () => void;
};
