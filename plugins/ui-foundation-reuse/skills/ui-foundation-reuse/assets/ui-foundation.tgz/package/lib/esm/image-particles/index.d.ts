export { ImageParticles } from './ImageParticles.js';
export { resolveImageParticlesConfig, buildParticleField, particleState, MAX_IMAGE_PARTICLES } from './particleOps.js';
export type { ImageParticleMode, ImageParticlesProps, ImageParticlesConfig, ParticleField, ParticleInput } from './types.js';
