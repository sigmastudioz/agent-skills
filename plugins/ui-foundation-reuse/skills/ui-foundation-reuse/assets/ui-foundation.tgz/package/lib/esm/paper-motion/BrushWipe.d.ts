/// <reference types="react" />
import type { BrushWipeProps } from './types.js';
/** Decorative only. The host owns the scene switch and semantic visibility. */
export declare function BrushWipe({ progress, direction, seed, roughness, color, className, style }: BrushWipeProps): JSX.Element;
