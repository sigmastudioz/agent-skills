import type { FluidConfig, FluidFieldProps, FluidPreset } from './types.js';
export declare const FLUID_PRESETS: Record<FluidPreset, {
    color: string;
    accentColor: string;
}>;
export declare function resolveFluidConfig(props?: FluidFieldProps): FluidConfig;
export declare function fluidRgb(hex: string): [number, number, number];
export declare function simulationSize(width: number, height: number, limit: number): [number, number];
