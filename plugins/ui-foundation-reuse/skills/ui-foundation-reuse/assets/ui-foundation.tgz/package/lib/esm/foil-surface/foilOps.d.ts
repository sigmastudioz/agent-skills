import type { FoilSurfaceProps, ResolvedFoilConfig } from './types.js';
export declare function resolveFoilConfig(props: Partial<FoilSurfaceProps>): ResolvedFoilConfig;
/** Vertical field of view in sheet units; preserves margins in narrow containers. */
export declare function foilViewHeight(width: number, height: number, ratio: number): number;
/** Projection shared by drawing and pointer picking. Input UVs remain attached to the mesh. */
export declare function projectFoilPoint(x: number, y: number, z: number, turn: number): [number, number, number];
