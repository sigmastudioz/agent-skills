import type { CymaticsConfig } from './types.js';
export interface CymaticsParticles {
    positions: Float32Array;
    velocity: Float32Array;
    grain: Float32Array;
    random: number;
}
export declare function createCymaticsParticles(count: number, seed: number, circle: boolean): CymaticsParticles;
/** Overdamped grain transport toward low-displacement regions of the modal field. */
export declare function stepCymaticsParticles(particles: CymaticsParticles, field: Float32Array, gradient: Float32Array, config: CymaticsConfig, amplitude: number, delta: number): void;
