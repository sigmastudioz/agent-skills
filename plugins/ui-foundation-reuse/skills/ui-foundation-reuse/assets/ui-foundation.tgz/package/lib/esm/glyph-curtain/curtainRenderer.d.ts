import type { CurtainField } from './curtainOps.js';
/** Glyphs rasterize once per text/font/size change; animation only blits the atlas. */
export declare function createCurtainRenderer(canvas: HTMLCanvasElement, text: string, width: number, height: number, dpr: number, fontSize: number, fontFamily: string, color: string, direction: 'ltr' | 'rtl'): ((field: CurtainField) => void) | null;
