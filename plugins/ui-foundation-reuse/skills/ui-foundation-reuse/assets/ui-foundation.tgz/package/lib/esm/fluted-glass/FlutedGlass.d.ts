/// <reference types="react" />
import type { FlutedGlassProps } from './types.js';
/** Static image refraction. Draws only for loading, resize and changed controls. */
export declare function FlutedGlass(props: FlutedGlassProps): JSX.Element;
