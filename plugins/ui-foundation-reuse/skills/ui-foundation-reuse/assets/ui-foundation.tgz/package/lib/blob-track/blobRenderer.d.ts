import type { TrackedBlob } from './types.js';
type Drawable = HTMLImageElement | HTMLVideoElement;
/** Cover-crop the current frame into a columns × rows grid. Throws SecurityError on tainted media. */
export declare function sampleFrame(context: CanvasRenderingContext2D, media: Drawable, columns: number, rows: number, frameWidth: number, frameHeight: number): Uint8ClampedArray | null;
export interface HudStyle {
    color: string;
    labels: boolean;
    crosshair: boolean;
    links: boolean;
}
/** Bracketed boxes, crosshairs, labels and links, in CSS pixels. */
export declare function drawHud(context: CanvasRenderingContext2D, blobs: readonly TrackedBlob[], width: number, height: number, style: HudStyle): void;
export {};
