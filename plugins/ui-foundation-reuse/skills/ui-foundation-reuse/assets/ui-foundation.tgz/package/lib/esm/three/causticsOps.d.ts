import type { ReactNode, RefObject } from 'react';
import type { FloorTransform, StageEffectProps } from './stagingOps.js';
export interface CausticsProps extends StageEffectProps, FloorTransform {
    /** Closed, non-overlapping ordinary meshes. Their geometry and rigid transforms drive the pattern. */
    children?: ReactNode;
    size?: [number, number];
    /** World-space position of a directional beam aimed at the wrapped geometry. */
    lightSource?: [number, number, number];
    /** Share this value with GlassMaterial. Material properties are not inferred. */
    ior?: number;
    intensity?: number;
    color?: string;
    /** Opaque built-in floor by default. null adds light over an existing floor. */
    floorColor?: string | null;
    /** Photon grid side, 32–256 (squared to obtain the photon count). */
    samples?: number;
    /** Receiving texture side in physical pixels, 128–1024. */
    resolution?: number;
    /** Photon footprint in texture pixels, 1–8. */
    softness?: number;
}
export interface CausticsRuntimeProps extends CausticsProps {
    casterRef: RefObject<any>;
}
export declare function resolveCausticsConfig(props?: CausticsProps): {
    enabled: boolean;
    position: [number, number, number];
    rotation: [number, number, number];
    size: [number, number];
    lightSource: [number, number, number];
    ior: number;
    intensity: number;
    color: string;
    floorColor: string | null;
    samples: number;
    resolution: number;
    softness: number;
};
export type CausticsConfig = ReturnType<typeof resolveCausticsConfig>;
/** Centered stratified samples: the GPU reads the light-space surface at each UV. */
export declare function causticPhotonGrid(side: number): Float32Array;
/** Normalize splat energy against beam area, receiver area, grid density and footprint. */
export declare function causticPhotonPower(beamArea: number, receiverArea: number, config: CausticsConfig): number;
