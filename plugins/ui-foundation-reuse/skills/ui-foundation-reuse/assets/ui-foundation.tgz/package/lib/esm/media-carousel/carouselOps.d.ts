export declare function resolveCarouselWindow(length: number, index: number, visibleCount?: number): {
    count: number;
    maximum: number;
    start: number;
    end: number;
};
