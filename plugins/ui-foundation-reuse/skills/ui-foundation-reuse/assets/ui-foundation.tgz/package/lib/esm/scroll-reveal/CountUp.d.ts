import { type CSSProperties } from 'react';
import { type RevealTriggerOptions } from './useRevealTrigger.js';
export interface CountUpProps extends Omit<RevealTriggerOptions, 'once'> {
    /** Final value. */
    to: number;
    /** Starting value. Default 0. */
    from?: number;
    /** Count length in ms. Default 1600. */
    duration?: number;
    /** Wait after entering view, ms. Default 0. */
    delay?: number;
    /** Fixed fraction digits. Default 0. */
    decimals?: number;
    /** BCP 47 locale for grouping/decimal marks. Default the runtime locale. */
    locale?: string;
    /** Extra Intl.NumberFormat options (currency, percent, compact…). */
    format?: Intl.NumberFormatOptions;
    prefix?: string;
    suffix?: string;
    as?: 'span' | 'p' | 'div' | 'strong' | 'dd';
    className?: string;
    style?: CSSProperties;
    onComplete?: () => void;
}
/**
 * Counts a number up once in view (ease-out). The final value renders on the
 * server, under reduced motion and without IntersectionObserver, and is what
 * screen readers read; the ticking digits are aria-hidden and tabular.
 */
export declare function CountUp({ to, from, duration, delay, decimals, locale, format, prefix, suffix, as, threshold, rootMargin, className, style, onComplete, }: CountUpProps): JSX.Element;
