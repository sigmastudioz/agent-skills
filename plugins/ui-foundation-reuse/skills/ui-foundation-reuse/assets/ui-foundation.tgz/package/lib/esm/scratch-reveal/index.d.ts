export { ScratchReveal } from './ScratchReveal.js';
export type { ScratchRevealHandle, ScratchRevealProps } from './types.js';
