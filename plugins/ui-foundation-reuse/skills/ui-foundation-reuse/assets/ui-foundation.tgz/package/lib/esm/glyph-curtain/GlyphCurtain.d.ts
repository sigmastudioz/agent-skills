/// <reference types="react" />
import type { GlyphCurtainHandle, GlyphCurtainProps } from './types.js';
/** Original pinned-strand glyph physics. No font assets, audio, WebGL or page layout. */
export declare const GlyphCurtain: import("react").ForwardRefExoticComponent<GlyphCurtainProps & import("react").RefAttributes<GlyphCurtainHandle>>;
