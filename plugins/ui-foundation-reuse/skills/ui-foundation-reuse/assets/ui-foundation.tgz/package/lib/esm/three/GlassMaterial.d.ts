/// <reference types="react" />
import { type GlassMaterialProps } from './glassOps.js';
/** Native physical transmission: attach to a mesh inside Scene/World or a consumer Canvas. */
export declare const GlassMaterial: import("react").ForwardRefExoticComponent<GlassMaterialProps & import("react").RefAttributes<any>>;
