import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import type { ResolvedIridescenceConfig } from './types.js';
export interface IridescenceRenderer extends WebGLRendererLike {
    render(config: ResolvedIridescenceConfig, time: number, pointer: [number, number]): void;
}
export declare function createIridescenceRenderer(canvas: HTMLCanvasElement): IridescenceRenderer | null;
