/// <reference types="react" />
import type { DitherProps } from './types.js';
/** 1-bit and few-tone dithering. Bayer runs on the shared WebGL image-filter pass;
 * Floyd–Steinberg and Atkinson diffuse error on the CPU. Both are static. */
export declare function Dither(props: DitherProps): JSX.Element;
