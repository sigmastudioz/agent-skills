/// <reference types="react" />
import type { BloomProps } from './stagingOps.js';
/** One root-level Bloom per Canvas; processes the complete visible scene, including portals. */
export declare function Bloom(props: BloomProps): JSX.Element;
