import type { GrayScottPreset, GrayScottState, PhysarumState } from './types.js';
export declare const GRAY_SCOTT_PRESETS: Readonly<Record<GrayScottPreset, readonly [number, number]>>;
/** Small deterministic PRNG (mulberry32), so the same seed grows the same first frames. */
export declare function seededRandom(seed: number): () => number;
/** u = 1 everywhere, v seeded in a few square patches. */
export declare function createGrayScott(size: number, seed: number): GrayScottState;
/** Drop a square of v (pointer seeding). Coordinates wrap. */
export declare function seedGrayScott(state: GrayScottState, x: number, y: number, half: number): void;
/** Gray–Scott on a torus: Du = 1, Dv = .5, dt = 1, 3×3 Laplacian (.2 edges, .05 corners). */
export declare function stepGrayScott(state: GrayScottState, feed: number, kill: number, iterations?: number): GrayScottState;
export interface PhysarumParams {
    sensorAngle: number;
    sensorDistance: number;
    turn: number;
    step: number;
    deposit: number;
    decay: number;
}
export declare const PHYSARUM_DEFAULTS: PhysarumParams;
export declare function createPhysarum(size: number, count: number, seed: number): PhysarumState;
/** Sense → turn toward the strongest trail → move → deposit; then 3×3 blur and decay. */
export declare function stepPhysarum(state: PhysarumState, params?: PhysarumParams): PhysarumState;
/** Field in [0,1] → RGBA between two hex colors, written into `out`. */
export declare function shadeField(field: Float32Array, from: string, to: string, out: Uint8ClampedArray, gain?: number): void;
