/**
 * Raw device angles turned into screen-space tilt: x is left/right, y is towards/away,
 * independent of how the phone is rotated. `beta` (front-back) and `gamma` (left-right) are
 * the DeviceOrientationEvent angles in degrees; `screenAngle` is screen.orientation.angle.
 */
export declare function screenTilt(beta: number, gamma: number, screenAngle: number): [number, number];
/**
 * Tilt relative to a neutral pose, scaled so `range` degrees reaches ±1. Clamped to [-1, 1].
 */
export declare function normalizeTilt(angles: readonly [number, number], neutral: readonly [number, number], range: number): [number, number];
/** Pointer position in the viewport mapped to [-1, 1] on both axes (centre is 0). */
export declare function pointerTilt(clientX: number, clientY: number, width: number, height: number): [number, number];
export type TiltPermission = 'granted' | 'denied' | 'prompt' | 'unsupported';
/** What this browser needs before orientation events arrive. Safe on the server. */
export declare function tiltPermissionState(): TiltPermission;
