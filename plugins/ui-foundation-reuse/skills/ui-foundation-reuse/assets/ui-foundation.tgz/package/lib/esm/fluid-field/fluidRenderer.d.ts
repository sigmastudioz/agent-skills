import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import type { InteractionState } from '../core/interaction.js';
import type { FluidConfig } from './types.js';
export interface FluidRenderer extends WebGLRendererLike {
    render(config: FluidConfig, time: number, input: InteractionState, interactive: boolean): void;
}
export declare function createFluidRenderer(canvas: HTMLCanvasElement, limit: number): FluidRenderer | null;
