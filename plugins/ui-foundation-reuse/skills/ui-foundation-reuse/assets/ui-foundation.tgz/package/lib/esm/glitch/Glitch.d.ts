/// <reference types="react" />
import type { GlitchProps } from './types.js';
/** Seeded still-image glitch on the shared image-filter pass. Motion is a pure function
 * of the gated lifecycle phase; zero amount stops the loop and shows the original. */
export declare function Glitch({ kind, intensity, trigger, interval, progress, seed, speed, offset, paused, className, style, ...rest }: GlitchProps): JSX.Element;
