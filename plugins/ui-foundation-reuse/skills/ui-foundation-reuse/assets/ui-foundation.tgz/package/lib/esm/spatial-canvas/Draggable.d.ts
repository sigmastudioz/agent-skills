import { type CSSProperties, type ReactNode } from 'react';
export interface DraggableProps {
    children: ReactNode;
    /** A descendant marked data-drag-handle starts dragging and accepts arrow keys. */
    label?: string;
    initialPosition?: {
        x: number;
        y: number;
    };
    onPositionChange?: (position: {
        x: number;
        y: number;
    }) => void;
    className?: string;
    style?: CSSProperties;
}
/** Movable DOM content, constrained to its positioned parent. No window UI is imposed. */
export declare function Draggable({ children, initialPosition, onPositionChange, label, className, style }: DraggableProps): import("react").JSX.Element;
