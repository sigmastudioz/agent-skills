import type { FieldPoint, GeometricScene, MotionProgram, ResolvedGeometricConfig } from './types.js';
interface Circle {
    x: number;
    y: number;
    r: number;
}
/** Unique Delaunay edges for a point set in any 2D space. Fewer than 3 points yield none. */
export declare function delaunayEdges(points: Array<{
    x: number;
    y: number;
}>): Array<[number, number]>;
export declare function linkPoints(points: FieldPoint[], mode: ResolvedGeometricConfig['link'], maxDistance: number): Array<{
    a: number;
    b: number;
    confidence: number;
}>;
/** Two-circle crossings. Empty when the circles miss or one contains the other. */
export declare function circleIntersections(a: Circle, b: Circle): Array<{
    x: number;
    y: number;
}>;
/** Keep `angle`, or flip it, so the ray points into the emptier half-plane. */
export declare function openDirection(points: FieldPoint[], origin: FieldPoint, angle: number): number;
export declare function circleChain(points: FieldPoint[], count: number, baseRadius: number, ratio: number): {
    circles: Circle[];
    crossings: Array<{
        x: number;
        y: number;
    }>;
};
export declare function motionPoint(point: FieldPoint, index: number, time: number, program: MotionProgram): FieldPoint & {
    scale: number;
    reveal: number;
};
export declare function buildGeometricScene(lum: Float32Array, width: number, height: number, config: Pick<ResolvedGeometricConfig, 'density' | 'threshold' | 'link' | 'shapes' | 'motion' | 'seed' | 'maxDistance' | 'showLinks' | 'showShapes' | 'showChain'>, time: number, pointer: {
    x: number;
    y: number;
    strength: number;
}): GeometricScene;
export {};
