/// <reference types="react" />
import type { CursorVideoProps } from './types.js';
/** Pointer, touch or keyboard scrubs a silent film; idle has no RAF work. */
export declare function CursorVideo(props: CursorVideoProps): JSX.Element;
