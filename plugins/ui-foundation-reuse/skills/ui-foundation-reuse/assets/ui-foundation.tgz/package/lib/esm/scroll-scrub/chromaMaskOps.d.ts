/** Retain dominant blue/green background pixels; neutral/foreground pixels become transparent. */
export declare function maskChromaPixels(pixels: Uint8ClampedArray, channel: 'blue' | 'green', threshold?: number, softness?: number): void;
