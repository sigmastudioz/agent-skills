/** Recipes are plain data, frozen recursively without importing React or a renderer. */
export declare function freezeRecipe<T>(value: T): T;
