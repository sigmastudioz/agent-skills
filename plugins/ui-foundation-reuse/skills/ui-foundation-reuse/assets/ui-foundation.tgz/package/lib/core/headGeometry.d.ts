/** Stylized procedural head surface shared by neural and particle artwork. Not anatomical data. */
type Vec3 = readonly [number, number, number];
export declare function headPoint(t: number, angle: number): Vec3;
export {};
