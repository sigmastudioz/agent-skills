import type { BloomConfig } from './stagingOps.js';
/** A single root composer; Three's peer supplies the HDR bloom and output conversion passes. */
export declare function createBloomPass(three: any, addons: any, renderer: any, scene: any, camera: any, initial: BloomConfig): {
    configure: (next: BloomConfig) => void;
    dispose: () => void;
    render(nextScene?: any, nextCamera?: any, delta?: number): void;
};
