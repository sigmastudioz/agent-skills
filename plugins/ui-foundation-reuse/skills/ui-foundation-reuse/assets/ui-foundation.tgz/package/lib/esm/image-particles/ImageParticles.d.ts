/// <reference types="react" />
import type { ImageParticlesProps } from './types.js';
/** Still image → Canvas2D particle field. Frames bypass React; with no ambient motion,
 * audio, trails, pointer or autoplay remaining, no RAF runs. */
export declare function ImageParticles({ src, alt, depthSrc, progress, paused, crossOrigin, audioSource, onComplete, onError, className, style, ...options }: ImageParticlesProps): JSX.Element;
