/// <reference types="react" />
import type { CausticsProps } from './causticsOps.js';
/** Two-interface refraction splats light onto a receiver. Children survive loading and GPU failure. */
export declare function Caustics(props: CausticsProps): JSX.Element;
