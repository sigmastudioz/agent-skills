/** Center-crop UV scale matching object-fit: cover. */
export declare function coverScale(imageWidth: number, imageHeight: number, width: number, height: number): [number, number];
