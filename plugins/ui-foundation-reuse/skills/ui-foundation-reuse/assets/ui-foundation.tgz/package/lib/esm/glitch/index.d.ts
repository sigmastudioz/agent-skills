export { Glitch } from './Glitch.js';
export { glitchAmount, scrollGlitchEnvelope } from './glitchOps.js';
export type { GlitchKind, GlitchProps, GlitchTrigger, GlitchSignal } from './types.js';
