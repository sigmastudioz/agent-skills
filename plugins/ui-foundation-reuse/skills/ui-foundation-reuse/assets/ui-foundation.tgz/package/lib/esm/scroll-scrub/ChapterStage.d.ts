import { type CSSProperties, type ReactNode } from 'react';
import { type ScrollChapter, type ScrollChapterState } from './timelineOps.js';
export interface ChapterStageProps {
    progress: number;
    chapters: readonly ScrollChapter[];
    /** The same presented progress drives artwork, copy and counters. */
    children: (chapter: ScrollChapterState, presentedProgress: number) => ReactNode;
    smoothingMs?: number;
    label?: string;
    className?: string;
    style?: CSSProperties;
}
/** Settling, offscreen-aware director. Media renderers remain the caller's choice. */
export declare function ChapterStage({ progress, chapters, children, smoothingMs, label, className, style }: ChapterStageProps): JSX.Element;
