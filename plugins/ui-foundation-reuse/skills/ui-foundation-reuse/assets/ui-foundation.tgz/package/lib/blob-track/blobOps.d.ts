import type { BlobTrackSignal, TrackedBlob } from './types.js';
export type Region = Omit<TrackedBlob, 'id'>;
/** RGBA pixels → per-cell signal in [0,1]: luminance, or its inverse for darkness. */
export declare function signalField(pixels: Uint8ClampedArray, signal: Exclude<BlobTrackSignal, 'motion'>): Float32Array;
/** Absolute per-cell change between two luminance fields of equal size. */
export declare function motionField(previous: Float32Array, current: Float32Array): Float32Array;
/** 3×3 box blur (edges clamp). Joins speckled cells into regions before thresholding. */
export declare function smoothField(field: Float32Array, columns: number, rows: number): Float32Array;
/** Motion energy that decays instead of vanishing between changes: max(change, previous × decay). */
export declare function accumulateMotion(energy: Float32Array | null, change: Float32Array, decay?: number): Float32Array;
/** 4-connected regions where field ≥ threshold, largest first, normalized to the grid. */
export declare function findBlobs(field: Float32Array, columns: number, rows: number, threshold: number, minArea: number, maxBlobs: number): Region[];
/** Greedy nearest-center matching keeps IDs stable; unmatched regions get fresh IDs. */
export declare function matchBlobs(previous: readonly TrackedBlob[], regions: readonly Region[], nextId: number, maxDistance?: number): {
    blobs: TrackedBlob[];
    nextId: number;
};
/** Same IDs and boxes (to grid precision) → no callback or redraw needed. */
export declare function sameBlobs(a: readonly TrackedBlob[], b: readonly TrackedBlob[]): boolean;
