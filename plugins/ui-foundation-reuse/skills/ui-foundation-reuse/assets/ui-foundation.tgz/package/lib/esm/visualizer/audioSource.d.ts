import { type VisualizerAudioSource } from './audioOps.js';
/** Wrap an existing analyser. Its context, connections and audio playback remain caller-owned. */
export declare function createAudioAnalyser(analyser: AnalyserNode): VisualizerAudioSource;
