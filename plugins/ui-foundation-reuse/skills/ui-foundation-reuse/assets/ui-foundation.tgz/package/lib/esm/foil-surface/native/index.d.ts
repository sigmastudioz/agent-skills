export { FoilSurface } from './FoilSurface.js';
export type { NativeFoilSurfaceProps, NativeFoilSurfaceProps as FoilSurfaceProps } from './types.js';
