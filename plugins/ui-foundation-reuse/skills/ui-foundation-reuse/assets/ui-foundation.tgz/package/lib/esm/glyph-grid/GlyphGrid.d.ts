/// <reference types="react" />
import type { GlyphGridProps } from './types.js';
/** Luminance-indexed glyphs using the shared, font-independent byte atlas. */
export declare function GlyphGrid({ preset, ...props }: GlyphGridProps): JSX.Element;
