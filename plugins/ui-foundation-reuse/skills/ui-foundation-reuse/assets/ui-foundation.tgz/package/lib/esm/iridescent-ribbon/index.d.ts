export { IridescentRibbon } from './IridescentRibbon.js';
export { resolveIridescentRibbonConfig } from './ribbonOps.js';
export type { IridescentRibbonProps, IridescentRibbonConfig } from './types.js';
