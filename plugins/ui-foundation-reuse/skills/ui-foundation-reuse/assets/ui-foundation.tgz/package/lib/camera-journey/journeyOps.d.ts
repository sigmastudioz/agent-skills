import type { CameraJourney, CameraJourneyOptions, CameraJourneyPose, JourneyCamera } from './types.js';
export declare function createCameraJourney({ waypoints, durationMs, pacing }: CameraJourneyOptions): CameraJourney;
export declare function applyCameraJourneyPose(camera: JourneyCamera, pose: CameraJourneyPose): void;
/** Autoplay clock. Controlled scroll progress remains independent of speed. */
export declare function advanceCameraJourney(progress: number, deltaMs: number, durationMs: number, speed?: number): number;
