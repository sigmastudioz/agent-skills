import { type PointerEvent, type FocusEvent } from 'react';
export interface InteractionState {
    x: number;
    y: number;
    pressure: number;
    active: boolean;
    pressed: boolean;
    focused: boolean;
    revision: number;
}
/** Mutable input shared by effects without React renders. Coordinates are -1..1, Y points up. */
export interface InteractionSignal {
    current: InteractionState;
}
export declare function createInteractionSignal(): InteractionSignal;
export declare function normalizePointer(x: number, y: number, width: number, height: number): [number, number];
/** Spread handlers on a stable interaction surface; pass the signal to multiple effects. */
export declare function useInteraction(external?: InteractionSignal): {
    signal: InteractionSignal;
    handlers: {
        onPointerMove: (event: PointerEvent<HTMLElement>) => void;
        onPointerDown: (event: PointerEvent<HTMLElement>) => void;
        onPointerUp: (event: PointerEvent<HTMLElement>) => void;
        onPointerLeave: () => void;
        onPointerCancel: () => void;
        onFocusCapture: () => void;
        onBlurCapture: (event: FocusEvent<HTMLElement>) => void;
    };
};
