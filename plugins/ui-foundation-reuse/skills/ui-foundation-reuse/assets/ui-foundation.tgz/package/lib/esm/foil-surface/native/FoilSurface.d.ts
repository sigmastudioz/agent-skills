/// <reference types="react" />
import type { NativeFoilSurfaceProps } from './types.js';
/** Finger-driven perspective + transparent spectral foil; children always remain visible. */
export declare function FoilSurface({ children, width, height, alt, style, borderRadius, intensity, iridescence, hue, interactive, visible, paused, resetKey, testID, renderFoil, onError }: NativeFoilSurfaceProps): import("react").JSX.Element;
