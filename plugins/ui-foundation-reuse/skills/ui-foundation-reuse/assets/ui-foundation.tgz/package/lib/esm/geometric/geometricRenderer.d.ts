import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import type { ResolvedGeometricConfig } from './types.js';
export interface GeometricSource {
    image: HTMLCanvasElement | null;
    pixels: Uint8Array | null;
    width: number;
    height: number;
}
export interface GeometricRenderer extends WebGLRendererLike {
    render(config: ResolvedGeometricConfig, time: number, pointer: [number, number], pull: number, source: GeometricSource): void;
}
export declare function createGeometricRenderer(canvas: HTMLCanvasElement): GeometricRenderer | null;
