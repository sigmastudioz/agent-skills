import type { TrailPoint } from './types.js';
/** Frame-rate independent chain: the head chases the pointer, each blob chases the one ahead.
 * `follow` is the fraction closed per 60 Hz frame. */
export declare function stepTrail(points: readonly TrailPoint[], target: TrailPoint, follow: number, deltaMs: number): TrailPoint[];
/** True once every blob is within `epsilon` CSS pixels of the target; the loop may sleep. */
export declare function trailSettled(points: readonly TrailPoint[], target: TrailPoint, epsilon?: number): boolean;
/** Head first, tapering to ~35% of the head so the tail reads as a droplet. */
export declare function trailRadii(count: number, radius: number): number[];
/** Eases the reveal scale toward 1 while hovering and 0 after leaving. */
export declare function stepPresence(scale: number, active: boolean, deltaMs: number): number;
/** feColorMatrix values: keep color, sharpen the blurred alpha into a hard gooey edge. */
export declare const GOO_MATRIX = "1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -10";
