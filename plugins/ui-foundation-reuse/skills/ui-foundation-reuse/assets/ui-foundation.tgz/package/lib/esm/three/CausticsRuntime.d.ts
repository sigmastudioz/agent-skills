/// <reference types="react" />
import { type CausticsRuntimeProps } from './causticsOps.js';
export declare function createCausticsRuntime({ fiber, three }: any): (props: CausticsRuntimeProps) => JSX.Element;
