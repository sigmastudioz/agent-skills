import * as React from 'react';
import type { FrostedBlurProps } from './types.js';
export declare function FrostedBlur({ children, style, intensity, testID, scheme, surfaceColor, fallbackColor, nativeAvailable, blurComponent: Blur }: FrostedBlurProps): React.JSX.Element;
