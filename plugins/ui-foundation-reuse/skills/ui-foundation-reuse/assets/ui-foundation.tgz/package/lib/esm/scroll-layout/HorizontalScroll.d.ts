import { type CSSProperties, type ReactNode } from 'react';
export interface HorizontalScrollProps {
    children?: ReactNode;
    /** Gap between items, CSS px. Default 24. */
    gap?: number;
    /** Horizontal padding inside the track, CSS px. Default 24. */
    padding?: number;
    /** Accessible name for the region. Default 'Horizontal gallery'. */
    label?: string;
    className?: string;
    trackClassName?: string;
    style?: CSSProperties;
}
/**
 * Horizontal scroll section: the panel pins while vertical scrolling moves the
 * track sideways. The section height is measured so the motion ends exactly at
 * the last item. Keyboard focus scrolls the page to the focused item. Reduced
 * motion (or content narrower than the viewport) renders a native horizontal
 * scroller instead of hijacking vertical scroll.
 */
export declare function HorizontalScroll({ children, gap, padding, label, className, trackClassName, style, }: HorizontalScrollProps): JSX.Element;
