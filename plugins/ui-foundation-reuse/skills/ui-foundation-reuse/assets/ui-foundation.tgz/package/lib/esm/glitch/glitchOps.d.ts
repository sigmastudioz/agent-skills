import type { GlitchSignal, GlitchTrigger } from './types.js';
/** Viewport progress (0 entering → 1 exited) to glitch weight: full while entering,
 * easing to clean by the center so the settled image is readable. */
export declare function scrollGlitchEnvelope(progress: number): number;
/** Pure trigger → shader amount. Interval bursts are gated in the shader from phase. */
export declare function glitchAmount(trigger: GlitchTrigger, intensity: number, signal: GlitchSignal): number;
