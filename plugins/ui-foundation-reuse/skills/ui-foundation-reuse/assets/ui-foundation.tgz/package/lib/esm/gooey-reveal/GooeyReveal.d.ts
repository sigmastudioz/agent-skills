/// <reference types="react" />
import type { GooeyRevealProps } from './types.js';
/** A second image shows through a gooey blob trail that follows the pointer. SVG mask +
 * blur/alpha-threshold filter; no WebGL. The loop sleeps once the trail settles. */
export declare function GooeyReveal({ coverSrc, revealSrc, alt, revealAlt, radius, trail, follow, goo, revealed, onRevealedChange, className, style }: GooeyRevealProps): JSX.Element;
