/// <reference types="react" />
import type { DiscCarouselProps } from './types.js';
/** Bounded selection with overlapping, masked artwork and accessible controls. */
export declare function DiscCarousel({ items, index, onIndexChange, hole, duration, tilt, rotation, depth, gestures, label, className, style }: DiscCarouselProps): import("react").JSX.Element;
