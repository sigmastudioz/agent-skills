export { Posterize } from './Posterize.js';
export { POSTERIZE_PRESETS } from './presets.js';
export type { PosterizePreset, PosterizeProps } from './types.js';
