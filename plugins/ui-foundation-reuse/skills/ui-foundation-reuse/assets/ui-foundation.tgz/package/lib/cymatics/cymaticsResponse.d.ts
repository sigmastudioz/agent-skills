import { type CymaticsMode } from './cymaticsModes.js';
import type { CymaticsAudioFrame, CymaticsConfig } from './types.js';
export declare function resonanceAt(frequency: number, natural: number, q: number): number;
/** FFT → resonant mode envelopes, no allocation. A supplied silent/invalid frame stays silent. */
export declare function updateCymaticsResponse(modes: CymaticsMode[], weights: Float32Array, config: CymaticsConfig, frame: CymaticsAudioFrame | undefined, delta: number): number;
/** Four strongest modes bound the simulation cost, independent of FFT size. */
export declare function writeCymaticsField(modes: CymaticsMode[], weights: Float32Array, field: Float32Array, gradient: Float32Array): number;
