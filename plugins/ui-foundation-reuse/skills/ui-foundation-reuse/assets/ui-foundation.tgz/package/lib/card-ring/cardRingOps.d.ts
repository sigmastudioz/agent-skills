/** Angle between neighbouring cards, degrees. */
export declare function ringStep(count: number): number;
/** Cylinder radius that seats `count` cards of `cardWidth` with `gap` between their edges. */
export declare function ringRadius(count: number, cardWidth: number, gap: number): number;
/** Card facing the viewer for ring rotation `angle` (degrees, card i sits at i × step). */
export declare function frontIndex(angle: number, count: number): number;
/** How directly card `index` faces the viewer: 1 front, 0 side-on, -1 behind. */
export declare function cardFacing(index: number, angle: number, count: number): number;
/** Rotation that brings card `index` to the front with the shortest turn from `from`. */
export declare function angleForIndex(index: number, count: number, from: number): number;
/** Rest angle after a drag, biased by release velocity in degrees per second. */
export declare function snapAngle(angle: number, velocity: number, count: number): number;
/** Brightness and opacity for a card by facing; back cards stay legible as a silhouette. */
export declare function cardShade(facing: number): {
    brightness: number;
    opacity: number;
};
