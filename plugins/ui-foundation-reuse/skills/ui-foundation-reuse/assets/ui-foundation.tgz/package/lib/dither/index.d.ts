export { Dither } from './Dither.js';
export { DITHER_PRESETS } from './presets.js';
export { resolveDitherConfig, errorDiffuse } from './ditherOps.js';
export type { DitherAlgorithm, DitherPreset, DitherProps, ResolvedDitherConfig } from './types.js';
