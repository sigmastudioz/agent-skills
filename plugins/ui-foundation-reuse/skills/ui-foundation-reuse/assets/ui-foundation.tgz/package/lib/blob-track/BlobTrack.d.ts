/// <reference types="react" />
import type { BlobTrackProps } from './types.js';
/** Blob-tracking HUD over an image or a muted video. Detection runs on a small
 * cover-cropped grid; video analysis pauses off-screen, when paused, and under reduced motion. */
export declare function BlobTrack({ src, alt, media, signal, threshold, maxBlobs, minArea, resolution, color, labels, crosshair, links, crossOrigin, paused, onBlobs, onError, className, style }: BlobTrackProps): JSX.Element;
