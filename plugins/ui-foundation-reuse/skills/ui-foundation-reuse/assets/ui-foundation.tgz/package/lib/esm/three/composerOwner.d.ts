/** One post-processing chain may draw a Canvas. Throws when another already does. */
export declare function claimComposer(renderer: object, name: string): () => void;
