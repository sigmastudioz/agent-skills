import type { FloatingObject } from './types.js';
export declare function floatingTransform(item: FloatingObject, index: number, seconds: number, pointer?: {
    x: number;
    y: number;
}): string;
