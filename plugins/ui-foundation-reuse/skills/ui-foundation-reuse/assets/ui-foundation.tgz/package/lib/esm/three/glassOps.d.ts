export type GlassPreset = 'clear' | 'frosted' | 'smoked' | 'amber';
export interface GlassConfig {
    color: string;
    attenuationColor: string;
    attenuationDistance: number;
    transmission: number;
    roughness: number;
    thickness: number;
    ior: number;
    clearcoat: number;
    envMapIntensity: number;
}
export interface GlassMaterialProps extends Partial<GlassConfig> {
    preset?: GlassPreset;
}
export declare const GLASS_PRESETS: Readonly<Record<GlassPreset, Readonly<GlassConfig>>>;
/** Deliberately constrained colors keep invalid CSS out of Three's Color parser. */
export declare function surfaceColor(value: unknown, fallback: string): string;
export declare function resolveGlassConfig(props?: GlassMaterialProps): GlassConfig;
