import { type ReactNode, type RefObject } from 'react';
import { type FloatConfig } from './floatOps.js';
export interface FloatProps {
    children?: ReactNode;
    /** Radians per active second, 0 freezes time. Default 1. */
    speed?: number;
    floatIntensity?: number;
    rotationIntensity?: number;
    /** Vertical offset range in scene units. Default [-0.1, 0.1]. */
    floatingRange?: [number, number];
    /** Deterministic phase in radians; vary this between instances. Default 0. */
    phase?: number;
    paused?: boolean;
    position?: [number, number, number];
    rotation?: [number, number, number];
    scale?: number | [number, number, number];
}
export interface FloatGroup {
    position: {
        y: number;
    };
    rotation: {
        set(x: number, y: number, z: number): void;
    };
}
export interface FloatRuntimeProps {
    groupRef: RefObject<FloatGroup>;
    config: FloatConfig;
    paused: boolean;
}
/** Compose inside Scene or a consumer Canvas. The child graph stays mounted while peers load. */
export declare function Float({ children, paused, position, rotation, scale, ...motion }: FloatProps): JSX.Element;
