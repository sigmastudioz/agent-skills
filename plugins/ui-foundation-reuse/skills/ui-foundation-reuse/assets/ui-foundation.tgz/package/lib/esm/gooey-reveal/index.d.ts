export { GooeyReveal } from './GooeyReveal.js';
export { stepTrail, trailRadii, trailSettled } from './gooeyOps.js';
export type { GooeyRevealProps, TrailPoint } from './types.js';
