/// <reference types="react" />
import { type ExplodedAssemblyProps } from './assemblyOps.js';
export type { ExplodedAssemblyProps } from './assemblyOps.js';
/** Inside Scene/Canvas: stable part groups, pure poses, no peer loading or animation loop. */
export declare function ExplodedAssembly({ parts, amount, position, rotation, scale }: ExplodedAssemblyProps): import("react").JSX.Element;
