export { Iridescence } from './Iridescence.js';
export { IRIDESCENCE_PRESETS, resolveIridescenceConfig } from './presets.js';
export type { IridescenceProps, IridescencePreset, ResolvedIridescenceConfig } from './types.js';
