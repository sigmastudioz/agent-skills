/// <reference types="react" />
import type { FluidFieldProps } from './types.js';
/** Advected dye feedback over a procedural flowing material, with bounded simulation textures. */
export declare function FluidField(props?: FluidFieldProps): import("react").JSX.Element;
