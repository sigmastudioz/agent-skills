/// <reference types="react" />
import type { HeatmapProps } from './types.js';
/** Static photographic false color; redraws only when the source, size, or controls change. */
export declare function Heatmap({ preset, colorRamp, ...props }: HeatmapProps): JSX.Element;
