/// <reference types="react" />
import type { GradientProps } from './types.js';
/**
 * Animated WebGL gradient. Zero runtime dependencies.
 *
 * - SSR-safe: renders a CSS-gradient div until mounted.
 * - Accessible: freezes under `prefers-reduced-motion`; pauses off-screen.
 * - Reactive: color/shape/speed/frequency props update live (no renderer teardown).
 * - Resilient: falls back to a CSS gradient if WebGL is unavailable.
 */
export declare function Gradient(props: GradientProps): JSX.Element;
