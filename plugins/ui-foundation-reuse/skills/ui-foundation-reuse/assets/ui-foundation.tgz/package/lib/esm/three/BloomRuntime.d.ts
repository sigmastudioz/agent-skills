import { type BloomProps } from './stagingOps.js';
export declare function createBloomRuntime({ fiber, three, ...addons }: any): (props: BloomProps) => JSX.Element | null;
