export declare const BALL_PIT_COLORS: string[];
/** Instance colors must be linear, matching Three's color-managed material inputs. */
export declare function ballPitLayout(count: number, bounds: number, colors: string[], rand: () => number): {
    instances: {
        key: number;
        position: [number, number, number];
    }[];
    colorBuffer: Float32Array;
};
