import type { FlutedGlassProps, ResolvedFlutedGlassConfig } from './types.js';
/** All optical distances use CSS pixels, independent of canvas DPR. */
export declare function resolveFlutedGlassConfig(props?: Partial<FlutedGlassProps>): ResolvedFlutedGlassConfig;
