export { KineticText } from './KineticText.js';
export type { KineticTextProps } from './KineticText.js';
