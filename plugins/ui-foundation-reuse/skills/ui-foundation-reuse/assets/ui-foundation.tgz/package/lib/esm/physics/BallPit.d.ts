/// <reference types="react" />
export interface BallPitProps {
    /** Number of balls. Default 46. */
    count?: number;
    /** Ball colors, cycled. */
    colors?: string[];
    /** Bounciness, 0–1. Default 0.72. */
    restitution?: number;
    /** Ball radius. Default 0.44. */
    radius?: number;
    /** Bowl radius (containment). Default 5.2. */
    bounds?: number;
    /** Gravity strength. Default 14. */
    gravity?: number;
    /** Deterministic layout seed provider (defaults to Math.random). */
    rand?: () => number;
    /** Called when rapier cannot load. The pit renders nothing inside the scene. */
    onError?: (error: unknown) => void;
}
/**
 * A batteries-included rigid-body "ball pit": colorful spheres rain into a bowl
 * and bounce, via `@react-three/rapier`. Render inside `<Scene>` (set
 * `canvasProps={{ shadows: true }}` for contact shadows). Includes its own
 * lights; add your own camera/controls on <Scene> or compose freely.
 *
 * The rapier peer loads on mount. Import primitives from
 * `@sigmastudioz/ui-foundation/physics/rapier` when composing a custom world.
 */
export declare function BallPit({ onError, ...props }: BallPitProps): JSX.Element | null;
