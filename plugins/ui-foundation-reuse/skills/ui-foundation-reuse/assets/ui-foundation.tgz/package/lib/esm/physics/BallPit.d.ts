/// <reference types="react" />
export interface BallPitProps {
    /** Number of balls. Default 46. */
    count?: number;
    /** Ball colors, cycled. */
    colors?: string[];
    /** Bounciness, 0–1. Default 0.72. */
    restitution?: number;
    /** Ball radius. Default 0.44. */
    radius?: number;
    /** Bowl radius (containment). Default 5.2. */
    bounds?: number;
    /** Gravity strength. Default 14. */
    gravity?: number;
    /** Deterministic layout seed provider (defaults to Math.random). */
    rand?: () => number;
}
/**
 * A batteries-included rigid-body "ball pit": colorful spheres rain into a bowl
 * and bounce, via `@react-three/rapier`. Render inside `<Scene>` (set
 * `canvasProps={{ shadows: true }}` for contact shadows). Includes its own
 * lights; add your own camera/controls on <Scene> or compose freely.
 *
 * Requires the optional peer `@react-three/rapier` (plus the `three` peers).
 */
export declare function BallPit({ count, colors, restitution, radius, bounds, gravity, rand, }: BallPitProps): JSX.Element;
