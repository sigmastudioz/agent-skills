export { TypeRefraction } from './TypeRefraction.js';
export { resolveTypeRefractionConfig, driftPosition, applyTextTransform, wordSpans, baselineY, followToward } from './typeRefractionOps.js';
export { createTypeRefractionRenderer } from './typeRefractionRenderer.js';
export type { TypeRefractionRenderer } from './typeRefractionRenderer.js';
export type { TypeRefractionProps, ResolvedTypeRefractionConfig, TextRun } from './types.js';
