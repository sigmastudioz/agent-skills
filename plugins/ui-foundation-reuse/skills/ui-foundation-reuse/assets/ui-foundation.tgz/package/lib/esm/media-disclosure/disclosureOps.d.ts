import type { MediaDisclosureValue } from './types.js';
export declare function nextDisclosure(value: MediaDisclosureValue, id: string): MediaDisclosureValue;
