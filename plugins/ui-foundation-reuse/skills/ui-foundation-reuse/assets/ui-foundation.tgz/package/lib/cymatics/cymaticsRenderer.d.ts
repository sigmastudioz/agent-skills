import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import type { CymaticsAudioFrame, CymaticsConfig } from './types.js';
export interface CymaticsRenderer extends WebGLRendererLike {
    render(config: CymaticsConfig, frame: CymaticsAudioFrame | undefined, time: number, animate: boolean): void;
}
export declare function createCymaticsRenderer(canvas: HTMLCanvasElement, count: number, seed: number): CymaticsRenderer | null;
