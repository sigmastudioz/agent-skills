/// <reference types="react" />
import type { ImageFilterProps } from './types.js';
/** Shared image treatment host; static kinds draw on demand. No Three dependency. */
export declare function ImageFilter(props: ImageFilterProps): JSX.Element;
