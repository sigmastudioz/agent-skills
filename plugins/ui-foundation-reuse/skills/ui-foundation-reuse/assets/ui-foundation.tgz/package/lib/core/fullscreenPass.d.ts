/** Small owned WebGL pass. Locations and geometry are allocated once, never per frame. */
export declare const FULLSCREEN_VERTEX = "attribute vec2 aPosition; varying vec2 vUv; void main(){vUv=aPosition*.5+.5;gl_Position=vec4(aPosition,0.,1.);}";
export declare function createFullscreenPass(gl: WebGLRenderingContext, fragment: string, names: string[]): {
    uniforms: {
        [k: string]: WebGLUniformLocation | null;
    };
    dispose: () => void;
    draw(): void;
    use(): void;
};
export declare function createTexture(gl: WebGLRenderingContext): WebGLTexture;
