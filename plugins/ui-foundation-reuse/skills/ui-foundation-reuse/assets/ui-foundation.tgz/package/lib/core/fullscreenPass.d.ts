/** Small owned WebGL pass. Locations and geometry are allocated once, never per frame. */
export declare const FULLSCREEN_VERTEX = "attribute vec2 aPosition; varying vec2 vUv; void main(){vUv=aPosition*.5+.5;gl_Position=vec4(aPosition,0.,1.);}";
export interface PassStatus {
    ready: boolean;
    error?: Error;
}
/**
 * Hear when the passes of a context finish compiling in the background, or fail. Passes draw
 * nothing until then, so a still (paused or reduced-motion) effect needs this to draw its
 * frame. Returns an unsubscribe function. Nothing is reported for a context that compiled
 * synchronously.
 */
export declare function watchPasses(gl: object | null | undefined, listener: (status: PassStatus) => void): () => void;
/** True while any pass of this context is still compiling. */
export declare function passesPending(gl: object | null | undefined): boolean;
/**
 * Compile and link a fullscreen pass. Where the browser can compile in the background
 * (KHR_parallel_shader_compile), this returns at once: asking for the compile status straight
 * away is what blocks the main thread for hundreds of milliseconds. Until the program is ready
 * `use()` and `draw()` do nothing and `uniforms` is empty (setting a missing uniform is a
 * no-op in WebGL); `watchPasses` reports readiness or a late compile error. Without the
 * extension it compiles synchronously and throws on error, as before.
 */
export declare function createFullscreenPass(gl: WebGLRenderingContext, fragment: string, names: string[]): {
    uniforms: Record<string, WebGLUniformLocation | null>;
    dispose: () => void;
    /** False while the program is still compiling in the background. */
    readonly ready: boolean;
    draw(): void;
    use(): void;
};
export declare function createTexture(gl: WebGLRenderingContext): WebGLTexture;
