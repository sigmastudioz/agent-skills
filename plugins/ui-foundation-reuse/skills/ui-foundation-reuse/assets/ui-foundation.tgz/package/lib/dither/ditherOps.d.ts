import type { DitherAlgorithm, DitherProps, ResolvedDitherConfig } from './types.js';
/** Error-diffusion work is bounded; larger frames use proportionally larger cells. */
export declare const MAX_DIFFUSION_CELLS: number;
export declare function resolveDitherConfig(props?: Partial<DitherProps>): ResolvedDitherConfig;
export declare function isDiffusion(algorithm: DitherAlgorithm): boolean;
/** Square cells covering the frame; cell size grows only when the work bound requires it. */
export declare function ditherGrid(width: number, height: number, cellSize: number): {
    columns: number;
    rows: number;
    cell: number;
};
/** Contrast-adjusted Rec. 709 luminance in [0,1]; transparent pixels read as paper. */
export declare function ditherLuminance(pixels: ArrayLike<number>, count: number, contrast: number, invert: boolean): Float32Array;
/** Deterministic left-to-right error diffusion to `levels` tones in [0,1]. */
export declare function errorDiffuse(light: Float32Array, columns: number, rows: number, algorithm: 'floyd' | 'atkinson', levels: number): Float32Array;
/** Map tones through the same 256-texel ramp the GPU path samples. Alpha follows the source. */
export declare function ditherPixels(tones: Float32Array, palette: readonly string[], source: ArrayLike<number>): Uint8ClampedArray;
