export { FoilSurface } from './FoilSurface.js';
export type { FoilArtwork, FoilSurfaceProps, FoilSurfaceHandle } from './types.js';
