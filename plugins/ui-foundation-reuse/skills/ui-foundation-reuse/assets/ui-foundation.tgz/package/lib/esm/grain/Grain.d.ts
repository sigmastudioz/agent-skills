import type { CSSProperties } from 'react';
export interface GrainProps {
    /** Overlay opacity, 0–1. Default 0.08. */
    opacity?: number;
    /** Noise contrast, 0–1. Default 1. */
    intensity?: number;
    /** Grain refresh rate (Hz). Film grain reads well ~12–24. Default 24. */
    fps?: number;
    /** Blend mode against the content below. Default 'soft-light'. */
    blendMode?: CSSProperties['mixBlendMode'];
    /** Optional tint (hex) for the noise. Default white = neutral grey grain. */
    color?: string;
    className?: string;
    style?: CSSProperties;
}
/**
 * Animated film-grain / noise overlay — the texture nearly every "designer"
 * site in the reference video shares. Absolutely positioned, `pointer-events:
 * none`, so it sits over whatever it's placed inside. A fine 128px noise tile
 * cycles through eight precomputed exposures and repeated across the surface for crisp grain at
 * any size. Honors reduced-motion (renders one static frame).
 */
export declare function Grain({ opacity, intensity, fps, blendMode, color, className, style, }: GrainProps): JSX.Element;
