/// <reference types="react" />
import type { FrostedBlurProps } from './types.js';
export declare function FrostedBlur({ children, style, intensity, testID, className, surfaceColor }: FrostedBlurProps): import("react").JSX.Element;
