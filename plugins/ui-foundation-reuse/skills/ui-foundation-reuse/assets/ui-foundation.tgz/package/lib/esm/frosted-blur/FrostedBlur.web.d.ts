import * as React from 'react';
import type { FrostedBlurProps } from './types.js';
export declare function FrostedBlur({ children, style, intensity, testID, className, surfaceColor }: FrostedBlurProps): React.JSX.Element;
