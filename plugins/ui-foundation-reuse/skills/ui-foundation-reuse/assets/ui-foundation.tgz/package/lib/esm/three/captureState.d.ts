export declare const isAuxiliaryCapture: (renderer: object) => boolean;
/** Per-pass scratch state; callers guard re-entry. Restore even after a failed GPU draw. */
export declare function createRenderState(three: any): <T>(renderer: any, draw: () => T) => T;
/** Reflections and shadow captures draw cached surfaces rather than recursively recapturing them. */
export declare function captureAuxiliary<T>(renderer: object, draw: () => T): T | undefined;
