/// <reference types="react" />
import type { DotMatrixProps } from './types.js';
/** LED dot-matrix sign on a 2D canvas. The marquee advances whole columns, so the canvas
 * redraws only when the window moves; it sleeps off-screen and renders static under reduced motion. */
export declare function DotMatrix({ text, label, columns, padding, mode, speed, color, background, offOpacity, glow, shape, paused, className, style }: DotMatrixProps): JSX.Element;
