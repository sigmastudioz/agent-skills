export { DotMatrix } from './DotMatrix.js';
export { marqueeOffset, matrixFrame, staticOffset, textColumns } from './matrixOps.js';
export type { DotMatrixProps } from './types.js';
