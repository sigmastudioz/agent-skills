export { AdaptiveSurface } from './AdaptiveSurface.js';
export type { AdaptiveSurfaceProps, SurfaceAppearance } from './types.js';
