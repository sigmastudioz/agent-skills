import type { ImageFilterKind, ImageFilterProps, ResolvedImageFilterConfig } from './types.js';
export declare function resolveImageFilterConfig(props?: Partial<ImageFilterProps>): ResolvedImageFilterConfig;
export declare function imageFilterKind(kind: ImageFilterKind): number;
export declare function filterColor(color: string): [number, number, number];
export declare function createGlyphPixels(): Uint8Array;
