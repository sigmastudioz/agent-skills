import type { ImageFilterGlitchMode, ImageFilterKind, ImageFilterProps, ResolvedImageFilterConfig } from './types.js';
export declare function resolveImageFilterConfig(input?: Partial<ImageFilterProps>): ResolvedImageFilterConfig;
export declare function imageFilterKind(kind: ImageFilterKind): number;
export declare function glitchModeIndex(mode: ImageFilterGlitchMode): number;
/** `uMode` is shared: glitch treatment, or zoom (0) / spin (1) for the zoom-blur kind. */
export declare function filterModeIndex(config: Pick<ResolvedImageFilterConfig, 'kind' | 'glitchMode' | 'blurMode'>): number;
/** Recursive Bayer threshold in [0,1); mirrors the shader's `ditherBayer`. */
export declare function bayerThreshold(x: number, y: number, size: 4 | 8): number;
export declare function filterColor(color: string): [number, number, number];
export declare function createGlyphPixels(): Uint8Array;
