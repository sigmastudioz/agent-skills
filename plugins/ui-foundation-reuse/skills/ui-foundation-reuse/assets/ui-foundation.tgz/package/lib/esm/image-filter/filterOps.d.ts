import type { ImageFilterGlitchMode, ImageFilterKind, ImageFilterProps, ResolvedImageFilterConfig } from './types.js';
export declare function resolveImageFilterConfig(input?: Partial<ImageFilterProps>): ResolvedImageFilterConfig;
export declare function imageFilterKind(kind: ImageFilterKind): number;
export declare function glitchModeIndex(mode: ImageFilterGlitchMode): number;
/** `uMode` is shared: glitch treatment, or zoom (0) / spin (1) for the zoom-blur kind. */
export declare function filterModeIndex(config: Pick<ResolvedImageFilterConfig, 'kind' | 'glitchMode' | 'blurMode'>): number;
/** Recursive Bayer threshold in [0,1); mirrors the shader's `ditherBayer`. */
export declare function bayerThreshold(x: number, y: number, size: 4 | 8): number;
export declare function filterColor(color: string): [number, number, number];
export declare function createGlyphPixels(): Uint8Array;
/** At most this many glitch pattern changes per second of real time (WCAG 2.3.1). */
export declare const MAX_GLITCH_CHANGES_PER_SECOND = 3;
/**
 * Glitch patterns per unit of animation phase. Phase advances at `speed` per second, so the
 * pattern changes `rate × speed` times a second; the rate keeps that at or under the cap
 * (10 per phase unit at low speeds, as before).
 */
export declare function glitchPatternRate(speed: number): number;
/**
 * A burst interval long enough that bursts start and end at most three times a second in real
 * time (each burst is two changes, clean to glitched and back). `interval` 0 (constant glitch)
 * is unchanged.
 */
export declare function glitchSafeInterval(interval: number, speed: number): number;
