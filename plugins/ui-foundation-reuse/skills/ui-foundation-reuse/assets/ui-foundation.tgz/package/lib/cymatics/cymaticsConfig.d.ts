import type { CymaticsConfig, CymaticsProps } from './types.js';
export declare function resolveCymaticsConfig(props?: CymaticsProps): CymaticsConfig;
