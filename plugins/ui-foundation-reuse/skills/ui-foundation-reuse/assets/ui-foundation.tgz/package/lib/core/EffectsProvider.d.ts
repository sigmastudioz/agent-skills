import { type ReactNode } from 'react';
export interface EffectsSettings {
    /** Pause effects in this subtree. A nested provider cannot undo a parent's pause. */
    paused: boolean;
    /** Maximum pixel density for shader canvases. Default 2; 1 saves GPU work. */
    maxDpr: number;
    /** Maximum RAF animation updates per second. Default 60. */
    maxFps: number;
}
export interface EffectsProviderProps extends Partial<EffectsSettings> {
    children?: ReactNode;
}
/** Shared performance controls. OS reduced-motion preferences always take precedence. */
export declare function EffectsProvider({ children, paused, maxDpr, maxFps }: EffectsProviderProps): JSX.Element;
export declare function useEffectsSettings(): EffectsSettings;
