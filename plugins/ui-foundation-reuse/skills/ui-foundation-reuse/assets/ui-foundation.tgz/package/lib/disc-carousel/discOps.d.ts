export declare function resolveDiscIndex(index: number, length: number): number;
export declare function discPose(position: number, selected: number, depth?: number): {
    x: number;
    y: number;
    scale: number;
    rotate: number;
    layer: number;
    visible: boolean;
};
export declare function discMask(hole: number): string;
