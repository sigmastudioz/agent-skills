export declare const GLYPH_WIDTH = 5;
export declare const GLYPH_HEIGHT = 7;
export declare function glyphRows(char: string): readonly number[];
