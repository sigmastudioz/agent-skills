/** Owned buffer/program lifecycle for the particle-form and luminous-trails passes. */
export declare function createGlowPass(canvas: HTMLCanvasElement, vertex: string, fragment: string, data: Float32Array | (() => Float32Array), attributes: readonly (readonly [name: string, size: number])[], names: readonly string[]): {
    gl: WebGLRenderingContext;
    uniforms: {
        [k: string]: WebGLUniformLocation | null;
    };
    dispose: () => void;
    resize(width: number, height: number, dpr: number): void;
    use(): void;
} | null;
/** Integrate speed instead of multiplying absolute time: changing speed never rewinds. */
export declare function createGlowClock(): (time: number, speed: number) => number;
/** Validated hex colors shared by both luminous effects. */
export declare function glowColor(value: unknown, fallback: string): string;
export declare function glowRgb(hex: string): [number, number, number];
