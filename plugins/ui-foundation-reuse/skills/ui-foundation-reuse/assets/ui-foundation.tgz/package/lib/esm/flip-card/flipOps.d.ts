import type { PendulumState } from './types.js';
/** Transform for the rotating inner layer. */
export declare function flipTransform(flipped: boolean, axis: 'x' | 'y'): string;
/** Damped pendulum, semi-implicit Euler, angles in radians. `length` in CSS pixels sets the
 * period (longer strap = slower swing); time is scaled so a 200 px strap swings at ~1 Hz. */
export declare function stepPendulum(state: PendulumState, deltaMs: number, length: number, damping: number): PendulumState;
export declare function pendulumAtRest(state: PendulumState): boolean;
/** CSS rotation (clockwise positive) of the strap when the card is dragged to (dx, dy)
 * from the pivot, y down: dragging right swings the card right, a negative angle. */
export declare function dragAngle(dx: number, dy: number): number;
/** Controls inside a face keep their own clicks and keys; the card does not flip for them. */
export declare const FLIP_IGNORE = "a[href],button,input,select,textarea,summary,label,[role=\"button\"],[role=\"link\"],[contenteditable=\"\"],[contenteditable=\"true\"],[data-flip-ignore]";
/** True when an event started on a control inside the card rather than on the card itself. */
export declare function fromInnerControl(target: EventTarget | null, card: Element): boolean;
/** A press that moved less than this is a click (flip), not a drag. */
export declare const CLICK_SLOP = 5;
