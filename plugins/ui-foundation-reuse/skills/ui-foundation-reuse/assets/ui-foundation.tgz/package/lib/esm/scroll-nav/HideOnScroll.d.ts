import { type CSSProperties, type ReactNode } from 'react';
export interface HideOnScrollProps {
    children?: ReactNode;
    /** Host element. Default 'header'. */
    as?: 'header' | 'nav' | 'div';
    /** Never hide within this many px of the top. Default 64. */
    offset?: number;
    /** Direction threshold, CSS px. Default 6. */
    threshold?: number;
    /** Slide duration, ms. Default 260. */
    duration?: number;
    className?: string;
    /** Position it yourself, e.g. `{ position: 'sticky', top: 0 }`. */
    style?: CSSProperties;
    onVisibilityChange?: (visible: boolean) => void;
}
/**
 * Header that slides away while scrolling down and returns on scroll up. It stays
 * visible near the top and whenever it contains keyboard focus. Reduced motion
 * removes the slide (it still hides). Uses window scroll.
 */
export declare function HideOnScroll({ children, as, offset, threshold, duration, className, style, onVisibilityChange, }: HideOnScrollProps): JSX.Element;
