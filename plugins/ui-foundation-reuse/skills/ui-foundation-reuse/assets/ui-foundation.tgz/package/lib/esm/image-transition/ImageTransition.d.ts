/// <reference types="react" />
import type { ImageTransitionProps } from './types.js';
/** On-demand image shader. URLs and decoded sequence frames share the same renderer. */
export declare function ImageTransition({ from, to, alt, progress, kind, intensity, className, style, onError }: ImageTransitionProps): import("react").JSX.Element;
