/**
 * BlurView material for the current theme.
 * iOS `chromeMaterial` (no Light suffix) reads charcoal even when the app is
 * in light mode — that is the dark-slab Settings / tab-bar bug.
 */
export declare function resolveFrostedBlurType(platform: string, scheme: 'light' | 'dark'): 'dark' | 'light' | 'chromeMaterialLight';
