/// <reference types="react" />
import type { AdaptiveSurfaceProps } from './types.js';
/** Caller-owned identity and appearance respond to an actual content boundary. */
export declare function AdaptiveSurface({ boundaryRef, scrollRootRef, offset, before, after, children, onBoundaryChange, duration, className, style }: AdaptiveSurfaceProps): import("react").JSX.Element;
