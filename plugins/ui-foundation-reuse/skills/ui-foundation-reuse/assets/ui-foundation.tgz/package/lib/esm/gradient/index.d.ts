export { Gradient } from './Gradient.js';
export { resolveGradientConfig, GRADIENT_PRESET_NAMES, } from './presets.js';
export { DEFAULT_GRADIENT_FREQUENCY, finiteNumberOr, clampGradientFrequency, } from './gradientOps.js';
export type { GradientProps, GradientColors, GradientShape, GradientPreset, ResolvedGradientConfig, } from './types.js';
