import type { CurtainConfig, GlyphCurtainProps } from './types.js';
export declare function resolveCurtainConfig(props: GlyphCurtainProps): CurtainConfig;
export interface CurtainField {
    x: Float32Array;
    y: Float32Array;
    previousX: Float32Array;
    previousY: Float32Array;
    width: number;
    height: number;
    segment: number;
    columns: number;
    rows: number;
    top: number;
}
export declare function curtainAnchor(field: CurtainField, column: number): number;
export declare function createCurtainField(width: number, height: number, config: CurtainConfig): CurtainField;
export declare function resetCurtainField(field: CurtainField): void;
/** Fixed timestep, pinned independent strands. Returns average squared velocity. */
export declare function stepCurtainField(field: CurtainField, config: CurtainConfig, pointer?: {
    x: number;
    y: number;
} | null): number;
