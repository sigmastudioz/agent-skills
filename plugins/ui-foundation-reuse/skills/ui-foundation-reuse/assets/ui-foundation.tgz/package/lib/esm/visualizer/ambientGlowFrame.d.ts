type MixerBands = {
    bass: number;
    mid: number;
    treble: number;
    energy: number;
};
/** Slow wash around the color wheel. 12 = lava-lamp, 40 = club strobe. */
export declare const GLOW_HUE_DEG_PER_SEC = 18;
/** Extra hue kick when the analyzer flags a beat. */
export declare const GLOW_BEAT_HUE_JUMP = 42;
export type AmbientGlowInput = MixerBands & {
    beat: boolean;
    playing: boolean;
    timeSec: number;
    beatBoostDeg: number;
};
export type AmbientGlowFrame = {
    /** Top stop of the halo gradient (already includes alpha). */
    color: string;
    /** Opaque hex for the listener ring stroke. */
    hex: string;
    opacity: number;
    scale: number;
};
/** h in degrees, s/l/a in 0–1. */
export declare function hslToRgba(h: number, s: number, l: number, a: number): string;
export declare function hslToHex(h: number, s: number, l: number): string;
/**
 * Bass pulls toward gold/red, treble toward cyan/violet, time walks the wheel.
 */
export declare function pickGlowHue(input: AmbientGlowInput): number;
/** Follow the short way around the wheel, including the 360→0 seam. */
export declare function followGlowHue(current: number, target: number, elapsed: number): number;
export declare function resolveAmbientGlowFrame(input: AmbientGlowInput, hue?: number): AmbientGlowFrame;
export {};
