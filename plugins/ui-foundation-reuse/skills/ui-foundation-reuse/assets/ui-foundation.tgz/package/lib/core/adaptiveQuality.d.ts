export { createQualityHistory, sampleQuality } from './qualityOps.js';
export type { QualityHistory } from './qualityOps.js';
/** Use the returned multiplier for resolution or detail budgets. Sampling stops when inactive. */
export declare function useAdaptiveQuality(active?: boolean): number;
