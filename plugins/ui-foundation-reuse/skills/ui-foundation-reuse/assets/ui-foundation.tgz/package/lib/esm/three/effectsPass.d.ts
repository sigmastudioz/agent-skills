import { type PostEffectsConfig } from './effectsOps.js';
/**
 * One composer for the Canvas: scene → ambient occlusion → depth of field → bloom → output.
 * Order matters: occlusion belongs to the lit scene, blur comes from the lens, glow from the
 * sensor, and the output pass applies the renderer's tone curve and colour space last.
 */
export declare function createEffectsPass(three: any, addons: any, renderer: any, scene: any, camera: any, initial: PostEffectsConfig): {
    configure: (next: PostEffectsConfig) => boolean;
    dispose: () => void;
    shape: string;
    render(nextScene?: any, nextCamera?: any, delta?: number): void;
};
