/// <reference types="react" />
import type { IridescenceProps } from './types.js';
/** Flowing iridescent satin with pointer-lit highlights and a CSS fallback. */
export declare function Iridescence(props?: IridescenceProps): JSX.Element;
