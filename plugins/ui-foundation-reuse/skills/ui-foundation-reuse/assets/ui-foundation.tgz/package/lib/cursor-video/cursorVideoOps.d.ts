export declare function cursorProgress(position: number, origin: number, length: number, reverse?: boolean): number;
export declare function videoRangeProgress(progress: number, start?: number, end?: number): number;
