/// <reference types="react" />
import type { CRTSurfaceProps } from './types.js';
/** A DOM media treatment. Overlays are decorative and never intercept input. */
export declare function CRTSurface({ children, noise, scanlines, animated, className, style }: CRTSurfaceProps): import("react").JSX.Element;
