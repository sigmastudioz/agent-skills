export { SpectralRibbon } from './SpectralRibbon.js';
export { SPECTRAL_RIBBON_COLORS, resolveSpectralRibbonConfig } from './ribbonOps.js';
export type { SpectralRibbonProps, SpectralRibbonConfig, SpectralRibbonColors } from './types.js';
