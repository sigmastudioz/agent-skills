import type { ReactNode } from 'react';
export type AssemblyVector = readonly [number, number, number];
export interface AssemblyPart {
    id: string;
    position?: AssemblyVector;
    /** Displacement from its assembled position at amount=1, in scene units. */
    offset?: AssemblyVector;
    rotation?: AssemblyVector;
    /** Extra XYZ rotation in radians at amount=1. */
    spin?: AssemblyVector;
    children?: ReactNode;
}
export interface ExplodedAssemblyProps {
    parts: readonly AssemblyPart[];
    /** Controlled assembled(0) → separated(1) pose. No implicit hover or global input. */
    amount: number;
    position?: AssemblyVector;
    rotation?: AssemblyVector;
    scale?: number;
}
export declare function sampleAssemblyPose(part: AssemblyPart, amount: number): {
    position: [number, number, number];
    rotation: [number, number, number];
};
