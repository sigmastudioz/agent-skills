import type { FieldPoint } from './types.js';
export declare const FIELD_SIZE = 128;
export declare function clamp01(value: number): number;
/** Pull a sample toward the pointer. Strength 0 is the identity. Matches the shader. */
export declare function warpUv(x: number, y: number, px: number, py: number, strength: number): [number, number];
/** Procedural portrait field. `v` is 0 at the bottom, 1 at the top. */
export declare function proceduralColor(u: number, v: number, seed: number, time: number): {
    r: number;
    g: number;
    b: number;
    l: number;
};
/** Row 0 is the top of the frame. */
export declare function writeProceduralField(pixels: Uint8Array, lum: Float32Array, seed: number, time: number): void;
export declare function sampleLum(lum: Float32Array, w: number, h: number, u: number, v: number): number;
/** Source window for a cover crop into a destination aspect. */
export declare function coverSourceRect(srcW: number, srcH: number, dstW: number, dstH: number): {
    sx: number;
    sy: number;
    sw: number;
    sh: number;
};
export declare function warpLuminance(lum: Float32Array, w: number, h: number, px: number, py: number, strength: number): Float32Array;
/** Sobel magnitude plus non-maximum suppression. Points are in y-up 0–1 space. */
export declare function extractPoints(lum: Float32Array, w: number, h: number, threshold: number, limit: number): FieldPoint[];
export interface ImagePlane {
    canvas: HTMLCanvasElement;
    lum: Float32Array;
}
/** Cover-crop `image` into a GPU texture and a matching luminance grid. Browser only. */
export declare function readImagePlane(image: CanvasImageSource & {
    width: number;
    height: number;
}, dstW: number, dstH: number): ImagePlane | null;
