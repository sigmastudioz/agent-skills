export interface VisualizerAudioFrame {
    bins: number[];
    waveform: number[];
    peaks: number[];
    amplitude: number;
    bass: number;
    mid: number;
    treble: number;
    beat: number;
}
/** A retained frame, sampled by the visualizer only while it renders. */
export interface VisualizerAudioSource {
    sample(): VisualizerAudioFrame;
}
export declare const createAudioFrame: () => VisualizerAudioFrame;
export declare function frequencyBands(sampleRate: number, fftSize: number): [number, number][];
export interface AudioHistory {
    baseline: number;
    cooldown: number;
}
/** Log-frequency aggregation, time-based envelopes, RMS and an onset envelope. No allocations. */
export declare function analyzeAudio(frequency: Uint8Array, wave: Uint8Array, bands: [number, number][], frame: VisualizerAudioFrame, history: AudioHistory, delta: number): void;
