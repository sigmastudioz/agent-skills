import type { GlowPoint, ResolvedGlowPoint } from './types.js';
export declare function resolveGlowPoints(points: readonly GlowPoint[], intensity?: number): ResolvedGlowPoint[];
