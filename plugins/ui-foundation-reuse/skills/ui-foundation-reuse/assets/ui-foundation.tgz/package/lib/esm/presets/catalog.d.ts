import type { CuratedPreset, PresetFilter } from './types.js';
export declare const CURATED_PRESETS: readonly CuratedPreset[];
export declare function getCuratedPreset(id: string): CuratedPreset | undefined;
/** Every query word must match; independent facets are combined with AND. */
export declare function findCuratedPresets(filter?: PresetFilter): readonly CuratedPreset[];
