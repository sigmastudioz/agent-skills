/// <reference types="react" />
import type { CardRingProps } from './types.js';
/**
 * Cards around a 3D cylinder (CSS 3D, no WebGL). Rotate by dragging, the arrow keys
 * (Home/End), the buttons, or link it to scroll with `progress` / `scrollTrack`; it rests
 * with one card in front. Only the front card is focusable and exposed to assistive
 * technology (the others are inert); the front card is announced politely. Reduced motion
 * snaps instead of spinning. While it spins, transforms are written straight to the cards:
 * React renders only when the front card changes.
 */
export declare function CardRing({ items, cardWidth, aspectRatio, gap, tilt, index, defaultIndex, onIndexChange, progress, scrollTrack, duration, controls, label, className, cardClassName, style, }: CardRingProps): JSX.Element;
