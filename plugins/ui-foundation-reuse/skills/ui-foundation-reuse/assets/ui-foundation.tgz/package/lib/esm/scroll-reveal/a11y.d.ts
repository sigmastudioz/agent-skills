import type { CSSProperties } from 'react';
/** Screen-reader-only text. aria-label is prohibited on generic and paragraph roles. */
export declare const VISUALLY_HIDDEN: CSSProperties;
