import type { CymaticsAudioSource } from './types.js';
/** Wrap a caller-owned analyser; reading never changes its graph or FFT settings. */
export declare function createCymaticsAnalyser(analyser: AnalyserNode): CymaticsAudioSource;
/** Visual insert for any Web Audio graph. Unity dry output; no automatic speaker connection. */
export declare function createCymaticsEffect(context: BaseAudioContext): {
    input: GainNode;
    output: GainNode;
    analyser: AnalyserNode;
    audio: CymaticsAudioSource;
    dispose(): void;
};
