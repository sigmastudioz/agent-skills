export { GlyphCurtain } from './GlyphCurtain.js';
export type { GlyphCurtainProps, GlyphCurtainHandle } from './types.js';
