export { Pixelate } from './Pixelate.js';
export type { PixelateProps } from './types.js';
