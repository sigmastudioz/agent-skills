export { Pixelate } from './Pixelate.js';
export { PixelateTransition } from './PixelateTransition.js';
export { pixelateTransitionFrame } from './transitionOps.js';
export type { PixelateTransitionFrame, PixelateTransitionOptions } from './transitionOps.js';
export type { PixelateProps, PixelateTransitionProps } from './types.js';
