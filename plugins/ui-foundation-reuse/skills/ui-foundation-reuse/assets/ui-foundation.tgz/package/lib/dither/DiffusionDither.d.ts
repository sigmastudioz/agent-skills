/// <reference types="react" />
import type { DitherProps, ResolvedDitherConfig } from './types.js';
interface DiffusionDitherProps extends Pick<DitherProps, 'src' | 'alt' | 'className' | 'style' | 'onError' | 'crossOrigin'> {
    config: ResolvedDitherConfig;
}
/** CPU error diffusion: static, drawn once per source, size or control change. No RAF. */
export declare function DiffusionDither({ src, alt, className, style, onError, crossOrigin, config }: DiffusionDitherProps): JSX.Element;
export {};
