import type { GeometricScene, ResolvedGeometricConfig } from './types.js';
/** Stroke the sampled graph in y-up coordinates over a CSS-sized canvas. */
export declare function paintGeometric(canvas: HTMLCanvasElement, scene: GeometricScene, config: Pick<ResolvedGeometricConfig, 'ink' | 'accent' | 'inkOpacity' | 'showNodes' | 'showChain'>, dpr: number): void;
