export { finiteNumberOr } from '../core/numberOps.js';
/** Spatial scale of 1 matches the original hardcoded noise field. */
export declare const DEFAULT_GRADIENT_FREQUENCY = 1;
/** Keep the field from collapsing (0) or exploding into noise. */
export declare function clampGradientFrequency(value: number): number;
