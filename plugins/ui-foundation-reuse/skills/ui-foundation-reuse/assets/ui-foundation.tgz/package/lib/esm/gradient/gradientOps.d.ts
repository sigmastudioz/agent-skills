export { finiteNumberOr } from '../core/numberOps.js';
/** Spatial scale of 1 matches the original hardcoded noise field. */
export declare const DEFAULT_GRADIENT_FREQUENCY = 1;
/** Keep the field from collapsing (0) or exploding into noise. */
export declare function clampGradientFrequency(value: number): number;
/** Live, per-frame input on top of the resolved config. */
export interface GradientInput {
    /** Pointer warp centre in the shader's aspect-corrected space (0,0 is the centre). */
    offset: [number, number];
    /** Multiplies `amplitude` (audio). 1 = unchanged. */
    amplitudeScale: number;
}
/** Audio frame (from `/visualizer` sources) → amplitude multiplier, 1 … 1 + 1.5 × reactivity. */
export declare function audioAmplitudeScale(frame: {
    amplitude?: number;
    bass?: number;
} | null | undefined, reactivity: number): number;
/**
 * Eases the warp centre toward the pointer target. `target` is the pointer in 0–1 page/element
 * coordinates (y down) or null when the pointer is away, which relaxes the warp to the centre.
 */
export declare function easePointerOffset(current: [number, number], target: [number, number] | null, aspect: number, strength: number, seconds: number): [number, number];
