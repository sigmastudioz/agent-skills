/// <reference types="react" />
import type { HalftoneProps } from './types.js';
/** Color print dots on paper; supports ink/paper duotone and luminance inversion. */
export declare function Halftone(props: HalftoneProps): JSX.Element;
