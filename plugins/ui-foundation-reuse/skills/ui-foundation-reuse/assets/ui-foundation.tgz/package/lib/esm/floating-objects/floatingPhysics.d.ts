import type { ForceBody2D } from '../force-2d/types.js';
import type { FloatingObject } from './types.js';
export interface FloatingBody extends ForceBody2D {
    angle: number;
    spin: number;
}
export declare function createFloatingBody(item: FloatingObject, width: number, height: number): FloatingBody;
/** Reuses the shared collision solver; this adapter owns free-flight walls and spin. */
export declare function stepFloatingBodies(bodies: FloatingBody[], width: number, height: number, seconds: number): void;
