import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import type { ResolvedFlutedGlassConfig } from './types.js';
export interface FlutedGlassRenderer extends WebGLRendererLike {
    load(src: string, ready: (error?: string) => void): () => void;
    render(config: ResolvedFlutedGlassConfig): void;
}
export declare function createFlutedGlassRenderer(canvas: HTMLCanvasElement): FlutedGlassRenderer | null;
