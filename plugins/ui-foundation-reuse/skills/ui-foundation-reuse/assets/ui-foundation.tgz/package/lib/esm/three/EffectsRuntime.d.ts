import { type PostEffectsProps } from './effectsOps.js';
export declare function createEffectsRuntime({ fiber, three, ...addons }: any): (props: PostEffectsProps) => JSX.Element | null;
