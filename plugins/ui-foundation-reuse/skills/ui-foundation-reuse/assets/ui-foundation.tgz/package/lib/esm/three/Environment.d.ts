/// <reference types="react" />
import type { EnvironmentProps, FinishProps } from './lightingOps.js';
/**
 * Lights the whole scene from an environment, so metal, glass and glossy surfaces have
 * something to reflect. With no `src` it uses a built-in neutral studio room (no asset);
 * with `src` it uses your equirectangular `.hdr` or `.exr`. Place it inside `<Scene>`.
 * It adds to any lights already in the scene, so lower or remove those to taste.
 */
export declare function Environment(props: EnvironmentProps): JSX.Element | null;
/**
 * The renderer's tone curve and exposure: how scene light becomes screen colour. Place it
 * inside `<Scene>`. One per scene; it restores the previous settings when removed.
 */
export declare function Finish(props: FinishProps): JSX.Element | null;
