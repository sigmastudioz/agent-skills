export { ApertureReveal } from './ApertureReveal.js';
export { apertureClipPath, spotlightMask } from './apertureOps.js';
export type { ApertureRevealProps, AperturePoint } from './types.js';
