export { MovingBlobs } from './MovingBlobs.js';
export type { MovingBlobsProps } from './types.js';
