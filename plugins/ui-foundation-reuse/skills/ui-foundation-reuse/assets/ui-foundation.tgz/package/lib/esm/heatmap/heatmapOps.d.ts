/** True for 2–16 #RGB/#RRGGBB colors. */
export declare function isHeatmapRamp(ramp?: readonly string[]): ramp is readonly string[];
/** 2–16 evenly spaced #RGB/#RRGGBB colors. Invalid ramps use the thermal palette. */
export declare function resolveHeatmapRamp(ramp?: readonly string[]): string[];
/** A small linear RGB lookup texture; endpoints are exact and all texels are opaque. */
export declare function createHeatmapPixels(ramp: readonly string[]): Uint8Array;
