import type { AperturePoint } from './types.js';
export declare function apertureImageRect(aspect: number, width: number, height: number): {
    x: number;
    y: number;
    width: number;
    height: number;
};
/** Registers a source-space polygon to the same centered cover crop as the image. */
export declare function apertureClipPath(points: readonly AperturePoint[], aspect: number, width: number, height: number): string;
export declare function spotlightMask(radius: number, feather: number, width: number, height: number): string;
