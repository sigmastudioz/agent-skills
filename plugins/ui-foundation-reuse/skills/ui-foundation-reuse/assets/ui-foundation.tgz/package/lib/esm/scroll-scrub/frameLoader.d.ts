export interface FrameLoaderOptions {
    /** Maximum decoded frames retained (2..256). Default 24. */
    cacheSize?: number;
    /** Concurrent image requests (1..8). Default 4. */
    concurrency?: number;
    /** Neighbors requested on either side of the target. Default 6. */
    preload?: number;
    onFrame: (image: HTMLImageElement, index: number) => void;
    /** Cache notification, including neighbors that do not replace the current frame. */
    onLoad?: (image: HTMLImageElement, index: number) => void;
    /** Failed frames are skipped for this loader's lifetime. */
    onError?: (index: number, src: string) => void;
}
export interface FrameSequenceLoader {
    seek(index: number): void;
    peek(index: number): HTMLImageElement | null;
    dispose(): void;
}
/** Bounded LRU cache with target-first loading and nearest-available fallback. No work until seek(). */
export declare function createFrameSequenceLoader(sources: readonly string[], options: FrameLoaderOptions): FrameSequenceLoader;
