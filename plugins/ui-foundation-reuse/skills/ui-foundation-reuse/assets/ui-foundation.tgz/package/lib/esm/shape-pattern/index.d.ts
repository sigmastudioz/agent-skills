export { ShapePattern } from './ShapePattern.js';
export { SHAPE_PATTERNS, resolveShapePatternConfig, buildShapePattern, createShapePatternSvg } from './shapePatternOps.js';
export type { ShapePatternKind, ShapePatternConfig, ShapePatternProps, ResolvedShapePatternConfig, ShapePatternScene, ShapePatternSvgOptions, ShapeMark, ShapePatternParameters, ShapePatternParameter } from './types.js';
export { SHAPE_PATTERN_CONTROLS, defaultShapeParameters, shapePatternHasMotion } from './shapePatternControls.js';
export type { ShapePatternControl } from './shapePatternControls.js';
