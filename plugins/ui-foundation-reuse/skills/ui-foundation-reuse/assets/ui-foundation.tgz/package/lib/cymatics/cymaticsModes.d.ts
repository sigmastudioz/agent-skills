import type { CymaticsConfig, CymaticsShape } from './types.js';
export declare const CYMATICS_GRID = 112;
export interface CymaticsMode {
    m: number;
    n: number;
    root: number;
    values: Float32Array;
}
/** Integer-order Bessel J, convergent power series on the bounded mode domain. */
export declare function besselJ(order: number, x: number): number;
export declare function modeFrequency(mode: Pick<CymaticsMode, 'root'>, config: CymaticsConfig): number;
/** Only rebuilt on shape changes. Radial lookup avoids per-cell Bessel evaluations. */
export declare function buildCymaticsModes(shape: CymaticsShape): CymaticsMode[];
