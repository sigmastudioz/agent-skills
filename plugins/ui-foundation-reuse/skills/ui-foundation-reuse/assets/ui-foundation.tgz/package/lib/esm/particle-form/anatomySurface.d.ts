type Point = readonly [number, number, number];
interface SurfaceSample {
    position: Point;
    normal: Point;
}
/** Both reference meshes share angular coordinates, keeping neighboring particles
 * together through the morph. Bilinear sampling avoids a fixed point-count grid.
 */
export declare function sampleAnatomy(shape: 'head' | 'brain', u: number, v: number): SurfaceSample;
export {};
