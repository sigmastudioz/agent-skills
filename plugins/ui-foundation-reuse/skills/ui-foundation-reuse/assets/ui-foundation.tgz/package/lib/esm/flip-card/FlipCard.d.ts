/// <reference types="react" />
import type { FlipCardProps } from './types.js';
/** Two-sided card. The root is a toggle button (aria-pressed); the hidden face is inert so
 * its links cannot take focus. Reduced motion crossfades in place of the 3D turn. */
export declare function FlipCard({ front, back, label, trigger, flipped, onFlippedChange, axis, duration, className, style }: FlipCardProps): JSX.Element;
