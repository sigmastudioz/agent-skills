/// <reference types="react" />
import type { GlassLensProps } from './types.js';
export interface GlassLensRegistry {
    register(element: HTMLElement, radius: number | undefined): () => void;
    /** True while WebGL draws the lenses; otherwise lenses use the CSS fallback. */
    ready: boolean;
}
export declare const GlassLensContext: import("react").Context<GlassLensRegistry | null>;
/**
 * A refracting lens inside `RefractiveGlass`. It lays out like any element; its
 * box and corner radius become the lens shape. Its children stay crisp DOM above
 * the glass. Outside a RefractiveGlass, or while WebGL is unavailable, it renders
 * as CSS frosted glass.
 */
export declare function GlassLens({ children, as, radius, className, style, href, onClick }: GlassLensProps): JSX.Element;
export declare function useGlassLensRegistry(): GlassLensRegistry | null;
