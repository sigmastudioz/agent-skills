import type { FloatProps } from './Float.js';
export interface FloatConfig {
    speed: number;
    floatIntensity: number;
    rotationIntensity: number;
    floatingRange: [number, number];
    phase: number;
}
export declare function resolveFloatConfig(props?: FloatProps): FloatConfig;
/** Deterministic hover at an accumulated phase: Y offset and XYZ rotations, relative to an outer group. */
export declare function sampleFloatMotion(time: number, config: FloatConfig): [number, number, number, number];
