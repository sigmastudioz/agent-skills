/** Load a still image for pixel sampling. Cancelling also detaches handlers, so an
 * obsolete source can never report into a newer one. */
export declare function loadSampledImage(src: string, crossOrigin: 'anonymous' | 'use-credentials', ready: (image: HTMLImageElement) => void, failed: (error: Error) => void): () => void;
/** Center-cropped cover sample of a frame at columns × rows. A CORS-tainted image
 * throws SecurityError from getImageData; callers keep their semantic fallback. */
export declare function sampleCoverPixels(image: HTMLImageElement, columns: number, rows: number, frameWidth: number, frameHeight: number): Uint8ClampedArray;
