import type { WebGLRendererLike } from '../core/useWebGLEffect.js';
import type { ResolvedImageFilterConfig } from './types.js';
export interface ImageFilterRenderer extends WebGLRendererLike {
    load(src: string, ready: (error?: string) => void): () => void;
    /** Optional lifecycle time excludes pauses; omitted time redraws the frozen frame. */
    render(config: ResolvedImageFilterConfig, timeSeconds?: number): void;
}
export declare function createImageFilterRenderer(canvas: HTMLCanvasElement): ImageFilterRenderer | null;
