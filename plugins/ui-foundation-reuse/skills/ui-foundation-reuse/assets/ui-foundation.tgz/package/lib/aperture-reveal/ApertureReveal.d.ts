/// <reference types="react" />
import type { ApertureRevealProps } from './types.js';
/** A source-registered aperture multiplied by a transient, feathered spotlight. */
export declare function ApertureReveal({ src, alt, aperture, imageAspect, children, contentFit, label, radius, feather, smoothingMs, open, onOpenChange, className, style }: ApertureRevealProps): JSX.Element;
