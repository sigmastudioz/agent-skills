/// <reference types="react" />
import type { CymaticsProps } from './types.js';
/** Incoming spectrum excites bounded surface modes; grains gather along their nodal regions. */
export declare function Cymatics(props?: CymaticsProps): JSX.Element;
