/// <reference types="react" />
import type { FloatingObjectsProps } from './types.js';
/** One shared clock; per-frame writes never rerender the caller's content. */
export declare function FloatingObjects({ items, speed, pointerStrength, motion, label, className, style }: FloatingObjectsProps): import("react").JSX.Element;
