/// <reference types="react" />
import type { FoilSurfaceHandle, FoilSurfaceProps } from './types.js';
/** Flexible, double-sided printed foil with a breakable perforated seam. */
export declare const FoilSurface: import("react").ForwardRefExoticComponent<FoilSurfaceProps & import("react").RefAttributes<FoilSurfaceHandle>>;
