export { StickyReveal } from './StickyReveal.js';
export type { StickyRevealProps } from './StickyReveal.js';
