import type { ResolvedGradientConfig } from './types.js';
export interface GradientRenderer {
    /** Draw one frame. `timeSeconds` drives motion; pass a fixed value to freeze. */
    render(config: ResolvedGradientConfig, timeSeconds: number): void;
    /** Resize the drawing buffer to CSS size × dpr. */
    resize(cssWidth: number, cssHeight: number, dpr: number): void;
    dispose(): void;
}
/**
 * Build a renderer bound to `canvas`, or `null` when WebGL is unavailable
 * (old browsers, jsdom, blocked contexts). Callers fall back to CSS.
 */
export declare function createGradientRenderer(canvas: HTMLCanvasElement): GradientRenderer | null;
/** CSS `linear-gradient` string used when WebGL is unavailable (also SSR paint). */
export declare function cssFallbackGradient(config: ResolvedGradientConfig): string;
