/// <reference types="react" />
import type { GeometricProps } from './types.js';
/**
 * A living contour field. Samples a photograph — or grows its own luminance —
 * then draws isolines, flow, print, and a vector graph from that same signal.
 * Pointer gravity bends both layers. Reduced motion and pause hold one frame.
 */
export declare function Geometric(props?: GeometricProps): JSX.Element;
