import type { FloatRuntimeProps } from './Float.js';
/** Fiber hooks are injected only after the optional peer has loaded. */
export declare function createFloatRuntime(fiber: any): ({ groupRef, config, paused }: FloatRuntimeProps) => null;
